﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.RVP
{
	public class MockRVPService : IRVPService
	{
		public Models.rvp GetRVP(string universalId)
		{
			var retval = new Models.rvp
			{
				first_name = "Adam",
				last_name = "RVP",
				address = new Models.address
				{
					city = "Miami",
					state = "Florida"
				},
				employeeId = "0000001",
			};
			return retval;
		}
	}
}
