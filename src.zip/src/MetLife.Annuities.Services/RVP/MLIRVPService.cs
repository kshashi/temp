﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Data;

namespace MetLife.Annuities.Services.RVP
{
	public class MLIRVPService : IRVPService
	{
		//TODO instantiate rvp class based on values from IBSE if possible.  
		public Models.rvp GetRVP(string universalId)
		{
            return new MetLife.Annuities.Services.Security.IBSEUserService().GetRVP(universalId);
		}
	}
}
