﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Security
{
    public enum CreateUserStatus
    {
        Success = 102,
        Failure = 103
    }
    public class CreateUserStatusDetails
    {
        public CreateUserStatus Status { get; set; }

        public string StatusCode { get; set; }

        public string StatusDesc { get; set; }
    }
}
