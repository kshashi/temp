﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace MetLife.Annuities.Services.Security
{

	//TODO add necessary properties for return from user creation
	public class AnnuitiesUser
	{
		public AnnuitiesUser()
		{
		}

		public string UserName { get; set; }


        public int UserID { get; set; }

        public string ExternalUserID { get; set; }
    }
}


