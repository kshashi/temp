﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Security
{
	public interface IUserService
	{
		//Start -- Offshore Comment
		//Prevoiusly AnnuitiesUser was the return type 
		// now it has been changed to RegistrationResponse as 
		// AnnuitiesUser has been asked not to be used
		//End -- Offshore Comment
		AnnuitiesUser CreateUser(string username, string password, string firstname, string lastname, out CreateUserStatusDetails statusDetails);

        List<SecurityQuestion> GetSecurityQuestions();
        List<SecurityQuestion> GetCustomerSecurityQuestions();

		//Get questions with answer for user
        List<SecurityQuestion> GetUserSecurityQuestions(string universalId, string metRefId);		

		//KeyValuePair is a response code and response description from the service
		//pass in the metrefid if we have it.  Otherwise, need to implement call to IBSE to get MetRefId from universalId
		KeyValuePair<string, string> SetSecurityQuestions(string universalId, string metRefId, List<SecurityQuestion> questions, bool isUpdate);

		bool CheckSecurityQuestionAnswer(string universalId, string metRefId, string questionNumber, string answer, out int attempts);

        bool ResetPassword(string universalId, string currentPassword, string newPassword, out string statusDesc);
        bool ResetPassword(string universalId, string newPassword, out string statusDesc);

		void UploadProfileImage(byte[] file, string fileName);

		System.Net.HttpWebResponse GetProfileImage(string fileName);
		System.Net.HttpWebResponse GetDocument(string fileName);

        bool ResetPassword(string universalId, Dictionary<string, string> questionAnswers, string newPassword, out string statusDesc);
	}

}
