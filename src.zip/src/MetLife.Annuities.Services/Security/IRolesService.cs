﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Security
{
    public interface IRolesService
    {

        void IBSEAddUsersToRoles(string[] universalId, string[] roleNames);

        string[] GetAllRoles();

        string[] GetRolesForUser(string universalId);

        string[] GetUsersInRole(string roleName);

        bool IsUserInRole(string universalId, string roleName);

        bool RoleExists(string roleName);

        //Start--Offshore Comment
        //If AddUsersToRoles returns nothing then why should RemoveUsersFromRoles return object.
        //Moreover what will be the content of the object because service returns mutlple success or failure for serveral universalId
        //Return type should be a List in that case.
        //End--Offshore Comment
        object IBSERemoveUsersToRoles(string[] universalId, string[] roleNames);

        //Start -- Offshore Comment
        //This method was not in the interface previously
        // Added by Offshore to implement Security Questions functionality
        // Verify and confirm the method signature
        //End -- Offshore Comment
        //ChalengeQuestions GetSecurityQuestions(UserSecurityQuestions data);
    }
}
