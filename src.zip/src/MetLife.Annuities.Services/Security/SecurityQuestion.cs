﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Security
{
	public class SecurityQuestion
	{
		public string QuestionNumber { get; set; }
		public string QuestionText { get; set; }
		public string QuestionAnswer { get; set; }
        public string QuestionAnswerConfirm { get; set; }
	}
}
