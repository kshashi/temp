﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Net.Http;
using MetLife.Annuities.Services.Models;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Net;
using System.Xml;
using System.IO;
using System.Configuration;
using MetLife.MLI.Services.Proxy.IBSE;
using MetLife.Annuities.Data;


namespace MetLife.Annuities.Services.Security
{
	public class IBSERolesService : IRolesService
	{
		public string[] GetAllRoles()
		{
			try
			{
				List<string> retval = new List<string>();
				var roles = ConfigurationManager.AppSettings["RoleMap"].Split(',');
				foreach (var r in roles)
				{
					var r2 = r.Split(';');
					if (r2.Length > 1)
					{
						retval.Add(r2[1]);
					}
				}
				return retval.ToArray();
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
			}
		}

		public List<KeyValuePair<string, string>> GetRoleMap()
		{
			List<KeyValuePair<string, string>> retval = new List<KeyValuePair<string, string>>();
			var roles = ConfigurationManager.AppSettings["RoleMap"].Split(',');
			foreach (var r in roles)
			{
				var r2 = r.Split(';');
				if (r2.Length > 1)
				{
					retval.Add(new KeyValuePair<string, string>(r2[0], r2[1]));
				}
			}
			return retval;
		}

		public string[] GetRolesForUser(string universalId)
		{
			string[] ibseRoles;
			return this.GetRolesForUser(universalId, out ibseRoles);
		}

		private string[] GetRolesForUser(string universalId, out string[] ibseRoles)
		{
			try
			{

				//GetRolesFromIBSE
				ibseRoles = this.GetRolesFromIBSE(universalId);
                var advisorRole = this.GetRoleMap().Where(r => r.Value.ToLower() == "advisor").First().Value;

                //First check if user is an Admin
                var adminRole = this.GetRoleMap().Where(r => r.Value.ToLower() == "admin").First().Value;
                if (ibseRoles.Contains(adminRole))
                    return new string[] {adminRole};

				//Next, check if user is an RVP
                if (this.IsUserRVP(universalId))
                {
                    if (ConfigurationManager.AppSettings["PilotPhase"] == "1")
                    {
                        if (ibseRoles.Contains(advisorRole))
                            return new string[] { this.GetRoleMap().Where(r => r.Value.ToLower() == "rvp").First().Value };
                    }
                    else
                        return new string[] { this.GetRoleMap().Where(r => r.Value.ToLower() == "rvp").First().Value };
                }
				
				//Check if user is a client
				var clientRole = this.GetRoleMap().Where(r => r.Value.ToLower() == "client").First().Value;
				if (ibseRoles.Contains(clientRole))
					return new string[] { clientRole };
				
				//Check if user is an advisor				
				var adv = new MetLife.Annuities.Services.Advisors.AdvisorService();
				var a = adv.GetAdvisor(universalId, string.Empty);
				if (a != null && a.firm != null && (a.firm.entitled || adv.IsTestID(universalId)))
				{
					if (ConfigurationManager.AppSettings["PilotPhase"] == "1")
					{
						if (ibseRoles.Contains(advisorRole))
							return new string[] { advisorRole };
					}
					else
						return new string[] { advisorRole };
				}				

				//No access
				return new string[] { };

			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private string[] GetRolesFromIBSE(string universalId)
		{
			Request req = new Request();
			req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
			req.Data = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.UserProfileData("123", universalId, "", "", ConfigurationManager.AppSettings["ESSSMHService.ApplicationID"]);
			ProcessRequest reqBody = new ProcessRequest(req);
			MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy();
			ibseProxy.Process(reqBody);

			XDocument doc;
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
			nsmgr.AddNamespace("m", "urn:ESSSMHService");

			using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
			{
				nodeReader.MoveToContent();
				doc = XDocument.Load(nodeReader);
			}

			var d = (from r in doc.Descendants("R") select r).FirstOrDefault().Value;
			var roles = d.Split(new char[] { '^' }, StringSplitOptions.RemoveEmptyEntries);
			var usrRoles = (from i in this.GetRoleMap()
											join r in roles on i.Key equals r
											select i.Value).ToList();
			return usrRoles.ToArray();
		}

		private bool IsUserRVP(string userId)
		{
			using (MIGDataContext mig = new MIGDataContext())
			{
				var rvp = mig.am_get_rvp(userId).ToList();
				if (rvp != null && rvp.Count > 0)
					return true;
				else
					return false;
			}
		}

		public string[] GetUsersInRole(string roleName)
		{
			 // To use for Home Office
            Request req = new Request();
            req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
						//req.Data = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.UserProfileData("123", universalId, "", "", ConfigurationManager.AppSettings["ESSSMHService.SourceID"]);
            ProcessRequest reqBody = new ProcessRequest(req);
            MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy();
            ibseProxy.Process(reqBody);

            XDocument doc;
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
            nsmgr.AddNamespace("m", "urn:ESSSMHService");

            using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
            {
                nodeReader.MoveToContent();
                doc = XDocument.Load(nodeReader);
            }

            var d = (from r in doc.Descendants("R") select r).FirstOrDefault().Value;
            var roles = d.Split(new char[] { '^' }, StringSplitOptions.RemoveEmptyEntries);
            var usrRoles = (from i in this.GetRoleMap()
                            join r in roles on i.Key equals r
                            select i.Value).ToList();
            return usrRoles.ToArray();
		}

		public bool IsUserInRole(string username, string roleName)
		{
			string [] ibseRoles;
			var retval = this.GetRolesForUser(username, out ibseRoles).Contains(roleName);
			if (!retval)
				retval = ibseRoles.Contains(roleName);
			return GetRolesForUser(username).Contains(roleName);
		}

		public bool RoleExists(string roleName)
		{
			return GetAllRoles().Contains(roleName);
		}

		public void IBSEAddUsersToRoles(string[] universalId, string[] roleNames)
		{
			this.IBSEUpdateUserRoles(universalId, roleNames, true);
		}

		public object IBSERemoveUsersToRoles(string[] universalId, string[] roleNames)
		{
			this.IBSEUpdateUserRoles(universalId, roleNames, false);
			return null;
		}

		private void IBSEUpdateUserRoles(string[] universalId, string[] roleNames, bool addRoles)
		{
			try
			{
				var usrRoles = (from i in this.GetRoleMap()
												join r in roleNames on i.Key equals r
												select i.Key).ToList();
				string roles = "";
				foreach (var r in usrRoles)
				{
					roles += "," + r;
				}
				if (roles.Length > 0)
					roles = roles.Substring(1);

				foreach (string user in universalId)
				{
					Request req = new Request();
					req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
					var d = new MetLife.MLI.Services.Proxy.IBSE.UserEntitlement.UserEntitlementData();
					d.Action = "UPD_USER_ROLES";
					d.ESELoginID = user;
					d.MetRfrId = "";
					d.AppID = ConfigurationManager.AppSettings["ESSSMHService.SourceID"];
					d.PrflEseLoginId = user;
					d.ProcInd = "E";
					d.AppShortNm = "AnnuityMet";
					if (addRoles)
						d.AddRoles = roles;
					else
						d.RemoveRoles = roles;

					req.Data = d;
					ProcessRequest reqBody = new ProcessRequest(req);
					MetLife.MLI.Services.Proxy.IBSE.UserEntitlement.IBSEUserEntitlementProxy ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.UserEntitlement.IBSEUserEntitlementProxy(ConfigurationManager.AppSettings["ESSSMHServicePort.ServiceEndpointURL"] + "?APPID=" + ConfigurationManager.AppSettings["ESSSMHService.SourceID"] + "&URN=ESSUserEntitlementService");
					ibseProxy.Process(reqBody);
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}		

		//public ChalengeQuestions GetSecurityQuestions(UserSecurityQuestions data)
		//{
		//  //MetLife.Annuities.Services.Security.SecurityQuestions request = null;
		//  //IBSECredentials cred = null;
		//  //HttpClient client = null;
		//  //HttpRequestMessage invokeRequest = null;
		//  //HttpResponseMessage response = null;
		//  //try
		//  //{
		//  //  request = new MetLife.Annuities.Services.Security.SecurityQuestions();
		//  //  cred = new IBSECredentials();
		//  //  request.Credentials = cred;
		//  //  request.Data = data;
		//  //  string xml = Common.SerializeObjectToXML(request);
		//  //  XmlDocument XMLINPUT = new XmlDocument();
		//  //  XMLINPUT.LoadXml(xml);
		//  //  client = new HttpClient();
		//  //  Uri uri = new Uri(string.Format("http://int.emsservices.metlife.com/EMSServices/ESSSecAdminWS?APPID={0}&ESELOGINID={1}&XMLINPUT={2}", System.Configuration.ConfigurationManager.AppSettings["ESSSMHService.SourceID"], "", XMLINPUT.InnerXml));
		//  //  invokeRequest = new HttpRequestMessage(HttpMethod.Post, uri) { };
		//  //  response = new HttpClient().SendAsync(invokeRequest).Result;
		//  //  var resp = response.Content.ReadAsStringAsync().Result;
		//  //  ChalengeQuestions r = (ChalengeQuestions)Common.DeserializeXMLToObject(new ChalengeQuestions(), response, "security");
		//  //  if (!r.Equals(null))
		//  //    if (r.Status.Code.Equals("0"))
		//  //    {
		//  //      return r;
		//  //    }
		//  //    else
		//  //    {
		//  //      return null;
		//  //    }
		//  //  else
		//  //    return null;
		//  //}
		//  //catch (Exception ex)
		//  //{
		//  //  throw ex;
		//  //}
		//  //finally
		//  //{
		//  //  client.Dispose();
		//  //  invokeRequest.Dispose();
		//  //  response.Dispose();
		//  //}
		//  throw new NotImplementedException();
		//}

	}
}


