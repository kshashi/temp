﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.MLI.Services.Proxy.IBSE;
using System.Configuration;
using System.Xml.Linq;
using System.Xml;
using System.IO;

namespace MetLife.Annuities.Services.Security
{
	public class IBSEUserService : IUserService
	{
		public void UploadProfileImage(byte[] file, string fileName)
		{
			var dh = new MetLife.MLI.Services.Proxy.SharePoint.DocLibHelper();
			Exception error = null;
			if (!dh.Upload(Path.Combine(MetLife.MLI.Services.Proxy.Configuration.SharePointSettings.GetSettings().URL, ConfigurationManager.AppSettings["ProfileImageFolder"], fileName), file, null, out error))
				throw error;

		}

		public System.Net.HttpWebResponse GetProfileImage(string fileName)
		{
			try
			{
				return MetLife.MLI.Services.Proxy.SharePoint.Lists.GetListAttachment(Path.Combine(ConfigurationManager.AppSettings["SharePointBaseFolder"], fileName));
			}
			catch (Exception ex)
			{
				var msg = ex.ToString();
			}
			return MetLife.MLI.Services.Proxy.SharePoint.Lists.GetListAttachment(ConfigurationManager.AppSettings["ProfileImageFolder"] + ConfigurationManager.AppSettings["DefaultProfileImage"]);
		}

		public System.Net.HttpWebResponse GetDocument(string fileName)
		{
			return MetLife.MLI.Services.Proxy.SharePoint.Lists.GetListAttachment(Path.Combine(ConfigurationManager.AppSettings["SharePointDocumentsBaseFolder"], fileName));
		}

		public AnnuitiesUser CreateUser(string username, string password, string firstname, string lastname, out CreateUserStatusDetails statusDetails)
		{
            statusDetails = new CreateUserStatusDetails();
            //check password for hyphen or period b/c ibse doesn't allow those and returns an ambiguous error message
            if (password.Contains('.') || password.Contains('-'))
            {
                statusDetails.Status = CreateUserStatus.Failure;
                statusDetails.StatusCode = "-1";
                statusDetails.StatusDesc = "Please do not use periods(.) or hyphens(-) in your password.";
                return null;
            }

			Request req = new Request();			
			req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
			var d = new MetLife.MLI.Services.Proxy.IBSE.Registration.RegistrationData();

			d.Action = "CUS_REGISTRATION";
			d.AppShortNm = ConfigurationManager.AppSettings["ESSSMHService.SourceID"];
			d.SrcId = ConfigurationManager.AppSettings["ESSSMHService.SourceID"];
			d.ESELoginID = username;
			d.FstNm = firstname;
			d.LstNm = lastname;
			d.UsrCd = "T";
			d.UsrPrflTypCd = "C";
			d.PswrdTxt = password;
			d.Password = password;
			d.PrflEseLoginId = ConfigurationManager.AppSettings["ESSSMHService.UserID"];
			d.ActTypCd = "I";
			req.Data = d;

			ProcessRequest registrationRequestBody = new ProcessRequest(req);

			var ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.Registration.IBSERegisterProxy();
			ibseProxy.Url = ConfigurationManager.AppSettings["IBSERegisterProxy.ServiceEndpointURL"];
			ibseProxy.Process(registrationRequestBody);
			XDocument doc;
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
			nsmgr.AddNamespace("m", "urn:ESSRegService");

			using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
			{
				nodeReader.MoveToContent();
				doc = XDocument.Load(nodeReader);
			}

			var response = (from n in doc.Descendants("RETURN_STATUS") select n).First();

			statusDetails.StatusCode = response.Element("STATUS_CODE").Value;
			statusDetails.StatusDesc = response.Element("STATUS_TEXT").Value;

			if (statusDetails.StatusCode == "0")
			{
				statusDetails.Status = CreateUserStatus.Success;
				var usr = new AnnuitiesUser() { ExternalUserID = doc.Descendants("DATA").First().Element("USR_ID").Value, UserName = username };
				var roleService = new IBSERolesService();
				roleService.IBSEAddUsersToRoles(new string[] { username }, new string[] { roleService.GetRoleMap().Where(i => i.Value == "Client").First().Key });
				return usr;
			}

			return null;        
		}

       
        public bool ResetPassword(string universalId, string password, out string statusDesc)
        {
            
            //check password for hyphen or period b/c ibse doesn't allow those and returns an ambiguous error message
            if (password.Contains('.') || password.Contains('-'))
            {
                statusDesc = "Please do not use periods(.) or hyphens(-) in your password.";
                return false;
            }


            Request req = new Request();
            req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
            var d = new MetLife.MLI.Services.Proxy.IBSE.Registration.RegistrationData();

            d.Action = "CUS_REGISTRATION";
            d.AppShortNm = ConfigurationManager.AppSettings["ESSSMHService.SourceID"];
            d.SrcId = ConfigurationManager.AppSettings["ESSSMHService.SourceID"];
            d.ESELoginID = universalId;
            d.UsrPrflTypCd = "C";
            d.PswrdTxt = password;
            d.Password = password;
            d.PrflEseLoginId = ConfigurationManager.AppSettings["ESSSMHService.UserID"];
            d.ActTypCd = "U";
            req.Data = d;
            ProcessRequest registrationRequestBody = new ProcessRequest(req);

            var ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.Registration.IBSERegisterProxy();
            ibseProxy.Url = ConfigurationManager.AppSettings["IBSERegisterProxy.ServiceEndpointURL"];
            ibseProxy.Process(registrationRequestBody);
            XDocument doc;
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
            nsmgr.AddNamespace("m", "urn:ESSRegService");

            using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
            {
                nodeReader.MoveToContent();
                doc = XDocument.Load(nodeReader);
            }

            var response = (from n in doc.Descendants("RETURN_STATUS") select n).First();
            statusDesc = response.Element("STATUS_TEXT").Value;
            if (response.Element("STATUS_CODE").Value == "0")
                return true;
            else
                return false;

        }

		public bool ResetPassword(string universalId, string currentPassword,  string newPassword, out string statusDesc)
		{

            //check password for hyphen or period b/c ibse doesn't allow those and returns an ambiguous error message
            if (newPassword.Contains('.') || newPassword.Contains('-'))
            {
                statusDesc = "Please do not use periods(.) or hyphens(-) in your password.";
                return false;
            }

            Request req = new Request();
            req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
            var data = new MetLife.MLI.Services.Proxy.IBSE.Authentication.AuthenticationData("AUTH_USER", universalId, ConfigurationManager.AppSettings["ESSSMHService.SourceID"]);
            data.PswrdTxt = currentPassword;
            data.NewPswrdTxt = newPassword;

            req.Data = data;

            ProcessRequest authRequestBody = new ProcessRequest(req);

            var ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.Authentication.IBSEAuthenticationProxy();
			ibseProxy.Url = ConfigurationManager.AppSettings["IBSERegisterProxy.ServiceEndpointURL"];
			ibseProxy.Process(authRequestBody);
			XDocument doc;
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
			nsmgr.AddNamespace("m", "urn:ESSAuthService");

			using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
			{
				nodeReader.MoveToContent();
				doc = XDocument.Load(nodeReader);
			}

			var response = (from n in doc.Descendants("Status") select n).First();
			statusDesc = response.Element("Text").Value;
			if (response.Element("Code").Value == "0")
				return true;
			else
				return false;

		}

        public bool CheckSecurityQuestionAnswer(string universalId, string metRefId, string questionNumber, string answer, out int attempts)
        {
            if (string.IsNullOrWhiteSpace(metRefId))
                metRefId = this.GetMetRefId(universalId);
            Request serviceRequest = new Request();
            serviceRequest.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
            var data = new MetLife.MLI.Services.Proxy.IBSE.SecurityAdmin.ChallengeQuestionData("CHK_CHLNG_QA", "", metRefId, "", ConfigurationManager.AppSettings["ESSSMHService.SourceID"], "C", "1", "");

            data.CQ1 = questionNumber;
            data.CA1 = answer;

            serviceRequest.Data = data;

            ProcessRequest registrationRequestBody = new ProcessRequest(serviceRequest);

            var ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.SecurityAdmin.IBSESecurityAdminProxy();
            ibseProxy.Process(registrationRequestBody);
            XDocument doc;
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
            nsmgr.AddNamespace("m", "urn:ESSSecAdminService");

            using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
            {
                nodeReader.MoveToContent();
                doc = XDocument.Load(nodeReader);
            }

            var d = doc.Descendants("RETURN_STATUS").First();

            var code = d.Element("STATUS_CODE").Value;
            var desc = d.Element("STATUS_TEXT").Value;

            if (desc.Contains("ChlngAnsFailCnt:"))
                attempts = int.Parse(desc.Split(':')[1]);
            else
                attempts = 0;

            return (code == "0");
        }


		public List<SecurityQuestion> GetUserSecurityQuestions(string universalId, string metRefId)
		{
			if (string.IsNullOrWhiteSpace(metRefId))
				metRefId = this.GetMetRefId(universalId);

            if (string.IsNullOrWhiteSpace(metRefId))
                return null;            

			return this.GetSecurityQuestions("C", metRefId);
		}

        public List<SecurityQuestion> GetSecurityQuestions()
		{            
            return this.GetSecurityQuestions("C", null);
		}

        public List<SecurityQuestion> GetCustomerSecurityQuestions()
		{            
            return this.GetSecurityQuestions("C", null);
		}

		private List<SecurityQuestion> GetSecurityQuestions(string userType, string metRefId)
		{
			if (string.IsNullOrWhiteSpace(metRefId))
				metRefId = "";
			Request registrationRequest = new Request();
			registrationRequest.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
			registrationRequest.Data = new MetLife.MLI.Services.Proxy.IBSE.SecurityAdmin.ChallengeQuestionListData((string.IsNullOrWhiteSpace(metRefId) ? "GET_CHLNG_QUES" : "GET_CHLNG_ANS"), "", metRefId, "", ConfigurationManager.AppSettings["ESSSMHService.SourceID"], userType, "");
            
			ProcessRequest registrationRequestBody = new ProcessRequest(registrationRequest);

			var ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.SecurityAdmin.IBSESecurityAdminProxy();
			ibseProxy.Process(registrationRequestBody);
			XDocument doc;
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
			nsmgr.AddNamespace("m", "urn:ESSSecAdminService");

			using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
			{
				nodeReader.MoveToContent();
				doc = XDocument.Load(nodeReader);
			}

			var d = (from r in doc.Descendants((string.IsNullOrWhiteSpace(metRefId) ? "ChlngQues" : "ChlngAns"))
							 select new SecurityQuestion
							 {
								 QuestionNumber = r.Element("ChlngQuesNum").Value,
								 QuestionText = r.Element("ChlngQuesTxt").Value,
                                 QuestionAnswer = r.Element("UsrChlngAnsTxt") == null ||  string.IsNullOrWhiteSpace(r.Element("UsrChlngAnsTxt").Value) ? "" : r.Element("UsrChlngAnsTxt").Value,
                                 QuestionAnswerConfirm = r.Element("UsrChlngAnsTxt") == null || string.IsNullOrWhiteSpace(r.Element("UsrChlngAnsTxt").Value) ? "" : r.Element("UsrChlngAnsTxt").Value
							 }).ToList();
            //var fc = (doc.Descendants("ChlngAnsFailCnt").FirstOrDefault());
            //if (fc != null) {
            //    int cnt = 0;
            //    int.TryParse(fc.Value, out cnt);
            //    failCount = cnt;
            //}
            //else
            //    failCount = 0;
			return d;
		}

		public KeyValuePair<string, string> SetSecurityQuestions(string universalId, string metRefId, List<SecurityQuestion> questions, bool isUpdate)
		{
			if (string.IsNullOrWhiteSpace(metRefId))
				metRefId = this.GetMetRefId(universalId);
			Request challengeRequest = new Request();
            var data = new MetLife.MLI.Services.Proxy.IBSE.SecurityAdmin.ChallengeQuestionData("UPD_CHLNG_ANS", "", metRefId, "", ConfigurationManager.AppSettings["ESSSMHService.SourceID"], "C", questions.Count.ToString(), (isUpdate ? "U" : "I"));
            data.Count = "3";
			int i = 1;
			foreach (var q in questions)
			{
				switch (i)
				{
					case 1:
						data.CA1 = q.QuestionAnswer;
						data.CQ1 = q.QuestionNumber;
						break;
					case 2:
						data.CA2 = q.QuestionAnswer;
						data.CQ2 = q.QuestionNumber;
						break;
					case 3:
						data.CA3 = q.QuestionAnswer;
						data.CQ3 = q.QuestionNumber;
						break;
                    //case 4:
                    //    data.CA4 = q.QuestionAnswer;
                    //    data.CQ4 = q.QuestionNumber;
                    //    break;
                    //case 5:
                    //    data.CA5 = q.QuestionAnswer;
                    //    data.CQ5 = q.QuestionNumber;
                    //    break;
					default:
						break;
				}
				i++;
			}

			challengeRequest.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
			challengeRequest.Data = data;

			ProcessRequest challengeRequestBody = new ProcessRequest(challengeRequest);

			var ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.SecurityAdmin.IBSESecurityAdminProxy();
			var d = new KeyValuePair<string, string>();
			XDocument doc;
			try
			{
				ibseProxy.Process(challengeRequestBody);
				XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
				nsmgr.AddNamespace("m", "urn:ESSSecAdminService");

				using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
				{
					nodeReader.MoveToContent();
					doc = XDocument.Load(nodeReader);
				}

				d = (from r in doc.Descendants("Status") select new KeyValuePair<string, string>(r.Element("Code").Value, r.Element("Text").Value)).Single();

			}
			catch (Exception e)
			{
				string msg = "";
				try
				{
					XmlDocument x = new XmlDocument();
					msg = e.Message.Substring(e.Message.IndexOf("SOAP Response") + 13);
					doc = XDocument.Parse(msg);
					d = (from r in doc.Descendants(XName.Get("Fault", "http://schemas.xmlsoap.org/soap/envelope/")) select new KeyValuePair<string, string>(r.Element("faultcode").Value, r.Element("faultstring").Value)).Single();
				}
				catch (Exception)
				{
					d = new KeyValuePair<string, string>("-1", msg);
				}
			}

			return d;
		}

	
		private string GetMetRefId(string universalId)
		{
			Request req = new Request();
			req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
			var data = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.UserProfileData("1", universalId, "", "", ConfigurationManager.AppSettings["ESSSMHService.ApplicationID"]);
			data.PrflTypCd = "C";
			req.Data = data;
			ProcessRequest reqBody = new ProcessRequest(req);
			MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy();
			ibseProxy.Process(reqBody);

			XDocument doc;
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
			nsmgr.AddNamespace("m", "urn:ESSSMHService");

			using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
			{
				nodeReader.MoveToContent();
				doc = XDocument.Load(nodeReader);
			}

			var d = (from r in doc.Descendants("U") select r).First().Descendants("MID").First().Value;

			return d;

		}

        public Models.rvp GetRVP(string universalId)
        {
            Request req = new Request();
            req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
            req.Data = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.UserProfileData("123", universalId, "", "", ConfigurationManager.AppSettings["ESSSMHService.ApplicationID"]);
            ProcessRequest reqBody = new ProcessRequest(req);
            MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy();
            ibseProxy.Process(reqBody);

            XDocument doc;
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
            nsmgr.AddNamespace("m", "urn:ESSSMHService");

            using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
            {
                nodeReader.MoveToContent();
                doc = XDocument.Load(nodeReader);
            }

            var u = doc.Descendants("U").FirstOrDefault();
            var r = new Models.rvp();            
            r.first_name = u.Descendants("FN").FirstOrDefault().Value;
            r.last_name = u.Descendants("LN").FirstOrDefault().Value;
            r.email = u.Descendants("EM").FirstOrDefault().Value;

            return r;
        }



		public bool ResetPassword(string universalId, Dictionary<string, string> questionAnswers, string newPassword, out string statusDesc)
		{
			int attempts = 0;
			bool correctAnswer = true;
			foreach (var item in questionAnswers)
			{
				if (!CheckSecurityQuestionAnswer(universalId, null, item.Key, item.Value, out attempts))
					correctAnswer = false;
			}
			if (correctAnswer)
				return ResetPassword(universalId, newPassword, out statusDesc);
			else
				statusDesc = "Answers are not correct";

			return correctAnswer;
		}
	}
}
