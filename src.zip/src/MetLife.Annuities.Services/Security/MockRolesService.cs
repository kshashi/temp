﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Security
{
    public class MockRolesService 
    {
        public void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public string[] GetAllRoles()
        {
            return new[] { "Advisor", "RVP", "Client" };
        }

        public string[] GetRolesForUser(string username)
        {
            return new[] { username };
        }

        public string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public bool IsUserInRole(string username, string roleName)
        {
            return username.Equals(roleName);
        }

        public bool RoleExists(string roleName)
        {
            return GetAllRoles().Contains(roleName);
        }

        public object RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }
    }
}
