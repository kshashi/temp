﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Pages
{
	public class MockPageService : IPageService
	{
        public Models.client_footer GetClientFooter()
        {
            throw new NotImplementedException();
        }
    }
}
