﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Pages
{
	public interface IPageService
	{
        client_footer GetClientFooter();
	}
}
