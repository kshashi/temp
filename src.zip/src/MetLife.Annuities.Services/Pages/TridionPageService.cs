﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;

namespace MetLife.Annuities.Services.Pages
{
    public class TridianPageService : IPageService
    {
        public client_footer GetClientFooter()
        {
            TridionContainer tridion = new TridionContainer(TridionConfiguration.TridionWebServiceUrl,
                 TridionConfiguration.TridionPublicationId);
            var component = tridion.GetComponent<client_footer>();
            return component.Item;
        }
    }
}
