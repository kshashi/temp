﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Net;
using System.Collections;

namespace MetLife.Annuities.Services
{
    public class TridionContainer 
    {
        private string _url;
        private int _pubId;
        public TridionComponent<T> GetComponent<T>()
        {
            // figure out the component we're getting 
            // from the generic type we are returning
            string componentName = typeof(T).ToString();
            componentName = componentName.Substring(componentName.LastIndexOf(".") + 1);

            // get last update date
            var lastModifed = GetLastModifiedDate(componentName);

            // try to get the component from cache
            TridionComponent<T> component = CacheLayer.Get<TridionComponent<T>>(componentName);

            if (component == null || lastModifed != component.LastUpdated) //Important: Tridion does not include AM/PM although it uses the AM/PM clock so can't look for lastModified greater; need to do not equal to
            {
                // get the url for the component
                var url = GenerateUrlForComponent(componentName);

                // load the remote component
                XDocument xmlDoc = XDocument.Load(url);

                // grab the last update time
                var currentLastMode = DateTime.Parse(xmlDoc.Element("items").Attribute("last_modified").Value);

                // grab the component element
                XmlSerializer s = new XmlSerializer(typeof(T));
                var obj = (T)s.Deserialize(xmlDoc.Element("items").FirstNode.CreateReader());

                // combine them
                component = new TridionComponent<T>();
                component.LastUpdated = lastModifed;
                component.Item = obj;

                CacheLayer.AddLong(component, componentName);
            }
            return component;
        }

        private string GenerateUrlForComponent(string componentName)
        {
            return _url + "/GetItems?keyname=wsquerycriteria&keyvalue=" + componentName + "&pubid=" + _pubId + "&xpathExpression=";
        }           

        private DateTime GetLastModifiedDate(string componentName)
        {
            var url = GenerateUrlForComponent(componentName) + "timestamp";
            using (WebClient client = new WebClient())
            {
                string resp = client.DownloadString(url);
                return DateTime.Parse(resp);
            }
        }

        public TridionContainer(string url, int publicationId)
        {
            _pubId = publicationId;
            _url = url;
        }

        public TridionContainer()
        {
            _pubId = TridionConfiguration.TridionPublicationId;
            _url = TridionConfiguration.TridionWebServiceUrl;
        }
    }

}




