﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class UserProfile
    {
        public int UserProfileID { get; set; }

        public string ProfileImageUrl { get; set; }

        public string ExternalID { get; set; }

        public int InternalID { get; set; }
    }
}
