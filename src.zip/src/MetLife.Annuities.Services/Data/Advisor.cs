﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class Advisor
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public UserProfile UserProfile { get; set; }
        public int AdvisorID { get; set; }
        public string SystemID { get; set; }
        public string UniversalID { get; set; }
    }
}
