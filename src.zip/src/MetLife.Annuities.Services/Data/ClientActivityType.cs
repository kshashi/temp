﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public enum ClientActivityType
    {
        Flags = 1,
        AccountUpdate = 2,
        ProgressChange = 3
    }
}
