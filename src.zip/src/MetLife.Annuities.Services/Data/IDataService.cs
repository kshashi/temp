﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Security;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Services.Data
{
    public interface IDataService
    {
        PagedList<Activity> GetClientActivity(int advisorId, int? clientId, int page, int pageSize, string sort, string filter);

        Client SaveClient(Client client, int advisorId);

        Flag GetLastFlagForClient(int client_id);

        int SaveFlag(int hypotheticalId, int illustrationId, Dictionary<string, string> meta, Flag flag, string action);
        SavedProductItem GetAnnuity(Guid guid);
        Dictionary<int, string> GetStates();

        Dictionary<byte, string> GetMaritalStatuses();

        Dictionary<int, string> GetPhoneNumberTypes();

        Client GetClient(int clientId);

        void SaveClientFinance(ClientFinance finance);

        void SaveClientPersona(ClientPersona persona);

        ClientFinance GetClientFinance(int clientId);

        Dictionary<char, string> GetGenders();

        Client[] GetClientsForAdvisor(int advisorId);

        Dictionary<int, string> GetNeedTimespans();


        PagedList<Client> GetClientsForAdvisor(int advisorId, int page, int pageSize, string filter, string sort);

        UserProfile GetUserProfile(int userId);

        void SaveUserProfile(UserProfile profile);

        PagedList<Client> GetRecentClientsForAdvisor(int p);

        void WriteClientHistory(HistoryType type, int clientId, Dictionary<string, string> replacements);

        PagedList<ClientHistory> GetClientHistory(int clientId);

        void ToggleHypotheticalView(string state, string clientId, advisor advisor);

        UserProfile GetUserProfileByExternalId(string userId);

        UserProfile CreateIBANNMETUser(string currentRole, string userId, string systemId);

        Advisor GetAdvisor(string universalId);

        Advisor GetAdvisor(int advisor_id);

        Advisor GetAdvisorBySystemId(string systemId);
        void SaveAdvisor(Advisor advisor);
        void UpdateClientProgress(int client_id, ClientProgressType clientProgressType, advisor advisor);

        Client GetClient(string universalId);


        int SaveShieldProduct(ShieldProduct product, Client client);

        SavedProductItem[] GetSavedAnnuities(int client_id);

        SavedProductItem GetAnnuity(int annuity_id);

        ClientProgress[] GetClientProgressStates();

        ShieldProduct GetShieldProduct(int id);

        void DeleteHypothetical(int id);

        Guid CreateSeriesVAShell(Client client);

        void StartApplication(int hypotheticalId);

        SavedProductItem GetApplicationAnnuity(int client_id);

        FlagsChartModel GetFlagsForHypothetical(int id);

        void DeleteFlag(int p);

        void UpdateSummaryItem(SavedProductItem summary);

        void SaveApplicationConsent(Client client, SavedProductItem annuity, Hypothetical hypothetical, string productCode, bool epcConsent, bool prospectusSent, advisor advisor);

        Benefit[] GetBenefits();

        void MarkApplicationPurchased(int p);

        bool IsDNSSEmail(string email);

        bool IsDNSSEmail(List<string> emails, ref string[] dnssEmails);

        void LogAdvisorLogon(string systemId, string notes);
        
	        List<Doc> SearchDoc(string state, string channel, string product, string active);

            Dictionary<string, string> GetProducts();
            Dictionary<string, string> GetChannels();
            Doc GetTDocDetails(string doc_cd, string doc_prd, string dstr_cd);
            bool UpdateDocDetails(string doc_cd, string doc_prd, string dstr_typ, Doc docs, out string errorMessage);
            Dictionary<string, string> GetDocCombined();
            Dictionary<string, string> GetActiveDocCombined();
            Doc GetStateDocDetails(string doc_cd, string doc_prd, string dstr_typ, int st);
            bool UpdateStateDocDetails(string doc_cd, string doc_prd, string dstr_typ, int st, Doc docs, out string errorMessage);
            bool AddDocDetails(Doc docs, out string errorMessage);
            bool AddStateDocDetails(Doc docs, out string errorMessage);
            bool CheckForStateReferenceActiveDocument(string doc_cd, string doc_prd, string dstr_typ, out string errorMessage);
            bool CheckForActiveDocument(string doc_cd, string doc_prd, string dstr_typ, out string errorMessage);
        List<Doc> SearchStateDocMapping(string docCode);

    }
}
