﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Data
{
    public class ClientPersona
    {
        public int ClientID { get; set; }

        public int? PersonaID { get; set; }

        public string PersonaName { get; set; }
        public string Goals { get; set; }
        public string Quote { get; set; }
        public string ThumbnailUri { get; set; }
        public string[] Videos { get; set; }

        public video[] VideosItems { get; set; }

        public video OutroVideo { get; set; }

        public video IntroVideo { get; set; }

        public string BrightcovePlaylistID { get; set; }
    }
}
