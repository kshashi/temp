﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class ClientHistory
    {
        public DateTime ActivityDate { get; set; }

        public string Description { get; set; }

        public object CTALink { get; set; }

        public object CTAText { get; set; }

        public object Status { get; set; }
        public long Timestamp { get; set; }
    }
}
