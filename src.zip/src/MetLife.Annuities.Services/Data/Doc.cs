﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class Doc
    {
        public string DOC_CD { get; set; }
        public string DOC_NM { get; set; }
        public string DOC_DSCR { get; set; }
        public string DOC_PATH_VAL { get; set; }
        public string CRT_USR_ID { get; set; }
        public DateTime CRT_TS { get; set; }
        public string LST_UPDT_BY_USR_ID { get; set; }
        public DateTime LST_UPDT_TS { get; set; }
        public string DSTR_CD { get; set; }
        public bool? DOC_RQR_IND { get; set; }
        public string DOC_TYP_DSCR { get; set; }
        public string DOC_PRD { get; set; }
        public bool? Active { get; set; }
        public string Message { get; set; }
        public int StateID { get; set; }
        public string State { get; set; }
        public string DOC_Combined { get; set; }
    }
}
