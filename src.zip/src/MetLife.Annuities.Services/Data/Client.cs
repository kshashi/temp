﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class Client
    {
        public int ClientID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }
        public Guid UniqueId { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int UserId { get; set; }
        public DateTime? LastActivityDate { get; set; }
        public bool HasAlerts { get; set; }
        public int Age
        {
            get
            {
                DateTime now = DateTime.Now;
                int age = now.Year - DateOfBirth.Year;
                if (now < DateOfBirth.AddYears(age)) age--;
                return age;
            }
        }
        public byte MaritalStatusID { get; set; }

        public char Gender { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string City { get; set; }

        public int StateID { get; set; }

        public string Zip { get; set; }

        public PhoneNumber[] PhoneNumbers { get; set; }

        public string EmailAddress { get; set; }

        public int? TestimonialPersonaID { get; set; }

        public int AdvisorID { get; set; }

        public string StatusText { get; set; }

        public string[] Goals { get; set; }

        public GenderType GenderType
        {

            get
            {
                return Gender.Equals(char.Parse("M")) ? GenderType.Male : Services.GenderType.Female;

            }
        }
        public string StateCode { get; set; }

        public Client()
        {
            PhoneNumbers = new PhoneNumber[] { };
            EmailAddress = "";
            ClientGuests = new ClientGuest[] { };
        }

        public int[] SelectedPersonaVideos { get; set; }

        public string[] History { get; set; }

        public string CurrentStatus { get; set; }

        public int CurrentStatusId { get; set; }

        public ClientProgressType ClientProgress
        {
            get
            {
                return (ClientProgressType)CurrentStatusId;
            }
        }

        public ClientGuest[] ClientGuests { get; set; }

        public string FullName { get { return FirstName + " " + LastName; } }

        public bool HypotheticalViewEnabled { get; set; }

        public string UniversalID { get; set; }

        public Annuities.AnnuityProductType PreferredAnnuityProductType { get; set; }

        public string GetPronoun(PronounType type)
        {
            switch (type)
            {
                case PronounType.HisHer:
                    return GenderType == Services.GenderType.Male ? "His" : "Her";
                case PronounType.HeShe:
                    return GenderType == Services.GenderType.Male ? "He" : "She";
                case PronounType.HimHer:
                    return GenderType == Services.GenderType.Male ? "Him" : "Her";
                default:
                    break;
            }

            return "";
        }

        public object MaritalStatusText { get; set; }

        public bool StartedApplicationProcess { get; set; }

        public bool SecurityQuestionsSet { get; set; }


        public string SocialSecurityNumber { get; set; }

        public Activity LatestActivity { get; set; }

        public string BrightcovePlaylistID { get; set; }
    }

    public enum PronounType
    {
        HisHer = 1,
        HeShe = 2,
        HimHer
    }

    public class PhoneNumber
    {
        public string TypeName { get; set; }
        public int? TypeID { get; set; }
        public string Number { get; set; }
    }


}
