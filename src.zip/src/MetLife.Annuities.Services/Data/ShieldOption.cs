﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class ShieldOption
    {
        public string ShieldName { get; set; }
        public string ShieldCode { get; set; }
        public decimal Protection { get; set; }
        public int TermLength { get; set; }
        public string IndexName { get; set; }
        public string IndexCode { get; set; }
        public decimal AllocationPercent { get; set; }
        public decimal? MGOStepRate { get; set; }
    }
}
