﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class ShieldCalculatorModel
    {
        public ShieldProduct Product { get; set; }

        public string ClientName { get; set; }

        public string JointName { get; set; }

        public string AdvisorName { get; set; }

        public Guid Id { get; set; }
    }
}
