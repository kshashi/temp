﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class ClientFinance
    {
        public int ClientID { get; set; }

        public int? RetirementAge { get; set; }

        public int? DepedentCount { get; set; }

        public decimal? IncomeSalary { get; set; }

        public decimal? IncomeRental { get; set; }

        public decimal? IncomeSocialSecurity { get; set; }

        public decimal? IncomePensions { get; set; }

        public decimal? IncomeOther { get; set; }

        public bool? HasWillsTrustsEtc { get; set; }
        public bool? HasDependents { get { return DepedentCount > 0; } }

        public decimal? ExpensesFuture { get; set; }

        public decimal? ExpensesCurrent { get; set; }

        public decimal? NetWorth { get; set; }

        public decimal? InvestmentRoth { get; set; }

        public decimal? Investment401k { get; set; }

        public decimal? InvestmentIRA { get; set; }

        public decimal? Investment403B { get; set; }

        public decimal? InitialInvestment { get; set; }
        public int? IncomeTiming { get; set; }
        public int? RiskTolerance { get; set; }

        public string RiskToleranceText { get; set; }

        public string IncomeTimingText { get; set; }

        public Dictionary<string, decimal> IncomeSources { get; set; }
        public Dictionary<string, decimal> Expenses { get; set; }
        public Dictionary<string, decimal> Investments { get; set; }
        public string[] Goals { get; set; }
        public int[] ImportantBenefits { get; set; }

        public bool? HasInvestments { get { return Investments.Sum(g => g.Value) > 0; } }

        public string[] ImportantBenefitsText { get; set; }

        public ClientFinance()
        {
            Goals = new string[] { };
            ImportantBenefits = new int[] { };
            IncomeSources = new Dictionary<string, decimal>();
            Expenses = new Dictionary<string, decimal>();
            Investments = new Dictionary<string, decimal>();
        }


    }
}
