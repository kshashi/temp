﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public enum HistoryType
    {
        Other = 0,
        ProfileUpdated = 1,
        FlagsAdded = 2,
        ProspectusDelievered = 3,
        NewAnnuity = 4,
        ApplicationForms = 5,
        FinancialProfileUpdated = 6
    }
}
