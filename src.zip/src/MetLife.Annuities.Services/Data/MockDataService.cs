﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Data
{
    public class MockDataService : IDataService
    {
        public Client SaveClient(Client client, int advisorId)
        {
            throw new NotImplementedException();
        }

        public Dictionary<int, string> GetStates()
        {
            throw new NotImplementedException();
        }

        public Dictionary<byte, string> GetMaritalStatuses()
        {
            throw new NotImplementedException();
        }

        public Dictionary<int, string> GetPhoneNumberTypes()
        {
            throw new NotImplementedException();
        }

        public Client GetClient(int clientId)
        {
            return new Client { FirstName = "Jim", LastName = "Burns", Goals = new string[] { "Goal 1" } };
        }

        public void SaveClientFinance(ClientFinance finance)
        {
            throw new NotImplementedException();
        }

        public void SaveClientPersona(ClientPersona persona)
        {
            throw new NotImplementedException();
        }

        public ClientFinance GetClientFinance(int clientId)
        {
            throw new NotImplementedException();
        }

        public Dictionary<char, string> GetGenders()
        {
            throw new NotImplementedException();
        }

        public Client[] GetClientsForAdvisor(int advisorId)
        {
            throw new NotImplementedException();
        }

        public Dictionary<int, string> GetNeedTimespans()
        {
            throw new NotImplementedException();
        }

        public PagedList<Models.activity> GetClientActivity(int advisorId, int page, int pageSize, string sort, string filter)
        {
            throw new NotImplementedException();
        }

        public PagedList<Client> GetClientsForAdvisor(int advisorId, int page, int pageSize, string filter, string sort)
        {
            throw new NotImplementedException();
        }

        public UserProfile GetUserProfile(int userId)
        {
            throw new NotImplementedException();
        }

        public void SaveUserProfile(UserProfile profile)
        {
            throw new NotImplementedException();
        }

        public PagedList<Client> GetRecentClientsForAdvisor(int p)
        {
            throw new NotImplementedException();
        }

        public void WriteClientActivity(ClientActivityType type, int clientId)
        {
            throw new NotImplementedException();
        }

        public PagedList<ClientHistory> GetClientHistory(int clientId)
        {
            throw new NotImplementedException();
        }

        public void ToggleHypotheticalView(string state, string clientId,advisor advisor)
        {
            throw new NotImplementedException();
        }

        public UserProfile GetUserProfileByExternalId(string userId)
        {
            return new UserProfile { ExternalID = "safuj3-8j3faf", InternalID = 1, ProfileImageUrl = null, UserProfileID = 1 };
        }

        public UserProfile CreateIBANNMETUser(string currentRole, string userId)
        {
            throw new NotImplementedException();
        }

        public Advisor GetAdvisor(string universalId)
        {
            throw new NotImplementedException();
        }


        public Advisor GetAdvisor(int advisor_id)
        {
            throw new NotImplementedException();
        }


        public void UpdateClientProgress(int client_id, ClientProgressType clientProgressType)
        {
            throw new NotImplementedException();
        }


        public Client GetClient(string universalId)
        {
            throw new NotImplementedException();
        }




        public int SaveShieldProduct(ShieldProduct product, Client client)
        {
            throw new NotImplementedException();
        }


        public Annuities.SavedProductItem[] GetSavedAnnuities(int client_id)
        {
            throw new NotImplementedException();
        }


        public ClientProgress[] GetClientProgressStates()
        {
            throw new NotImplementedException();
        }


        public void UpdateClientProgress(int client_id, ClientProgressType clientProgressType, Models.advisor advisor)
        {
            throw new NotImplementedException();
        }


        public int SaveFlag(int hypotheticalId, int illustrationId, Dictionary<string, string> meta, Flag flag,string action)
        {
            throw new NotImplementedException();
        }


        public ShieldProduct GetShieldProduct(int id)
        {
            throw new NotImplementedException();
        }


        PagedList<Activity> IDataService.GetClientActivity(int advisorId, int? clientId, int page, int pageSize, string sort, string filter)
        {
            throw new NotImplementedException();
        }


        public void WriteClientHistory(HistoryType type, int clientId, Dictionary<string, string> replacements)
        {
            throw new NotImplementedException();
        }

        public PagedList<Activity> GetClientActivity(int advisorId, int? clientId, int page, int pageSize, string sort, string filter)
        {
            throw new NotImplementedException();
        }


        public void DeleteHypothetical(int id)
        {
            throw new NotImplementedException();
        }


        public Guid CreateSeriesVAShell(Client client)
        {
            throw new NotImplementedException();
        }


        public void UpdateSecurityQuestion(int clientId, bool isSet)
        {
            throw new NotImplementedException();
        }


        public void StartApplication(int hypotheticalId)
        {
            throw new NotImplementedException();
        }


        public Annuities.SavedProductItem GetApplicationAnnuity(int client_id)
        {
            throw new NotImplementedException();
        }


        public FlagsChartModel GetFlagsForHypothetical(int id)
        {
            throw new NotImplementedException();
        }


        public void DeleteFlag(int p)
        {
            throw new NotImplementedException();
        }


        public void UpdateSummaryItem(Annuities.SavedProductItem summary)
        {
            throw new NotImplementedException();
        }


        public Flag GetLastFlagForClient(int client_id)
        {
            throw new NotImplementedException();
        }


        public void SaveApplicationConsent(Client client, Annuities.SavedProductItem annuity, Annuities.Hypothetical hypothetical, string productCode, bool epcConsent, bool prospectusSent)
        {
            throw new NotImplementedException();
        }


        public UserProfile CreateIBANNMETUser(string currentRole, string userId, string systemId)
        {
            throw new NotImplementedException();
        }


        public Advisor GetAdvisorBySystemId(string systemId)
        {
            throw new NotImplementedException();
        }


        public void SaveAdvisor(Advisor advisor)
        {
            throw new NotImplementedException();
        }


        public Annuities.SavedProductItem GetAnnuity(int annuity_id)
        {
            throw new NotImplementedException();
        }


        SavedProductItem[] IDataService.GetSavedAnnuities(int client_id)
        {
            throw new NotImplementedException();
        }

        SavedProductItem IDataService.GetAnnuity(int annuity_id)
        {
            throw new NotImplementedException();
        }

        SavedProductItem IDataService.GetApplicationAnnuity(int client_id)
        {
            throw new NotImplementedException();
        }

       

        public void SaveApplicationConsent(Client client, SavedProductItem annuity, Hypothetical hypothetical, string productCode, bool epcConsent, bool prospectusSent, Models.advisor advisor)
        {
            throw new NotImplementedException();
        }


        public SavedProductItem GetAnnuity(Guid guid)
        {
            throw new NotImplementedException();
        }


        public Benefit[] GetBenefits()
        {
            throw new NotImplementedException();
        }


        public void MarkApplicationPurchased(int p)
        {
            throw new NotImplementedException();
        }

        public bool IsDNSSEmail(string email)
        {
            throw new NotImplementedException();
        }

        public bool IsDNSSEmail(List<string> emails, ref string[] dnssEmails)
        {
            throw new NotImplementedException();
        }


        public void LogAdvisorLogon(string systemId, string notes)
        {
            throw new NotImplementedException();
        }

       

         public Dictionary<string, string> GetProducts()
        {
            throw new NotImplementedException();
        }

        public Dictionary<string, string> GetChannels()
        {
            throw new NotImplementedException();
        }

        public Doc GetTDocDetails(string doc_cd, string doc_prd, string dstr_cd)
        {
            throw new NotImplementedException();
        }
        public bool UpdateDocDetails(string doc_cd, string doc_prd, string dstr_typ, Doc docs, out string errorMessage)
        {
            throw new NotImplementedException();
        }
        public Dictionary<string, string> GetDocCombined()
        {
            throw new NotImplementedException();
        }
        public Dictionary<string, string> GetActiveDocCombined()
        {
            throw new NotImplementedException();
        }
        public Doc GetStateDocDetails(string doc_cd, string doc_prd, string dstr_cd, int st)
        {
            throw new NotImplementedException();
        }
        public bool UpdateStateDocDetails(string doc_cd, string doc_prd, string dstr_typ, int st, Doc docs, out string errorMessage)
        {
            throw new NotImplementedException();
        }

        public bool AddDocDetails(Doc docs, out string errorMessage)
        {
            throw new NotImplementedException();
        }
        public bool AddStateDocDetails(Doc docs, out string errorMessage)
        {
            throw new NotImplementedException();
        }
        public bool CheckForStateReferenceActiveDocument(string doc_cd, string doc_prd, string dstr_typ, out string errorMessage)
        {
            throw new NotImplementedException(); 
        }
        public List<Doc> SearchDoc(string state, string channel, string product, string active)
        {
            throw new NotImplementedException();
        }

        public List<Doc> SearchStateDocMapping(string docCode)
        {
            throw new NotImplementedException();
        }
        public bool CheckForActiveDocument(string doc_cd, string doc_prd, string dstr_typ, out string errorMessage)
        {
            throw new NotImplementedException();
        }
    }
}
