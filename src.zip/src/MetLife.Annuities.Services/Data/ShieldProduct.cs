﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Services.Data
{
    public class ShieldProduct
    {
        public string Name { get; set; }
        public decimal InitialInvestment { get; set; }
        public bool EnhancedDeathBenefit { get; set; }
        public AnnuityProductType HypotheticalType
        {
            get
            {
                return AnnuityProductType.ShieldLevel;
            }
        }
        public ShieldOption[] ShieldOptions { get; set; }

        public string CreatedTime { get; set; }

        public string CreatedBy { get; set; }

        public int Id { get; set; }
    }
}
