﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class ClientProgress
    {
        public ClientProgressType ClientProgressType { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class Progress
    {
        public ProgressStep[] Steps { get; set; }
    }

    public class ProgressStep
    {
        public bool Complete { get; set; }
        public string Url { get; set; }
        public string Copy { get; set; }
    }
}
