﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class FlagsChartModel
    {
        public string hypothetical_type { get; set; }
        public int hypothetical_id { get; set; }
        public ChartFlag[] chart_flags { get; set; }
    }

    public class ChartFlag
    {
        public Dictionary<string, string> meta { get; set; }
        public Flag[] flags { get; set; }
    }

    public class Flag
    {
        public int id { get; set; }
        public long created_time { get; set; }
        public long created_time_js { get {
            var dt = new DateTime(this.created_time);
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var time = dt.Subtract(new TimeSpan(epoch.Ticks));
            return (long)(time.Ticks / 10000);
        } }
        public string selected_option { get; set; }
        public string hypothetical_id { get; set; }
        public ChartPosition position { get; set; }
    }

    public class ChartPosition
    {
        public int x { get; set; }
        public int y { get; set; }
    }

    public class SaveChartFlag
    {
        public string action { get; set; }
        public string data { get; set; }
    }
}
