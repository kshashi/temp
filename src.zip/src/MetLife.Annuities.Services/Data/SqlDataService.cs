﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Annuities;
using System.Globalization;
using Newtonsoft.Json;
using System.Data.SqlTypes;
using System.Configuration;


namespace MetLife.Annuities.Services.Data
{
    public class SqlDataService : IDataService
    {
        const string STATEMAPPINGERROR = "Unable to inactive document because it is referenced in state mappings.";
        const string ACTIVEDOCUMENTERROR = "A document must be active to be mapped.";
        const string SUCCESSADDMESSAGE = "Record added successfully.";
        const string SUCCESSUPDATEMESSAGE = "Record updated successfully.";
        const string UPDATEEXCEPTIONMESSAGE = "Update failed – << {0} >>";
        const string INSERTEXCEPTIONMESSAGE = "Insert failed – << {0} >>";
        public PagedList<Client> GetClientsForAdvisor(int advisorId, int page, int pageSize, string filter, string sort)
        {
            var list = new PagedList<Client>();

            using (var ctx = new AnnuitiesDataContext())
            {
                list.CurrentPage = page;
                var query = ctx.T_CLNTs.Where(g => g.ADV_ID == advisorId && g.CLNT_PRGRS_ID > 1);

                if (!string.IsNullOrEmpty(filter))
                {
                    query = query.Where(g => g.FRST_NM.Contains(filter) ||
                        g.LST_NM.Contains(filter) || (g.FRST_NM + " " + g.LST_NM).Contains(filter) ||
                        g.T_ADRs.Count(c => c.CITY_NM.Contains(filter) ||
                            c.T_ST_PRVNC_LKUP.ST_PRVNC_NM.Contains(filter) ||
                            c.T_ST_PRVNC_LKUP.ST_PRVNC_CD.Contains(filter)) > 0);
                }
                int totalCount = query.Count();
                switch (sort)
                {
                    case "last_name":
                        query = query.OrderBy(g => g.LST_NM);
                        break;
                    case "state":
                        query = query.OrderBy(g => g.T_ADRs.First().T_ST_PRVNC_LKUP.ST_PRVNC_NM);
                        break;
                    case "city":
                        query = query.OrderBy(g => g.T_ADRs.First().CITY_NM);
                        break;
                    case "recent_activity":
                    case "recent":
                        query = query.OrderByDescending(g => g.LST_UPDT_TS);
                        break;
                    default:
                        break;
                }
                query = query.Skip((page - 1) * pageSize).Take(pageSize);
                int numberOfPages = (int)Math.Ceiling(((decimal)((decimal)totalCount / (decimal)pageSize)));
                list.TotalPages = numberOfPages == 0 ? 1 : numberOfPages;

                var items = from c in query
                            select new Client
                            {
                                ClientID = c.CLNT_ID,
                                FirstName = c.FRST_NM,
                                LastName = c.LST_NM,
                                City = c.T_ADRs.First().CITY_NM,
                                StateCode = c.T_ADRs.First().T_ST_PRVNC_LKUP.ST_PRVNC_CD,
                                CurrentStatus = c.T_CLNT_PRGR.PRGRS_NM,
                                CurrentStatusId = c.CLNT_PRGRS_ID.Value,
                                LastActivityDate = c.LST_UPDT_TS,
                                HasAlerts = c.ALRT_IND,
                                LatestActivity = GetLatestActivity(c)
                            };


                list.Items = items.ToArray();
                return list;
            }
        }

        private Activity GetLatestActivity(T_CLNT client)
        {
            return GetClientActivity(client.ADV_ID.Value, client.CLNT_ID, 1, 1, "recent", "").Items.FirstOrDefault();
        }


        public Client SaveClient(Client client, int advisorId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                T_CLNT entity = new T_CLNT();
                if (client.ClientID > 0)
                {
                    entity = ctx.T_CLNTs.Single(g => g.CLNT_ID == client.ClientID);
                }
                else
                {
                    // they're new
                    entity.CLNT_PRGRS_ID = 1;
                    entity.T_USR_PRFL = new T_USR_PRFL { EXT_SYS_ID = "", EXT_SYS_TYP_ID = 1 };
                    entity.UNQ_ID = Guid.NewGuid();
                }


                entity.FRST_NM = client.FirstName;
                entity.LST_NM = client.LastName;
                entity.BRTH_DT = client.DateOfBirth;
                entity.ADV_ID = advisorId;
                entity.SEX_CD = client.Gender;
                entity.MRY_STTS_ID = client.MaritalStatusID;
                entity.ALRT_IND = client.HasAlerts;
                entity.LST_4_DGT_OF_TIN = client.SocialSecurityNumber;
                entity.PRFR_HYPTHTCL_TYP_ID = (int)client.PreferredAnnuityProductType;
                entity.SCTY_QUES_IND = client.SecurityQuestionsSet;
                ctx.T_TELs.DeleteAllOnSubmit(entity.T_TELs);
                ctx.T_EMAIL_ADRs.DeleteAllOnSubmit(entity.T_EMAIL_ADRs);
                ctx.T_ADRs.DeleteAllOnSubmit(entity.T_ADRs);
                ctx.SubmitChanges();

                entity.T_TELs.AddRange((from t in client.PhoneNumbers
                                        select new T_TEL
                                        {
                                            TEL_NUM = t.Number,
                                            TEL_TYP_ID = t.TypeID
                                        }));

                entity.T_EMAIL_ADRs.Add(new T_EMAIL_ADR { EMAIL_ADR_TXT = client.EmailAddress });

                entity.T_ADRs.Add(new T_ADR
                {
                    ADR_1_LN = client.Address1,
                    ADR_2_LN = client.Address2,
                    CITY_NM = client.City,
                    ZIP_CD = client.Zip,
                    ST_ID = client.StateID,
                    ADR_TYP_ID = 1
                });

                if (client.ClientID == 0)
                    ctx.T_CLNTs.InsertOnSubmit(entity);

                ctx.SubmitChanges();
                client.ClientID = entity.CLNT_ID;
            }

            return client;
        }


        public Dictionary<int, string> GetStates()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return ctx.T_ST_PRVNC_LKUPs.OrderBy(g => g.ST_PRVNC_CD).ToDictionary(g => g.ST_ID, g => g.ST_PRVNC_CD);
            }
        }

        public Dictionary<byte, string> GetMaritalStatuses()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return ctx.T_MRY_STTs.OrderByDescending(g => g.MRY_STTS_NM).ToDictionary(g => g.MRY_STTS_ID, g => g.MRY_STTS_NM);
            }
        }


        public Dictionary<int, string> GetPhoneNumberTypes()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return ctx.T_TEL_TYP_LKUPs.ToDictionary(g => g.TEL_TYP_ID, g => g.TEL_TYP_DSCR);
            }
        }


        public Client GetClient(int clientId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = ctx.T_CLNTs.Single(g => g.CLNT_ID == clientId);
                var addr = model.T_ADRs.FirstOrDefault();
                var lastActivity = model.T_CLNT_ACT_LOGs.OrderByDescending(g => g.CRT_TS).FirstOrDefault();

                var client = new Client
                {
                    FirstName = model.FRST_NM,
                    LastName = model.LST_NM,
                    ClientID = model.CLNT_ID,
                    Gender = model.SEX_CD.Value,
                    Address1 = addr.ADR_1_LN,
                    Address2 = addr.ADR_2_LN,
                    City = addr.CITY_NM,
                    CurrentStatusId = model.CLNT_PRGRS_ID.Value,
                    StateCode = addr.T_ST_PRVNC_LKUP.ST_PRVNC_CD,
                    Zip = addr.ZIP_CD,
                    DateOfBirth = model.BRTH_DT,
                    MaritalStatusID = model.MRY_STTS_ID,
                    MaritalStatusText = model.T_MRY_STT.MRY_STTS_NM,
                    StateID = addr.ST_ID,
                    StartedApplicationProcess = model.T_CLNT_HYPTHTCLs.Count(g => g.APPL_IND == true) > 0,
                    AdvisorID = model.ADV_ID.Value,
                    PreferredAnnuityProductType = (AnnuityProductType)model.PRFR_HYPTHTCL_TYP_ID,
                    TestimonialPersonaID = model.TSTMNL_PER_ID,
                    BrightcovePlaylistID = model.T_CLNT_TSTMNL_VIDs.FirstOrDefault() != null ? model.T_CLNT_TSTMNL_VIDs.First().VID_NM : "",
                    SecurityQuestionsSet = model.SCTY_QUES_IND,
                    SocialSecurityNumber = model.LST_4_DGT_OF_TIN,
                    HasAlerts = model.ALRT_IND,
                    PhoneNumbers = (from p in model.T_TELs
                                    select new PhoneNumber
                                    {
                                        TypeID = p.TEL_TYP_ID,
                                        Number = p.TEL_NUM,
                                        TypeName = p.T_TEL_TYP_LKUP.TEL_TYP_DSCR
                                    }).ToArray(),
                    EmailAddress = (from e in model.T_EMAIL_ADRs
                                    select e.EMAIL_ADR_TXT).First(),
                    SelectedPersonaVideos = (from e in model.T_CLNT_TSTMNL_VIDs
                                             select e.CLNT_TSTMNL_VID_ID).ToArray(),
                    StatusText = model.T_CLNT_PRGR.PRGRS_NM,
                    CurrentStatus = model.T_CLNT_PRGR.PRGRS_NM,
                    History = (from e in model.T_CLNT_HISTs
                               select e.HIST_CMNT_TXT).ToArray(),
                    Goals = model.T_CLNT_GOALs.Select(g => g.GOAL_DSCR).ToArray(),
                    HypotheticalViewEnabled = model.CLNT_VW_ENABL_IND.HasValue ? model.CLNT_VW_ENABL_IND.Value : false,
                    UniversalID = model.T_USR_PRFL.EXT_SYS_ID,
                    LastActivityDate = lastActivity == null ? DateTime.UtcNow : lastActivity.CRT_TS,
                    UniqueId = model.UNQ_ID.Value,
                    UserId = model.USR_PRFL_ID
                };

                return client;
            }
        }


        public Dictionary<char, string> GetGenders()
        {
            return new Dictionary<char, string>(){
                 {char.Parse("M"),"Male"},
                 {char.Parse("F"),"Female"}
            };
        }

        public ClientFinance GetClientFinance(int clientId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var client = ctx.T_CLNTs.Single(g => g.CLNT_ID == clientId);

                var model = new ClientFinance
                {
                    DepedentCount = client.DPND_CNT,
                    RetirementAge = client.RTR_AGE,
                    HasWillsTrustsEtc = client.WILL_IND,
                    NetWorth = client.CLNT_NET_WRTH_AMT,
                    InitialInvestment = client.INIT_INVST_AMT,
                    IncomeTiming = client.INCM_TM_ID,
                    RiskTolerance = client.RISK_TLRN_ID,
                    RiskToleranceText = client.T_RISK_TLRN_LKUP == null ? "" : client.T_RISK_TLRN_LKUP.RISK_TLRN_DSCR,
                    IncomeTimingText = client.T_INCM_TM_LKUP == null ? "" : client.T_INCM_TM_LKUP.INCM_TM_DSCR,
                    Goals = (from p in client.T_CLNT_GOALs
                             select p.GOAL_DSCR).ToArray(),
                    ImportantBenefitsText = (from b in client.T_CLNT_BENs
                                             select b.T_BEN_TYP_LKUP.BEN_TYP_DSCR).ToArray(),
                    ImportantBenefits = (from b in client.T_CLNT_BENs
                                         select b.BEN_TYP_ID).ToArray(),
                    IncomeSources = client.T_CLNT_INCMs.ToDictionary(g => g.T_INCM_TYP_LKUP.INCM_TYP_DSCR,
                    g => g.INCM_AMT.Value),
                    Expenses = client.T_CLNT_EXPs.ToDictionary(g => g.T_EXP_TYP_LKUP.EXP_TYP_DSCR,
                    g => g.EXP_AMT.Value),
                    Investments = client.T_CLNT_INVSTs.ToDictionary(g => g.T_INVST_TYP_LKUP.INVST_TYP_DSCR,
                     g => g.INVST_AMT.Value),
                };

                decimal val = 0;
                if (model.IncomeSources.TryGetValue("Salary", out val))
                    model.IncomeSalary = val;

                if (model.IncomeSources.TryGetValue("Rentals", out val))
                    model.IncomeRental = val;

                if (model.IncomeSources.TryGetValue("Pensions", out val))
                    model.IncomePensions = val;

                if (model.IncomeSources.TryGetValue("Social Security", out val))
                    model.IncomeSocialSecurity = val;

                if (model.IncomeSources.TryGetValue("Other", out val))
                    model.IncomeOther = val;

                if (model.Expenses.TryGetValue("Current", out val))
                    model.ExpensesCurrent = val;

                if (model.Expenses.TryGetValue("Future", out val))
                    model.ExpensesFuture = val;

                if (model.Investments.TryGetValue("Roth IRA(s)", out val))
                    model.InvestmentRoth = val;
                if (model.Investments.TryGetValue("403B(s)", out val))
                    model.Investment403B = val;
                if (model.Investments.TryGetValue("401K(s)", out val))
                    model.Investment401k = val;
                if (model.Investments.TryGetValue("Trad. IRA(s)", out val))
                    model.InvestmentIRA = val;
                return model;
            }
        }


        public void SaveClientFinance(ClientFinance finance)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var client = ctx.T_CLNTs.Single(g => g.CLNT_ID == finance.ClientID);
                client.DPND_CNT = finance.DepedentCount;
                client.RTR_AGE = finance.RetirementAge;
                client.WILL_IND = finance.HasWillsTrustsEtc;
                client.CLNT_NET_WRTH_AMT = finance.NetWorth;
                client.INIT_INVST_AMT = finance.InitialInvestment;
                client.INCM_TM_ID = finance.IncomeTiming;
                client.RISK_TLRN_ID = finance.RiskTolerance;

                ctx.T_CLNT_INCMs.DeleteAllOnSubmit(client.T_CLNT_INCMs);
                ctx.T_CLNT_EXPs.DeleteAllOnSubmit(client.T_CLNT_EXPs);
                ctx.T_CLNT_INVSTs.DeleteAllOnSubmit(client.T_CLNT_INVSTs);
                ctx.T_CLNT_BENs.DeleteAllOnSubmit(client.T_CLNT_BENs);
                ctx.T_CLNT_GOALs.DeleteAllOnSubmit(client.T_CLNT_GOALs);
                ctx.SubmitChanges();

                if (finance.IncomeSalary.HasValue)
                    client.T_CLNT_INCMs.Add(new T_CLNT_INCM
                    {
                        INCM_TYP_ID = 1,
                        INCM_AMT = finance.IncomeSalary.Value
                    });

                if (finance.IncomeRental.HasValue)
                    client.T_CLNT_INCMs.Add(new T_CLNT_INCM
                    {
                        INCM_TYP_ID = 2,
                        INCM_AMT = finance.IncomeRental.Value
                    });

                if (finance.IncomePensions.HasValue)
                    client.T_CLNT_INCMs.Add(new T_CLNT_INCM
                    {
                        INCM_TYP_ID = 3,
                        INCM_AMT = finance.IncomePensions.Value
                    });

                if (finance.IncomeSocialSecurity.HasValue)
                    client.T_CLNT_INCMs.Add(new T_CLNT_INCM
                    {
                        INCM_TYP_ID = 4,
                        INCM_AMT = finance.IncomeSocialSecurity.Value
                    });

                if (finance.IncomeOther.HasValue)
                    client.T_CLNT_INCMs.Add(new T_CLNT_INCM
                    {
                        INCM_TYP_ID = 5,
                        INCM_AMT = finance.IncomeOther.Value
                    });

                if (finance.ExpensesCurrent.HasValue)
                    client.T_CLNT_EXPs.Add(new T_CLNT_EXP
                    {
                        EXP_TYP_ID = 1,
                        EXP_AMT = finance.ExpensesCurrent.Value
                    });

                if (finance.ExpensesFuture.HasValue)
                    client.T_CLNT_EXPs.Add(new T_CLNT_EXP
                    {
                        EXP_TYP_ID = 2,
                        EXP_AMT = finance.ExpensesFuture.Value
                    });

                if (finance.InvestmentRoth.HasValue)
                    client.T_CLNT_INVSTs.Add(new T_CLNT_INVST
                    {
                        INVST_TYP_ID = 1,
                        INVST_AMT = finance.InvestmentRoth.Value
                    });

                if (finance.InvestmentIRA.HasValue)
                    client.T_CLNT_INVSTs.Add(new T_CLNT_INVST
                    {
                        INVST_TYP_ID = 2,
                        INVST_AMT = finance.InvestmentIRA.Value
                    });

                if (finance.Investment401k.HasValue)
                    client.T_CLNT_INVSTs.Add(new T_CLNT_INVST
                    {
                        INVST_TYP_ID = 3,
                        INVST_AMT = finance.Investment401k.Value
                    });

                if (finance.Investment403B.HasValue)
                    client.T_CLNT_INVSTs.Add(new T_CLNT_INVST
                    {
                        INVST_TYP_ID = 4,
                        INVST_AMT = finance.Investment403B.Value
                    });


                foreach (var item in finance.ImportantBenefits)
                {
                    var entity = new T_CLNT_BEN { BEN_TYP_ID = item };

                    client.T_CLNT_BENs.Add(entity);

                }

                foreach (var item in finance.Goals)
                {
                    if (!string.IsNullOrEmpty(item))
                    {
                        var entity = new T_CLNT_GOAL { GOAL_DSCR = item };
                        client.T_CLNT_GOALs.Add(entity);
                    }
                }

                ctx.SubmitChanges();
            }
        }


        public void SaveClientPersona(ClientPersona persona)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var client = ctx.T_CLNTs.Single(g => g.CLNT_ID == persona.ClientID);

                ctx.T_CLNT_TSTMNL_VIDs.DeleteAllOnSubmit(client.T_CLNT_TSTMNL_VIDs);
                ctx.SubmitChanges();

                client.T_CLNT_TSTMNL_VIDs.Add(new T_CLNT_TSTMNL_VID { VID_NM = persona.BrightcovePlaylistID });

                client.TSTMNL_PER_ID = persona.PersonaID;

                ctx.SubmitChanges();
            }
        }


        public Dictionary<string, string> GetIBSERoles()
        {
            throw new NotImplementedException();
        }


        public Client[] GetClientsForAdvisor(int advisorId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var clients = ctx.T_CLNTs.Where(g => g.ADV_ID == advisorId);

                var query = from c in clients
                            select new Client
                            {
                                ClientID = c.CLNT_ID,
                                FirstName = c.FRST_NM,
                                LastName = c.LST_NM,
                                City = c.T_ADRs.First().CITY_NM,
                                StateCode = c.T_ADRs.First().T_ST_PRVNC_LKUP.ST_PRVNC_CD
                            };

                return query.ToArray();
            }
        }


        public Dictionary<int, string> GetNeedTimespans()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return ctx.T_INCM_TM_LKUPs.ToDictionary(g => g.INCM_TM_ID, g => g.INCM_TM_DSCR);
            }
        }


        public PagedList<Activity> GetClientActivity(int advisorId, int? clientId, int page, int pageSize, string sort, string filter)
        {

            var list = new PagedList<Activity>();
            list.CurrentPage = page;

            using (var ctx = new AnnuitiesDataContext())
            {
                var query = ctx.T_CLNT_ACT_LOGs.Where(g => g.T_CLNT.ADV_ID == advisorId);
                var history = ctx.T_CLNT_HISTs.Where(g => g.T_CLNT.ADV_ID == advisorId);
                if (clientId.HasValue)
                {
                    query = query.Where(g => g.CLNT_ID == clientId.Value);
                    history = history.Where(g => g.CLNT_ID == clientId.Value);
                }

                var fullQuery = ((from q in query
                                  select new Activity
                                  {
                                      Date = q.CRT_TS,
                                      Timestamp = q.CRT_TS.Ticks,
                                      Client = new Client
                                      {
                                          FirstName = q.T_CLNT.FRST_NM,
                                          LastName = q.T_CLNT.LST_NM,
                                          ClientID = q.CLNT_ID

                                      },
                                      HistoryType = HistoryType.Other,
                                      Description = q.ACT_DSCR,
                                      Type = q.T_CLNT_ACT_TYP.ACT_NM
                                  }).ToArray()).Union(
                                 (from q in history
                                  select new Activity
                                  {
                                      Date = q.CRT_TS,
                                      Timestamp = q.CRT_TS.Ticks,
                                      Client = new Client
                                      {
                                          FirstName = q.T_CLNT.FRST_NM,
                                          LastName = q.T_CLNT.LST_NM,
                                          ClientID = q.CLNT_ID

                                      },
                                      HistoryType = (HistoryType)q.CLNT_HIST_TYP_ID,
                                      Description = q.HIST_CMNT_TXT,
                                      Type = q.HIST_TITL_TXT
                                  }).ToArray()
                                 );
                switch (sort)
                {
                    case "recent":
                    case "most_recent":
                    case "most recent":
                        fullQuery = fullQuery.OrderByDescending(g => g.Date);
                        break;
                    case "last_name":
                        fullQuery = fullQuery.OrderBy(g => g.Client.LastName);
                        break;
                    case "flags_added":
                        var changes = fullQuery.Where(g => g.HistoryType == HistoryType.FlagsAdded).OrderByDescending(g => g.Date);
                        fullQuery = changes.Union(fullQuery.Where(g => g.HistoryType != HistoryType.FlagsAdded));
                        break;
                    case "profile_changes":
                        changes = fullQuery.Where(g => g.HistoryType == HistoryType.ProfileUpdated).OrderByDescending(g => g.Date);
                        fullQuery = changes.Union(fullQuery.Where(g => g.HistoryType != HistoryType.ProfileUpdated));
                        break;
                    case "status_changes":
                        changes = fullQuery.Where(g => g.HistoryType == HistoryType.Other).OrderByDescending(g => g.Date);
                        fullQuery = changes.Union(fullQuery.Where(g => g.HistoryType != HistoryType.Other));
                        break;
                    default:
                        break;
                }
                int count = fullQuery.Count();
                fullQuery = fullQuery.Skip((page - 1) * pageSize).Take(pageSize);
                int numberOfPages = (count % pageSize > 0 ? count / pageSize + 1 : count / pageSize);
                list.TotalPages = numberOfPages == 0 ? 1 : numberOfPages;
                list.Items = fullQuery.ToArray();

            }

            return list;
        }


        public UserProfile GetUserProfile(int userId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = ctx.T_USR_PRFLs.Single(g => g.USR_PRFL_ID == userId);

                return new UserProfile
                {
                    UserProfileID = model.USR_PRFL_ID,
                    ProfileImageUrl = model.USR_PRFL_IMG_URL,
                    ExternalID = model.EXT_SYS_ID

                };
            }
        }


        public void SaveUserProfile(UserProfile profile)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = ctx.T_USR_PRFLs.Single(g => g.USR_PRFL_ID == profile.UserProfileID);

                model.USR_PRFL_IMG_URL = profile.ProfileImageUrl;
                model.EXT_SYS_ID = profile.ExternalID;
                ctx.SubmitChanges();
            }
        }


        public PagedList<Client> GetRecentClientsForAdvisor(int advisorId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var clients = ctx.T_CLNTs.Where(g => g.ADV_ID == advisorId).OrderByDescending(g => g.CRT_TS).Take(5);
                return new PagedList<Client>()
                {
                    Items = (from c in clients
                             select new Client
                             {
                                 ClientID = c.CLNT_ID,
                                 FirstName = c.FRST_NM,
                                 LastName = c.LST_NM,
                                 City = c.T_ADRs.First().CITY_NM,
                                 StateCode = c.T_ADRs.First().T_ST_PRVNC_LKUP.ST_PRVNC_CD,
                                 CurrentStatus = c.T_CLNT_PRGR.PRGRS_NM
                             }).ToArray(),
                    CurrentPage = 1,
                    TotalPages = 1
                };
            }


        }


        public void WriteClientHistory(HistoryType type, int clientId, Dictionary<string, string> replacements)
        {
            var client = GetClient(clientId);
            using (var ctx = new AnnuitiesDataContext())
            {
                var historyType = ctx.T_CLNT_HIST_TYPs.Single(g => g.CLNT_HIST_TYP_ID == (int)type);
                var description = historyType.CLNT_HIST_TYP_DSCR;
                var title = historyType.CLNT_HIST_TYP_TITL;
                if (replacements == null)
                    replacements = new Dictionary<string, string>();

                if (!replacements.ContainsKey("{pronoun}"))
                {
                    if (type == HistoryType.ApplicationForms)
                        replacements.Add("{pronoun}", client.GetPronoun(PronounType.HimHer).ToLower());
                    else
                        replacements.Add("{pronoun}", client.GetPronoun(PronounType.HisHer).ToLower());
                }
                if (!replacements.ContainsKey("{name}"))
                    replacements.Add("{name}", client.FirstName);




                if (replacements != null)
                {
                    foreach (var key in replacements.Keys)
                    {
                        description = description.Replace(key, replacements[key]);
                        title = title.Replace(key, replacements[key]);
                    }
                }

                var entity = new T_CLNT_HIST
                {
                    CLNT_ID = clientId,
                    T_CLNT_HIST_TYP = historyType,
                    HIST_CMNT_TXT = description,
                    HIST_TITL_TXT = title,
                    CRT_TS = DateTime.UtcNow,
                    LST_UPDT_TS = DateTime.UtcNow
                };
                ctx.T_CLNT_HISTs.InsertOnSubmit(entity);

                ctx.SubmitChanges();
            }

            if (type == HistoryType.FlagsAdded)
            {
                client.HasAlerts = true;
                SaveClient(client, client.AdvisorID);
            }

        }


        public PagedList<ClientHistory> GetClientHistory(int clientId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return new PagedList<ClientHistory>
                {
                    CurrentPage = 1,
                    TotalPages = 1,
                    Items = (from c in ctx.T_CLNT_ACT_LOGs
                             where c.CLNT_ID == clientId
                             orderby c.CRT_TS descending
                             select new ClientHistory
                             {
                                 ActivityDate = c.CRT_TS,
                                 Description = c.ACT_DSCR,
                                 Status = c.T_CLNT_ACT_TYP.ACT_NM
                             }).ToArray()

                };
            }
        }


        public void ToggleHypotheticalView(string state, string clientId, advisor advisor)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var client = ctx.T_CLNTs.Single(g => g.CLNT_ID == int.Parse(clientId));
                client.CLNT_VW_ENABL_IND = state.Equals("on");
                ctx.SubmitChanges();
            }
            if (state == "on")
            {

                UpdateClientProgress(int.Parse(clientId), Services.ClientProgressType.ProductReviewEnabled,
                    advisor);

            }
        }


        public UserProfile GetUserProfileByExternalId(string userId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var user = ctx.T_USR_PRFLs.SingleOrDefault(g => g.EXT_SYS_ID == userId);
                if (user == null)
                    return null;
                var profile = new UserProfile
                {
                    UserProfileID = user.USR_PRFL_ID,
                    ProfileImageUrl = user.USR_PRFL_IMG_URL,
                    ExternalID = user.EXT_SYS_ID
                };
                return profile;
            }
        }


        public UserProfile CreateIBANNMETUser(string currentRole, string userId, string systemId)
        {

            using (var ctx = new AnnuitiesDataContext())
            {
                // create the user first
                var user = new T_USR_PRFL
                {
                    EXT_SYS_ID = userId,
                    USR_PRFL_IMG_URL = null
                };

                switch (currentRole)
                {
                    case "rvp":
                        //user.T_WHLSLs.Add(new T_WHLSL());
                        break;
                    case "advisor":
                        var advisor = new T_ADV { SYS_ID = systemId };
                        user.T_ADVs.Add(advisor);
                        break;
                    default:
                        break;
                }


                ctx.T_USR_PRFLs.InsertOnSubmit(user);

                ctx.SubmitChanges();

                var profile = new UserProfile
                {
                    UserProfileID = user.USR_PRFL_ID,
                    ProfileImageUrl = user.USR_PRFL_IMG_URL,
                    ExternalID = user.EXT_SYS_ID
                };

                switch (currentRole)
                {
                    case "rvp":
                        //profile.InternalID = user.T_WHLSLs.First().WHLSL_ID;
                        break;
                    default:
                        break;
                }

                return profile;
            }
        }

        public Advisor GetAdvisor(string universalId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var adv = ctx.T_ADVs.Single(g => g.T_USR_PRFL.EXT_SYS_ID == universalId);

                return new Advisor
                {
                    AdvisorID = adv.ADV_ID,
                    UserProfile = new UserProfile
                    {
                        UserProfileID = adv.T_USR_PRFL.USR_PRFL_ID,
                        ProfileImageUrl = adv.T_USR_PRFL.USR_PRFL_IMG_URL,
                        ExternalID = adv.T_USR_PRFL.EXT_SYS_ID
                    }
                };

            }
        }


        public Advisor GetAdvisor(int advisor_id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var adv = ctx.T_ADVs.Single(g => g.ADV_ID == advisor_id);

                return new Advisor
                {
                    AdvisorID = adv.ADV_ID,
                    UniversalID = adv.T_USR_PRFL.EXT_SYS_ID,
                    UserProfile = new UserProfile
                    {
                        UserProfileID = adv.T_USR_PRFL.USR_PRFL_ID,
                        ProfileImageUrl = adv.T_USR_PRFL.USR_PRFL_IMG_URL
                    }
                };

            }
        }


        public void UpdateClientProgress(int client_id, ClientProgressType progress, advisor advisor)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var client = ctx.T_CLNTs.Single(g => g.CLNT_ID == client_id);

                if (client.CLNT_PRGRS_ID > (int)progress)
                    return;
                var progressEntity = ctx.T_CLNT_PRGRs.Single(g => g.CLNT_PRGRS_ID == (int)progress);
                client.CLNT_PRGRS_ID = progressEntity.CLNT_PRGRS_ID;
                client.ALRT_IND = true;
                var desc = progressEntity.PRGRS_FRMT_DSCR
                    .Replace("{client_name}", client.FRST_NM);

                if (advisor != null)
                {
                    desc = desc.Replace("{advisor_name}", CultureInfo.InvariantCulture.TextInfo.ToTitleCase(advisor.first_name + " " + advisor.last_name));
                }
                var activity = new T_CLNT_ACT_LOG
                {
                    CLNT_ACT_TYP_ID = (int)ClientActivityType.ProgressChange,
                    ACT_DSCR = desc,
                    ADV_VW_IND = false

                };
                client.T_CLNT_ACT_LOGs.Add(activity);
                ctx.SubmitChanges();
            }
        }


        public Client GetClient(string universalId)
        {
            T_CLNT client = null;
            using (var ctx = new AnnuitiesDataContext())
            {
                client = (from c in ctx.T_CLNTs
                          where c.T_USR_PRFL.EXT_SYS_ID == universalId
                          select c
                              ).SingleOrDefault();
                if (client == null)
                    return null;
            }

            return GetClient(client.CLNT_ID);
        }


        public int SaveShieldProduct(ShieldProduct product, Client client)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var illustration = new T_CLNT_HYPTHTCL
                {
                    CLNT_ID = client.ClientID,
                    ADV_ID = client.AdvisorID,
                    HYPTHTCL_NM = product.Name,
                    INIT_INVST_AMT = product.InitialInvestment,
                    HYPTHTCL_DSCR = "not sure what goes here",
                    CLNT_HYPTHTCL_TYP_ID = (int)product.HypotheticalType,
                    EDB_IND = product.EnhancedDeathBenefit,
                    PROD_TYP_NM = "Shield Level Selector"
                };

                foreach (var item in product.ShieldOptions)
                {
                    illustration.T_SHLD_LVLs.Add(new T_SHLD_LVL
                    {
                        ALLOC_AMT = item.AllocationPercent,
                        MKT_IDX_CD = item.IndexCode,
                        PROT_AMT = item.Protection,
                        SHLD_TYP_CD = item.ShieldCode,
                        TRM_LNTH = item.TermLength,
                        MKT_IDX_VAL = item.IndexName,
                        SHLD_TYP_NM = item.ShieldName,
                        SHLD_LVL_NM = item.ShieldName,
                        SHLD_SB_NM = "",
                        SHLD_LVL_RT = item.MGOStepRate
                    });
                }

                ctx.T_CLNT_HYPTHTCLs.InsertOnSubmit(illustration);
                ctx.SubmitChanges();

                return illustration.CLNT_HYPTHTCL_ID;
            }
        }


        public SavedProductItem[] GetSavedAnnuities(int client_id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = from c in ctx.T_CLNT_HYPTHTCLs
                            where c.CLNT_ID == client_id &&
                            c.CLNT_HYPTHTCL_EX_ID == null &&
                            (c.ILLUS_DATA != null || c.CLNT_HYPTHTCL_TYP_ID == 2)
                            select new SavedProductItem
                            {
                                CreatedBy = c.CRT_USR_ID,
                                CreatedDate = c.CRT_TS,
                                InitialInvestment = c.INIT_INVST_AMT,
                                Id = c.CLNT_HYPTHTCL_ID,
                                Name = c.HYPTHTCL_NM,
                                ProductTypeName = c.PROD_TYP_NM,
                                PurchasePayment = c.PRCH_PY_VAL,
                                ReceivePayments = c.RCV_PY_VAL,
                                ProductAddOnNames = c.PROD_ADD_ON_NM,
                                ShieldLevels = (from g in c.T_SHLD_LVLs
                                                select new ShieldLevel
                                                {
                                                    Name = g.SHLD_TYP_NM,
                                                    AllocationPercent = g.ALLOC_AMT,
                                                    Index = g.MKT_IDX_VAL,
                                                    Term = g.TRM_LNTH,
                                                    //Protection = g.PROTECTION,
                                                    Subname = g.SHLD_SB_NM,
                                                    Protection = g.PROT_AMT
                                                }).ToArray(),
                                ProductType = (AnnuityProductType)c.CLNT_HYPTHTCL_TYP_ID,
                                WasPurchased = c.CLNT_VW_ENABL_IND
                            };

                return query.ToArray();
            }


        }


        public ClientProgress[] GetClientProgressStates()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = from c in ctx.T_CLNT_PRGRs
                            select new ClientProgress
                            {
                                ClientProgressType = (ClientProgressType)c.CLNT_PRGRS_ID,
                                Id = c.CLNT_PRGRS_ID,
                                Name = c.PRGRS_NM
                            };

                return query.ToArray();
            }
        }

        public ShieldProduct GetShieldProduct(int id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = from c in ctx.T_CLNT_HYPTHTCLs
                            where c.CLNT_HYPTHTCL_ID == id
                            select new ShieldProduct
                            {
                                Id = c.CLNT_HYPTHTCL_ID,
                                Name = c.HYPTHTCL_NM,
                                InitialInvestment = c.INIT_INVST_AMT,
                                EnhancedDeathBenefit = c.EDB_IND.Value,
                                ShieldOptions = (from s in c.T_SHLD_LVLs
                                                 select new ShieldOption
                                                 {
                                                     TermLength = s.TRM_LNTH,
                                                     AllocationPercent = s.ALLOC_AMT,
                                                     IndexCode = s.MKT_IDX_CD,
                                                     IndexName = s.MKT_IDX_VAL,
                                                     Protection = s.PROT_AMT,
                                                     ShieldCode = s.SHLD_TYP_CD,
                                                     ShieldName = s.SHLD_TYP_NM,
                                                     MGOStepRate = s.SHLD_LVL_RT
                                                 }).ToArray()
                            };

                return query.Single();
            }
        }


        public void DeleteHypothetical(int id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == id);
                ctx.T_SHLD_LVLs.DeleteAllOnSubmit(model.T_SHLD_LVLs);
                ctx.T_CLNT_HYPTHTCL_ILLUS.DeleteAllOnSubmit(model.T_CLNT_HYPTHTCL_ILLUS);
                ctx.T_CLNT_HYPTHTCL_FLGs.DeleteAllOnSubmit(model.T_CLNT_HYPTHTCL_FLGs);
                ctx.T_CLNT_HYPTHTCLs.DeleteOnSubmit(model);
                ctx.SubmitChanges();
            }
        }


        public Guid CreateSeriesVAShell(Client client)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var entity = new T_CLNT_HYPTHTCL
                {
                    ADV_ID = client.AdvisorID,
                    CLNT_HYPTHTCL_TYP_ID = (int)AnnuityProductType.Variable,
                    CLNT_ID = client.ClientID,
                    HYPTHTCL_GUID = Guid.NewGuid(),
                    HYPTHTCL_NM = "Untitled",
                    HYPTHTCL_DSCR = ""
                };
                ctx.T_CLNT_HYPTHTCLs.InsertOnSubmit(entity);

                ctx.SubmitChanges();

                return entity.HYPTHTCL_GUID.Value;
            }
        }




        public void StartApplication(int hypotheticalId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var annuity = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == hypotheticalId);

                annuity.T_CLNT.CLNT_PRGRS_ID = (int)ClientProgressType.ProductReviewInProgress;

                // get all hypotheticals
                var hyps = ctx.T_CLNT_HYPTHTCLs.Where(g => g.CLNT_ID == annuity.CLNT_ID);
                foreach (var hyp in hyps)
                {
                    if (hyp.APPL_IND == true)
                        hyp.APPL_IND = false;
                }

                annuity.APPL_IND = true;
                ctx.SubmitChanges();
            }
        }


        public SavedProductItem GetApplicationAnnuity(int client_id)
        {
            T_CLNT_HYPTHTCL item = null;
            using (var ctx = new AnnuitiesDataContext())
            {
                item = ctx.T_CLNT_HYPTHTCLs.FirstOrDefault(g => g.CLNT_ID == client_id && g.APPL_IND == true);
                if (item == null)
                    return null;

            }
            return GetSavedAnnuities(client_id).Single(g => g.Id == item.CLNT_HYPTHTCL_ID);
        }

        public FlagsChartModel GetFlagsForHypothetical(int id)
        {

            using (var ctx = new AnnuitiesDataContext())
            {
                var hypo = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == id);
                FlagsChartModel model = new FlagsChartModel
                {
                    hypothetical_id = hypo.CLNT_HYPTHTCL_ID,
                    hypothetical_type = hypo.T_CLNT_HYPTHTCL_TYP_LKUP.CLNT_HYPTHTCL_TYP_NM.ToLower()
                };

                model.chart_flags = (from f in hypo.T_CLNT_HYPTHTCL_FLGs
                                     group f by f.META_VAL into g
                                     select new ChartFlag
                                     {
                                         meta = JsonConvert.DeserializeObject<Dictionary<string, string>>(g.Key),
                                         flags = (from t in g
                                                  select new Flag
                                                  {
                                                      created_time = t.CRT_TS.Ticks,
                                                      position = JsonConvert.DeserializeObject<ChartPosition>(t.FLG_PSTN_PARM_VAL),
                                                      id = t.CLNT_HYPTHTCL_FLG_ID,
                                                      selected_option = t.FLG_DTL,
                                                      hypothetical_id = t.CLNT_HYPTHTCL_ILLUS_ID.ToString()
                                                  }).ToArray()
                                     }).ToArray();
                /*
                 * 
                  var flags = new FlagsChartModel
            {
                hypothetical_id = id,
                hypothetical_type = "sls",
                chart_flags = new ChartFlag[]{
                    new ChartFlag{
                        meta = new Dictionary<string, string>() {
                            { "product", "shield10" },
                            { "term", "1" },
                            { "index", "nasdaq" },
                            { "market", "market-down" }
                        },
                        flags = new Flag[]{
                            new Flag{ id=1, created_time=1367524386000, selected_option="Step Rate", position=new ChartPosition{ x=156,y=208 } },
                            new Flag{ id=2, created_time=1367524386000, selected_option="Fees & Charges", position=new ChartPosition{ x=568,y=126 } }
                        }
                    },
                    new ChartFlag{
                        meta = new Dictionary<string, string>() {
                            { "product", "shield10" },
                            { "term", "1" },
                            { "index", "nasdaq" },
                            { "market", "market-up" }
                        },
                        flags = new Flag[]{
                            new Flag{ id=3, created_time=1367524386000, selected_option="Death Benefit", position=new ChartPosition{ x=95,y=135 } },
                            new Flag{ id=4, created_time=1367524386000, selected_option="Term Length", position=new ChartPosition{ x=670,y=200 } }
                        }
                    }
                }
            };*/

                return model;
            }
        }

        public int SaveFlag(int hypotheticalId, int illustrationId, Dictionary<string, string> meta, Flag flag, string action)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                T_CLNT_HYPTHTCL_FLG model = null;
                if (action == "insert")
                {
                    model = new T_CLNT_HYPTHTCL_FLG
                    {
                        CLNT_HYPTHTCL_ILLUS_ID = hypotheticalId,
                        FLG_PSTN_PARM_VAL = JsonConvert.SerializeObject(flag.position, Formatting.None),
                        META_VAL = JsonConvert.SerializeObject(meta),
                        FLG_DTL = flag.selected_option
                    };
                    ctx.T_CLNT_HYPTHTCL_FLGs.InsertOnSubmit(model);
                }
                else
                {
                    model = ctx.T_CLNT_HYPTHTCL_FLGs.Single(g => g.CLNT_HYPTHTCL_FLG_ID == flag.id);
                    if (action == "update")
                    {
                        model.CLNT_HYPTHTCL_ILLUS_ID = hypotheticalId;
                        model.FLG_PSTN_PARM_VAL = JsonConvert.SerializeObject(flag.position, Formatting.None);
                        model.META_VAL = JsonConvert.SerializeObject(meta);
                        model.FLG_DTL = flag.selected_option;
                    }
                }

                ctx.SubmitChanges();
                return model.CLNT_HYPTHTCL_FLG_ID;
            }
        }


        public void DeleteFlag(int flag_id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                ctx.T_CLNT_HYPTHTCL_FLGs.DeleteOnSubmit(ctx.T_CLNT_HYPTHTCL_FLGs.Single(g => g.CLNT_HYPTHTCL_FLG_ID == flag_id));
                ctx.SubmitChanges();
            };
        }


        public void UpdateSummaryItem(SavedProductItem summary)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == summary.Id);
                model.INIT_INVST_AMT = summary.InitialInvestment;
                model.PROD_TYP_NM = summary.ProductTypeName;
                model.PROD_ADD_ON_NM = summary.ProductAddOnNames;
                model.RCV_PY_VAL = summary.ReceivePayments;
                ctx.SubmitChanges();
            }
        }

           //var hypo = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == id);
           //     FlagsChartModel model = new FlagsChartModel
           //     {
           //         hypothetical_id = hypo.CLNT_HYPTHTCL_ID,
           //         hypothetical_type = hypo.T_CLNT_HYPTHTCL_TYP_LKUP.CLNT_HYPTHTCL_TYP_NM.ToLower()
           //     };

           //     model.chart_flags = (from f in hypo.T_CLNT_HYPTHTCL_FLGs
           //                          group f by f.META_VAL into g
           //                          select new ChartFlag
           //                          {
           //                              meta = JsonConvert.DeserializeObject<Dictionary<string, string>>(g.Key),
           //                              flags = (from t in g
           //                                       select new Flag
           //                                       {
           //                                           created_time = t.CRT_TS.Ticks,
           //                                           position = JsonConvert.DeserializeObject<ChartPosition>(t.FLG_PSTN_PARM_VAL),
           //                                           id = t.CLNT_HYPTHTCL_FLG_ID,
           //                                           selected_option = t.FLG_DTL
           //                                       }).ToArray()
           //                          }).ToArray();

        public Flag GetLastFlagForClient(int client_id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = (from h in ctx.T_CLNT_HYPTHTCL_FLGs
                                 join ch in ctx.T_CLNT_HYPTHTCLs on 
                                     h.CLNT_HYPTHTCL_ILLUS_ID equals ch.CLNT_HYPTHTCL_ID
                                 where ch.CLNT_ID == client_id
                                 orderby h.CRT_TS descending
                                select new Flag
                             {
                                 created_time = h.CRT_TS.Ticks,
                                 position = JsonConvert.DeserializeObject<ChartPosition>(h.FLG_PSTN_PARM_VAL),
                                 id = h.CLNT_HYPTHTCL_FLG_ID,
                                 hypothetical_id = h.CLNT_HYPTHTCL_ILLUS_ID.ToString(),
                                 selected_option = h.FLG_DTL
                             }).FirstOrDefault();
 
                return model; 
            }
            
        }


        public void SaveApplicationConsent(Client client, SavedProductItem annuity, Hypothetical hypothetical, string productCode, bool epcConsent, bool prospectusSent, advisor advisor)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                T_E_PRSP_CNSNT consent = new T_E_PRSP_CNSNT
                {
                    CLNT_ID = client.ClientID,
                    E_PRSP_CNSNT_ID = epcConsent ? 1 : 0,
                    PLN_CD = productCode,
                    PRSP_SNT_DT = DateTime.UtcNow,
                    EPC_CNSNT_IND = epcConsent
                };

                ctx.T_E_PRSP_CNSNTs.InsertOnSubmit(consent);

                ctx.SubmitChanges();
            }
        }


        public Advisor GetAdvisorBySystemId(string systemId)
        {
            int id = 0;
            using (var ctx = new AnnuitiesDataContext())
            {
                id = ctx.T_ADVs.Single(g => g.SYS_ID == systemId).ADV_ID;
            }
            return GetAdvisor(id);
        }


        public void SaveAdvisor(Advisor advisor)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var entity = ctx.T_ADVs.Single(g => g.ADV_ID == advisor.AdvisorID);
                entity.SYS_ID = advisor.SystemID;
                ctx.SubmitChanges();
            }
        }

        public SavedProductItem GetAnnuity(Guid guid)
        {
            int id = 0;

            using (var ctx = new AnnuitiesDataContext())
            {
                id = ctx.T_CLNT_HYPTHTCLs.Single(g => g.HYPTHTCL_GUID == guid).CLNT_HYPTHTCL_ID;
            }

            return GetAnnuity(id);
        }

        public SavedProductItem GetAnnuity(int annuity_id)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = from c in ctx.T_CLNT_HYPTHTCLs
                            where c.CLNT_HYPTHTCL_ID == annuity_id &&
                            (c.ILLUS_DATA != null || c.CLNT_HYPTHTCL_TYP_ID == 2)
                            select new SavedProductItem
                            {
                                CreatedBy = c.CRT_USR_ID,
                                CreatedDate = c.CRT_TS,
                                InitialInvestment = c.INIT_INVST_AMT,
                                Id = c.CLNT_HYPTHTCL_ID,
                                Name = c.HYPTHTCL_NM,
                                ProductTypeName = c.PROD_TYP_NM,
                                PurchasePayment = c.PRCH_PY_VAL,
                                ReceivePayments = c.RCV_PY_VAL,
                                ProductAddOnNames = c.PROD_ADD_ON_NM,
                                ShieldLevels = (from g in c.T_SHLD_LVLs
                                                select new ShieldLevel
                                                {
                                                    Name = g.SHLD_TYP_NM,
                                                    AllocationPercent = g.ALLOC_AMT,
                                                    Index = g.MKT_IDX_VAL,
                                                    Term = g.TRM_LNTH,
                                                    //Protection = g.PROTECTION,
                                                    Subname = g.SHLD_SB_NM,
                                                    Protection = g.PROT_AMT
                                                }).ToArray(),
                                ProductType = (AnnuityProductType)c.CLNT_HYPTHTCL_TYP_ID,
                                HasError = c.CLNT_HYPTHTCL_EX_ID != null

                            };

                return query.Single();
            }
        }


        public Benefit[] GetBenefits()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return (from c in ctx.T_BEN_TYP_LKUPs
                        select new Benefit
                        {
                            BenefitName = c.BEN_TYP_DSCR,
                            Id = c.BEN_TYP_ID
                        }).ToArray();
            }
        }


        public void MarkApplicationPurchased(int annuityId)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var model = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == annuityId);
                model.CLNT_VW_ENABL_IND = true;
                ctx.SubmitChanges();
            }
        }

        public bool IsDNSSEmail(string email)
        {
            email = string.IsNullOrWhiteSpace(email) ? "" : email;
            if (email.ToLower().EndsWith("@metlife.com"))
                return false;
            using (var ctx = new AnnuitiesDataContext())
            {
                var itm = ctx.T_DNSS_EMAILs.Where(e => e.EMAIL_ADR_TXT == email).FirstOrDefault();
                if (itm != null)
                    return true;
                else
                    return false;
            }
        }

        public bool IsDNSSEmail(List<string> emails, ref string[] dnssEmails)
        {
            emails = emails.Where(e => !string.IsNullOrWhiteSpace(e) && !e.ToLower().EndsWith("@metlife.com")).ToList();
            using (var ctx = new AnnuitiesDataContext())
            {
                dnssEmails = (from e in ctx.T_DNSS_EMAILs
                              where emails.Contains(e.EMAIL_ADR_TXT)
                              select e.EMAIL_ADR_TXT).ToArray();
                
                if (dnssEmails != null && dnssEmails.Length > 0)
                    return true;
                else
                    return false;
            }
        }

        public void LogAdvisorLogon(string systemId, string notes)
        {
            using (var mig = new MIGDataContext())
            {
                int? actID = null;
                mig.Con_AddActivity(ConfigurationManager.AppSettings["ActivityUserId"], systemId, DateTime.Now, notes, ConfigurationManager.AppSettings["LogonActivityCategory"], 0, DateTime.Now, ConfigurationManager.AppSettings["ActivityUserId"], string.Empty, ConfigurationManager.AppSettings["LogonActivitySubCategory"], false, ref actID);
            }
        }

        /// <summary>
        /// Fetches all products from T_PRD_LKUP table
        /// </summary>
        /// <returns>Dictionary object of Products</returns>
        public Dictionary<string, string> GetProducts()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var list = ctx.T_PRD_LKUPs.Select(p => p.PRD_CD).ToList();
                var dict = list.Select((s, i) => new { s, i }).ToDictionary(x => x.s, x => x.s);
                return dict;

            }
        }
        /// <summary>
        /// This method fetches all the channels from T_DSTR_LKUP table
        /// </summary>
        /// <returns>Dictionary object of channels</returns>
        public Dictionary<string, string> GetChannels()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var list = ctx.T_DSTR_LKUPs.Select(p => p.DSTR_CD).Distinct().ToList();
                var dict = list.Select((s, i) => new { s, i }).ToDictionary(x => x.s, x => x.s);
                return dict;
            }
        }

        /// <summary>
        ///  This method fetches all doc codes from T_Doc table with combination of description and name
        /// </summary>
        /// <returns>Dictionary object of Doc Codes</returns>
        public Dictionary<string, string> GetDocCombined()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = (from e in ctx.T_DOCs.Distinct()

                             select new
                             {
                                 CombinedVal = (e.DOC_CD + " - " + e.DOC_TYP_DSCR + " - " + e.DOC_NM)
                             }).Distinct().ToList();
                var dict = query.Select((s, i) => new { s, i }).ToDictionary(x => x.s.CombinedVal.ToString(), x => x.s.CombinedVal.ToString());
                return dict;
            }
        }

        /// <summary>
        /// This method fetches all active doc codes from T_Doc table with combination of description and name
        /// </summary>
        /// <returns>Dictionary object of Doc Codes</returns>
        public Dictionary<string, string> GetActiveDocCombined()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = (from e in ctx.T_DOCs.Distinct()
                             where e.ACT_IND == true
                             select new
                             {
                                 CombinedVal = (e.DOC_CD + " - " + e.DOC_TYP_DSCR + " - " + e.DOC_NM)
                             }).Distinct().ToList();
                var dict = query.Select((s, i) => new { s, i }).ToDictionary(x => x.s.CombinedVal.ToString(), x => x.s.CombinedVal.ToString());
                return dict;
            }
        }

        /// <summary>
        /// This method fetches record from T_Doc table against doc code,product and channel
        /// </summary>
        /// <param name="doc_cd"></param>
        /// <param name="doc_prd"></param>
        /// <param name="dstr_cd"></param>
        /// <returns>Object of Doc Class</returns>
        public Doc GetTDocDetails(string doc_cd, string doc_prd, string dstr_cd)
        {
            try
            {
                using (var ctx = new AnnuitiesDataContext())
                {
                    var model = ctx.T_DOCs.SingleOrDefault(g => (g.DOC_CD.Equals(doc_cd) && g.DOC_PRD.Equals(doc_prd) && g.DSTR_CD.Equals(dstr_cd)));
                    var tdoc = new Doc
                    {
                        DOC_CD = model.DOC_CD,
                        DOC_NM = model.DOC_NM,
                        DOC_DSCR = model.DOC_DSCR,
                        DOC_PATH_VAL = (string.IsNullOrWhiteSpace(model.DOC_PATH_VAL) ? model.DOC_PATH_VAL : model.DOC_PATH_VAL.Replace("##BASE_URL##", ConfigurationManager.AppSettings["baseurl"])),
                        DSTR_CD = model.DSTR_CD,
                        DOC_RQR_IND = model.DOC_RQR_IND,
                        DOC_TYP_DSCR = model.DOC_TYP_DSCR,
                        DOC_PRD = model.DOC_PRD,
                        Active = model.ACT_IND
                    };

                    return tdoc;

                }
            }
            catch (Exception)
            {

                throw;
            }

        }
        /// <summary>
        /// This method Updates record of T_Doc table
        /// </summary>
        /// <param name="doc_cd"></param>
        /// <param name="doc_prd"></param>
        /// <param name="dstr_typ"></param>
        /// <param name="docs"></param>
        /// <param name="errorMessage">Output parameter</param>
        /// <returns>Boolean value</returns>
        public bool UpdateDocDetails(string doc_cd, string doc_prd, string dstr_typ, Doc docs, out string errorMessage)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                bool retVal = false;
                errorMessage = string.Empty;
                string outputmessage = string.Empty;

                try
                {

                    int updt = ctx.am_Update_Doc("Update Doc", docs.DOC_CD, docs.StateID, null, null, docs.LST_UPDT_BY_USR_ID, DateTime.UtcNow, docs.DOC_PRD, docs.DSTR_CD, docs.DOC_NM, docs.DOC_RQR_IND, docs.DOC_DSCR, docs.DOC_PATH_VAL, docs.DOC_TYP_DSCR, docs.Active, doc_cd, null, doc_prd, dstr_typ, ref outputmessage);
                    if (outputmessage != "Success")
                    {
                        errorMessage = string.Format(UPDATEEXCEPTIONMESSAGE, outputmessage);
                    }
                    else
                    {
                        errorMessage = SUCCESSUPDATEMESSAGE;
                        retVal = true;
                    }


                }
                catch (Exception ex)
                {

                    retVal = false;
                    errorMessage = string.Format(UPDATEEXCEPTIONMESSAGE, ex.Message);
                }



                return retVal;


            }
        }
        /// <summary>
        /// This method fetches record from T_Doc_ST table against doc code,product,channel and sate
        /// </summary>
        /// <param name="doc_cd"></param>
        /// <param name="doc_prd"></param>
        /// <param name="dstr_cd"></param>
        /// <param name="st"></param>
        /// <returns>Object of Doc Class</returns>
        public Doc GetStateDocDetails(string doc_cd, string doc_prd, string dstr_cd, int st)
        {
            try
            {
                using (var ctx = new AnnuitiesDataContext())
                {


                    var model = (from x in ctx.T_DOC_STs
                                 join y in ctx.T_DOCs
                                                          on new { x.DOC_CD, x.DOC_PRD, x.DSTR_CD } equals new { y.DOC_CD, y.DOC_PRD, y.DSTR_CD }
                                 where x.DOC_CD.Equals(doc_cd) && x.DOC_PRD.Equals(doc_prd) && x.DSTR_CD.Equals(dstr_cd) && x.ST_ID.Equals(st)
                                 select new
                                 {
                                     DOC_CD = x.DOC_CD,
                                     Combined = (x.DOC_CD + " - " + y.DOC_TYP_DSCR + " - " + y.DOC_NM),
                                     DSTR_CD = x.DSTR_CD,
                                     DOC_PRD = x.DOC_PRD,
                                     StateId = x.ST_ID,
                                     Active = x.act_ind

                                 }).SingleOrDefault();

                    var tdoc = new Doc
                    {
                        DOC_CD = model.DOC_CD,
                        DSTR_CD = model.DSTR_CD,
                        StateID = model.StateId,
                        DOC_Combined = model.Combined,
                        DOC_PRD = model.DOC_PRD,
                        Active = model.Active
                    };

                    return tdoc;
                }
            }
            catch (Exception)
            {

                throw;
            }


        }
        /// <summary>
        ///  This method Updates record of T_Doc_ST table
        /// </summary>
        /// <param name="doc_cd"></param>
        /// <param name="doc_prd"></param>
        /// <param name="dstr_typ"></param>
        /// <param name="st"></param>
        /// <param name="docs"></param>
        /// <param name="errorMessage">Output Parameter</param>
        /// <returns>Boolean value</returns>
        public bool UpdateStateDocDetails(string doc_cd, string doc_prd, string dstr_typ, int st, Doc docs, out string errorMessage)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                bool retVal = false;
                errorMessage = string.Empty;
                string outputmessage = string.Empty;
                try
                {
                    int updt = ctx.am_Update_Doc("Update ST", docs.DOC_Combined, docs.StateID, null, null, docs.LST_UPDT_BY_USR_ID, DateTime.UtcNow, docs.DOC_PRD, docs.DSTR_CD, docs.DOC_NM, docs.DOC_RQR_IND, docs.DOC_DSCR, docs.DOC_PATH_VAL, docs.DOC_TYP_DSCR, docs.Active, doc_cd, st, doc_prd, dstr_typ, ref outputmessage);
                    if (outputmessage != "Success")
                    {
                        errorMessage = string.Format(UPDATEEXCEPTIONMESSAGE, outputmessage);
                    }
                    else
                    {
                        errorMessage = SUCCESSUPDATEMESSAGE;
                        retVal = true;
                    }
                }
                catch (Exception ex)
                {
                    retVal = false;
                    errorMessage = string.Format(UPDATEEXCEPTIONMESSAGE, ex.Message);

                }


                return retVal;


            }
        }
        /// <summary>
        ///  This method adds record of T_Doc table
        /// </summary>
        /// <param name="docs"></param>
        /// <param name="errorMessage">Output Parameter</param>
        /// <returns>Boolean Value</returns>
        public bool AddDocDetails(Doc docs, out string errorMessage)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                bool retVal = false;
                errorMessage = string.Empty;
                T_DOC tDoc = new T_DOC();
                try
                {
                    tDoc.DOC_PRD = docs.DOC_PRD;
                    tDoc.DOC_CD = docs.DOC_CD;
                    tDoc.DOC_NM = docs.DOC_NM;
                    tDoc.DOC_DSCR = docs.DOC_DSCR;
                    tDoc.DOC_PATH_VAL = docs.DOC_PATH_VAL;
                    tDoc.DSTR_CD = docs.DSTR_CD;
                    tDoc.DOC_RQR_IND = docs.DOC_RQR_IND;
                    tDoc.DOC_TYP_DSCR = docs.DOC_TYP_DSCR;
                    tDoc.DOC_DSCR = docs.DOC_DSCR;
                    tDoc.CRT_USR_ID = docs.CRT_USR_ID;
                    tDoc.LST_UPDT_BY_USR_ID = docs.CRT_USR_ID;
                    tDoc.ACT_IND = true;
                    ctx.T_DOCs.InsertOnSubmit(tDoc);
                    ctx.SubmitChanges();
                    errorMessage = SUCCESSADDMESSAGE;
                    retVal = true;
                }
                catch (Exception ex)
                {
                    retVal = false;
                    errorMessage = string.Format(INSERTEXCEPTIONMESSAGE, ex.Message);

                }


                return retVal;
            }
           


        }
        /// <summary>
        /// This method adds record of T_Doc_ST tables
        /// </summary>
        /// <param name="docs"></param>
        /// <param name="errorMessage">Output Parameter</param>
        /// <returns>Boolean Value</returns>
        public bool AddStateDocDetails(Doc docs, out string errorMessage)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                bool retVal = false;
                errorMessage = string.Empty;
                T_DOC_ST tDoc = new T_DOC_ST();
                try
                {
                    tDoc.DOC_PRD = docs.DOC_PRD;
                    tDoc.DOC_CD = docs.DOC_Combined;
                    tDoc.DSTR_CD = docs.DSTR_CD;
                    tDoc.ST_ID = docs.StateID;
                    tDoc.CRT_USR_ID = docs.CRT_USR_ID;
                    tDoc.act_ind = true;
                    ctx.T_DOC_STs.InsertOnSubmit(tDoc);
                    ctx.SubmitChanges();
                    errorMessage = SUCCESSADDMESSAGE;
                    retVal = true;
                }
                catch (Exception ex)
                {
                    retVal = false;
                    errorMessage = string.Format(INSERTEXCEPTIONMESSAGE, ex.Message);

                }


                return retVal;
            }
           


        }

        /// <summary>
        /// This method checks for active states for a doc code, product and channel
        /// </summary>
        /// <param name="doc_cd"></param>
        /// <param name="doc_prd"></param>
        /// <param name="dstr_typ"></param>
        /// <param name="errorMessage">output Parameter</param>
        /// <returns>Boolean Value</returns>
        public bool CheckForStateReferenceActiveDocument(string doc_cd, string doc_prd, string dstr_typ, out string errorMessage)
        {
            bool retval = false;
            errorMessage = string.Empty;
            try
            {
                using (var ctx = new AnnuitiesDataContext())
                {
                    int cnt = ctx.T_DOC_STs.Count(me => me.DOC_CD == doc_cd && me.DOC_PRD == doc_prd && me.DSTR_CD == dstr_typ && me.act_ind == true);
                    if (cnt != 0)
                    {
                        errorMessage = STATEMAPPINGERROR;
                        retval = true;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return retval;
        }

        /// <summary>
        /// This method checks for document to be active for a doc code, product and channel
        /// </summary>
        /// <param name="doc_cd"></param>
        /// <param name="doc_prd"></param>
        /// <param name="dstr_typ"></param>
        /// <param name="errorMessage">Output Parameter</param>
        /// <returns>Boolean Value</returns>
        public bool CheckForActiveDocument(string doc_cd, string doc_prd, string dstr_typ, out string errorMessage)
        {
            bool retval = false;
            errorMessage = string.Empty;
            try
            {
                using (var ctx = new AnnuitiesDataContext())
                {
                    int cnt = ctx.T_DOCs.Count(me => me.DOC_CD == doc_cd && me.DOC_PRD == doc_prd && me.DSTR_CD == dstr_typ);
                    int cntTrue = ctx.T_DOCs.Count(me => me.DOC_CD == doc_cd && me.DOC_PRD == doc_prd && me.DSTR_CD == dstr_typ && me.ACT_IND == true);
                    if (cnt != 0 && cntTrue == 0)
                    {
                        errorMessage = ACTIVEDOCUMENTERROR;
                        retval = true;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            return retval;
        }
        /// <summary>
        ///  This method searches against state, channel,product and active field
        /// </summary>
        /// <param name="state"></param>
        /// <param name="channel"></param>
        /// <param name="product"></param>
        /// <param name="active"></param>
        /// <returns>List Object of Doc Class</returns>
        public List<Doc> SearchDoc(string state, string channel, string product, string active)
        {
            List<Doc> retval = new List<Doc>();
            bool? act_ind = null;
            if (!string.IsNullOrEmpty(active))
                act_ind = Convert.ToBoolean(active);

            using (var ctx = new AnnuitiesDataContext())
            {
                if (!string.IsNullOrEmpty(state))
                {
                    retval = (from s in ctx.T_DOC_STs
                              join d in ctx.T_DOCs
                              on new { s.DOC_CD, s.DSTR_CD, s.DOC_PRD } equals new { d.DOC_CD, d.DSTR_CD, d.DOC_PRD }
                              where (string.IsNullOrEmpty(channel)) ? s.DSTR_CD == s.DSTR_CD : s.DSTR_CD == channel
                              where (string.IsNullOrEmpty(product)) ? s.DOC_PRD == s.DOC_PRD : s.DOC_PRD == product
                              where (string.IsNullOrEmpty(state)) ? s.ST_ID == s.ST_ID : s.ST_ID == Convert.ToInt32(state)
                              where (act_ind == null) ? d.ACT_IND == d.ACT_IND : d.ACT_IND == act_ind
                              select new Doc
                              {
                                  DOC_CD = d.DOC_CD,
                                  DOC_NM = d.DOC_NM,
                                  DOC_TYP_DSCR = d.DOC_TYP_DSCR,
                                  DOC_PATH_VAL = (string.IsNullOrWhiteSpace(d.DOC_PATH_VAL) ? d.DOC_PATH_VAL : d.DOC_PATH_VAL.Replace("##BASE_URL##", ConfigurationManager.AppSettings["baseurl"])),
                                  DOC_RQR_IND = d.DOC_RQR_IND,
                                  DOC_PRD = d.DOC_PRD,
                                  DSTR_CD = d.DSTR_CD,
                                  Active = d.ACT_IND
                              }).Distinct().ToList<Doc>();

                }
                else
                {
                    retval = (from d in ctx.T_DOCs
                              where (string.IsNullOrEmpty(channel)) ? d.DSTR_CD == d.DSTR_CD : d.DSTR_CD == channel
                              where (string.IsNullOrEmpty(product)) ? d.DOC_PRD == d.DOC_PRD : d.DOC_PRD == product
                              where (act_ind == null) ? d.ACT_IND == d.ACT_IND : d.ACT_IND == act_ind
                              select new Doc
                              {
                                  DOC_CD = d.DOC_CD,
                                  DOC_NM = d.DOC_NM,
                                  DOC_TYP_DSCR = d.DOC_TYP_DSCR,
                                  DOC_PATH_VAL = (string.IsNullOrWhiteSpace(d.DOC_PATH_VAL) ? d.DOC_PATH_VAL : d.DOC_PATH_VAL.Replace("##BASE_URL##", ConfigurationManager.AppSettings["baseurl"])),
                                  DOC_RQR_IND = d.DOC_RQR_IND,
                                  DOC_PRD = d.DOC_PRD,
                                  DSTR_CD = d.DSTR_CD,
                                  Active = d.ACT_IND
                              }).Distinct().ToList<Doc>();
                }
                return retval;
            }
        }
        /// <summary>
        /// This method searches state mapping against doc code
        /// </summary>
        /// <param name="docCode"></param>
        /// <returns>List Object of Doc Class</returns>
        public List<Doc> SearchStateDocMapping(string docCode)
        {
            List<Doc> retval = new List<Doc>();
            using (var ctx = new AnnuitiesDataContext())
            {
                retval = (from s in ctx.T_DOC_STs

                          join st in ctx.T_ST_PRVNC_LKUPs
                          on s.ST_ID equals st.ST_ID
                          where (string.IsNullOrEmpty(docCode)) ? s.DOC_CD == s.DOC_CD : s.DOC_CD == docCode
                          select new Doc
                          {
                              DOC_CD = s.DOC_CD,
                              StateID = s.ST_ID,
                              State = st.ST_PRVNC_CD,
                              DOC_PRD = s.DOC_PRD,
                              DSTR_CD = s.DSTR_CD,
                              Active = s.act_ind
                          }).Distinct().ToList<Doc>();

                return retval;
            }
        }
    }
}
