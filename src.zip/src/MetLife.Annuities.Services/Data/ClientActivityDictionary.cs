﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Data
{
    public class ClientActivityDictionary : Dictionary<ClientActivityType, string>
    {

    }
}
