﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Content
{
    public interface IContentService
    {

        disclaimer[] GetDisclaimer(string disclaimerID);

        disclaimer[] GetProductDisclaimer(bool EDBMax, string planCode);

        document_item[] GetRelatedDocuments(bool EDBMax, string planCode, string state, string advisorType);

        video[] GetAdvisorIntroTutorials(string advisorId);

        resources_collection GetClientResources(string clientState, string advisorUniversalID);

        video[] GetDefaultVideosForPersona(int personaId);

        video[] GetPersonaVideosForIds(int[] video_ids);

        personas GetPersonas();

        persona GetPersona(int persona_id);

        shield_configuration_data GetSLSConfiguration();

        market_indexes GetMarketIndexes();

        products GetProducts();

        allocations GetAllocations();

        advisor_tutorials GetAdvisorTutorials();

        advisor_faqs GetAdvisorFAQs();

        disclosures GetDisclosures();

        video[] GetVideosByCategory(string categoryName);

        global_config GetGlobalConfiguration();
    }
}
