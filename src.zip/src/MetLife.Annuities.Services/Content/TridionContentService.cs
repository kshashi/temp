﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using System.Xml;
using MetLife.Annuities.Services.Fulfillment;
using MetLife.Annuities.Services.Advisors;

namespace MetLife.Annuities.Services.Content
{
    public class TridianContentService : IContentService
    {
        TridionContainer tridion = new TridionContainer();
        AdvisorService _advisorService = new AdvisorService();

        public video[] GetAdvisorIntroTutorials(string advisorId)
        {
            return null;
        }

        public resources_collection GetClientResources(string clientState, string advisorUniversalID)
        {
            var resources = tridion.GetComponent<resources_collection>().Item;
            //resources.videos = resources.videos.DistinctBy(g => g.uri).ToArray();
            var adv = _advisorService.GetAdvisor(advisorUniversalID);
            var advisorPlanCodes = _advisorService.GetPlanCodesForAdvisor(advisorUniversalID, clientState);
            var products = this.GetProducts();

            var retval = new resources_collection();
            retval.faqs = resources.faqs;
            retval.glossary = resources.glossary;

            //retval.videos = resources.videos;

            List<video> filteredVideos = new List<video>();

            foreach (var v in resources.videos)
            {
                if (_advisorService.ShowVideo(advisorUniversalID,clientState,v.category))
                    filteredVideos.Add(v);
            }

            retval.videos = filteredVideos.ToArray();

            retval.documents = null;

            List<document_item> filteredDocs = new List<document_item>();

            foreach (var di in resources.documents)
            {
                if ((from p in products.product
                     join pc in di.plan_codes on p.plan_code equals pc
                     join apc in advisorPlanCodes on p.plan_code equals apc
                     where (adv.advisor_type.ToUpper() != "TPD" || (p.distribution.ToUpper() == "BOTH" || p.distribution.ToUpper() == "TPD"))
                     select p).Count() > 0)
                {
                    filteredDocs.Add(di);
                }

            }
            
            ISharePoint SharePointService = new SharePoint();
            List<document_item> prospectus = (from f in SharePointService.GetFormList(clientState, advisorUniversalID,adv.advisor_type).Where(g => g.type.ToString() == "Prospectus").Distinct()
                                              select new
                                              {
                                                  title = f.name,
                                                  link = f.path,
                                                  type = f.type.ToString(),
                                                  name = f.type.ToString()
                                              }).Distinct().Select(d => new document_item { title = d.title, link = d.link, category = new category() { description = d.type, name = d.name } }).ToList();

            if (prospectus != null)
                filteredDocs.AddRange(prospectus);

            retval.documents = (from d in filteredDocs
                                select new document_item
                                {
                                    category = d.category,
                                    death_benefits = d.death_benefits,
                                    description = d.description,
                                    id = d.id,
                                    link = (d.link != null ? d.link.Replace("##BASE_URL##", System.Configuration.ConfigurationManager.AppSettings["baseurl"]) : ""),
                                    plan_codes = d.plan_codes,
                                    riders = d.riders,
                                    title = d.title
                                }).ToArray();
            return retval;
        }

        public video[] GetDefaultVideosForPersona(int personaId)
        {
            throw new NotImplementedException();
        }

        public video[] GetPersonaVideosForIds(int[] video_ids)
        {
            throw new NotImplementedException();
        }

        public personas GetPersonas()
        {
            return tridion.GetComponent<personas>().Item;
        }

        public persona GetPersona(int persona_id)
        {
            return tridion.GetComponent<personas>().Item.persona
                 .Where(g => g.id == persona_id.ToString())
                 .Single();
        }

        public shield_configuration_data GetSLSConfiguration()
        {
            return tridion.GetComponent<shield_configuration_data>().Item;
        }

        public market_indexes GetMarketIndexes()
        {
            return tridion.GetComponent<market_indexes>().Item;
        }

        public allocations GetAllocations()
        {
            return tridion.GetComponent<allocations>().Item;
        }

        public products GetProducts()
        {
            return tridion.GetComponent<products>().Item;
        }

        public advisor_tutorials GetAdvisorTutorials()
        {
            return tridion.GetComponent<advisor_tutorials>().Item;
        }

        public advisor_faqs GetAdvisorFAQs()
        {
            return tridion.GetComponent<advisor_faqs>().Item;
        }

        public disclosures GetDisclosures()
        {
            return tridion.GetComponent<disclosures>().Item;
        }

        public disclaimer[] GetDisclaimer(string disclaimerID)
        {
            return tridion.GetComponent<disclaimers>().Item.disclaimer.Where(g => g.id.Equals(disclaimerID, StringComparison.InvariantCultureIgnoreCase)).ToArray();
        }

        public disclaimer[] GetProductDisclaimer(bool EDBMax, string planCode)
        {
            var allDisclaimers = tridion.GetComponent<disclaimers>().Item.disclaimer;

            if (!EDBMax)
            {
                allDisclaimers = allDisclaimers.Where(x => x.plan_codes != null && x.death_benefits == null).ToArray();
                return allDisclaimers.Where(x => x.plan_codes.Select(g => g.ToLower()).Contains(planCode.ToLower())).ToArray();
            }
            else
            {
                allDisclaimers = allDisclaimers = allDisclaimers.Where(x => x.plan_codes != null && x.death_benefits != null).ToArray();
                return allDisclaimers.Where(x => x.plan_codes.Select(g => g.ToLower()).Contains(planCode.ToLower()) && x.death_benefits.Contains("EDB Max")).ToArray();
            }
        }

        public document_item[] GetRelatedDocuments(bool EDBMax, string planCode, string state, string advisorType)
        {
            var allDocs = tridion.GetComponent<resources_collection>().Item.documents.ToList();

            allDocs = (from d in allDocs
                       select new document_item
                       {
                           category = d.category,
                           death_benefits = d.death_benefits,
                           description = d.description,
                           id = d.id,
                           link = (d.link != null ? d.link.Replace("##BASE_URL##", System.Configuration.ConfigurationManager.AppSettings["baseurl"]) : ""),
                           plan_codes = d.plan_codes,
                           riders = d.riders,
                           title = d.title
                       }).ToList();

            if (!EDBMax)
            {
                allDocs = allDocs.Where(x => x.plan_codes != null && x.death_benefits == null).ToList();
                allDocs = allDocs.Where(x => x.plan_codes.Select(g => g.ToLower()).Contains(planCode.ToLower())).ToList();
            }
            else
            {
                allDocs = allDocs.Where(x => x.plan_codes != null && x.death_benefits != null).ToList();
                allDocs = allDocs.Where(x => x.plan_codes.Select(g => g.ToLower()).Contains(planCode.ToLower()) && x.death_benefits.Contains("EDB Max")).ToList();
            }

            ISharePoint SharePointService = new SharePoint();
            form prospectus = SharePointService.GetFormList(planCode, state, advisorType)
                    .SingleOrDefault(g => g.type.ToString() == "Prospectus");

            if (prospectus != null)
                allDocs.Add(new document_item() { title = prospectus.name, link = prospectus.path });
            return allDocs.ToArray();
        }

        public video[] GetVideosByCategory(string categoryName)
        {
            return tridion.GetComponent<resources_collection>().Item.videos.Where(g => g.category.name == categoryName).ToArray();
        }


        public global_config GetGlobalConfiguration()
        {
            return tridion.GetComponent<global_config>().Item;
        }
    }
}