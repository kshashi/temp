﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;
using MetLife.Annuities.Services.Models;


namespace MetLife.Annuities.Services.Fulfillment
{
    public interface ISharePoint
    {
        form[] GetTDOCForms();

        Stream GetDocument(string file);

        string[] GetPlanCodes(string stateCode, List<string> tridionPlanCodes);

        Stream GetFile(string doc_path_val);
        
        form[] GetFormList(string productName, string state, string advisorType);

        //form[] GetFormList(string state, string advisorType);

        form[] GetDistinctTDOCForms();
    }
}
