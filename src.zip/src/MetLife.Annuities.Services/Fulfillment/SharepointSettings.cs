﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace MetLife.Annuities.Services.Fulfillment
{
    public class SharePointSettings : ConfigurationSection
    {
        public SharePointSettings()
        {
        }

        public static SharePointSettings GetSettings()
        {
            SharePointSettings settings = System.Configuration.ConfigurationManager.GetSection("mlisharePoint") as SharePointSettings;
            return settings;
        }

        [ConfigurationProperty("url", DefaultValue = "", IsRequired = false)]
        public string URL
        {
            get
            {
                return (string)base["url"];
            }
        }

        [ConfigurationProperty("userName", DefaultValue = "", IsRequired = true)]
        public string UserName
        {
            get
            {
                return (string)base["userName"];
            }
        }

        [ConfigurationProperty("password", DefaultValue = "", IsRequired = true)]
        public string Password
        {
            get
            {
                return (string)base["password"];
            }
        }

        [ConfigurationProperty("domain", DefaultValue = "", IsRequired = true)]
        public string Domain
        {
            get
            {
                return (string)base["domain"];
            }
        }
    }
}
