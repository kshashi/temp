﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Fulfillment
{
    public class DocumentInfo
    {
        public string ID { get; set; }
        public string FileName { get; set; }
        public int FileSize { get; set; }
    }
}
