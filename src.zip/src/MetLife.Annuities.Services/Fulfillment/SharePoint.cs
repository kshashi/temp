﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;
using System.Web;
using System.IO;
using System.Net;
using System.ServiceModel.Web;
using System.Configuration;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Advisors;


namespace MetLife.Annuities.Services.Fulfillment
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class SharePoint : ISharePoint
    {
        AdvisorService _advisorService = new AdvisorService();

        public Stream GetDocument(string file)
        {
            if (!string.IsNullOrEmpty(file))
            {
                string filePath = file;
                bool addCreds = false;


                SharePointSettings settings = SharePointSettings.GetSettings();

                if (!filePath.Contains("http"))
                {
                    filePath = settings.URL + file;
                    addCreds = true;
                }

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(filePath);

                if (addCreds)
                {
                    request.Credentials = new NetworkCredential(settings.UserName, settings.Password, settings.Domain);
                }

                // Set some reasonable limits on resources used by this request
                request.MaximumAutomaticRedirections = 4;
                request.MaximumResponseHeadersLength = 4;

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (WebOperationContext.Current != null)
                {
                    WebOperationContext.Current.OutgoingResponse.ContentType = response.ContentType;
                    WebOperationContext.Current.OutgoingResponse.ContentLength = response.ContentLength;
                    //string fileName = System.IO.Path.GetFileName(filePath);
                    WebOperationContext.Current.OutgoingResponse.Headers.Add("Content-Disposition", "inline; filename=" + file);
                }
                return response.GetResponseStream();
            }
            return null;
        }

        public Stream GetFile(string doc_path_val)
        {
            var webclient = new WebClient();
            byte[] doc = webclient.DownloadData(doc_path_val);
            return new MemoryStream(doc);
        }

        public string[] GetPlanCodes(string stateCode,  List<string> tridionPlanCodes)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                //If the prospectus exists in IBANNMET, the state is approved for the plan code
                var q = from ds in ctx.T_DOC_STs
                        join sl in ctx.T_ST_PRVNC_LKUPs on
                        ds.ST_ID equals sl.ST_ID
                        join pcl in ctx.T_PLN_CD_LKUPs on
                        ds.DOC_PRD equals pcl.DOC_PRD
                        join d in ctx.T_DOCs on
                        ds.DOC_CD equals d.DOC_CD
                        where sl.ST_PRVNC_CD == stateCode && d.DOC_TYP_DSCR == "Prospectus"
                        where d.ACT_IND == true
                        select pcl.PLN_CD.ToString();

                List<string> retVal = new List<string>();

                foreach (var pl in q)
                {
                    if (tridionPlanCodes.Contains(pl.ToString()))
                        retVal.Add(pl.ToString());
                };

                return retVal.ToArray();
            }
        }

        public form[] GetTDOCForms()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = from d in ctx.T_DOCs
                            where d.ACT_IND == true
                            select new form
                            {
                                doc_code = d.DOC_CD,
                                name = d.DOC_NM,
                                description = d.DOC_DSCR,
                                type = d.DOC_TYP_DSCR,
                                path = (string.IsNullOrWhiteSpace(d.DOC_PATH_VAL) ? d.DOC_PATH_VAL : d.DOC_PATH_VAL.Replace("##BASE_URL##", ConfigurationManager.AppSettings["baseurl"])),
                                document_product_code = d.DOC_PRD,
                                distribution = d.DSTR_CD
                            };
                return query.ToArray();
            }
        }

        public form[] GetDistinctTDOCForms()
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var query = (from d in ctx.T_DOCs
                             where d.ACT_IND == true
                            select new form
                            {
                                doc_code = d.DOC_CD,
                                path = (string.IsNullOrWhiteSpace(d.DOC_PATH_VAL) ? d.DOC_PATH_VAL : d.DOC_PATH_VAL.Replace("##BASE_URL##", ConfigurationManager.AppSettings["baseurl"]))
                                
                            }).Distinct();
                return query.ToArray();
            }
        }
            
        public form[] GetFormList(string planCode, string state, string advisorType)
        {
            string key = string.Concat("forms", planCode, state, advisorType);

            form[] forms = CacheLayer.Get<form[]>(key);

            if (forms != null)
                return forms;

            using (var ctx = new AnnuitiesDataContext())
            {
                var query = from d in ctx.T_DOCs
                            join ds in ctx.T_DOC_STs on
                            new { d.DOC_CD, d.DSTR_CD, d.DOC_PRD } equals new { ds.DOC_CD, ds.DSTR_CD, ds.DOC_PRD }
                            join st in ctx.T_ST_PRVNC_LKUPs on
                            ds.ST_ID equals st.ST_ID
                            join dc in ctx.T_PLN_CD_LKUPs on
                            ds.DOC_PRD equals dc.DOC_PRD
                            where st.ST_PRVNC_CD == state && dc.PLN_CD == planCode && d.DSTR_CD == advisorType
                            where d.ACT_IND == true
                            select new form
                            {
                                doc_code = d.DOC_CD,
                                name = d.DOC_NM,
                               description =  d.DOC_DSCR,
                               type = d.DOC_TYP_DSCR,
                               path = (d.DOC_PATH_VAL == null) ? string.Empty : d.DOC_PATH_VAL.Replace("##BASE_URL##", ConfigurationManager.AppSettings["baseurl"]),
                               plan_code =  dc.PLN_CD,
                               document_product_code =d.DOC_PRD,
                               distribution = d.DSTR_CD
                            };
                CacheLayer.AddShort(query.ToArray(), key);
                return query.ToArray();
            };

        }

      }
}
