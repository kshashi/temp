﻿using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace MetLife.Annuities.Services.Fulfillment
{
    public static class Extensions
    {
        public static XElement GetXElement(this XmlNode node)
        {
            XDocument xDoc = new XDocument();
            using (XmlWriter xmlWriter = xDoc.CreateWriter())
                node.WriteTo(xmlWriter);
            return xDoc.Root;
        }

        #region Conversions

        public static string ToStringEX(this Stream stream)
        {
            using (StreamReader reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }
        }

        #endregion
    }
}
