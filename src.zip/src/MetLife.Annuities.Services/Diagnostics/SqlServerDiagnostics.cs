﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Data;

namespace MetLife.Annuities.Services.Diagnostics
{
    public class SqlServerDiagnostics
    {
        public string TestConnection()
        {

            using (var context = new AnnuitiesDataContext())
            {
                try
                {
                    var mr = context.T_MRY_STTs.First();
                    return context.Connection.ConnectionString + ": connection succeeded";
                }
                catch (Exception ex)
                {
                    return "Error connecting to " + context.Connection.ConnectionString + ": " + ex.Message;
                }
            }


        }
    }
}
