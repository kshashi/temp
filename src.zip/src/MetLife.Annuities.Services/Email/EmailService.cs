﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Collections;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Annuities;
using System.IO;

namespace MetLife.Annuities.Services.Email
{
    public class EmailService : IEmailService
    {
        private TridionContainer Tridion = new TridionContainer();

        public void SendAdvisorInvite(advisor advisor, string rvpName, string inviteUrl)
        {
            email_template template = GetTridionTemplate("sendadvisorinvite");
            EmailSender sender = new EmailSender(template, advisor.email.ToString());
            var replacements = new Dictionary<string, string>();
            replacements.Add("##ADVISOR_FIRST_NAME##", advisor.first_name);
            replacements.Add("##RVP_NAME##", rvpName);
            sender.ReplyTo = template.reply_to;
            sender.SendEmail(replacements, template.do_not_email_applicable);
        }

        public void SendFeedbackEmail(string type, string content, string fromEmail, string fromName)
        {
            var template = GetTridionTemplate("feedback");
            var sender = new EmailSender(template, template.from.address);
            var replacements = new Dictionary<string, string>();
            replacements.Add("##USER_NAME##", fromName );
            replacements.Add("##FEEDBACK_TYPE##", type);
            replacements.Add("##FEEDBACK_TEXT##", content);
            sender.ReplyTo = fromEmail;
            sender.SendEmail(replacements, template.do_not_email_applicable);
        }


        public void SendNewClientEmail(AnnuityProductType annuityProductType, Client client, advisor advisor, string inviteUrl)
        {
            EmailSender sender;
            Dictionary<string, string> replacements;
            string applyDNSS = string.Empty;
            SetupNewClientEmail(annuityProductType, client, advisor, inviteUrl, out sender, out replacements, out applyDNSS);
            sender.SendEmail(replacements, applyDNSS);
        }

        public string PreviewNewClientEmail(AnnuityProductType annuityProductType, Client client, advisor advisor, string inviteUrl)
        {
            EmailSender sender;
            Dictionary<string, string> replacements;
            string applyDNSS = string.Empty;
            SetupNewClientEmail(annuityProductType, client, advisor, inviteUrl, out sender, out replacements, out applyDNSS);
            return sender.PreviewEmail(replacements);
        }

        public string PreviewWelcomeEmail(Client client, advisor advisor)
        {
            var template = GetTridionTemplate("welcome");
            var sender = new EmailSender(template, client.EmailAddress);
            var replacements = new Dictionary<string, string>
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName},
                {"##ADVISOR_FIRST_NAME##",advisor.first_name},
                {"##ADVISOR_LAST_NAME##",advisor.last_name},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1},
                {"##ADVISOR_CITY##",advisor.address.city},
                {"##ADVISOR_STATE##",advisor.address.state},
                {"##ADVISOR_ZIP##",advisor.address.zip},
                {"##ADVISOR_PHONE##",advisor.phone_numbers[0].number},
                {"##ADVISOR_FAX##",advisor.phone_numbers[0].number},
                {"##ADVISOR_EMAIL##",advisor.email}
            };

            return sender.PreviewEmail(replacements);
        }

        public string PreviewReengageEmail(Client client, advisor advisor)
        {
            EmailSender sender;
            Dictionary<string, string> replacements;
            string applyDNSS = string.Empty;
            PrepareReengageEmail(client, advisor, out sender, out replacements, out applyDNSS);

            return sender.PreviewEmail(replacements);
        }

        private void PrepareReengageEmail(Client client, advisor advisor, out EmailSender sender, out Dictionary<string, string> replacements, out string applyDNSS)
        {
            var template = GetTridionTemplate("reengage");
            sender = new EmailSender(template, client.EmailAddress);
            replacements = new Dictionary<string, string>
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName},
                {"##ADVISOR_FIRST_NAME##",advisor.first_name},
                {"##ADVISOR_LAST_NAME##",advisor.last_name},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1},
                {"##ADVISOR_CITY##",advisor.address.city},
                {"##ADVISOR_STATE##",advisor.address.state},
                {"##ADVISOR_ZIP##",advisor.address.zip},
                {"##ADVISOR_PHONE##",advisor.phone_numbers[0].number},
                {"##ADVISOR_FAX##",advisor.phone_numbers[0].number},
                {"##ADVISOR_EMAIL##",advisor.email},
                {"##IMAGE_NAME##",advisor.profile_image_uri}
            };
            applyDNSS = template.do_not_email_applicable;
        }

        public void SendReengageEmail(Client client, advisor advisor)
        {
            EmailSender sender;
            Dictionary<string, string> replacements;
            string applyDNSS = string.Empty;
            PrepareReengageEmail(client, advisor, out sender, out replacements, out applyDNSS);
            sender.CC = advisor.email;
            sender.ReplyTo = advisor.email;
            sender.SendEmail(replacements, applyDNSS);
        }

        private void SetupNewClientEmail(AnnuityProductType annuityProductType, Client client, advisor advisor, string inviteUrl, out EmailSender sender, out Dictionary<string, string> replacements, out string applyDNSS)
        {

            email_template template = null;
            switch (annuityProductType)
            {
                case AnnuityProductType.Variable:
                    template = GetTridionTemplate("welcome_seriesva");
                    break;
                case AnnuityProductType.ShieldLevel:
                    template = GetTridionTemplate("welcome_sls");
                    break;
                default:
                    break;
            }

            sender = new EmailSender(template, client.EmailAddress);
            sender.CC = advisor.email;
            sender.ReplyTo = advisor.email;
            replacements = new Dictionary<string, string>()
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName},
                {"##ADVISOR_FIRST_NAME##",advisor.first_name.ToString()},
                {"##ADVISOR_LAST_NAME##",advisor.last_name.ToString()},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1.ToString()},
                {"##ADVISOR_ADDRESS_LINE2##",(advisor.address.address_line_2 == null ? "" : advisor.address.address_line_2.ToString())},
                {"##ADVISOR_CITY##",advisor.address.city.ToString()},
                {"##ADVISOR_STATE##",advisor.address.state.ToString()},
                {"##ADVISOR_ZIP##",advisor.address.zip.ToString()},
                {"##ADVISOR_PHONE##",advisor.phone_numbers.First().number.ToString()},
                {"##ADVISOR_FAX##",advisor.phone_numbers.First().number.ToString()},
                {"##ADVISOR_EMAIL##",advisor.email.ToString()},
                {"##CREATE_PASSWORD_URL##",inviteUrl},
                {"##IMAGE_NAME##",advisor.profile_image_uri}
            };
            applyDNSS = template.do_not_email_applicable;
        }

        public string PreviewChartEnabled(AnnuityProductType annuityProductType, Client client, advisor advisor, object annuity)
        {
            Dictionary<string, string> replacements;
            EmailSender emailsender;
            string applyDNSS = string.Empty;
            PrepareChartEnabled(annuityProductType, client, advisor, out replacements, out emailsender, annuity, out applyDNSS);
            return emailsender.PreviewEmail(replacements);
        }

        public void SendChartEnabled(AnnuityProductType annuityProductType, Client client, advisor advisor, object annuity)
        {
            Dictionary<string, string> replacements;
            EmailSender sender;
            string applyDNSS = string.Empty;
            PrepareChartEnabled(annuityProductType, client, advisor, out replacements, out sender, annuity, out applyDNSS);
            sender.CC = advisor.email;
            sender.ReplyTo = advisor.email;
            sender.SendEmail(replacements, applyDNSS);

        }

        private void PrepareChartEnabled(AnnuityProductType annuityProductType, Client client, advisor advisor, out Dictionary<string, string> replacements, out EmailSender sender, object annuity, out string applyDNSS)
        {
            email_template template = null;
            replacements = new Dictionary<string, string>
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName},
                {"##ADVISOR_FIRST_NAME##",advisor.first_name},
                {"##ADVISOR_LAST_NAME##",advisor.last_name},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1},
                {"##ADVISOR_CITY##",advisor.address.city},
                {"##ADVISOR_STATE##",advisor.address.state},
                {"##ADVISOR_ZIP##",advisor.address.zip},
                {"##ADVISOR_PHONE##",advisor.phone_numbers[0].number},
                {"##ADVISOR_FAX##",advisor.phone_numbers[0].number},
                {"##ADVISOR_EMAIL##",advisor.email},
                {"##IMAGE_NAME##",advisor.profile_image_uri}
            };
            template = GetTridionTemplate("interactive_chart");
            switch (annuityProductType)
            {
                case AnnuityProductType.Variable:
                    Hypothetical hypo = (Hypothetical)annuity;
                    replacements.Add("##ANNUITY_URL##", "/clients/seriesva/gmib?id=" + hypo.Id);
                    break;
                case AnnuityProductType.ShieldLevel:
                    ShieldProduct product = (ShieldProduct)annuity;
                    replacements.Add("##ANNUITY_URL##", "/clients/sls/protection?id=" + product.Id);
                    break;
                default:
                    break;
            }

            applyDNSS = template.do_not_email_applicable;
            sender = new EmailSender(template, client.EmailAddress);
        }

        private email_template GetTridionTemplate(string templateId)
        {
            return Tridion.GetComponent<email_templates>()
                .Item.email_template
                .Single(g => g.id == templateId);
        }
        
        public void SendPaperProspectusEmail(Client client, advisor advisor)
        {
            var template = GetTridionTemplate("prospectusDeclined");
            var replacements = new Dictionary<string, string>
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName}, 
                {"##CLIENT_LAST_NAME##",client.LastName},
                {"##ADVISOR_FIRST_NAME##",advisor.first_name},
                {"##ADVISOR_LAST_NAME##",advisor.last_name},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1},
                {"##ADVISOR_CITY##",advisor.address.city},
                {"##ADVISOR_STATE##",advisor.address.state},
                {"##ADVISOR_ZIP##",advisor.address.zip},
                {"##ADVISOR_PHONE##",advisor.phone_numbers[0].number},
                {"##ADVISOR_FAX##",advisor.phone_numbers[0].number},
                {"##ADVISOR_EMAIL##",advisor.email}
            };
            var sender = new EmailSender(template, advisor.email);
            sender.ReplyTo = template.reply_to;
            sender.SendEmail(replacements, template.do_not_email_applicable);
        }


        public void SendAdvisorFlagNotification(advisor advisor, Client client, SavedProductItem annuity)
        {
            var template = GetTridionTemplate("Flag_Advisor");
            var replacements = new Dictionary<string, string>
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName}, 
                {"##CLIENT_LAST_NAME##",client.LastName},
                {"##CLIENT_ADDRESS##",client.Address1}, 
                {"##CLIENT_CITY##",client.City},
                {"##CLIENT_STATE##",client.StateCode}, 
                {"##CLIENT_ZIP##",client.Zip},
                {"##CLIENT_PHONE##",client.PhoneNumbers[0].Number}, 
                {"##CLIENT_FAX##",client.PhoneNumbers[0].Number},
                {"##CLIENT_EMAIL##",client.EmailAddress},                 
                {"##ADVISOR_FIRST_NAME##",advisor.first_name},
                {"##ADVISOR_LAST_NAME##",advisor.last_name},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1},
                {"##ADVISOR_CITY##",advisor.address.city},
                {"##ADVISOR_STATE##",advisor.address.state},
                {"##ADVISOR_ZIP##",advisor.address.zip},
                {"##ADVISOR_PHONE##",advisor.phone_numbers[0].number},
                {"##ADVISOR_FAX##",advisor.phone_numbers[0].number},
                {"##ADVISOR_EMAIL##",advisor.email},
                {"##ANNUITY_NAME##",annuity.Name},
                {"##ANNUITY_TYPE##",annuity.ProductTypeName}

            };
            var sender = new EmailSender(template, advisor.email);
            sender.ReplyTo = template.reply_to;
            sender.SendEmail(replacements, template.do_not_email_applicable);
        }

        public void SendProspectus(Client client, advisor advisor, form prospectus, SavedProductItem product, Stream filestream)
        {
            var template = GetTridionTemplate("prospectusConsent");

            var replacements = new Dictionary<string, string>
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName}, 
                {"##CLIENT_LAST_NAME##",client.LastName},
                {"##CLIENT_ADDRESS##",client.Address1}, 
                {"##CLIENT_CITY##",client.City},
                {"##CLIENT_STATE##",client.StateCode}, 
                {"##CLIENT_ZIP##",client.Zip},
                {"##CLIENT_PHONE##",client.PhoneNumbers[0].Number}, 
                {"##CLIENT_FAX##",client.PhoneNumbers[0].Number},
                {"##CLIENT_EMAIL##",client.EmailAddress},                 
                {"##ADVISOR_FIRST_NAME##",advisor.first_name},
                {"##ADVISOR_LAST_NAME##",advisor.last_name},
                {"##ADVISOR_ADDRESS_LINE1##",advisor.address.address_line_1},
                {"##ADVISOR_CITY##",advisor.address.city},
                {"##ADVISOR_STATE##",advisor.address.state},
                {"##ADVISOR_ZIP##",advisor.address.zip},
                {"##ADVISOR_PHONE##",advisor.phone_numbers[0].number},
                {"##ADVISOR_FAX##",advisor.phone_numbers[0].number},
                {"##ADVISOR_EMAIL##",advisor.email},
                {"##ANNUITY_NAME##",product.Name},
                {"##ANNUITY_TYPE##",product.ProductTypeName},
                {"##IMAGE_NAME##",advisor.profile_image_uri},
                {"##PROSPECTUS_URL##",prospectus.path},
                {"##PRODUCT_NAME##", product.Name}

            };
            var sender = new EmailSender(template, client.EmailAddress);
            sender.CC = advisor.email;
            sender.ReplyTo = advisor.email;
            sender.Attachments.Add(new Attachment(filestream, prospectus.name + ".pdf"));
            sender.SendEmail(replacements, template.do_not_email_applicable);
        }
        
        public void SendPasswordResetEmail(Client client)
        {
            var template = GetTridionTemplate("clientpassword");
            var sender = new EmailSender(template, client.EmailAddress);
            var replacements = new Dictionary<string, string>()
            {
                {"##CLIENT_FIRST_NAME##",client.FirstName}
            };
            sender.ReplyTo = template.reply_to;
            sender.SendEmail(replacements, template.do_not_email_applicable);
        }
    }
}
