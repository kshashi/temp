﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Net.Mail;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Services.Data;
using System.IO;

namespace MetLife.Annuities.Services.Email
{

    public interface IEmailService
    {
        void SendProspectus(Client client, advisor advisor, form prospectus, SavedProductItem product, Stream filestream);

        void SendAdvisorInvite(advisor advisor, string rvpName, string inviteUrl);

        void SendFeedbackEmail(string type, string content, string fromEmail, string fromDisplay);

        void SendNewClientEmail(AnnuityProductType annuityProductType, Client client, advisor advisor, string inviteUrl);

        string PreviewNewClientEmail(AnnuityProductType annuityProductType, Client client, advisor advisor, string inviteUrl);

        string PreviewReengageEmail(Client client, advisor advisor);

        string PreviewWelcomeEmail(Client client, advisor advisor);

        void SendReengageEmail(Client client, advisor advisor);

        string PreviewChartEnabled(AnnuityProductType annuityProductType, Client client, advisor advisor, object annuity);

        void SendChartEnabled(AnnuityProductType annuityProductType, Client client, advisor advisor, object annuity);

        void SendPaperProspectusEmail(Client SelectedClient, advisor advisor);

        void SendAdvisorFlagNotification(advisor advisor, Client client, SavedProductItem annuity);

        void SendPasswordResetEmail(Client client);
    }
}
