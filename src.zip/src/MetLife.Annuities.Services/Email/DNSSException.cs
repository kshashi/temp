﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MetLife.Annuities.Services.Email
{
    [Serializable]
    public class DNSSException : Exception
    {
        public string[] emails { get; set; }
        public DNSSException()
        {
        }

        public DNSSException(string message)
            : base(message)
        {
        }

        public DNSSException(string message, string[] dnssEmails)
            : base(message)
        {
            this.emails = dnssEmails;
        }


        public DNSSException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected DNSSException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            if (info != null)
            {
                var lst = info.GetValue("emails", emails.GetType());
                if (lst != null)
                this.emails = (string[])lst;
            }
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            if (info != null)
            {
                info.AddValue("emails", emails);
            }
        }
    }
}
