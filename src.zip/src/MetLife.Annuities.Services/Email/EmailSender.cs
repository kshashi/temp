﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Web.UI.WebControls;
using MetLife.Annuities.Services.Models;
using System.Text.RegularExpressions;

namespace MetLife.Annuities.Services.Email
{
    public class EmailSender
    {
        private email_template _template;
        private string _toEmail;
        private string _fromEmail;
        private string _fromDisplayName;
        public string CC { get; set; }
        private List<Attachment> _attachments;
        public List<Attachment> Attachments
        {
            get
            {
                if (_attachments == null)
                    _attachments = new List<Attachment>();
                return _attachments;
            }
        }
        public void SendEmail(Dictionary<string, string> bodyFields, string applyDNSSFilter)
        {
            // TO DO: If client is on DO NOT SOLICIT List, throw do not solicit exception

            MailDefinition def = new MailDefinition();
            MailMessage msg = new MailMessage(_fromEmail, _toEmail, _template.subject, _template.body);

            if (!bodyFields.ContainsKey("##BASE_URL##"))
                bodyFields.Add("##BASE_URL##", System.Configuration.ConfigurationManager.AppSettings["baseurl"]);

            foreach (var field in bodyFields.Keys)
            {
                msg.Body = msg.Body.Replace(field, bodyFields[field]);
                msg.Subject = msg.Subject.Replace(field, bodyFields[field]);
            }

            if (!string.IsNullOrEmpty(_template.reply_to) && _template.reply_to.Contains(char.Parse("@")))
                msg.ReplyToList.Add(new MailAddress(_template.reply_to));
            msg.IsBodyHtml = true;

            msg.From = new MailAddress(_fromEmail, _fromDisplayName);
            msg.Sender = new MailAddress(ConfigurationManager.AppSettings["EmailSenderAddress"], ConfigurationManager.AppSettings["EmailSenderName"]);

            if (!string.IsNullOrEmpty(ReplyTo))
                msg.ReplyToList.Add(new MailAddress(ReplyTo));
            if (!string.IsNullOrEmpty(CC))
                msg.CC.Add(new MailAddress(this.CC));

            if (this.Attachments.Count() > 0)
            {
                foreach (var attachment in Attachments)
                {
                    msg.Attachments.Add(attachment);
                }
            }

            SmtpClient smtp = new SmtpClient();

            msg.Body = msg.Body.Replace("##FOOTER##", _template.footer);
            msg.Body = msg.Body.Replace("<![CDATA[", "");
            msg.Body = msg.Body.Replace("]]>", "");


            List<string> allEmails = msg.To.Select(e => e.Address).ToList();
            allEmails.AddRange(msg.CC.Select(e => e.Address).ToList());
            allEmails.AddRange(msg.Bcc.Select(e => e.Address).ToList());

            MetLife.Annuities.Services.Data.IDataService dataService = new MetLife.Annuities.Services.Data.SqlDataService();

            string[] dnssEmails = null;
            applyDNSSFilter = string.IsNullOrWhiteSpace(applyDNSSFilter) ? "" : applyDNSSFilter.ToLower();
            if (applyDNSSFilter == "true" && dataService.IsDNSSEmail(allEmails, ref dnssEmails))
                throw new DNSSException("Email in DNSS", dnssEmails);
            else
                smtp.Send(msg);
        }

        public string PreviewEmail(Dictionary<string, string> bodyFields)
        {
            MailDefinition def = new MailDefinition();
            MailMessage msg = new MailMessage(_fromEmail, _toEmail, _template.subject, _template.body);

            if (!bodyFields.ContainsKey("##BASE_URL##"))
                bodyFields.Add("##BASE_URL##", System.Configuration.ConfigurationManager.AppSettings["baseurl"]);

            foreach (var field in bodyFields.Keys)
            {
                msg.Body = msg.Body.Replace(field, bodyFields[field]);
            }

            // replace live links
            string pattern = @"href=""([^""]+)""";
            Regex rgx = new Regex(pattern);

            msg.Body = rgx.Replace(msg.Body, "href=\"#\"");
            msg.Body = msg.Body.Replace("##FOOTER##", _template.footer);
            msg.Body = msg.Body.Replace("<![CDATA[", "");
            msg.Body = msg.Body.Replace("]]>", "");

            return msg.Body;
        }

        public EmailSender(email_template template, string toEmail)
        {
            _template = template;
            _toEmail = toEmail;
            _fromEmail = template.from.address;
            _fromDisplayName = template.from.display_name;
        }

        //public EmailSender(email_template template, string toEmail, string fromEmail, string fromDisplayName)
        //{
        //    _template = template;
        //    _toEmail = toEmail;
        //    _fromEmail = fromEmail;
        //    _fromDisplayName = fromDisplayName;
        //}



        public string ReplyTo { get; set; }
    }
}
