﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services
{
    public enum GenderType
    {
        Male = 0,
        Female = 1
    }
}
