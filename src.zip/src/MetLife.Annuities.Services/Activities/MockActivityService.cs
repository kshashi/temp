﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Activities
{
    public class MockActivityService : IActivityService
    {
        public void AddActivity(ActivityTypes type, string clientId)
        {
            throw new NotImplementedException();
        }

        public activity[] GetClientsActivity(string advisorId)
        {
            throw new NotImplementedException();
        }
    }
}
