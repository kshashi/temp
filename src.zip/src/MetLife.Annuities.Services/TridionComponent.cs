﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services
{
    public class TridionComponent<T>
    {
        public DateTime LastUpdated { get; set; }
        public T Item { get; set; }

    }
}
