﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace MetLife.Annuities.Services
{
    public class TridionConfiguration
    {

        public static string TridionWebServiceUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["TridionWebServiceUrl"];
            }
        }

        public static int TridionPublicationId
        {
            get
            {
                return int.Parse(ConfigurationManager.AppSettings["TridionPublicationId"]);
            }
        }
    }
}
