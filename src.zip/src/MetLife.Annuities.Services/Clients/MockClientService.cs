﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Clients
{
    public class MockClientService : IClientService
    {
        public client[] GetClientsForAdvisor(string advisorId)
        {
            return new client[] {
                new client{  
                    first_name="Sandy", 
                    last_name="Myers",
                   address = new address{  
                       city="Miami", 
                       state="Florida",
                    },
                    id=1,
                    current_progress= new clientCurrent_progress{ percent_complete=10, status_text="Completed Profile"},
                    last_activity=DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                    notifications = new notification[] { 
                            new notification{ date= DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                            description="Bob Johnson added a flag to her annuity tool.",
                            id=1,
                            title="Flag Added",
                            type="FlagAdded"
                        }
                        }},
                new client{  
                    first_name="John", 
                    last_name="Nielsen",
                   address = new address{  
                       city="Miami", 
                       state="Florida",
                    },
             
                    id=2,
                    current_progress= new clientCurrent_progress{ percent_complete=10, status_text="Completed Profile"},
                    last_activity=DateTime.UtcNow.AddHours(new Random(DateTime.Now.Second).Next(1,100)),
                    notifications = new notification[] { 
                            new notification{ date= DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                            description="Bob Johnson added a flag to her annuity tool.",
                            id=1,
                            title="Flag Added",
                            type="FlagAdded"
                        },    
                            new notification{ date= DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                            description="Bob Johnson added a flag to her annuity tool.",
                            id=1,
                            title="Flag Added",
                            type="FlagAdded"
                        }}} ,
                new client{  
                    first_name="Misty", 
                    last_name="Pillars",
                    address = new address{  
                       city="Miami", 
                       state="Florida",
                    },
             
                    id=3,
                    current_progress= new clientCurrent_progress{ percent_complete=10, status_text="Completed Profile"},
                    last_activity=DateTime.UtcNow.AddHours(new Random(DateTime.Now.Second).Next(1,100)),
                    notifications = new notification[] { 
                            new notification{ date= DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                            description="Bob Johnson added a flag to her annuity tool.",
                            id=1,
                            title="Flag Added",
                            type="FlagAdded"
                        }
                    }}
                         
            };
        }

        public client GetClient(int id)
        {
            return new client
            {
                first_name = "Sandy",
                last_name = "Myers",
                address = new address
                {
                    city = "Miami",
                    state = "Florida",
                },
                id = 1,
                current_progress = new clientCurrent_progress { percent_complete = 10, status_text = "Completed Profile" },
                last_activity = DateTime.UtcNow.AddHours(-new Random(DateTime.Now.Second).Next(1, 100)),
                notifications = new notification[] { 
                            new notification{ date= DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                            description="Bob Johnson added a flag to her annuity tool.",
                            id=1,
                            title="Flag Added",
                            type="FlagAdded"
                        }
                        }
            };
        }

        public string[] GetPersonaVideosIds(string clientUserId)
        {
            return new[] { "1", "2" };
        }


        public client GetClient(string clientUserId)
        {
            return new client
            {
                first_name = "Sandy",
                last_name = "Myers",
                address = new address
                {
                    city = "Miami",
                    state = "Florida",
                },
                id = 1,
                current_progress = new clientCurrent_progress { percent_complete = 10, status_text = "Completed Profile" },
                last_activity = DateTime.UtcNow.AddHours(-new Random(DateTime.Now.Second).Next(1, 100)),
                notifications = new notification[] { 
                            new notification{ date= DateTime.UtcNow.AddHours(- new Random(DateTime.Now.Second).Next(1,100)),
                            description="Bob Johnson added a flag to her annuity tool.",
                            id=1,
                            title="Flag Added",
                            type="FlagAdded"
                        }
                        }
            };
        }
    }
}
