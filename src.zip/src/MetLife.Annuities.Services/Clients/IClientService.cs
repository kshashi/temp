﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Clients
{
	//TODO Consider removing b/c this may be redundant
    public interface IClientService
    {
        client[] GetClientsForAdvisor(string advisorId);

        client GetClient(int id);


        client GetClient(string clientUserId);

        string[] GetPersonaVideosIds(string clientUserId);

     
    }
}
