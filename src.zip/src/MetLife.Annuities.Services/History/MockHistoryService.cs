﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.History
{
    public class MockHistoryService : IHistoryService
    {


        public history[] GetHistory(string clientId)
        {

            return new history[] {
                new history{
                     title="Account Update",
                     body="Sandy Mysers updated her address.",
                     created_date=DateTime.UtcNow.AddDays(-1),
                     type="ACCOUNTUPDATE"
                },
                new history{
                     title="Notes Added",
                     body="Sandy added three follow up flags.",
                     created_date=DateTime.UtcNow.AddDays(-3),
                     type="NOTESADDED"
                },
                new history{
                     title="New Hypothetical Saved",
                     body="Sandy",
                     created_date=DateTime.UtcNow.AddDays(-6),
                     type="NEWHYPOTHETHICAL"
                }
            };

        }

    }
}
