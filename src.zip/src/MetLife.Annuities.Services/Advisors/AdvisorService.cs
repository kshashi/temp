﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Models;
using MetLife.MLI.Services.Proxy.IBSE;
using System.Configuration;
using System.Xml.Linq;
using System.Xml;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Fulfillment;
using MetLife.Annuities.Services.Annuities;
using System.Web;

namespace MetLife.Annuities.Services.Advisors
{
    public class AdvisorService : IAdvisorService
    {
        private IDataService DataService = new SqlDataService();

        public PagedList<Models.advisor> FindAdvisors(string rvpId, string firstName, string lastName, string firmCode, string advisorId, string stateCode, int page, int pageSize, bool rvpRegionOnly, string filter, string sort)
        {

            switch (sort.ToLower())
            {
                case "city":
                case "state":
                    break;
                case "advisor_id":
                    sort = "contactid";
                    break;
                case "first_name":
                    sort = "firstname";
                    break;
                case "firm_name":
                    sort = "firm";
                    break;
                default:
                    break;
            }

            int? annMetStatus = null;
            switch (filter.ToLower())
            {
                case "no_invite_sent":
                    annMetStatus = 1;
                    break;
                case "invite_sent":
                    annMetStatus = 2;
                    break;
                case "activated_account":
                    annMetStatus = 4;
                    break;
                case "clients_entered":
                    annMetStatus = 6;
                    break;
                default:
                    break;
            }

            using (MIGDataContext mig = new MIGDataContext())
            {
                int? count = null;
                var contacts = (from contact in mig.am_search_agent(firstName, lastName, stateCode, firmCode, advisorId, rvpId, rvpRegionOnly, annMetStatus, sort, null, pageSize, page, ref count)
                                select new Models.advisor()
                                {
                                    first_name = contact.firstname.ToString(),
                                    last_name = contact.lastname.ToString(),
                                    address = new Models.address() { city = contact.City.ToString(), state = contact.State.ToString() },
                                    firm = new Models.firm() { entitled = contact.AnnuityMet, firm_name = contact.firmName },
                                    current_status = contact.ANN_MET_STATUS_DESC,
                                    current_status_id = contact.ANN_MET_STATUS_ID.Value,
                                    universal_id = contact.portalname,
                                    system_id = contact.systemid,
                                    email = contact.email
                                }).ToArray();

                count = count.GetValueOrDefault();

                var retval = new PagedList<Models.advisor>();
                int totalPages = 0;
                totalPages = (count.Value % pageSize > 0 ? count.Value / pageSize + 1 : count.Value / pageSize);
                retval.TotalPages = totalPages;
                if (page > totalPages)
                    page = totalPages;
                if (page <= 0)
                    page = 1;

                retval.Items = contacts;
                retval.CurrentPage = page;
                return retval;
            }
        }

        public PagedList<Models.advisor> GetAdvisors(string rvpId, int page, int pageSize)
        {
            return this.FindAdvisors(rvpId, null, null, null, null, null, page, pageSize, true, null, null);
        }

        public Models.advisor GetAdvisor(string universalId)
        {
            return this.GetAdvisor(universalId, string.Empty);
        }

        public Models.advisor GetAdvisor(string universalId, string systemId)
        {
            if (string.IsNullOrWhiteSpace(systemId))
            {
                systemId = this.GetDemoAccountSystemId(universalId);
                if (string.IsNullOrWhiteSpace(systemId))
                    systemId = this.GetSystemId(universalId);
            }
            advisor adv = null;
            using (MIGDataContext mig = new MIGDataContext())
            {

                adv = (from a in mig.am_get_agent(systemId)
                       select new Models.advisor
                       {
                           address = new Models.address() { address_line_1 = a.address1, address_line_2 = a.address2, city = a.City, state = a.State, zip = a.Zipcode },
                           email = a.email,
                           firm = new Models.firm() { firm_name = a.firmName, entitled = a.AnnuityMet, firm_code = a.firmcode },
                           first_name = a.firstname,
                           last_name = a.lastname,
                           phone_numbers = new Models.phone_number[] { new Models.phone_number() { number = a.phone } },
                           current_status = a.ANN_MET_STATUS_DESC,
                           current_status_id = a.ANN_MET_STATUS_ID.Value,
                           universal_id = universalId,
                           system_id = systemId,
                           advisor_type = a.Comp
                       }).SingleOrDefault();

            }
            try
            {
                var advisor = DataService.GetAdvisor(adv.universal_id);
                adv.profile_image_uri = advisor.UserProfile.ProfileImageUrl;
            }
            catch (Exception)
            {

            }

            return adv;
        }

        private string GetDemoAccountSystemId(string universalId)
        {
            if (string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["DemoAdvisorAccounts"]))
                return string.Empty;
			var accounts = ConfigurationManager.AppSettings["DemoAdvisorAccounts"].Split(',');
			foreach (var a in accounts)
			{
				var a2 = a.Split(';');
				if (a2.Length > 1 && a2[0].ToLower() == universalId.ToLower())
				{
                    return a2[1];
				}
			}
			return string.Empty;		
        }

        private string GetSystemId(string universalId)
        {
            using (MIGDataContext mig = new MIGDataContext())
            {
                var advisor = mig.am_get_systemid(null, universalId, null, null, null, null, null, null).FirstOrDefault();
                string sId = string.Empty;
                if (advisor == null)
                {
                    var contactId = this.GetContactId(universalId);
                    if (string.IsNullOrWhiteSpace(contactId))
                        return null;
                    var adv = mig.am_get_systemid(null, null, null, contactId, null, null, null, null).FirstOrDefault();
                    if (adv != null)
                        return adv.systemId;
                    else
                        return null;
                }
                else
                    sId = advisor.systemId;

                return sId;
            }
        }

        private string GetContactId(string universalId)
        {
            Request req = new Request();
            req.Credentials = new Credentials(ConfigurationManager.AppSettings["ESSSMHService.UserID"], ConfigurationManager.AppSettings["ESSSMHService.Password"]);
            var data = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.UserProfileData("1", universalId, "", "", ConfigurationManager.AppSettings["ESSSMHService.ApplicationID"]);
            data.PrflTypCd = "C";
            req.Data = data;
            ProcessRequest reqBody = new ProcessRequest(req);
            MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy ibseProxy = new MetLife.MLI.Services.Proxy.IBSE.UserProfile.IBSEUserProfileProxy();
            ibseProxy.Process(reqBody);

            XDocument doc;
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(ibseProxy.ResponseBody.NameTable);
            nsmgr.AddNamespace("m", "urn:ESSSMHService");

            using (var nodeReader = new XmlNodeReader(ibseProxy.ResponseBody))
            {
                nodeReader.MoveToContent();
                doc = XDocument.Load(nodeReader);
            }

            var d = (from r in doc.Descendants("U") select r).First().Descendants("DAI").First().Value;
            if (string.IsNullOrWhiteSpace(d))
            {
                d = (from r in doc.Descendants("U") select r).First().Descendants("AGT").First().Value;
                if (!string.IsNullOrWhiteSpace(d) && d.Length > 5)
                    d = d.Substring(d.Length - 5);
            }

            if (string.IsNullOrWhiteSpace(d))
                d = (from r in doc.Descendants("U") select r).First().Descendants("BID").First().Value;

            return d;
        }

        public string[] GetPlanCodesForAdvisor(string universalId, string state)    
        {
            string firmCode = GetAdvisor(universalId).firm.firm_code;
            string key = string.Concat("planCodes", firmCode, state);
            string[] retval = CacheLayer.Get<string[]>(key);
                     
            if (retval != null)
                return (string[])retval;

            //Plan codes list comes from MIG then filtered down by Tridion then filtered down by presence of prospectus in T_DOC_ST table
            using (MIGDataContext mig = new MIGDataContext())
            {
                var adv = this.GetAdvisor(universalId);
                ISharePoint SharePointService = new SharePoint();

                //Get Plan Codes from MIG
                System.Collections.Generic.IEnumerable<string> planCodes = (from a in mig.am_get_products(adv.system_id)
                                                                            select a.plancode);
                //Filter by Tridion
                var tridion = new TridionContainer();

                TridionComponent<products> products = tridion.GetComponent<products>();

                //Put the Tridion Plan codes in a list
                List<string> tridionPlanCodes = new List<string>();

                foreach (var p in products.Item.product)
                {
                    tridionPlanCodes.Add(p.plan_code);
                }
                //Apply state filter
                
                retval = SharePointService.GetPlanCodes(state, tridionPlanCodes);

                CacheLayer.AddShort(retval, key);
                return retval;
                }
            }
        
        public bool ShowVideo(string universalId, string state, videoCategory category)
        {
            if (category.name.ToString().ToLower().Contains("shield") || category.name.ToString().ToLower().Contains("sls"))
                return CanSellProductType(universalId,state,AnnuityProductType.ShieldLevel);
            else
                return CanSellProductType(universalId, state, AnnuityProductType.Variable);
        }

        public bool CanSellProductType(string universalId, string state, AnnuityProductType productType)
        {
            List<string> typeList;
            List<AnnuityProductType> impDescList = new List<AnnuityProductType>();

            advisor adv = GetAdvisor(universalId);
            string key = string.Concat("entitled", adv.firm.firm_code, productType,state);
            typeList = CacheLayer.Get<List<string>>(key);

            if (typeList == null)
            {
                typeList = new List<string>();
                string[] planCodes;
                var tridion = new TridionContainer();
                Dictionary<string, string> basic = new Dictionary<string, string>();
                
                var products = tridion.GetComponent<products>().Item.product.ToList();                
                var query = products.ToDictionary(pp => pp.plan_code, pp => pp.product_type_id).Distinct();

                foreach(var item in query)
                {
                    //Create list of plan codes andd product types from Tridion (accepted by Annuities One-On-One)
                    basic.Add(item.Key,item.Value);
                }
               
                planCodes = GetPlanCodesForAdvisor(universalId, state);

                //Compare the the plan codes the advisor can sell to the plan codes AM supports and create new list
                foreach(var item in basic)
                {
                    foreach(var pc in planCodes)
                    {
                        if (item.Key == pc)
                            typeList.Add(item.Value);
                    }
                }
                typeList = typeList.Distinct().ToList();
                CacheLayer.AddShort(typeList, key);
            }
           
            foreach (var pd in typeList)
            {
                if (pd.Contains("shield_annuity_product"))
                    impDescList.Add(AnnuityProductType.ShieldLevel);
                if (pd.Contains("Variable Annuity"))
                    impDescList.Add(AnnuityProductType.Variable);
            }

            foreach(AnnuityProductType pd in impDescList)
            {
                if (pd == productType)
                    return true;
            }

            return false;
        }

        public string[] GetVeriableProducts(string universalId, string state)
        {
            advisor adv = GetAdvisor(universalId);
            string key = string.Concat("products", adv.firm.firm_code, AnnuityProductType.Variable, state);
            List<string> retval = CacheLayer.Get<List<string>>(key);

            if (retval != null)
                return ((List<string>)retval).ToArray();


            if (retval == null)
            {
                retval = new List<string>();

                string[] planCodes;
                planCodes = GetPlanCodesForAdvisor(universalId, state);

                var tridion = new TridionContainer();
                Dictionary<string, string> basic = new Dictionary<string, string>();
                var products = tridion.GetComponent<products>().Item.product.ToList();
                //products = products.Where(a => a.product_type_id.Contains("Variable Annuity"));
                var query = products.Where(a => a.product_type_id.Contains("Variable Annuity")).ToDictionary(pp => pp.plan_code, pp => pp.title).Distinct();
                
                foreach (var item in query)
                {
                    //Create list of plan codes andd product types from Tridion (accepted by Annuities One-On-One)
                    basic.Add(item.Key, item.Value);
                }

                //Compare the the plan codes the advisor can sell to the plan codes AM supports and create new list
                foreach (KeyValuePair<string, string> item in basic)
                {
                    foreach (var pc in planCodes)
                    {
                        if (item.Key == pc)
                            retval.Add(item.Value);
                    }
                }
                retval = retval.Distinct().ToList();
                CacheLayer.AddShort(retval, key);
            }
            return retval.ToArray();
        }

        public void UpdateAdvisorStatus(string universalId, string systemId, AdvisorStatus status)
        {
            using (MIGDataContext mig = new MIGDataContext())
            {
                if (string.IsNullOrWhiteSpace(systemId))
                    systemId = this.GetSystemId(universalId);
                mig.am_update_annmet_contact(systemId, (int)status);
            }
        }

        public firm[] GetEntitledFirms()
        {
            using (MIGDataContext mig = new MIGDataContext())
            {
                var firms = (from f in mig.am_get_annmet_firms()
                             select new firm
                             {
                                 entitled = true,
                                 firm_code = f.firmcode,
                                 firm_name = (f.firmname == null ? string.Empty : f.firmname)
                             }).ToArray();
                return firms;
            }
        }

        public Dictionary<int, string> GetAdvisorStatusList()
        {
            using (MIGDataContext mig = new MIGDataContext())
            {
                return mig.T_ANN_MET_LKUPs.ToDictionary(l => l.ANN_MET_STATUS_ID, l => l.ANN_MET_STATUS_DESC);
            }
        }


        public bool IsTestID(string universalId)
        {
            return !string.IsNullOrWhiteSpace(this.GetDemoAccountSystemId(universalId));
        }
    }
}