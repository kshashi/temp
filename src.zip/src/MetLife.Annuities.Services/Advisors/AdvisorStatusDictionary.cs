﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Advisors
{
    public class AdvisorStatusDictionary : Dictionary<int, string>
    {

        public AdvisorStatusDictionary()
        {
            this.Add(1, "Not Invited");
            this.Add(2, "Invite E-mail Sent");
            this.Add(3, "Account Activated");
            this.Add(4, "Client Set Up");
            this.Add(5, "Active Clients");
        }
    }
}
