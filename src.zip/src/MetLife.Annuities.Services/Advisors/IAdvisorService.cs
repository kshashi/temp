﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using System.ServiceModel;
using System.ServiceModel.Web;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Services.Advisors
{

	public interface IAdvisorService
	{
		PagedList<advisor> FindAdvisors(string rvpId, string firstName, string lastName, string firmCode, string advisorId, string stateCode, int page, int pageSize, bool rvpRegionOnly, string filter, string sort);
		//TODO Consider Removing GetAdvisors in favor of always using FindAdvisors		
		//PagedList<advisor> GetAdvisors(string rvpId, int page, int pageSize);

		Dictionary<int, string> GetAdvisorStatusList();

		advisor GetAdvisor(string universalId, string systemId);

		advisor GetAdvisor(string universalId);

		string[] GetPlanCodesForAdvisor(string universalId, string state);

		firm[] GetEntitledFirms();

		void UpdateAdvisorStatus(string universalId, string systemId, AdvisorStatus statusId);

        bool CanSellProductType(string universalId, string state, AnnuityProductType productType);

        string[] GetVeriableProducts(string universalId, string state);

        bool IsTestID(string universalId);
    }

}
