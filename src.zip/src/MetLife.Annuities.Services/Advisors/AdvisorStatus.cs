﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Advisors
{
    public enum AdvisorStatus
    {
        NotInvited = 1,
        Invited = 2,
        AccountActivated = 4,
        ClientSetup = 6,
        ActiveClients = 5

    }
}
