﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Services.Advisors
{
	public class MockAdvisorService : IAdvisorService
	{
		public PagedList<advisor> FindAdvisors(string rvpId, string firstName, string lastName, string firmCode, string advisorId, string stateCode, int page, int pageSize, bool rvpRegionOnly)
		{/*
			var lst = new[] {
                new advisor{ 
                    first_name="Sandy", 
                    last_name="Myers",
                    address = new address{ 
                        city="Miami", 
                        state="Florida"
                    },
                    id=1,
                    profile_image_uri="http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"},
                new advisor{ 
                    first_name="John", 
                    last_name="Nielsen",
                    address = new address{ 
                        city="Miami", 
                        state="Florida"
                    },
                    id=2,
                    profile_image_uri="http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"},
                new advisor{ 
                    first_name="Jimmy", 
                    last_name="Nelson",
                    address = new address{ 
                        city="Miami", 
                        state="Florida"
                    },
                    id=3,
                    profile_image_uri="http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"},

           };

			var retval = new PagedList<advisor>();
			retval.Items = lst;
			retval.TotalPages = 1;
			retval.CurrentPage = 1;
			return retval;
          * */
            return null;
		}
        //public PagedList<advisor> GetAdvisors(string rvpId, int page, int pageSize)
        //{/*
        //    var items = new[] {
        //        new advisor{ 
        //            first_name="Sandy", 
        //            last_name="Myers",
        //            address = new address{ 
        //                city="Miami", 
        //                state="Florida"
        //            },
        //            id=1,
        //            profile_image_uri="http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"},
        //        new advisor{ 
        //            first_name="John", 
        //            last_name="Nielsen",
        //            address = new address{ 
        //                city="Miami", 
        //                state="Florida"
        //            },
        //            id=2,
        //            profile_image_uri="http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"},
        //        new advisor{ 
        //            first_name="Jimmy", 
        //            last_name="Nelson",
        //            address = new address{ 
        //                city="Miami", 
        //                state="Florida"
        //            },
        //            id=3,
        //            profile_image_uri="http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"},

        //   };

        //    return new PagedList<advisor>() { Items = items, CurrentPage = 1, TotalPages = 1 };
        //    */
        //    return null;
        //}

		public advisor GetAdvisor(string universalId)
		{
			return new advisor
			{
				first_name = "Jimmy",
				last_name = "Nelson",
				email = "jnelson@metlife.com",
				address = new address
				{
					address_line_1 = "1234 Main Street",
					city = "Miami",
					state = "Florida",
					zip = "33133"
				},
				id = 3,
				profile_image_uri = "http://cdn.bleacherreport.net/images_root/users/photos/000/397/654/no-profile-img_crop_38x38.gif"
			};
		}

        public IEnumerable<am_get_productsResult> GetPlanCodesForAdvisor(string universalId)
        {
            throw new NotImplementedException();
        }

    

		public void UpdateAdvisorStatus(string universalId, string systemId, AdvisorStatus statusId)
		{
			throw new NotImplementedException();
		}

        public string[] GetPlanCodesForAdvisor(string universalId, string state)
        {
            throw new NotImplementedException();
        }

		public firm[] GetEntitledFirms()
		{
			var firms = new List<firm>();					
			firms.Add(new firm() { firm_name = "Test Firm", firm_code = "MLI", entitled = true });
			firms.Add(new firm() { firm_code = "CPB", firm_name = "Test Firm 2", entitled = true});
			return firms.ToArray();
		}


		public advisor GetAdvisor(string universalId, string systemId)
		{
			throw new NotImplementedException();
		}

        public bool CanSellProductType(string universalId, string state, AnnuityProductType productType)
        {
            throw new NotImplementedException();
        }

        public string[] GetVeriableProducts(string universalId, string state)
        {
            throw new NotImplementedException();
        }

        public PagedList<advisor> FindAdvisors(string rvpId, string firstName, string lastName, string firmCode, string advisorId, string stateCode, int page, int pageSize, bool rvpRegionOnly, string filter, string sort)
        {
            throw new NotImplementedException();
        }


				public Dictionary<int, string> GetAdvisorStatusList()
				{
					throw new NotImplementedException();
				}


                public bool IsTestID(string universalId)
                {
                    throw new NotImplementedException();
                }
    }

}
