﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services
{
    public enum ClientMilestoneProgressType
    {
        ClientSetup = 1,
        ProductReview = 2,
        ApplicationPurchase = 3
    }
}
