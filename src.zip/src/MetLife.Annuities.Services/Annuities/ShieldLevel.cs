﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Annuities
{
    public class ShieldLevel
    {
        public string Name { get; set; }
        public string Subname { get; set; }
        public decimal Protection { get; set; }
        public int Term { get; set; }
        public string Index { get; set; }
        public decimal AllocationPercent { get; set; }
    }
}
