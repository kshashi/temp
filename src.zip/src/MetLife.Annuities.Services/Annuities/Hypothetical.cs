﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Annuities
{
    public class Hypothetical
    {
        public decimal InitialInvestment { get; set; }
        public int TermLength { get; set; }
        public string ProductPlanCode { get; set; }
        public Illustration[] Illustrations { get; set; }
        public decimal StartingBenefitBase { get; set; }
        public int Id { get; set; }

        public bool HasJointLife { get; set; }

        public bool HasSingleLife { get; set; }

        public bool HasGMIBRider { get; set; }

        public string PayoutOption
        {
            get
            {
                if (HasJointLife)
                    return "Joint/Last Survivor w/5 yrs";
                if (HasSingleLife)
                    return "Single Life w/Period Certain";
                return "";
            }
        }

        public string DeathBenefitType { get; set; }
        public bool PayoutStepUpSelected { get; set; }

        public bool DeathBenefitStepUpSelected { get; set; }

        public bool HasEDB { get; set; }

        public string ProductTypeName { get; set; }

        public string ReceivePayments { get; set; }

        public string Name { get; set; }

        public string ProductAddOnNames { get; set; }

        public groups_root Allocations { get; set; }

        public string DeathBenefitTypeLong { get; set; }


        public bool IsMPP { get; set; }

        public string DocumentProductCode { get; set; }


        public string GuaranteedCompoundingRate { get; set; }
    }
}
