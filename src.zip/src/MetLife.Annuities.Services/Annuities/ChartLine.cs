﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Annuities
{
    public class ChartLine
    {
        private VectorDictionary _vectors = new VectorDictionary();

        public string VectorName { get; set; }
        public string ColumnName
        {
            get
            {
                return _vectors[VectorCode].ColumnName;
            }
        }
        public string LineName
        {
            get
            {
                return _vectors[VectorCode].LineName;
            }
        }

        public string VectorCode { get; set; }
        public DataSeries[] DataSeries { get; set; }
    }
}
