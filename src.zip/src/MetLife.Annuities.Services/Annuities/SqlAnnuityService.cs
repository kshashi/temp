﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Data;
using MetLife.Annuities.Services.Models;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Content;
using System.IO;
using System.Configuration;

namespace MetLife.Annuities.Services.Annuities
{
    public class SqlAnnuityService : IAnnuityService
    {
        private IContentService ContentService = new TridianContentService();

        public Models.annuity_product_category[] GetAvailableProducts(string advisorId)
        {
            throw new NotImplementedException();
        }

        public Hypothetical GetHypothetical(int id)
        {
            HypotheticalTranslator translator = new HypotheticalTranslator();
            var xml = string.Empty;
            groups_root groups = null;
            T_CLNT_HYPTHTCL data = null;
            using (var ctx = new AnnuitiesDataContext())
            {
                data = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == id);
                xml = data.ILLUS_DATA.ToString();
                if (data.ALLOC_DATA != null)
                    groups = JsonConvert.DeserializeObject<groups_root>(data.ALLOC_DATA);
            }

            var hypothetical = translator.TranslateXml(xml);

            hypothetical.Id = data.CLNT_HYPTHTCL_ID;
            hypothetical.Name = data.HYPTHTCL_NM;
            hypothetical.Allocations = groups;
            hypothetical.GuaranteedCompoundingRate = data.HYPTHTCL_DSCR;
            // grab title from tridion
            var product = GetProduct(hypothetical.ProductPlanCode);
            // set the title from tridion
            hypothetical.ProductTypeName = product.title;
            // grab MPP from database
            string mpp = GetProductMPP(hypothetical.ProductPlanCode);
            hypothetical.DocumentProductCode = mpp;
            // set whether its MPP or not
            hypothetical.IsMPP = mpp.ToLower() == "mpp";
            return hypothetical;

        }

        private string GetProductMPP(string planCode)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                return ctx.T_PLN_CD_LKUPs.Single(g => g.PLN_CD == planCode).DOC_PRD;
            }
        }

        private product GetProduct(string planCode)
        {
            return ContentService.GetProducts().product.Single(g => g.plan_code == planCode);
        }


        public Illustration GetHypotheticalIllustration(int id)
        {
            HypotheticalTranslator translator = new HypotheticalTranslator();
            var xml = string.Empty;
            using (var ctx = new AnnuitiesDataContext())
            {
                xml = ctx.T_CLNT_HYPTHTCL_ILLUS.Single(g => g.CLNT_HYPTHTCL_ILLUS_ID == id).ILLUS_DATA.ToString();
            }
            var hypothetical = translator.TranslateIllustrationXml(xml);
            return hypothetical;
        }


        public groups_root GetAllocations(int id)
        {
            var groups = new groups_root
            {
                groups = new groups_rootGroups[]{
                    new groups_rootGroups{
                           groupName="Managed Volatility",
                            groupPercent=10,
                             portfolios= new groups_rootGroupsPortfolio[]{
                                  new groups_rootGroupsPortfolio{
                                    id="id",
                                    name="JP Morgan Global",
                                    percent=50
                                  },
                                  new groups_rootGroupsPortfolio{
                                    id="id",
                                    name="AQR Global Risk Portfolio",
                                    percent=50
                                  }
                             }
                    },
                    new groups_rootGroups{
                           groupName="Momentum",
                            groupPercent=20,
                             portfolios= new groups_rootGroupsPortfolio[]{
                                 new groups_rootGroupsPortfolio{
                                    id="id",
                                    name="Alliance Bernstein",
                                    percent=20
                                  },
                                  new groups_rootGroupsPortfolio{
                                    id="id",
                                    name="MetLife Balanced Plus",
                                    percent=80
                                  } 
                             }
                    },
                    new groups_rootGroups{
                           groupName="Balanced Risk",
                            groupPercent=70,
                             portfolios= new groups_rootGroupsPortfolio[]{
                                  new groups_rootGroupsPortfolio{
                                    id="id",
                                    name="JP Morgan Plus",
                                    percent=5
                                  },
                                  new groups_rootGroupsPortfolio{
                                    id="id",
                                    name="Global QR Portfolio",
                                    percent=95
                                  } 
                             }
                    } 
                }
            };

            return groups;
        }


        public Hypothetical GetHypothetical(Guid id)
        {
            int hypotheticalId = 0;
            using (var ctx = new AnnuitiesDataContext())
            {
                var annuity = ctx.T_CLNT_HYPTHTCLs.SingleOrDefault(g => g.HYPTHTCL_GUID == id);
                if (annuity == null)
                    return null;
                hypotheticalId = annuity.CLNT_HYPTHTCL_ID;
            }

            return GetHypothetical(hypotheticalId);

        }

        public void UpdateHypothetical(int id, string name, Hypothetical hypothetical)
        {
            using (var ctx = new AnnuitiesDataContext())
            {
                var annuity = ctx.T_CLNT_HYPTHTCLs.Single(g => g.CLNT_HYPTHTCL_ID == id);
                annuity.HYPTHTCL_NM = name;
                annuity.ALLOC_DATA = JsonConvert.SerializeObject(hypothetical.Allocations).ToString();
                annuity.HYPTHTCL_DSCR = hypothetical.GuaranteedCompoundingRate;
                ctx.SubmitChanges();
            }
        }


        public byte[] GetSummaryPDF(int id)
        {
            try
            {
                var fs = MetLife.MLI.Services.Proxy.SharePoint.Lists.GetListAttachment(Path.Combine(ConfigurationManager.AppSettings["HypotheticalFolder"], id.ToString() + ".pdf")).GetResponseStream();
                MemoryStream ms = new MemoryStream();                
                fs.CopyTo(ms);
                return ms.ToArray();
            }
            catch (Exception)
            {
                return null;
            }                       
        }

        public void SaveSummaryPDF(int id, byte[] b)
        {
            var dh = new MetLife.MLI.Services.Proxy.SharePoint.DocLibHelper();
            Exception error = null;
            if (!dh.Upload(Path.Combine(MetLife.MLI.Services.Proxy.Configuration.SharePointSettings.GetSettings().URL, ConfigurationManager.AppSettings["HypotheticalFolder"], id.ToString() + ".pdf"), b, null, out error))
                throw error;

            return;
        }
    }
}
