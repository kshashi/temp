﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;
using System.IO;
using System.Web;

namespace MetLife.Annuities.Services.Annuities
{
    public class MockAnnuityService : IAnnuityService
    {
        public annuity_product_category[] GetAvailableProducts(string advisorId)
        {
            return new annuity_product_category[] {
                new annuity_product_category{ 
                    title="Variable Annuity",
                    products = new annuity_product_categoryProduct[] {
                        new annuity_product_categoryProduct{
                            title="Series VA",
                            description="Brief description about annuity goes here lorem ipsum...",
                            highlights = new string[] {
                                "7 years minimum",
                                "1.3% fee"
                            }
                        },
                        new annuity_product_categoryProduct{
                            title="Series VA",
                            description="Brief description about annuity goes here lorem ipsum...",
                            highlights = new string[] {
                                "7 years minimum",
                                "1.3% fee"
                            }
                        }
                              
                    }
                }
            };

        }

        public Hypothetical GetHypothetical(int id)
        {
            HypotheticalTranslator translator = new HypotheticalTranslator();
            
            string path = HttpContext.Current.Server.MapPath(@"~\public\samples\Class VA 04222013.xml");
            var xml = File.ReadAllText(path);
            var hypothetical = translator.TranslateXml(xml);

            return hypothetical;
        }


        public Illustration GetHypotheticalIllustration(int id)
        {
            throw new NotImplementedException();
        }


        public groups_root GetAllocations(int id)
        {
            throw new NotImplementedException();
        }


        public Hypothetical GetHypothetical(Guid id)
        {
            throw new NotImplementedException();
        }


        public void UpdateHypothetical(int id, string name)
        {
            throw new NotImplementedException();
        }


        public void UpdateHypothetical(int id, string name, Hypothetical hypothetical)
        {
            throw new NotImplementedException();
        }


        public byte[] GetSummaryPDF(int id)
        {
            throw new NotImplementedException();
        }

        public void SaveSummaryPDF(int id, byte[] b)
        {
            throw new NotImplementedException();
        }
    }
}
