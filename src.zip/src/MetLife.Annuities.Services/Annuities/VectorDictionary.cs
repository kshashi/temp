﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Annuities
{
    public class VectorDictionary : Dictionary<string, VectorData>
    {
        public VectorDictionary()
        {
            this.Add("101", new VectorData { ColumnName = "Anniversary Year", LineName = "Anniversary Year" });
            this.Add("1002500121", new VectorData { ColumnName = "Age", LineName = "Age" });
            this.Add("1002500127", new VectorData { ColumnName = "Purchase Payment(s)", LineName = "Purchase Payment(s)" });
            this.Add("1002500182", new VectorData { ColumnName = "Withdrawl Amount", LineName = "Withdrawl Amount" });
            this.Add("1002500128", new VectorData { ColumnName = "Withdrawl Value", LineName = "Withdrawl Value" });
            this.Add("1002500129", new VectorData { ColumnName = "Account Value", LineName = "Account Value" });
            this.Add("1002500135", new VectorData { ColumnName = "Hypothetical Death Benefit", LineName = "Hypothetical Death Benefit"});
            this.Add("1002500154", new VectorData { ColumnName = "GMIB Max 4% Compounding Income Base / EDB Max 4% Compounding Benefit Base", LineName = "GMIB Max 4% Compounding Income Base / EDB Max 4% Compounding Benefit Base" });
            this.Add("1002500159", new VectorData { ColumnName = "Account Value", LineName = "Account Value" });
            this.Add("1002500161", new VectorData { ColumnName = "4% Annual Withdrawl", LineName = "4% Annual Withdrawl" });
            this.Add("1002500158", new VectorData { ColumnName = "Total Guaranteed Payout Amount", LineName = "Total Guaranteed Payout Amount" });
            this.Add("1002500133", new VectorData { ColumnName = "EDB Max Benefit Base", LineName = "EDB Max Benefit Base" });
            this.Add("1002500155", new VectorData { ColumnName = "Benefit Base", LineName = "Benefit Base" });
            this.Add("1002500153", new VectorData { ColumnName = "Step Up Indicator", LineName = "Step Up Indicator" });
            this.Add("1002500122", new VectorData { ColumnName = "Joint Ages", LineName = "Joint Ages" });
            this.Add("1002500123", new VectorData { ColumnName = "Gross Rate", LineName = "Gross Rate" });
            this.Add("1002500124", new VectorData { ColumnName = "Net Rate", LineName = "Net Rate" });
            /*
            
            
            this.Add("1002500175", new VectorData { ColumnName = "Highest Anniversary Value Income Base", LineName = "Highest Anniversary Value Income Base" });
            this.Add("1002500135", new VectorData { ColumnName = "Total Death Benefit", LineName = "Total Death Benefit" });
            this.Add("1002500134", new VectorData { ColumnName = "Total Death Benefit (EPD)", LineName = "Total Death Benefit (EPD)" });
            */
             
        }
    }

    public class VectorData
    {
        public string ColumnName { get; set; }
        public string LineName { get; set; }
    }
}
