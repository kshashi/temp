﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Annuities
{
    class IllustrationModelDictionary : Dictionary<string, string>
    {
        public IllustrationModelDictionary()
        {
            this.Add("MODEL_AGGRESSIVE_GROSS", "Aggressive");
            this.Add("MODEL_MODERATE_GROSS", "Moderate");
            this.Add("MODEL_CONSERVATIVE_GROSS", "Conservative");
            this.Add("MODEL_CONSERVATIVE_NET", "Conservative Net");
            this.Add("MODEL_ZERO_GROSS", "0% Return");
            this.Add("MODEL_FNRA_AGGRESSIVE", "Aggressive - Constant Rate");
            this.Add("MODEL_FNRA_MODERATE", "Moderate - Constant Rate");
            this.Add("MODEL_FNRA_CONSERVATIVE", "Conservative - Constant Rate");

        }
    }
}
