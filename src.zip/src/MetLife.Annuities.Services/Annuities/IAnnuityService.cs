﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Annuities
{
    public interface IAnnuityService
    {

        annuity_product_category[] GetAvailableProducts(string advisorId);
        Hypothetical GetHypothetical(int id);
        Hypothetical GetHypothetical(Guid id);
        Illustration GetHypotheticalIllustration(int id);
        groups_root GetAllocations(int id);
        void UpdateHypothetical(int id, string name, Hypothetical hypothetical);
        byte[] GetSummaryPDF(int id);
        void SaveSummaryPDF(int id, byte[] b);
    }
}
