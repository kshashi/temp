﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Annuities
{
    public class Illustration
    {
        private IllustrationModelDictionary _illustration = new IllustrationModelDictionary();

        public string MarketTypeCode { get; set; }
        public string MarketTypeName
        {
            get
            {
                return _illustration[MarketTypeCode];
            }
        }  
        public ChartLine[] ChartLines { get; set; }

        public bool IsJointIllustration { get; set; }
        public string OldestApplicant { get; set; }
        public string GrossAverageAnnualRateOfReturn { get; set; }
        public string NetAverageAnnualRateOfReturn { get; set; }
    }
}
