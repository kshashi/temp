﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services.Annuities
{
    public class SavedProductItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ProductTypeName { get; set; }
        public string ProductAddOnNames { get; set; }
        public decimal InitialInvestment { get; set; }
        public string ReceivePayments { get; set; }
        public AnnuityProductType ProductType { get; set; }
        public ShieldLevel[] ShieldLevels { get; set; }
        public string PurchasePayment { get; set; }

        public long CreatedDateJavascript()
        {
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var time = this.CreatedDate.Subtract(new TimeSpan(epoch.Ticks));
            return (long)(time.Ticks / 10000);
        }

        public bool HasError { get; set; }

        public bool WasPurchased { get; set; }
    }
}
