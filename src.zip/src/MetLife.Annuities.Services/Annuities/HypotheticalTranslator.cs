﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using MetLife.Annuities.Services.Foresight;

namespace MetLife.Annuities.Services.Annuities
{
    internal class HypotheticalTranslator
    {
        Dictionary<string, string> pointOfInterestDictionary = new Dictionary<string, string>();

        internal HypotheticalTranslator()
        {
            pointOfInterestDictionary.Add("1002500153", "Assumesanoptionalstep-upiselectedbecausetheaccountvalue exceeds the current year’s 4% income/benefit base.");
        }

        internal Hypothetical TranslateXml(string xml)
        {
            MetLife.Annuities.Services.Foresight.TXLife_Type data;

            XmlSerializer serializer = new XmlSerializer(typeof(MetLife.Annuities.Services.Foresight.TXLife_Type));

            using (var reader = new StringReader(xml))
            {
                data = (TXLife_Type)serializer.Deserialize(reader);
                reader.Close();
            }

            var request = data.Items[0] as MetLife.Annuities.Services.Foresight.TXLifeRequest_Type;
            var response = data.Items[1] as MetLife.Annuities.Services.Foresight.TXLifeResponse_Type;

            var vectorDictionary = new VectorDictionary();
            var hypothetical = new Hypothetical();

            if (request != null)
            {
                var holding = (Holding_Type)request.OLifE.Items.Single(g => g.GetType() == typeof(Holding_Type));
                var annuity = (Annuity_Type)holding.Policy.Item1;
                hypothetical.InitialInvestment = annuity.InitDepositAmt;
                var rider = annuity.Rider.Where(g => g.RiderTypeCode.tc == "204").SingleOrDefault();
                if (rider != null)
                {
                    hypothetical.HasGMIBRider = true;
                    var lifeExtension = rider.OLifEExtension.SingleOrDefault(g => g.VendorCode == "0025");
                    var incomeoption = lifeExtension.Any.FirstOrDefault(g => g.Name == "IncomeOption");
                    if (incomeoption != null)
                    {
                        hypothetical.HasSingleLife = (incomeoption.Attributes["tc"].Value == "OLI_INCOMEBEN_LIFEANDCERT") || incomeoption.FirstChild.Value == "OLI_INCOMEBEN_LIFEANDCERT";
                        hypothetical.HasJointLife = (incomeoption.Attributes["tc"].Value == "OLI_INCOMEBEN_JOINTLIFEANDCERT") || incomeoption.FirstChild.Value == "OLI_INCOMEBEN_JOINTLIFEANDCERT";
                    }
                    var optionalResetYear = lifeExtension.Any.FirstOrDefault(g => g.Name == "OptionalResetEndYear");
                    hypothetical.PayoutStepUpSelected = false;
                    if (optionalResetYear != null)
                    {
                        int val = int.Parse(optionalResetYear.InnerText);
                        hypothetical.PayoutStepUpSelected = val != 0;
                    }
                }

                var deathRider = annuity.Rider.FirstOrDefault(g => g.RiderTypeCode.tc == "206");
                hypothetical.HasEDB = false;
                switch (deathRider.RiderSubTypeCode.Value)
                {
                    case "OLI_RIDERSUBTYPE_EDBMax":
                        hypothetical.DeathBenefitType = "EDB Max";
                        hypothetical.DeathBenefitTypeLong = "Enhanced Death Benefit Max (EDB Max)";
                        break;
                    case "OLI_RIDERSUBTYPE_ROPDB":
                        hypothetical.DeathBenefitType = "Principal Protection";
                        hypothetical.DeathBenefitTypeLong = "Principal Protection";
                        break;
                    case "OLI_RIDERSUBTYPE_STEPUPDB":
                        hypothetical.DeathBenefitType = "Annual Step-Up";
                        hypothetical.DeathBenefitTypeLong = "Annual Step-Up";
                        break;
                    default:
                        break;
                }
                if (deathRider.RiderSubTypeCode.Value == "OLI_RIDERSUBTYPE_EDBMax")
                {
                    hypothetical.HasEDB = true;
                    if (deathRider.OLifEExtension != null)
                    {
                        var lifeExtension = deathRider.OLifEExtension.SingleOrDefault(g => g.VendorCode == "0025");
                        var incomeOption = lifeExtension.Any.FirstOrDefault(g => g.Name == "OptionalResetEndYear");
                        hypothetical.DeathBenefitStepUpSelected = false;
                        if (incomeOption != null)
                        {
                            int val = int.Parse(incomeOption.InnerText);
                            hypothetical.DeathBenefitStepUpSelected = val != 0;
                        }
                    }
                }


                hypothetical.ProductPlanCode = holding.Policy.ProductCode;
                hypothetical.ProductTypeName = holding.HoldingName;
            }

            if (response != null)
            {
                var allowedModels = new IllustrationModelDictionary();

                var query = from d in response.IllustrationResult.ResultBasis
                                join m in allowedModels on d.id equals m.Key
                            where d.Vector != null
                            select new Illustration
                            {
                                MarketTypeCode = d.id,
                                ChartLines = (from c in d.Vector
                                              where vectorDictionary.Keys.Contains(c.VectorType.tc)
                                              select new ChartLine
                                              {
                                                  VectorCode = c.VectorType.tc,
                                                  VectorName = c.VectorType.Value,
                                                  DataSeries = (from v in c.V
                                                                select new DataSeries
                                                                {
                                                                    Value = v.Value,
                                                                    IsPointOfInterest = IsPointOfInterest(v.Value, c.VectorType),
                                                                    Comment = GetPointOfInterestComment(v.Value, c.VectorType),
                                                                }).ToArray()
                                              }).ToArray()

                            };

                var list = query.ToList();
                var index = list.FindIndex(x => x.MarketTypeName == "Moderate");
                if (index > -1)
                {
                    var item = list[index];
                    list[index] = list[0];
                    list[0] = item;
                }
                hypothetical.Illustrations = list.ToArray();

                var withdrawalVector = (from w in hypothetical.Illustrations[0].ChartLines
                                        where w.VectorName == "VECTOR_VA_WITHDRAWALS"
                                        select w).FirstOrDefault();

                if (withdrawalVector.DataSeries.Count(g => decimal.Parse(g.Value) > 0) == 0)
                    hypothetical.ReceivePayments = "None";
                else if (decimal.Parse(withdrawalVector.DataSeries[0].Value) > 0 || decimal.Parse(withdrawalVector.DataSeries[1].Value) > 0)
                    hypothetical.ReceivePayments = "Immediate";
                else
                {
                    for (int i = 0; i < withdrawalVector.DataSeries.Length; i++)
                    {
                        if (decimal.Parse(withdrawalVector.DataSeries[i].Value) > 0)
                        {
                            hypothetical.ReceivePayments = "Beginning Year " + (i);
                            break;
                        }

                    }
                }



                foreach (var illus in hypothetical.Illustrations)
                {
                    // check if its a joint illustration
                    illus.IsJointIllustration = illus.ChartLines.Count(g => g.VectorCode == "1002500122" && g.DataSeries.Max(x => int.Parse(x.Value)) > 0) > 0;
                    ChartLine agesJoint = null;
                    int ageOfJoint = 0;
                    if (illus.IsJointIllustration)
                    {
                        agesJoint = illus.ChartLines.Single(g => g.VectorCode == "1002500122");
                        ageOfJoint = int.Parse(agesJoint.DataSeries.Max(g => g.Value));
                    }


                    // get the ages vector
                    var ages = illus.ChartLines.Single(g => g.VectorCode == "1002500121");
                    int ageOfPrimary = int.Parse(ages.DataSeries.Last().Value);
                    int numberToNinty = 0;
                    if (ageOfPrimary > ageOfJoint)
                    {
                        numberToNinty = ages.DataSeries.Where(g => int.Parse(g.Value) <= 90).Count();
                        illus.OldestApplicant = "primary";
                    }
                    else
                    {
                        numberToNinty = agesJoint.DataSeries.Where(g => int.Parse(g.Value) <= 90).Count();
                        illus.OldestApplicant = "joint";
                    }

                    foreach (var chartline in illus.ChartLines)
                    {
                        chartline.DataSeries = chartline.DataSeries.Take(numberToNinty).ToArray();
                        foreach (var point in chartline.DataSeries)
                        {
                            decimal p = 0;
                            if (decimal.TryParse(point.Value, out p))
                            {
                                if (p > 1)
                                    point.Value = Math.Round(p, 0).ToString();
                                else
                                    point.Value = Math.Round(p, 4).ToString();
                            }
                        }

                    }

                    // get averages
                    illus.GrossAverageAnnualRateOfReturn = Math.Round((illus.ChartLines.Single(g => g.VectorCode == "1002500123").DataSeries.Skip(1).Average(g => decimal.Parse(g.Value)) * 100), 2).ToString("0.00");
                    illus.NetAverageAnnualRateOfReturn = Math.Round((illus.ChartLines.Single(g => g.VectorCode == "1002500124").DataSeries.Skip(1).Average(g => decimal.Parse(g.Value)) * 100), 2).ToString("0.00");
                }
                hypothetical.TermLength = hypothetical.Illustrations[0].ChartLines[0].DataSeries.Count();

                hypothetical.StartingBenefitBase = decimal.Parse(hypothetical.Illustrations[0]
                    .ChartLines.Where(g => g.VectorCode == "1002500154")
                    .FirstOrDefault()
                    .DataSeries.First().Value);

                //var endingAccountValue = hypothetical.Illustrations[0]
                //    .ChartLines.Where(g => g.VectorCode == "1002500129")
                //    .FirstOrDefault()
                //    .DataSeries.Last().Value;


            }

            if (hypothetical.HasGMIBRider && hypothetical.HasEDB)
                hypothetical.ProductAddOnNames = "GMIB Max & EDB Max";
            if (hypothetical.HasGMIBRider && !hypothetical.HasEDB)
                hypothetical.ProductAddOnNames = "GMIB Max";

            if (!string.IsNullOrEmpty(hypothetical.DeathBenefitType))
                hypothetical.ProductAddOnNames = "GMIB Max & " + hypothetical.DeathBenefitType;


            return hypothetical;
        }

        internal Illustration TranslateIllustrationXml(string xml)
        {
            MetLife.Annuities.Services.Foresight.ResultBasis_Type d;
            var vectorDictionary = new VectorDictionary();
            XmlRootAttribute xRoot = new XmlRootAttribute();
            xRoot.ElementName = "ResultBasis";
            XmlSerializer serializer = new XmlSerializer(typeof(MetLife.Annuities.Services.Foresight.ResultBasis_Type), null, new Type[] { typeof(Vector_Type[]), typeof(TC_VECTOR), typeof(Vector_Type) }, xRoot, "");

            using (var reader = new StringReader(xml))
            {
                d = (ResultBasis_Type)serializer.Deserialize(reader);
            }

            var query = new Illustration
                        {
                            MarketTypeCode = d.id,
                            ChartLines = (from c in d.Vector
                                          where vectorDictionary.Keys.Contains(c.VectorType.tc)
                                          select new ChartLine
                                          {
                                              VectorCode = c.VectorType.tc,
                                              VectorName = c.VectorType.Value,
                                              DataSeries = (from v in c.V
                                                            select new DataSeries
                                                            {
                                                                Value = v.Value,
                                                                IsPointOfInterest = IsPointOfInterest(v.Value, c.VectorType),
                                                                Comment = GetPointOfInterestComment(v.Value, c.VectorType),
                                                            }).ToArray()
                                          }).ToArray()

                        };

            return query;
        }

        private string GetPointOfInterestComment(string value, TC_VECTOR tC_VECTOR)
        {
            if (!IsPointOfInterest(value, tC_VECTOR))
                return null;
            return pointOfInterestDictionary[tC_VECTOR.tc];
        }

        private bool IsPointOfInterest(string value, TC_VECTOR tC_VECTOR)
        {
            if (tC_VECTOR.tc == "1002500153" && value == "HAV")
                return true;
            else
                return false;

        }
    }
}
