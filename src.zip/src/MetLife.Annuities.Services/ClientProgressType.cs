﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Services
{
    public enum ClientProgressType
    {
        ClientSetup = 1,
        WelcomeEmailSent = 2,
        PasswordSetup = 3,
        EducationalSegmentReview = 4,
        ProductPresentationInProgress = 5,
        ProductReviewEnabled = 6,
        ProductReviewEmailSent = 7,
        ProductReviewInProgress = 8,
        ProspectusDeliveryInProgress = 9,
        ProspectusConsentAndAccessConfirmed = 10,
        AccessGrantedToApplicationForms = 11
    }
}
