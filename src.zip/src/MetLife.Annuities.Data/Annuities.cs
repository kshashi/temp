namespace MetLife.Annuities.Data
{
    partial class AnnuitiesDataContext
    {
    }
}
