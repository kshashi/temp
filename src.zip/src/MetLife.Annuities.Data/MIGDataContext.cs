﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.Linq;
using System.Reflection;
using System.Data.Linq.Mapping;

namespace MetLife.Annuities.Data
{
	public partial class MIGDataContext : System.Data.Linq.DataContext
	{
		public MIGDataContext() :
			base(ConfigurationManager.ConnectionStrings["MIG"].ConnectionString, mappingSource)
		{
			OnCreated();
		}


		[Function(Name = "dbo.Con_SearchContact")]
		public ISingleResult<Con_SearchContactResult> Con_SearchContact(
														[Parameter(DbType = "Int")] int compID,
														[Parameter(DbType = "VarChar(25)")] string lastName,
														[Parameter(DbType = "VarChar(25)")] string firstName,
														[Parameter(DbType = "VarChar(25)")] string firmCode,
														[Parameter(DbType = "VarChar(25)")] string regionID,
														[Parameter(DbType = "VarChar(25)")] string state,
														[Parameter(DbType = "VarChar(25)")] string mailListName,
														[Parameter(DbType = "VarChar(50)")] string mymailListName,
														[Parameter(DbType = "VarChar(10)")] string userid,
														[Parameter(DbType = "Bit")] bool topproducer,
														[Parameter(DbType = "VarChar(25)")] string keyAdvancedFind1,
														[Parameter(DbType = "VarChar(8000)")] string valueAdvancedFind1,
														[Parameter(DbType = "VarChar(25)")] string keyAdvancedFind2,
														[Parameter(DbType = "VarChar(8000)")] string valueAdvancedFind2,
														[Parameter(DbType = "VarChar(25)")] string keyAdvancedFind3,
														[Parameter(DbType = "VarChar(8000)")] string valueAdvancedFind3,
														[Parameter(Name = "DistinctCount", DbType = "Int")] ref System.Nullable<int> distinctCount,
														[Parameter(Name = "LoggedInUsersCompany", DbType = "VarChar(3)")] string loggedInUsersCompany,
														[Parameter(DbType = "Bit")] System.Nullable<bool> iSPEC,
														[Parameter(DbType = "VarChar(25)")] string advisoryCouncil,
														[Parameter(DbType = "Bit")] System.Nullable<bool> eliteConcierge,
														[Parameter(Name = "ClientType", DbType = "VarChar(10)")] string clientType,
														[Parameter(Name = "FourthCharFromEnd", DbType = "Char(1)")] System.Nullable<char> fourthCharFromEnd,
														[Parameter(Name = "ProducerGroupID", DbType = "Char(4)")] string producerGroupID,
														[Parameter(Name = "PartialFirmCode", DbType = "VarChar(25)")] string partialFirmCode,
														[Parameter(Name = "Status", DbType = "VarChar(20)")] string status,
														[Parameter(Name = "IncludeBOE", DbType = "Int")] System.Nullable<int> includeBOE,
														[Parameter(Name = "AgencyCode", DbType = "VarChar(20)")] string agencyCode,
														[Parameter(Name = "OptOutIndicator", DbType = "Bit")] System.Nullable<bool> optOutIndicator,
														[Parameter(DbType = "Int")] System.Nullable<int> pagestart,
														[Parameter(DbType = "Int")] System.Nullable<int> pagesize,
														[Parameter(DbType = "VarChar(500)")] string sortby,
														[Parameter(DbType = "VarChar(10)")] string descasc,
														[Parameter(Name = "LicenseAuthority", DbType = "VarChar(200)")] string licenseAuthority,
														[Parameter(Name = "Lat", DbType = "Decimal(30,10)")] System.Nullable<Decimal> lat,
														[Parameter(Name = "Long", DbType = "Decimal(30,10)")] System.Nullable<Decimal> @long,
														[Parameter(Name = "Radius", DbType = "Int")] System.Nullable<int> radius,
														[Parameter(Name = "FirmName", DbType = "VarChar(90)")] string firmName,
														[Parameter(Name = "brokergoal_high", DbType = "VarChar(50)")] string brokerGoal_high,
														[Parameter(Name = "brokergoal_low", DbType = "VarChar(50)")] string brokerGoal_low,
														[Parameter(Name = "OpenMoneybook", DbType = "Bit")] System.Nullable<bool> openMoneybook,
														[Parameter(Name = "TerritoryFocus", DbType = "VarChar(50)")] string territoryFocus)
		{
			IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), compID, lastName, firstName, firmCode, regionID, state, mailListName, mymailListName, userid, topproducer, keyAdvancedFind1, valueAdvancedFind1, keyAdvancedFind2, valueAdvancedFind2, keyAdvancedFind3, valueAdvancedFind3, distinctCount, loggedInUsersCompany, iSPEC, advisoryCouncil, eliteConcierge, clientType, fourthCharFromEnd, producerGroupID, partialFirmCode, status, includeBOE, agencyCode, optOutIndicator, pagestart, pagesize, sortby, descasc, licenseAuthority, lat, @long, radius, firmName, brokerGoal_high, brokerGoal_low, openMoneybook, territoryFocus);
			distinctCount = ((System.Nullable<int>)(result.GetParameterValue(16)));
			return ((ISingleResult<Con_SearchContactResult>)(result.ReturnValue));
		}

		[global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.am_search_agent")]
		public ISingleResult<am_search_agentResult> am_search_agent(
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "FirstName", DbType = "VarChar(25)")] string firstName, 
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "LastName", DbType = "VarChar(25)")] string lastName, 
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "State", DbType = "Char(2)")] string state, 
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "FirmName", DbType = "VarChar(90)")] string firmName, 
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "ContactId", DbType = "Char(10)")] string contactId, 
			[global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "Char(10)")] string rvpId, 
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "MyTerritory", DbType = "Bit")] System.Nullable<bool> myTerritory,
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "AnnMetStatus", DbType = "Int")] System.Nullable<int> AnnMetStatus,
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "SortBy", DbType = "VarChar(50)")] string SortBy,
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "SortOrder", DbType = "VarChar(50)")] string SortOrder,
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "PageSize", DbType = "Int")] System.Nullable<int> PageSize,
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "PageNo", DbType = "Int")] System.Nullable<int> PageNo,
			[global::System.Data.Linq.Mapping.ParameterAttribute(Name = "TotalRecords", DbType = "Int")] ref System.Nullable<int> totalRecords)
		{
			IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), firstName, lastName, state, firmName, contactId, rvpId, myTerritory, AnnMetStatus, SortBy, SortOrder, PageSize, PageNo, totalRecords);
			totalRecords = ((System.Nullable<int>)(result.GetParameterValue(12)));
			return ((ISingleResult<am_search_agentResult>)(result.ReturnValue));
		}

	}

	public partial class am_search_agentResult
	{

		private string _systemid;

		private string _contactid;

		private string _firstname;

		private string _lastname;

		private string _firmName;

		private string _City;

		private string _State;

		private string _portalname;

		private char _status;

		private string _email;

		private string _ANN_MET_STATUS_DESC;

		private bool _AnnuityMet;

		private int? _ANN_MET_STATUS_ID;

		public am_search_agentResult()
		{
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_systemid", DbType = "Char(10) NOT NULL", CanBeNull = false)]
		public string systemid
		{
			get
			{
				return this._systemid;
			}
			set
			{
				if ((this._systemid != value))
				{
					this._systemid = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_contactid", DbType = "Char(10)")]
		public string contactid
		{
			get
			{
				return this._contactid;
			}
			set
			{
				if ((this._contactid != value))
				{
					this._contactid = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_firstname", DbType = "VarChar(25)")]
		public string firstname
		{
			get
			{
				return this._firstname;
			}
			set
			{
				if ((this._firstname != value))
				{
					this._firstname = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_lastname", DbType = "VarChar(25) NOT NULL", CanBeNull = false)]
		public string lastname
		{
			get
			{
				return this._lastname;
			}
			set
			{
				if ((this._lastname != value))
				{
					this._lastname = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_firmName", DbType = "VarChar(90)")]
		public string firmName
		{
			get
			{
				return this._firmName;
			}
			set
			{
				if ((this._firmName != value))
				{
					this._firmName = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_City", DbType = "VarChar(30)")]
		public string City
		{
			get
			{
				return this._City;
			}
			set
			{
				if ((this._City != value))
				{
					this._City = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_State", DbType = "Char(2)")]
		public string State
		{
			get
			{
				return this._State;
			}
			set
			{
				if ((this._State != value))
				{
					this._State = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_portalname", DbType = "VarChar(50)")]
		public string portalname
		{
			get
			{
				return this._portalname;
			}
			set
			{
				if ((this._portalname != value))
				{
					this._portalname = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_status", DbType = "Char(1) NOT NULL")]
		public char status
		{
			get
			{
				return this._status;
			}
			set
			{
				if ((this._status != value))
				{
					this._status = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_email", DbType = "VarChar(60)")]
		public string email
		{
			get
			{
				return this._email;
			}
			set
			{
				if ((this._email != value))
				{
					this._email = value;
				}
			}
		}
		
		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ANN_MET_STATUS_DESC", DbType = "VarChar(100)")]
		public string ANN_MET_STATUS_DESC
		{
			get
			{
				return this._ANN_MET_STATUS_DESC;
			}
			set
			{
				if ((this._ANN_MET_STATUS_DESC != value))
				{
					this._ANN_MET_STATUS_DESC = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AnnuityMet", DbType = "Bit")]
		public bool AnnuityMet
		{
			get
			{
				return this._AnnuityMet;
			}
			set
			{
				if ((this._AnnuityMet != value))
				{
					this._AnnuityMet = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ANN_MET_STATUS_ID", DbType = "Int")]
		public int? ANN_MET_STATUS_ID
		{
			get
			{
				return this._ANN_MET_STATUS_ID;
			}
			set
			{
				if ((this._ANN_MET_STATUS_ID != value))
				{
					this._ANN_MET_STATUS_ID = value;
				}
			}
		}

	}


	public partial class Con_SearchContactResult
	{

		private string _SystemID;

		private string _FirstName;

		private string _LastName;

		private string _birthDate;

		private string _Email;

		private string _RegionID;

		private string _Phone;

		private string _Phonetype;

		private System.Nullable<byte> _PhoneOrderKey;

		private string _FirmCode;

		private string _FirmName;

		private string _Channel;

		private string _Address1;

		private string _Address2;

		private string _City;

		private string _State;

		private string _ZipCode;

		private string _Type;

		private System.Nullable<byte> _AddressOrderKey;

		private string _AgencyCode;

		private string _AgencyName;

		private int _RowNumber;

		private string _Phone1;

		private string _Phonetype1;

		private System.Nullable<byte> _PhoneOrderKey1;

		private string _FirmCode1;

		private string _FirmName1;

		private string _Channel1;

		private string _Address11;

		private string _Address21;

		private string _City1;

		private string _State1;

		private string _ZipCode1;

		private string _Type1;

		private System.Nullable<byte> _AddressOrderKey1;

		private string _AgencyCode1;

		private string _AgencyName1;

		private System.Nullable<decimal> _Lat;

		private System.Nullable<decimal> _Long;

		private char _Status;

		private string _ContactID;

		private string _Producersegment;

		private string _ANWholesaler;

		private string _LIWholesaler;

		private string _TerritoryFocus;
		private string _PortalRegistered;

		private System.Nullable<decimal> _BrokerGoal;
		private System.Nullable<DateTime> _DateofLastWSActivity;
		private System.Nullable<DateTime> _DateofLastISAActivity;
		private System.Nullable<decimal> _VASales12m;
		private System.Nullable<decimal> _VASales24m;
		private System.Nullable<decimal> _LifeSales12m;
		private System.Nullable<decimal> _LifeSales24m;
		private System.Nullable<int> _WSActivity12m;
		private System.Nullable<int> _WSActivity24m;
		private System.Nullable<int> _ISAActivity12m;
		private System.Nullable<int> _ISAActivity24m;
		private System.Nullable<DateTime> _DateofNextAppointment;
		private System.Nullable<int> _OpenMoneybookCount;
		private System.Nullable<int> _AllPolicyCount12m;
		private System.Nullable<int> _PaidPolicyCount12m;
		private System.Nullable<int> _SubmittedPolicyCount12m;
		private System.Nullable<int> _AllPolicyCount24m;
		private System.Nullable<int> _PaidPolicyCount24m;
		private System.Nullable<int> _SubmittedPolicyCount24m;
		private System.Nullable<decimal> _MoneybookYTD;
		private System.Nullable<decimal> _MoneybookMTD;
		private System.Nullable<decimal> _VASubmittedMTD;
		private System.Nullable<decimal> _VASubmittedYTD;
		private System.Nullable<decimal> _VASalesMTD;
		private System.Nullable<decimal> _VASalesYTD;


		public Con_SearchContactResult()
		{
		}

		[Column(Storage = "_SystemID", DbType = "Char(10) NOT NULL", CanBeNull = false)]
		public string SystemID
		{
			get
			{
				return this._SystemID;
			}
			set
			{
				if ((this._SystemID != value))
				{
					this._SystemID = value;
				}
			}
		}

		[Column(Storage = "_FirstName", DbType = "VarChar(25)")]
		public string FirstName
		{
			get
			{
				return this._FirstName;
			}
			set
			{
				if ((this._FirstName != value))
				{
					this._FirstName = value;
				}
			}
		}

		[Column(Storage = "_LastName", DbType = "VarChar(25) NOT NULL", CanBeNull = false)]
		public string LastName
		{
			get
			{
				return this._LastName;
			}
			set
			{
				if ((this._LastName != value))
				{
					this._LastName = value;
				}
			}
		}

		[Column(Storage = "_birthDate", DbType = "VarChar(10)")]
		public string birthDate
		{
			get
			{
				return this._birthDate;
			}
			set
			{
				if ((this._birthDate != value))
				{
					this._birthDate = value;
				}
			}
		}

		[Column(Storage = "_Email", DbType = "VarChar(60)")]
		public string Email
		{
			get
			{
				return this._Email;
			}
			set
			{
				if ((this._Email != value))
				{
					this._Email = value;
				}
			}
		}

		[Column(Storage = "_RegionID", DbType = "Char(6) NOT NULL", CanBeNull = false)]
		public string RegionID
		{
			get
			{
				return this._RegionID;
			}
			set
			{
				if ((this._RegionID != value))
				{
					this._RegionID = value;
				}
			}
		}

		[Column(Storage = "_Phone", DbType = "VarChar(14)")]
		public string Phone
		{
			get
			{
				return this._Phone;
			}
			set
			{
				if ((this._Phone != value))
				{
					this._Phone = value;
				}
			}
		}

		[Column(Storage = "_Phonetype", DbType = "VarChar(50)")]
		public string Phonetype
		{
			get
			{
				return this._Phonetype;
			}
			set
			{
				if ((this._Phonetype != value))
				{
					this._Phonetype = value;
				}
			}
		}

		[Column(Storage = "_PhoneOrderKey", DbType = "TinyInt")]
		public System.Nullable<byte> PhoneOrderKey
		{
			get
			{
				return this._PhoneOrderKey;
			}
			set
			{
				if ((this._PhoneOrderKey != value))
				{
					this._PhoneOrderKey = value;
				}
			}
		}

		[Column(Storage = "_FirmCode", DbType = "VarChar(20)")]
		public string FirmCode
		{
			get
			{
				return this._FirmCode;
			}
			set
			{
				if ((this._FirmCode != value))
				{
					this._FirmCode = value;
				}
			}
		}

		[Column(Storage = "_FirmName", DbType = "VarChar(90)")]
		public string FirmName
		{
			get
			{
				return this._FirmName;
			}
			set
			{
				if ((this._FirmName != value))
				{
					this._FirmName = value;
				}
			}
		}

		[Column(Storage = "_Channel", DbType = "VarChar(40)")]
		public string Channel
		{
			get
			{
				return this._Channel;
			}
			set
			{
				if ((this._Channel != value))
				{
					this._Channel = value;
				}
			}
		}

		[Column(Storage = "_Address1", DbType = "VarChar(50)")]
		public string Address1
		{
			get
			{
				return this._Address1;
			}
			set
			{
				if ((this._Address1 != value))
				{
					this._Address1 = value;
				}
			}
		}

		[Column(Storage = "_Address2", DbType = "VarChar(50)")]
		public string Address2
		{
			get
			{
				return this._Address2;
			}
			set
			{
				if ((this._Address2 != value))
				{
					this._Address2 = value;
				}
			}
		}

		[Column(Storage = "_City", DbType = "VarChar(30)")]
		public string City
		{
			get
			{
				return this._City;
			}
			set
			{
				if ((this._City != value))
				{
					this._City = value;
				}
			}
		}

		[Column(Storage = "_State", DbType = "Char(2)")]
		public string State
		{
			get
			{
				return this._State;
			}
			set
			{
				if ((this._State != value))
				{
					this._State = value;
				}
			}
		}

		[Column(Storage = "_ZipCode", DbType = "VarChar(10)")]
		public string ZipCode
		{
			get
			{
				return this._ZipCode;
			}
			set
			{
				if ((this._ZipCode != value))
				{
					this._ZipCode = value;
				}
			}
		}

		[Column(Storage = "_Type", DbType = "Char(50)")]
		public string Type
		{
			get
			{
				return this._Type;
			}
			set
			{
				if ((this._Type != value))
				{
					this._Type = value;
				}
			}
		}

		[Column(Storage = "_AddressOrderKey", DbType = "TinyInt")]
		public System.Nullable<byte> AddressOrderKey
		{
			get
			{
				return this._AddressOrderKey;
			}
			set
			{
				if ((this._AddressOrderKey != value))
				{
					this._AddressOrderKey = value;
				}
			}
		}

		[Column(Storage = "_AgencyCode", DbType = "VarChar(20)")]
		public string AgencyCode
		{
			get
			{
				return this._AgencyCode;
			}
			set
			{
				if ((this._AgencyCode != value))
				{
					this._AgencyCode = value;
				}
			}
		}

		[Column(Storage = "_AgencyName", DbType = "VarChar(90)")]
		public string AgencyName
		{
			get
			{
				return this._AgencyName;
			}
			set
			{
				if ((this._AgencyName != value))
				{
					this._AgencyName = value;
				}
			}
		}

		[Column(Storage = "_RowNumber", DbType = "Int NOT NULL")]
		public int RowNumber
		{
			get
			{
				return this._RowNumber;
			}
			set
			{
				if ((this._RowNumber != value))
				{
					this._RowNumber = value;
				}
			}
		}

		[Column(Storage = "_Phone1", DbType = "VarChar(14)")]
		public string Phone1
		{
			get
			{
				return this._Phone1;
			}
			set
			{
				if ((this._Phone1 != value))
				{
					this._Phone1 = value;
				}
			}
		}

		[Column(Storage = "_Phonetype1", DbType = "VarChar(50)")]
		public string Phonetype1
		{
			get
			{
				return this._Phonetype1;
			}
			set
			{
				if ((this._Phonetype1 != value))
				{
					this._Phonetype1 = value;
				}
			}
		}

		[Column(Storage = "_PhoneOrderKey1", DbType = "TinyInt")]
		public System.Nullable<byte> PhoneOrderKey1
		{
			get
			{
				return this._PhoneOrderKey1;
			}
			set
			{
				if ((this._PhoneOrderKey1 != value))
				{
					this._PhoneOrderKey1 = value;
				}
			}
		}

		[Column(Storage = "_FirmCode1", DbType = "VarChar(20)")]
		public string FirmCode1
		{
			get
			{
				return this._FirmCode1;
			}
			set
			{
				if ((this._FirmCode1 != value))
				{
					this._FirmCode1 = value;
				}
			}
		}

		[Column(Storage = "_FirmName1", DbType = "VarChar(90)")]
		public string FirmName1
		{
			get
			{
				return this._FirmName1;
			}
			set
			{
				if ((this._FirmName1 != value))
				{
					this._FirmName1 = value;
				}
			}
		}

		[Column(Storage = "_Channel1", DbType = "VarChar(40)")]
		public string Channel1
		{
			get
			{
				return this._Channel1;
			}
			set
			{
				if ((this._Channel1 != value))
				{
					this._Channel1 = value;
				}
			}
		}

		[Column(Storage = "_Address11", DbType = "VarChar(50)")]
		public string Address11
		{
			get
			{
				return this._Address11;
			}
			set
			{
				if ((this._Address11 != value))
				{
					this._Address11 = value;
				}
			}
		}

		[Column(Storage = "_Address21", DbType = "VarChar(50)")]
		public string Address21
		{
			get
			{
				return this._Address21;
			}
			set
			{
				if ((this._Address21 != value))
				{
					this._Address21 = value;
				}
			}
		}

		[Column(Storage = "_City1", DbType = "VarChar(30)")]
		public string City1
		{
			get
			{
				return this._City1;
			}
			set
			{
				if ((this._City1 != value))
				{
					this._City1 = value;
				}
			}
		}

		[Column(Storage = "_State1", DbType = "Char(2)")]
		public string State1
		{
			get
			{
				return this._State1;
			}
			set
			{
				if ((this._State1 != value))
				{
					this._State1 = value;
				}
			}
		}

		[Column(Storage = "_ZipCode1", DbType = "VarChar(10)")]
		public string ZipCode1
		{
			get
			{
				return this._ZipCode1;
			}
			set
			{
				if ((this._ZipCode1 != value))
				{
					this._ZipCode1 = value;
				}
			}
		}

		[Column(Storage = "_Type1", DbType = "Char(50)")]
		public string Type1
		{
			get
			{
				return this._Type1;
			}
			set
			{
				if ((this._Type1 != value))
				{
					this._Type1 = value;
				}
			}
		}

		[Column(Storage = "_AddressOrderKey1", DbType = "TinyInt")]
		public System.Nullable<byte> AddressOrderKey1
		{
			get
			{
				return this._AddressOrderKey1;
			}
			set
			{
				if ((this._AddressOrderKey1 != value))
				{
					this._AddressOrderKey1 = value;
				}
			}
		}

		[Column(Storage = "_AgencyCode1", DbType = "VarChar(20)")]
		public string AgencyCode1
		{
			get
			{
				return this._AgencyCode1;
			}
			set
			{
				if ((this._AgencyCode1 != value))
				{
					this._AgencyCode1 = value;
				}
			}
		}

		[Column(Storage = "_Status", DbType = "Char(1)")]
		public char Status
		{
			get
			{
				return this._Status;
			}
			set
			{
				if ((this._Status != value))
				{
					this._Status = value;
				}
			}
		}

		[Column(Storage = "_ContactID", DbType = "Char(10)")]
		public string ContactID
		{
			get
			{
				return this._ContactID;
			}
			set
			{
				if ((this._ContactID != value))
				{
					this._ContactID = value;
				}
			}
		}

		[Column(Storage = "_AgencyName1", DbType = "VarChar(90)")]
		public string AgencyName1
		{
			get
			{
				return this._AgencyName1;
			}
			set
			{
				if ((this._AgencyName1 != value))
				{
					this._AgencyName1 = value;
				}
			}
		}

		[Column(Storage = "_Lat", DbType = "Decimal")]
		public System.Nullable<decimal> Lat
		{
			get
			{
				return this._Lat;
			}
			set
			{
				if ((this._Lat != value))
				{
					this._Lat = value;
				}
			}
		}

		[Column(Storage = "_Long", DbType = "Decimal")]
		public System.Nullable<decimal> Long
		{
			get
			{
				return this._Long;
			}
			set
			{
				if ((this._Long != value))
				{
					this._Long = value;
				}
			}
		}

		[Column(Storage = "_Producersegment", DbType = "VarChar(50)")]
		public string Producersegment
		{
			get
			{
				return this._Producersegment;
			}
			set
			{
				if ((this._Producersegment != value))
				{
					this._Producersegment = value;
				}
			}
		}

		[Column(Storage = "_ANWholesaler", DbType = "VarChar(120)")]
		public string ANWholesaler
		{
			get
			{
				return this._ANWholesaler;
			}
			set
			{
				if ((this._ANWholesaler != value))
				{
					this._ANWholesaler = value;
				}
			}
		}

		[Column(Storage = "_LIWholesaler", DbType = "VarChar(120)")]
		public string LIWholesaler
		{
			get
			{
				return this._LIWholesaler;
			}
			set
			{
				if ((this._LIWholesaler != value))
				{
					this._LIWholesaler = value;
				}
			}
		}

		[Column(Storage = "_TerritoryFocus", DbType = "VarChar(50)")]
		public string TerritoryFocus
		{
			get
			{
				return this._TerritoryFocus;
			}
			set
			{
				if ((this._TerritoryFocus != value))
				{
					this._TerritoryFocus = value;
				}
			}
		}


		[Column(Storage = "_PortalRegistered", DbType = "VarChar(3)")]
		public string PortalRegistered
		{
			get
			{
				return this._PortalRegistered;
			}
			set
			{
				if ((this._PortalRegistered != value))
				{
					this._PortalRegistered = value;
				}
			}
		}


		[Column(Storage = "_BrokerGoal", DbType = "Decimal")]
		public System.Nullable<decimal> BrokerGoal
		{
			get
			{
				return this._BrokerGoal;
			}
			set
			{
				if ((this._BrokerGoal != value))
				{
					this._BrokerGoal = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateofLastWSActivity", DbType = "DateTime")]
		public System.Nullable<DateTime> DateofLastWSActivity
		{
			get
			{
				return this._DateofLastWSActivity;
			}
			set
			{
				if ((this._DateofLastWSActivity != value))
				{
					this._DateofLastWSActivity = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateofLastISAActivity", DbType = "DateTime")]
		public System.Nullable<DateTime> DateofLastISAActivity
		{
			get
			{
				return this._DateofLastISAActivity;
			}
			set
			{
				if ((this._DateofLastISAActivity != value))
				{
					this._DateofLastISAActivity = value;
				}
			}
		}


		[Column(Storage = "_VASales12m", DbType = "Decimal")]
		public System.Nullable<decimal> VASales12m
		{
			get
			{
				return this._VASales12m;
			}
			set
			{
				if ((this._VASales12m != value))
				{
					this._VASales12m = value;
				}
			}
		}

		[Column(Storage = "_VASales24m", DbType = "Decimal")]
		public System.Nullable<decimal> VASales24m
		{
			get
			{
				return this._VASales24m;
			}
			set
			{
				if ((this._VASales24m != value))
				{
					this._VASales24m = value;
				}
			}
		}

		[Column(Storage = "_LifeSales12m", DbType = "Decimal")]
		public System.Nullable<decimal> LifeSales12m
		{
			get
			{
				return this._LifeSales12m;
			}
			set
			{
				if ((this._LifeSales12m != value))
				{
					this._LifeSales12m = value;
				}
			}
		}

		[Column(Storage = "_LifeSales24m", DbType = "Decimal")]
		public System.Nullable<decimal> LifeSales24m
		{
			get
			{
				return this._LifeSales24m;
			}
			set
			{
				if ((this._LifeSales24m != value))
				{
					this._LifeSales24m = value;
				}
			}
		}

		[Column(Storage = "_WSActivity12m", DbType = "Int")]
		public System.Nullable<int> WSActivity12m
		{
			get
			{
				return this._WSActivity12m;
			}
			set
			{
				if ((this._WSActivity12m != value))
				{
					this._WSActivity12m = value;
				}
			}
		}

		[Column(Storage = "_WSActivity24m", DbType = "Int")]
		public System.Nullable<int> WSActivity24m
		{
			get
			{
				return this._WSActivity24m;
			}
			set
			{
				if ((this._WSActivity24m != value))
				{
					this._WSActivity24m = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ISAActivity12m", DbType = "Int")]
		public System.Nullable<int> ISAActivity12m
		{
			get
			{
				return this._ISAActivity12m;
			}
			set
			{
				if ((this._ISAActivity12m != value))
				{
					this._ISAActivity12m = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ISAActivity24m", DbType = "Int")]
		public System.Nullable<int> ISAActivity24m
		{
			get
			{
				return this._ISAActivity24m;
			}
			set
			{
				if ((this._ISAActivity24m != value))
				{
					this._ISAActivity24m = value;
				}
			}
		}

		[global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateofNextAppointment", DbType = "DateTime")]
		public System.Nullable<DateTime> DateofNextAppointment
		{
			get
			{
				return this._DateofNextAppointment;
			}
			set
			{
				if ((this._DateofNextAppointment != value))
				{
					this._DateofNextAppointment = value;
				}
			}
		}

		[Column(Storage = "_OpenMoneybookCount", DbType = "Int")]
		public System.Nullable<int> OpenMoneybookCount
		{
			get
			{
				return this._OpenMoneybookCount;
			}
			set
			{
				if ((this._OpenMoneybookCount != value))
				{
					this._OpenMoneybookCount = value;
				}
			}
		}

		[Column(Storage = "_AllPolicyCount12m", DbType = "Int")]
		public System.Nullable<int> AllPolicyCount12m
		{
			get
			{
				return this._AllPolicyCount12m;
			}
			set
			{
				if ((this._AllPolicyCount12m != value))
				{
					this._AllPolicyCount12m = value;
				}
			}
		}

		[Column(Storage = "_PaidPolicyCount12m", DbType = "Int")]
		public System.Nullable<int> PaidPolicyCount12m
		{
			get
			{
				return this._PaidPolicyCount12m;
			}
			set
			{
				if ((this._PaidPolicyCount12m != value))
				{
					this._PaidPolicyCount12m = value;
				}
			}
		}

		[Column(Storage = "_SubmittedPolicyCount12m", DbType = "Int")]
		public System.Nullable<int> SubmittedPolicyCount12m
		{
			get
			{
				return this._SubmittedPolicyCount12m;
			}
			set
			{
				if ((this._SubmittedPolicyCount12m != value))
				{
					this._SubmittedPolicyCount12m = value;
				}
			}
		}

		[Column(Storage = "_AllPolicyCount24m", DbType = "Int")]
		public System.Nullable<int> AllPolicyCount24m
		{
			get
			{
				return this._AllPolicyCount24m;
			}
			set
			{
				if ((this._AllPolicyCount24m != value))
				{
					this._AllPolicyCount24m = value;
				}
			}
		}

		[Column(Storage = "_PaidPolicyCount24m", DbType = "Int")]
		public System.Nullable<int> PaidPolicyCount24m
		{
			get
			{
				return this._PaidPolicyCount24m;
			}
			set
			{
				if ((this._PaidPolicyCount24m != value))
				{
					this._PaidPolicyCount24m = value;
				}
			}
		}

		[Column(Storage = "_SubmittedPolicyCount24m", DbType = "Int")]
		public System.Nullable<int> SubmittedPolicyCount24m
		{
			get
			{
				return this._SubmittedPolicyCount24m;
			}
			set
			{
				if ((this._SubmittedPolicyCount24m != value))
				{
					this._SubmittedPolicyCount24m = value;
				}
			}
		}

		[Column(Storage = "_MoneybookYTD", DbType = "Decimal")]
		public System.Nullable<decimal> MoneybookYTD
		{
			get
			{
				return this._MoneybookYTD;
			}
			set
			{
				if ((this._MoneybookYTD != value))
				{
					this._MoneybookYTD = value;
				}
			}
		}

		[Column(Storage = "_MoneybookMTD", DbType = "Decimal")]
		public System.Nullable<decimal> MoneybookMTD
		{
			get
			{
				return this._MoneybookMTD;
			}
			set
			{
				if ((this._MoneybookMTD != value))
				{
					this._MoneybookMTD = value;
				}
			}
		}

		[Column(Storage = "_VASubmittedYTD", DbType = "Decimal")]
		public System.Nullable<decimal> VASubmittedYTD
		{
			get
			{
				return this._VASubmittedYTD;
			}
			set
			{
				if ((this._VASubmittedYTD != value))
				{
					this._VASubmittedYTD = value;
				}
			}
		}

		[Column(Storage = "_VASubmittedMTD", DbType = "Decimal")]
		public System.Nullable<decimal> VASubmittedMTD
		{
			get
			{
				return this._VASubmittedMTD;
			}
			set
			{
				if ((this._VASubmittedMTD != value))
				{
					this._VASubmittedMTD = value;
				}
			}
		}

		[Column(Storage = "_VASalesYTD", DbType = "Decimal")]
		public System.Nullable<decimal> VASalesYTD
		{
			get
			{
				return this._VASalesYTD;
			}
			set
			{
				if ((this._VASalesYTD != value))
				{
					this._VASalesYTD = value;
				}
			}
		}

		[Column(Storage = "_VASalesMTD", DbType = "Decimal")]
		public System.Nullable<decimal> VASalesMTD
		{
			get
			{
				return this._VASalesMTD;
			}
			set
			{
				if ((this._VASalesMTD != value))
				{
					this._VASalesMTD = value;
				}
			}
		}

	}
}
