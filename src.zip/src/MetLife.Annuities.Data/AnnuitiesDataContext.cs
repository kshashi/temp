﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Configuration;

namespace MetLife.Annuities.Data
{
    public partial class AnnuitiesDataContext
    {

        public AnnuitiesDataContext() :
            base(ConfigurationManager.ConnectionStrings["IBANNMET"].ConnectionString, mappingSource)
        {
            OnCreated();
        }

        /// <summary>
        /// Basic Audit User and Date Stamp Functionality
        /// </summary>
        /// <param name="failureMode"></param>
        public override void SubmitChanges(System.Data.Linq.ConflictMode failureMode)
        { 
            
            //Updates
            for (int changeCounter = 0; changeCounter < this.GetChangeSet().Updates.Count; changeCounter++)
            {
                object modifiedEntity = this.GetChangeSet().Updates[changeCounter];
                SetAuditStamp(this, modifiedEntity, ChangeType.Update);
            }

            //Inserts
            for (int changeCounter = 0; changeCounter < this.GetChangeSet().Inserts.Count; changeCounter++)
            {
                object modifiedEntity = this.GetChangeSet().Inserts[changeCounter];
                SetAuditStamp(this, modifiedEntity, ChangeType.Insert);
                SetAuditStamp(this, modifiedEntity, ChangeType.Update);
            }

            
            base.SubmitChanges(failureMode);
        }

        /// <summary>
        /// For Inserts or Updates - set the user and date stamps
        /// </summary>
        /// <param name="context"></param>
        /// <param name="modifiedEntity"></param>
        private void SetAuditStamp(DataContext context, object modifiedEntity, ChangeType changeType)
        {
            string userName = System.Threading.Thread.CurrentPrincipal.Identity.Name;
            const string Created = "CRT_TS", CreatedBy = "CRT_USR_ID",
                         Modified = "LST_UPDT_TS", ModifiedBy = "LST_UPDT_BY_USR_ID";

            if (changeType == ChangeType.Insert)
            {
                SetAuditValue(modifiedEntity, Created, System.DateTime.UtcNow);
                SetAuditValue(modifiedEntity, CreatedBy, userName);
            }
            else if (changeType == ChangeType.Update)
            {
                SetAuditValue(modifiedEntity, Modified, System.DateTime.UtcNow);
                SetAuditValue(modifiedEntity, ModifiedBy, userName);
            }
        }

        /// <summary>
        /// The type of modifications
        /// </summary>
        private enum ChangeType
        {
            Update,
            Insert
        }

        /// <summary>
        /// Set target value if it exists on the object
        /// </summary>
        /// <param name="modifiedEntity"></param>
        /// <param name="fieldName"></param>
        /// <param name="propertyValue"></param>
        private void SetAuditValue(object modifiedEntity, string fieldName, object propertyValue)
        {
            if (modifiedEntity.GetType().GetProperty(fieldName) != null) //Set current user and time stamp
            {
                modifiedEntity.GetType().GetProperty(fieldName).SetValue(modifiedEntity, propertyValue, null);
            }
        }
    }
}
