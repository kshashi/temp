﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MetLife.Annuities.Web
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.IgnoreRoute("public");
            
            routes.MapRoute(
                name: "SharepointAssets",
                url: "sharepoint/assets/images/{*path}",
                defaults: new { controller = "SharepointAssets", action = "Index" }
                );


            routes.MapRoute(
                name: "SharepointAssetsDocsPublic",
                url: "public/sharepoint/assets/documents/{*path}",
                defaults: new { controller = "SharepointAssets", action = "Documents" }
                );

            routes.MapRoute(
                name: "SharepointHypoSeriesVA",
                url: "public/sharepoint/hypo/seriesva/{id}",
                defaults: new { controller = "SeriesVA", action = "SummaryPDF", area = "Clients" }
                );
            routes.MapRoute(
                name: "SharepointHypoSLS",
                url: "public/sharepoint/hypo/sls/{id}",
                defaults: new { controller = "SLS", action = "SummaryPDF", area = "Clients" }
                );

            routes.MapRoute(
                name: "SharepointAssetsDocs",
                url: "sharepoint/assets/documents/{*path}",
                defaults: new { controller = "SharepointAssets", action = "Documents" }
                );

            routes.MapRoute(
                name: "TridionAssets",
                url: "annuity/assets/images/{*path}",
                defaults: new { controller = "TridionAssets", action = "Index" }
                );

            routes.MapRoute(
                name: "PublicAccount",
                url: "public/account/createpassword/{id}",
                defaults: new { controller = "Account", action = "CreatePassword", area="" }
                );

            routes.MapRoute(
                name: "PublicAccountForgotPassword",
                url: "public/account/forgotpassword",
                defaults: new { controller = "Account", action = "ForgotPassword", area = "" }
                );
            
            routes.MapRoute(
                name: "PublicAccountChangePassword",
                url: "public/account/changepassword",
                defaults: new { controller = "Account", action = "ChangePassword", area = "" }
                );

            routes.MapRoute(
                name: "PublicAccountQuestions",
                url: "public/account/questions",
                defaults: new { controller = "Account", action = "Questions", area = "" }
                );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}