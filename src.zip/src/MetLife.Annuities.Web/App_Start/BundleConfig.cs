﻿using System.Web;
using System.Web.Optimization;

namespace MetLife.Annuities.Web
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {

            bundles.Add(new ScriptBundle("~/public/javascripts/plugins").Include(
                "~/public/javascripts/app/router/AppRouter.js",
                "~/public/javascripts/app/model/ExampleModel.js",
                "~/public/javascripts/app/model/ExampleCollection.js"
                ));


            bundles.Add(new ScriptBundle("~/public/javascripts/app").Include(
                "~/public/javascripts/app/router/AppRouter.js",
                "~/public/javascripts/app/model/ExampleModel.js",
                "~/public/javascripts/app/model/ExampleCollection.js"
                ));


            bundles.Add(new StyleBundle("~/public/stylesheets/reset").Include(
                       "~/public/stylesheets/themes/base/jquery.ui.core.css",
                       "~/public/stylesheets/themes/base/jquery.ui.theme.css"));

            bundles.Add(new StyleBundle("~/public/stylesheets/plugins").Include(
                       "~/public/stylesheets/themes/base/jquery.ui.core.css",
                       "~/public/stylesheets/themes/base/jquery.ui.theme.css"));

            bundles.Add(new StyleBundle("~/public/stylesheets/app").Include(
                       "~/public/stylesheets/themes/base/jquery.ui.core.css",
                       "~/public/stylesheets/themes/base/jquery.ui.theme.css"));

            bundles.Add(new StyleBundle("~/public/stylesheets/mobile").Include(
                       "~/public/stylesheets/themes/base/jquery.ui.core.css",
                       "~/public/stylesheets/themes/base/jquery.ui.theme.css"));

            bundles.Add(new StyleBundle("~/public/stylesheets/javascript").Include(
                       "~/public/stylesheets/themes/base/jquery.ui.core.css",
                       "~/public/stylesheets/themes/base/jquery.ui.theme.css"));

            bundles.Add(new StyleBundle("~/public/stylesheets/print").Include(
                       "~/public/stylesheets/themes/base/jquery.ui.core.css",
                       "~/public/stylesheets/themes/base/jquery.ui.theme.css"));
            /*
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/public/javascripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/public/javascripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/public/javascripts/jquery.unobtrusive*",
                        "~/public/javascripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/public/javascripts/modernizr-*"));

            bundles.Add(new StyleBundle("~/public/stylesheets/css").Include("~/public/stylesheets/site.css"));

            bundles.Add(new StyleBundle("~/public/stylesheets/themes/base/css").Include(
                        "~/public/stylesheets/themes/base/jquery.ui.core.css",
                        "~/public/stylesheets/themes/base/jquery.ui.resizable.css",
                        "~/public/stylesheets/themes/base/jquery.ui.selectable.css",
                        "~/public/stylesheets/themes/base/jquery.ui.accordion.css",
                        "~/public/stylesheets/themes/base/jquery.ui.autocomplete.css",
                        "~/public/stylesheets/themes/base/jquery.ui.button.css",
                        "~/public/stylesheets/themes/base/jquery.ui.dialog.css",
                        "~/public/stylesheets/themes/base/jquery.ui.slider.css",
                        "~/public/stylesheets/themes/base/jquery.ui.tabs.css",
                        "~/public/stylesheets/themes/base/jquery.ui.datepicker.css",
                        "~/public/stylesheets/themes/base/jquery.ui.progressbar.css",
                        "~/public/stylesheets/themes/base/jquery.ui.theme.css"));
             * 
             * */
        }
    }
}