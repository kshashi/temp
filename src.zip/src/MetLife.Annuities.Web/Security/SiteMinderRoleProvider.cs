﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Web.Security
{
    public class SiteMinderRoleProvider : RoleProvider
    {
        public IRolesService RolesService { get; private set; }

        public SiteMinderRoleProvider()
        {
            RolesService = new IBSERolesService();
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            RolesService.IBSEAddUsersToRoles(usernames, roleNames);
        }

        public override string ApplicationName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override void CreateRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            return RolesService.GetAllRoles();
        }

        public override string[] GetRolesForUser(string username)
        {
            return RolesService.GetRolesForUser(username);
        }

        public override string[] GetUsersInRole(string roleName)
        {
            return RolesService.GetUsersInRole(roleName);
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            return RolesService.IsUserInRole(username, roleName);
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            RolesService.IBSERemoveUsersToRoles(usernames, roleNames);
        }

        public override bool RoleExists(string roleName)
        {
            return RolesService.RoleExists(roleName);
        }
    }
}