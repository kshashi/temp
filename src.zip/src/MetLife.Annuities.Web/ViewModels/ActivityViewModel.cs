﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.ViewModels
{
    public class ActivityIndexViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ActivityType { get; set; }
        public string ActivityDescription { get; set; }
        public string Date { get; set; }
        public string CTA { get; set; }
        public long Timestamp { get; set; }
        public HistoryType HistoryType { get; set; }
        public string CTAText { get; set; }

        public int ClientID { get; set; }
    }
}