﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;
using MetLife.Annuities.Web.ModelBinders;
using MetLife.Annuities.Services.Data;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.ViewModels
{
    [System.Web.Http.ModelBinding.ModelBinder(typeof(AliasModelBinder))]
    public class StateDocBasicViewModel
    {
         public string DocCode { get; set; }
         public int StateId { get; set; }     
         public IEnumerable<SelectListItem> Channels { get; set; }
         public string Channel { get; set; }
         public IEnumerable<SelectListItem> Products { get; set; }
         public string Product { get; set; }
         public IEnumerable<SelectListItem> States { get; set; }
         public string State { get; set; }
         public string Message { get; set; }
         public bool? Active { get; set; } 
         public IEnumerable<SelectListItem> DocCodeCombineds { get; set; }
         public string DocCodeCombined { get; set; }
         public StateDocBasicViewModel()
         {
         }
         public StateDocBasicViewModel(Doc tdoc, Dictionary<string, string> channels, Dictionary<string, string> products, Dictionary<int, string> states, Dictionary<string, string> dCodeCombined)
         {
            
             DocCode = tdoc.DOC_CD;
             Channel = tdoc.DSTR_CD;
             Message = tdoc.Message;
             StateId = tdoc.StateID;
             DocCodeCombined = tdoc.DOC_Combined;
             if (tdoc.Active != null)
             {
                 Active = tdoc.Active;

             }
             Channels = new SelectList(channels, "Key", "Value", tdoc.DSTR_CD);
             Products = new SelectList(products, "Key", "Value", tdoc.DOC_PRD);
             States = new SelectList(states, "Key", "Value", tdoc.StateID);
             DocCodeCombineds = new SelectList(dCodeCombined, "Key", "Value", tdoc.DOC_Combined);
   
         }
    }
}