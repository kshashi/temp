﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;
using MetLife.Annuities.Web.ModelBinders;
using MetLife.Annuities.Services.Data;
using System.Web.Mvc;


namespace MetLife.Annuities.Web.ViewModels
{
     [System.Web.Http.ModelBinding.ModelBinder(typeof(AliasModelBinder))]
    public class DocBasicViewModel
    {
 
         public string DocCode { get; set; }
         public string DocName { get; set; }     
         public string DocType { get; set; }
         public string Path { get; set; }
         public bool? DocRequireSelected { get; set; }
         public IEnumerable<SelectListItem> Channels { get; set; }
         public string Channel { get; set; }
         public IEnumerable<SelectListItem> Products { get; set; }
         public string Product { get; set; }
         public string Message { get; set; }
         public bool? Active { get; set; }
         public string DocDescription { get; set; }
         public string HtmlDocInfo { get; set; }

         public DocBasicViewModel()
         {
         }
         public DocBasicViewModel(Doc tdoc,Dictionary<string,string> channels,Dictionary<string,string> products)
         {
             DocCode = tdoc.DOC_CD;
             DocName = tdoc.DOC_NM;
             DocType = tdoc.DOC_TYP_DSCR;
             Path = tdoc.DOC_PATH_VAL;
             Channel = tdoc.DSTR_CD;
             Message = tdoc.Message;
             DocDescription = tdoc.DOC_DSCR;
             if(tdoc.DOC_RQR_IND!=null)
             {
                 DocRequireSelected = tdoc.DOC_RQR_IND;
               
             }
             if (tdoc.Active != null)
             {
                 Active = tdoc.Active;

             }
             Channels = new SelectList(channels, "Key", "Value", tdoc.DSTR_CD);
             Products = new SelectList(products, "Key", "Value", tdoc.DOC_PRD);

         }
    }
}