﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.ViewModels
{
    public class ClientsIndexCTADictionary : Dictionary<int, LinkItem>
    {
        public ClientsIndexCTADictionary()
        {
            this.Add(1, new LinkItem("Create A New Interactive Chart", "/advisors/impersonate?client_id={client_id}&next=/clients/charts/saved"));
            this.Add(2, new LinkItem("Resend Email", "/advisors/clients/email?client_id={client_id}&template=welcome"));
            this.Add(3, new LinkItem("View Client Profile", "/advisors/clients/profile?client_id={client_id}"));
            this.Add(4, new LinkItem("View Educational Videos", "/advisors/impersonate?client_id={client_id}"));
            this.Add(5, new LinkItem("View Saved Annuity(s)", "/advisors/impersonate?client_id={client_id}&next=/clients/charts/saved"));
            this.Add(6, new LinkItem("View Saved Annuity(s)", "/advisors/impersonate?client_id={client_id}&next=/clients/charts/saved"));
            this.Add(7, new LinkItem("View Saved Annuity(s)", "/advisors/impersonate?client_id={client_id}&next=/clients/charts/saved"));
            this.Add(8, new LinkItem("View Saved Annuity(s)", "/advisors/impersonate?client_id={client_id}&next=/clients/charts/saved"));
            this.Add(9, new LinkItem("View Application Progress", "/advisors/impersonate?client_id={client_id}&next=/clients/applications"));
            this.Add(10, new LinkItem("View Application Progress", "/advisors/impersonate?client_id={client_id}&next=/clients/applications"));
            this.Add(11, new LinkItem("View Forms", "/advisors/impersonate?client_id={client_id}&next=/clients/applications/find?agree=true"));

        }
    }

    public class LinkItem
    {
        public string Text { get; set; }
        public string Url { get; set; }
        public LinkItem(string text, string url)
        {
            Text = text;
            Url = url;
        }
    }
}