﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;
using System.ComponentModel.DataAnnotations;
using MetLife.Annuities.Services.Data;



namespace MetLife.Annuities.Web.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class ClientBasicViewModel
    {

        //public AddClientHeaderViewModel Header { get; set; }
        public IEnumerable<SelectListItem> States { get; set; }
        public IEnumerable<SelectListItem> MaritalStatuses { get; set; }
        public IEnumerable<SelectListItem> PhoneNumberTypes { get; set; }

        [BindAlias("client-first-name")]
        public string FirstName { get; set; }

        [BindAlias("client-last-name")]
        public string LastName { get; set; }

        [BindAlias("client-dob-month")]
        public int DOBMonth { get; set; }

        [BindAlias("client-dob-day")]
        public int DOBDay { get; set; }

        [BindAlias("client-dob-year")]
        public int DOBYear { get; set; }

        [BindAlias("client-marital-status")]
        public byte MaritalStatus { get; set; }

        [Required]
        [BindAlias("client-gender")]
        public char Gender { get; set; }

        [BindAlias("client-address-1")]
        public string Address1 { get; set; }

        [BindAlias("client-address-2")]
        public string Address2 { get; set; }

        [BindAlias("client-city")]
        public string City { get; set; }

        [BindAlias("client-state")]
        public int StateID { get; set; }

        [BindAlias("client-zip")]
        public string Zip { get; set; }

        [BindAlias("client-phone")]
        public PhoneNumberType[] PhoneNumbers { get; set; }

        [BindAlias("client-email")]
        public string[] EmailAddresses { get; set; }

        [BindAlias("client-id")]
        public int? ClientID { get; set; }

        public SelectList Genders { get; set; }

        public ClientBasicViewModel()
        {

        }

        public ClientBasicViewModel(Client client, Dictionary<int, string> states, Dictionary<byte, string> marital, Dictionary<int, string> phones, Dictionary<char, string> genders)
        {
            ClientID = client.ClientID;
            FirstName = client.FirstName;
            LastName = client.LastName;
            Address1 = client.Address1;
            Address2 = client.Address2;
            City = client.City;
            StateID = client.StateID;
            DOBDay = client.DateOfBirth.Day;
            DOBMonth = client.DateOfBirth.Month;
            DOBYear = client.DateOfBirth.Year;
            EmailAddresses = new string[] { client.EmailAddress };
            PhoneNumbers = (from p in client.PhoneNumbers
                            select new PhoneNumberType
                            {
                                Number = p.Number,
                                Type = p.TypeID.Value,
                            }).ToArray();
            Gender = client.Gender;
            MaritalStatus = client.MaritalStatusID;
            Zip = client.Zip;
            States = new SelectList(states, "Key", "Value", client.StateID);
            MaritalStatuses = new SelectList(marital, "Key", "Value", client.MaritalStatusID);
            PhoneNumberTypes = new SelectList(phones, "Key", "Value");
            Genders = new SelectList(genders, "Key", "Value", client.Gender);
        }

        internal Client MapClient(Client client)
        {
            client.FirstName = FirstName;
            client.LastName = LastName;
            client.DateOfBirth = new DateTime(DOBYear, DOBMonth, DOBDay);
            client.MaritalStatusID = MaritalStatus;
            client.Gender = Gender;
            client.Address1 = Address1;
            client.Address2 = Address2;
            client.City = City;
            client.StateID = StateID;
            client.Zip = Zip;
            client.PhoneNumbers = (from p in PhoneNumbers
                                   select new PhoneNumber
                                   {
                                       TypeID = p.Type,
                                       Number = p.Number
                                   }).ToArray();
            client.EmailAddress = EmailAddresses.First();
            client.ClientID = client.ClientID;
            return client;
        }
    }

    public class PhoneNumberType
    {
        public int Type { get; set; }
        public string Number { get; set; }
    }
}