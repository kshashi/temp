﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.ViewModels
{
    public class ForgotPasswordViewModel
    {
        public List<Services.Security.SecurityQuestion> Questions { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }
        public string PasswordConfirm { get; set; }
    }
}