﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;

namespace MetLife.Annuities.Web.ViewModels
{

    [ModelBinder(typeof(AliasModelBinder))]
    public class AccountQuestionsViewModel
    {
        [BindAlias("security-question")]
        public List<AccountQuestionAnswer> SecurityQuestion { get; set; }
    }

    public class AccountQuestionAnswer
    {
        public string Question { get; set; }
        public string Answer { get; set; }
        public string Confirm { get; set; }
        public string QuestionNumber { get; set; }

        public bool IsValid
        {
            get
            {
                return Confirm == Answer;
            }
        }
    }
}