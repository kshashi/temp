﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Models;
using Newtonsoft.Json;

namespace MetLife.Annuities.Web.ViewModels
{
    public class ClientFullViewModel
    {


        public ClientFullViewModel(Client client, ClientFinance finance, persona persona, video[] persona_videos, bool isAdvisorView, ClientHistory[] history, Progress progress)
        {
            ClientFinance = finance;
            Client = client;
            
            if (persona != null)
            {
                ClientPersona = new ClientPersona
                {
                    PersonaID = int.Parse(persona.id),
                    Goals = persona.short_description.ToString(),
                    PersonaName = persona.name.ToString(),
                    Quote = persona.quote.ToString(),
                    ThumbnailUri = persona.person_image_uri.ToString(),
                    VideosItems = persona_videos,
                    IntroVideo = persona.intro_video,
                    OutroVideo = persona.outro_video

                };
            }

            ClientHistory = history;
            IsAdvisorView = isAdvisorView;
            HypotheticalEnabledState = client.HypotheticalViewEnabled ? "on" : "off";
            ProgressJson = JsonConvert.SerializeObject(progress);
        }
        public Client Client { get; set; }
        public ClientFinance ClientFinance { get; set; }
        public ClientPersona ClientPersona { get; set; }
        public bool IsAdvisorView { get; set; }
        public ClientHistory[] ClientHistory { get; set; }
        public string ProgressJson { get; set; }
        public string HypotheticalEnabledState { get; set; }
    }
}