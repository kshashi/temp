﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ModelBinders;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class ClientFinancialViewModel
    {
        [BindAlias("client-age")]
        public int ClientRetirementAge { get; set; }

        [BindAlias("client-dependents")]
        public bool Dependents { get; set; }

        [BindAlias("client-dependents-count")]
        public int DependentCount { get; set; }

        [BindAlias("client-salary")]
        public decimal? Salary { get; set; }

        [BindAlias("client-rentals")]
        public decimal? RentalsIncome { get; set; }

        [BindAlias("client-social-security")]
        public decimal? SocialSecurityIncome { get; set; }

        [BindAlias("client-pensions")]
        public decimal? Pensionincome { get; set; }

        [BindAlias("client-other")]
        public decimal? OtherIncome { get; set; }

        [BindAlias("client-wills")]
        public bool? ClientWills { get; set; }

        [BindAlias("client-current-expenses")]
        public decimal? CurrentExpenses { get; set; }

        [BindAlias("client-future-expenses")]
        public decimal? FutureExpenses { get; set; }

        [BindAlias("client-net-worth")]
        public decimal? NetWorth { get; set; }

        [BindAlias("client-investments")]
        public bool? ClientInvestments { get; set; }

        [BindAlias("client-goals")]
        public List<string> Goals { get; set; }

        [BindAlias("client-needing-income")]
        public int IncomeNeeds { get; set; }

        [BindAlias("client-risk")]
        public int? RiskLevel { get; set; }

        [BindAlias("client-benefits")]
        public int[] ClientBenefits { get; set; }

        [BindAlias("client-roth")]
        public decimal? RothInvestment { get; set; }

        [BindAlias("client-401k")]
        public decimal? Investment401k { get; set; }

        [BindAlias("client-trad-ira")]
        public decimal? TraditionalIRA { get; set; }

        [BindAlias("client-403b")]
        public decimal? Investment403B { get; set; }

        [BindAlias("client-investment")]
        public decimal? InitialInvestment { get; set; }

        //public ClientHeaderViewModel Header { get; set; }

        [BindAlias("client-id")]
        public int ClientID { get; set; }

        public ClientFinancialViewModel()
        {
            ClientBenefits = new int[0];
        }

        public ClientFinancialViewModel(Client client, ClientFinance finance, Dictionary<int, string> timespans,Benefit[] benefits)
        {
            ClientBenefits = finance.ImportantBenefits;
            Goals = new List<string>();
            ClientFinance = finance;
            Salary = finance.IncomeSalary;
            RentalsIncome = finance.IncomeRental;
            Pensionincome = finance.IncomePensions;
            SocialSecurityIncome = finance.IncomeSocialSecurity;
            Investment401k = finance.Investment401k;
            Investment403B = finance.Investment403B;
            RothInvestment = finance.InvestmentRoth;
            TraditionalIRA = finance.InvestmentIRA;
            CurrentExpenses = finance.ExpensesCurrent;
            FutureExpenses = finance.ExpensesFuture;
            OtherIncome = finance.IncomeOther;
            NetWorth = finance.NetWorth;
            InitialInvestment = finance.InitialInvestment;
            RiskLevel = finance.RiskTolerance;
            Client = client;
            ClientID = client.ClientID;
            IncomeNeedsItems = new SelectList(timespans, "Key", "Value", finance.IncomeTiming);
            Goals = new List<string>(client.Goals);
            DependentCount = finance.DepedentCount.HasValue ? finance.DepedentCount.Value : 0;
            ClientWills = finance.HasWillsTrustsEtc;
            ClientInvestments = finance.HasInvestments;
            Benefits = benefits;
        }
        public ClientFinance ClientFinance { get; set; }

        public Client Client { get; set; }

        public SelectList IncomeNeedsItems { get; set; }

        internal ClientFinance MapClientFinance()
        {
            var finance = new ClientFinance
            {
                ClientID = ClientID,
                RetirementAge = ClientRetirementAge,
                DepedentCount = DependentCount,
                IncomeSalary = Salary,
                IncomeRental = RentalsIncome,
                IncomePensions = Pensionincome,
                IncomeSocialSecurity = SocialSecurityIncome,
                IncomeOther = OtherIncome,
                HasWillsTrustsEtc = ClientWills,
                ExpensesFuture = FutureExpenses,
                ExpensesCurrent = CurrentExpenses,
                NetWorth = NetWorth,
                InvestmentRoth = RothInvestment,
                Investment401k = Investment401k,
                InvestmentIRA = TraditionalIRA,
                Investment403B = Investment403B,
                InitialInvestment = InitialInvestment,
                //IncomeTiming = IncomeNeeds,
                RiskTolerance = RiskLevel,
                Goals = Goals.ToArray(),
                ImportantBenefits = ClientBenefits
            };

            return finance;
        }

        public Benefit[] Benefits { get; set; }
    }
}