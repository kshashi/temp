﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ModelBinders;
using System.Web.Http.ModelBinding;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Web.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class ClientProfileSettingsViewModel
    {

        public bool ChangingPassword
        {
            get
            {
                return !string.IsNullOrEmpty(ClientPassword);
            }
        }

        public bool ChangingQuestions
        {
            get
            {
                return SecurityQuestion.FirstOrDefault(g => !string.IsNullOrEmpty(g.QuestionAnswer)) != null;
            }
        }
        public string ClientPassword { get; set; }

        public string ClientPasswordConfirm { get; set; }

        [BindAlias("client-notifications-email")]
        public string ClientNotificationsEmail { get; set; }

        public bool IsAdvisorView { get; set; }


        [BindAlias("security-question")]
        public List<SecurityQuestion> SecurityQuestion { get; set; }

        public List<SecurityQuestion> Questions { get; set; }
        
        public string ClientPasswordCurrent { get; set; }
    }
}