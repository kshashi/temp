﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace MetLife.Annuities.Web
{
    public static class Messages
    {
        public const String INSERTEXCEPTIONMESSAGE = "Insert failed – << {0} >>";
        public const String UPDATEEXCEPTIONMESSAGE = "Update failed – << {0} >>";
        public const String INVALIDPARAMETERMESSAGE = "Unable to update, invalid parameters.";
        public const String NODATAAVAILABLEMESSAGE = "No Data Available currently for this doc.";

        public const string DOCCODE = "DocCode";
        public const string DOCCOMBINED = "DocCombined";
        public const string DOCCOMBINEDSEPERATOR = " - ";
        public const char EDITPARAMSEPERATOR = ':';
        public const string COMMANDSOURCEID = "source";

        public const string COMMANDRESET = "Reset";
        public const string COMMANDEDIT = "Edit";
        public const string COMMANDSEARCH = "Search";

        public const string ADMINROLE = "Admin";

    }

}