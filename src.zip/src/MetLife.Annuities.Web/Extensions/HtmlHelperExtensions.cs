﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace MetLife.Annuities.Web.Extensions
{
    public static class HtmlHelperExtensions
    {
        public static MvcHtmlString MenuLink(this HtmlHelper htmlHelper, string linkText, string actionName, string controllerName, string additionalClasses, object routeValues)
        {
            MvcHtmlString tagString = null;
            string currentAction = htmlHelper.ViewContext.RouteData.GetRequiredString("action");
            string currentController = htmlHelper.ViewContext.RouteData.GetRequiredString("controller");
            if (controllerName.Equals(currentController, StringComparison.InvariantCultureIgnoreCase))
            {
                tagString = htmlHelper.ActionLink(
                    linkText,
                    actionName,
                    controllerName,
                    routeValues,
                    new
                    {
                        @class = "selected" + (!string.IsNullOrEmpty(additionalClasses) ? " " + additionalClasses : "")
                    });

                tagString = new MvcHtmlString(tagString.ToString().Replace(linkText, "<span>" + linkText + "</span>"));
                return tagString;
            }
            if (!string.IsNullOrEmpty(additionalClasses))
            {
                tagString = htmlHelper.ActionLink(linkText, actionName, controllerName, routeValues, new { @class = additionalClasses });
                tagString = new MvcHtmlString(tagString.ToString().Replace(linkText, "<span>" + linkText + "</span>"));
                return tagString;
            }
            else
            {
                tagString = htmlHelper.ActionLink(linkText, actionName, controllerName, routeValues, null);
                tagString = new MvcHtmlString(tagString.ToString().Replace(linkText, "<span>" + linkText + "</span>"));
                return tagString;

            }
        }

        public static MvcHtmlString MenuLink(this HtmlHelper htmlHelper, string linkText, string actionName, string controllerName, string additionalClasses)
        {
            MvcHtmlString tagString = null;
            string currentAction = htmlHelper.ViewContext.RouteData.GetRequiredString("action");
            string currentController = htmlHelper.ViewContext.RouteData.GetRequiredString("controller");
            if (controllerName.Equals(currentController, StringComparison.InvariantCultureIgnoreCase))
            {
                tagString = htmlHelper.ActionLink(
                    linkText,
                    actionName,
                    controllerName,
                    null,
                    new
                    {
                        @class = "selected" + (!string.IsNullOrEmpty(additionalClasses) ? " " + additionalClasses : "")
                    });

                tagString = new MvcHtmlString(tagString.ToString().Replace(linkText, "<span>" + linkText + "</span>"));
                return tagString;
            }
            if (!string.IsNullOrEmpty(additionalClasses))
            {
                tagString = htmlHelper.ActionLink(linkText, actionName, controllerName, null, new { @class = additionalClasses });
                tagString = new MvcHtmlString(tagString.ToString().Replace(linkText, "<span>" + linkText + "</span>"));
                return tagString;
            }
            else
            {
                tagString = htmlHelper.ActionLink(linkText, actionName, controllerName);
                tagString = new MvcHtmlString(tagString.ToString().Replace(linkText, "<span>" + linkText + "</span>"));
                return tagString;

            }
        }


        public static MvcHtmlString MenuLink(this HtmlHelper htmlHelper, string linkText, string actionName, string controllerName)
        {
            return MenuLink(htmlHelper, linkText, actionName, controllerName, "");
        }
    }
}