﻿using System;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Security;

namespace MetLife.Annuities.Web
{
    public static class CookieSecurityProvider
    {

        static CookieSecurityProvider()
        {
        }

        public static HttpCookie Encrypt(HttpCookie httpCookie)
        {
            byte[] buffer = Encoding.Default.GetBytes(httpCookie.Value);

            //Referencing the Encode mehod of CookieProtectionHelper class
            httpCookie.Value = MachineKey.Encode(buffer, MachineKeyProtection.Encryption);
            return httpCookie;
        }
        public static HttpCookie Decrypt(HttpCookie httpCookie)
        {
            //Referencing the Decode mehod of CookieProtectionHelper class
            byte[] buffer = MachineKey.Decode(httpCookie.Value, MachineKeyProtection.Encryption);// (byte[])_decode.Invoke(null, new object[] { _cookieProtection, httpCookie.Value });
            httpCookie.Value = Encoding.Default.GetString(buffer, 0, buffer.Length);
            return httpCookie;
        }
    }
}