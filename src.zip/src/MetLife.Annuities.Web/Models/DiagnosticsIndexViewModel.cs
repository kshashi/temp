﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Models
{
	public class DiagnosticsIndexViewModel
	{
		public System.Collections.Specialized.NameValueCollection RequestHeaders { get; set; }

		public System.Collections.Specialized.NameValueCollection ResponseHeaders { get; set; }


		public HttpServerUtilityBase Server { get; set; }

        public string SqlInfo { get; set; }
    }

    
}