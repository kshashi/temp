﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Models
{
    public class VideoCategoryModel
    {
        public List<VideoCategory> Categories { get; set; }

        internal static VideoCategoryModel GenerateFromVideoArray(video[] video)
        {
            var model = new VideoCategoryModel();
            model.Categories = new List<VideoCategory>();
            model.Videos = video;
            var cats = video.Select(g => g.category.name).Distinct();
            foreach (var category in cats)
            {
                var c = (from v in video
                         where v.category.name == category
                         select new VideoCategory
                         {
                             Name = v.category.name,
                             Description = v.category.description
                         }).First();
                c.Videos = (from v in video
                           where v.category.name == category
                           select v).ToList();
                model.Categories.Add(c);

            }

            return model;
        }

        public video[] Videos { get; set; }
    }

    public class VideoCategory
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public List<video> Videos { get; set; }
    }

    public class Video
    {

        public string Name { get; set; }
    }
}