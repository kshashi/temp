﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Models
{
    public class FaqCategoryModel
    {
        public string CategoryName { get; set; }
        public List<FaqItemModel> FaqItems { get; set; }

        public static FaqCategoryModel[] GenerateFromFaqArray(faq_item[] items)
        {
            List<FaqCategoryModel> faqs = new List<FaqCategoryModel>();
            int faqNumber = 1;
            var categories = items.GroupBy(g => g.category.name).Select(g => g.Key);

            foreach (var category in categories)
            {
                var cat = new FaqCategoryModel { CategoryName = category };

                var faqsInCategory = items.Where(g => g.category.name == category).ToList();

                cat.FaqItems = new List<FaqItemModel>();

                foreach (var faq in faqsInCategory)
                {
                    cat.FaqItems.Add(new FaqItemModel
                    {
                        FaqNumber = faqNumber,
                        Id = faq.id,
                        Question = faq.question_text,                        
                        Answer = faq.answer_text
                    });
                    faqNumber++;
                }

                faqs.Add(cat);
            }

            return faqs.ToArray();
        }

        private FaqCategoryModel()
        {

        }
    }
}