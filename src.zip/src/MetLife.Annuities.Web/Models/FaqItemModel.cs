﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Web.Models
{
    public class FaqItemModel
    {
        public int FaqNumber { get; set; }

        public string Id { get; set; }

        public object Question { get; set; }

        public object Answer { get; set; }
    }
}
