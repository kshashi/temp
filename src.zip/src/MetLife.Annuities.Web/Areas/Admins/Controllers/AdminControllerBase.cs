﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Admins.Controllers
{
    public class AdminControllerBase : Controller
    {
        public admin SelectedAdmin { get; set; }

    }
}
