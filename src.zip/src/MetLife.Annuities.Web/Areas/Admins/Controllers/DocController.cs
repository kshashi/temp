﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Admins.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Admins.Controllers
{
    [Authorize(Roles = Messages.ADMINROLE)]
    public class DocController : AdminControllerBase
    {
        // GET: /Admins/Doc/
        private IDataService DataService = new SqlDataService();

        [HttpGet]
        public ActionResult Index()
        {
            var docViewModel = new DocViewModel();
            string selectedState = string.Empty;
            string selectedChannel = string.Empty;
            string selectedProduct = string.Empty;
            string active = string.Empty;
            string filter= string.Empty;
            
            if (Request.Cookies[Messages.DOCCODE] != null)
                filter = Convert.ToString(Request.Cookies[Messages.DOCCODE].Value);

            // fetching the search parametes from cookie
            if (filter.Contains(Messages.EDITPARAMSEPERATOR))
            {
                string[] parameters = filter.Split(Messages.EDITPARAMSEPERATOR);
                if (parameters.Length >= 4)
                {
                    selectedState = parameters[0];
                    selectedChannel = parameters[1];
                    selectedProduct = parameters[2];
                    active = parameters[3];
                }
            }
            docViewModel = new DocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel { Admin = SelectedAdmin },
                StateList = DataService.GetStates(),
                ProductList = DataService.GetProducts(),
                ChannelList = DataService.GetChannels(),
                // getting the search result from database
                DocList = (from d in DataService.SearchDoc(selectedState, selectedChannel, selectedProduct, active)
                           select new DocBasicViewModel
                           {
                               DocCode = d.DOC_CD,
                               DocName = d.DOC_NM,
                               DocType = d.DOC_TYP_DSCR,
                               Path = d.DOC_PATH_VAL,
                               Product = d.DOC_PRD,
                               Channel = d.DSTR_CD,
                               DocRequireSelected = (d.DOC_RQR_IND == null) ? null : d.DOC_RQR_IND,
                               HtmlDocInfo = "<div style=\"font-weight: 700; padding-bottom: 6px; padding-top: 5px;\">" + d.DOC_NM + "</div><div style=\"padding-bottom: 2px;\">" + d.DOC_TYP_DSCR + "</div><a href=\"" + d.DOC_PATH_VAL + "\" class=\"docLink\">" + d.DOC_PATH_VAL + "</a>",
                               Active = d.Active
                           }).ToList<DocBasicViewModel>(),
                SelectedState=selectedState,
                SelectedChannel=selectedChannel,
                SelectedProduct=selectedProduct,
                Active=active

            };
            return View("Index", docViewModel);
        }

        [HttpPost]
        public ActionResult Index(DocViewModel doc, FormCollection collection)
        {
            var docViewModel = new DocViewModel();
            var command = Convert.ToString(collection[Messages.COMMANDSOURCEID]);
            
            if (Request.Cookies[Messages.DOCCODE] != null)
                Request.Cookies[Messages.DOCCODE].Expires = DateTime.Now.AddDays(-1);

            string selectedState = Convert.ToString(doc.SelectedState) == null ? string.Empty : Convert.ToString(doc.SelectedState);
            string selectedChannel = Convert.ToString(doc.SelectedChannel) == null ? string.Empty : Convert.ToString(doc.SelectedChannel);
            string selectedProduct = Convert.ToString(doc.SelectedProduct) == null ? string.Empty : Convert.ToString(doc.SelectedProduct);
            string active = Convert.ToString(doc.Active) == null ? string.Empty : Convert.ToString(doc.Active);

            // if user click on Reset button
            if (command == Messages.COMMANDRESET)
            {
                HttpCookie myCookie = new HttpCookie(Messages.DOCCODE);
                myCookie.Value = string.Empty;
                Response.Cookies.Add(myCookie);

                return RedirectToAction("Index");
            }
            // if user click on edit button of any doc
            else if (command.StartsWith(Messages.COMMANDEDIT))
            {
                HttpCookie myCookie = new HttpCookie(Messages.DOCCODE);
                myCookie.Value = selectedState + Messages.EDITPARAMSEPERATOR + selectedChannel + Messages.EDITPARAMSEPERATOR + selectedProduct + Messages.EDITPARAMSEPERATOR + active;
                Response.Cookies.Add(myCookie);

                string[] data = command.Split(Messages.EDITPARAMSEPERATOR);  //  cd:11886-1-IL & chnl:ID & prd:MPP & st:418
                return RedirectToAction("update", new { cd = Encryption.Encrypt(data[1]), prd = Encryption.Encrypt(data[2]), chnl = Encryption.Encrypt(data[3]) });
            }
            // If user click on search button
            else
            {
                // save the search criteria in cookie, will be user for sorting and pagination in HttpGET method.
                HttpCookie myCookie = new HttpCookie(Messages.DOCCODE);
                myCookie.Value = selectedState + Messages.EDITPARAMSEPERATOR + selectedChannel + Messages.EDITPARAMSEPERATOR + selectedProduct + Messages.EDITPARAMSEPERATOR + active;
                Response.Cookies.Add(myCookie);

                docViewModel = new DocViewModel
                {
                    AdminHeaderViewModel = new AdminHeaderViewModel { Admin = SelectedAdmin },
                    StateList = DataService.GetStates(),
                    ProductList = DataService.GetProducts(),
                    ChannelList = DataService.GetChannels(),
                    DocList = (from d in DataService.SearchDoc(selectedState, selectedChannel, selectedProduct, active)
                               select new DocBasicViewModel
                               {
                                   DocCode = d.DOC_CD,
                                   DocName = d.DOC_NM,
                                   DocType = d.DOC_TYP_DSCR,
                                   Path = d.DOC_PATH_VAL,
                                   Product = d.DOC_PRD,
                                   Channel = d.DSTR_CD,
                                   DocRequireSelected = (d.DOC_RQR_IND == null) ? null : d.DOC_RQR_IND,
                                   HtmlDocInfo = "<div style=\"font-weight: 700; padding-bottom: 6px; padding-top: 5px;\">" + d.DOC_NM + "</div><div style=\"padding-bottom: 2px;\">" + d.DOC_TYP_DSCR + "</div><a href=\"" + d.DOC_PATH_VAL + "\" class=\"docLink\">" + d.DOC_PATH_VAL + "</a>",
                                   Active = d.Active
                               }).ToList<DocBasicViewModel>(),
                    SelectedState=selectedState,
                    SelectedChannel=selectedChannel,
                    SelectedProduct=selectedProduct,
                    Active=active

                };
                return View("Index", docViewModel);
            }
        }

        [HttpGet]
        public ActionResult Update()
        {
            string docCode = Encryption.Decrypt(Convert.ToString(Request.QueryString["cd"]));
            string docCd = Encryption.Decrypt(Convert.ToString(Request.QueryString["prd"]));
            string docchn = Encryption.Decrypt(Convert.ToString(Request.QueryString["chnl"]));

            Doc doc = new Doc();
            // check if the values are getting decrypted successfully.
            if (string.IsNullOrEmpty(docCd) || string.IsNullOrEmpty(docCode) || string.IsNullOrEmpty(docchn))
            {
                doc.Message = Messages.NODATAAVAILABLEMESSAGE;
            }
            else
            {
                try
                {
                    doc = DataService.GetTDocDetails(docCode, docCd, docchn);
                }
                catch (Exception)
                {
                    doc.Message = Messages.NODATAAVAILABLEMESSAGE;
                }
            }

            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var tmodel = new DocBasicViewModel(doc, channel, products);
            var docViewModel = new DocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View("Update", docViewModel);
        }

        [HttpPost]
        public ActionResult Update(DocBasicViewModel docBasic)
        {
            Doc doc = new Doc();
            string docCode = Encryption.Decrypt(Convert.ToString(Request.QueryString["cd"]));
            string docCd = Encryption.Decrypt(Convert.ToString(Request.QueryString["prd"]));
            string docchn = Encryption.Decrypt(Convert.ToString(Request.QueryString["chnl"]));

            bool IsUpdateable = false;
            // check if the values are getting decrypted successfully.
            if (string.IsNullOrEmpty(docCd) || string.IsNullOrEmpty(docCode) || string.IsNullOrEmpty(docchn))
            {
                doc.Message = Messages.INVALIDPARAMETERMESSAGE;
            }
            else
            {
                try
                {
                    doc.LST_UPDT_BY_USR_ID = User.Identity.Name;
                    doc.DOC_PRD = docBasic.Product;
                    doc.LST_UPDT_TS = DateTime.Now;
                    doc.DOC_PATH_VAL = docBasic.Path;
                    doc.DSTR_CD = docBasic.Channel;
                    doc.DOC_CD = docBasic.DocCode;
                    doc.DOC_NM = docBasic.DocName;
                    doc.DOC_RQR_IND = docBasic.DocRequireSelected;
                    doc.DOC_TYP_DSCR = docBasic.DocType;
                    doc.DOC_DSCR = docBasic.DocDescription;
                    doc.Active = docBasic.Active;
                    string errorMessage = string.Empty;
                    if (doc.Active == false)
                    {
                        if (!DataService.CheckForStateReferenceActiveDocument(docCode, docCd, docchn, out errorMessage))
                        {
                            IsUpdateable = true;
                        }

                    }

                    else
                    {
                        IsUpdateable = true;
                    }

                    if (IsUpdateable)
                    {
                        bool isUpdated = DataService.UpdateDocDetails(docCode, docCd, docchn, doc, out errorMessage);
                    }
                    doc.Message = errorMessage;


                }
                catch (Exception ex)
                {

                    doc.Message = string.Format(Messages.UPDATEEXCEPTIONMESSAGE, ex.Message);
                }
            }

            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();

            var tmodel = new DocBasicViewModel(doc, channel, products);
            var docViewModel = new DocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View("Update", docViewModel);
        }

        [HttpGet]
        public ActionResult Add()
        {
            Doc doc = new Doc();
            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var tmodel = new DocBasicViewModel(doc, channel, products);
            var docViewModel = new DocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View("Add", docViewModel);
        }
        [HttpPost]
        public ActionResult Add(DocBasicViewModel docBasic)
        {
            Doc doc = new Doc();
            string errorMessage = string.Empty;
            try
            {
                doc.DOC_PRD = docBasic.Product;
                doc.CRT_USR_ID = User.Identity.Name;
                doc.CRT_TS = DateTime.Now;
                doc.DOC_PATH_VAL = docBasic.Path;
                doc.DSTR_CD = docBasic.Channel;
                doc.DOC_CD = docBasic.DocCode;
                doc.DOC_NM = docBasic.DocName;
                doc.DOC_RQR_IND = docBasic.DocRequireSelected;
                doc.DOC_TYP_DSCR = docBasic.DocType;
                doc.DOC_DSCR = docBasic.DocDescription;
                doc.Active = true;
                bool isAdded = DataService.AddDocDetails(doc, out errorMessage);
                doc.Message = errorMessage;
            }
            catch (Exception ex)
            {

                doc.Message = string.Format(Messages.INSERTEXCEPTIONMESSAGE, ex.Message);
            }
            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var tmodel = new DocBasicViewModel(doc, channel, products);
            var docViewModel = new DocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View("Add", docViewModel);
        }
    }
}
