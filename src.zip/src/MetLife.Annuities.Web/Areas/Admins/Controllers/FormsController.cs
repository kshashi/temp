﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MetLife.Annuities.Web.Areas.Admins.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Fulfillment;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Admins.Controllers
{
    public class FormsController : AdminControllerBase
    {
        //
        // GET: /Admins/Forms/
        ISharePoint SharePointService = new SharePoint();
        private IDataService DataService = new SqlDataService();

        public ActionResult Index()
        {
            var states = DataService.GetStates();
            form[] tdocs = SharePointService.GetDistinctTDOCForms();
            //form[] stateForms = SharePointService.GetStateForms();
            
            var model = new AdminFormsViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                T_DOCS = tdocs
             
                    //doc_cde = forms.Select(d => d.doc_code).ToString(),
                    //doc_desc = forms.Select(d => d.description).ToString(),
                    //doc_nm = forms.Select(d => d.name).ToString(),
                    //doc_path_val = forms.Select(d => d.path).ToString(),
                    //doc_typ_dscr = forms.Select(d => d.type).ToString()
              
            };

            return View(model);
        }

       
         
    }
}
