﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Admins.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Admins.Controllers
{
     [Authorize(Roles = Messages.ADMINROLE)]
    public class StateDocController : AdminControllerBase
    {
        //
        // GET: /Admins/StateDoc/
        private IDataService DataService = new SqlDataService();

        [HttpGet]
        public ActionResult Index()
        {
            string selectedDoc = string.Empty;
            string combinedDocCode = string.Empty;

            if (Request.Cookies[Messages.DOCCOMBINED] != null)
                combinedDocCode = Convert.ToString(Request.Cookies[Messages.DOCCOMBINED].Value);

            // fetching the search parametes from cookie
            if (combinedDocCode.Contains(Messages.DOCCOMBINEDSEPERATOR))
                selectedDoc = combinedDocCode.Split(new string[] { Messages.DOCCOMBINEDSEPERATOR }, StringSplitOptions.RemoveEmptyEntries)[0];

            var stateDocViewModel = new StateDocViewModel
            {

                AdminHeaderViewModel = new AdminHeaderViewModel { Admin = SelectedAdmin },
                DocList = DataService.GetActiveDocCombined(),
                StateMappingList = (from d in DataService.SearchStateDocMapping(selectedDoc)
                                    select new StateDocBasicViewModel
                                    {
                                        DocCode = d.DOC_CD,
                                        State = d.State,
                                        StateId = d.StateID,
                                        Product = d.DOC_PRD,
                                        Channel = d.DSTR_CD,
                                        Active = d.Active
                                    }).ToList<StateDocBasicViewModel>(),
                SelectedDoc = combinedDocCode
            };
            return View(stateDocViewModel);
        }

        [HttpPost]
        public ActionResult Index(StateDocViewModel stateDoc, FormCollection collection)
        {


            var command = Convert.ToString(collection[Messages.COMMANDSOURCEID]);
            string combinedDocCode = Convert.ToString(stateDoc.SelectedDoc) == null ? string.Empty : Convert.ToString(stateDoc.SelectedDoc);
            
            if (Request.Cookies[Messages.DOCCOMBINED] != null)
                Request.Cookies[Messages.DOCCOMBINED].Expires = DateTime.Now.AddDays(-1);

            // if user click on reset button
            if (command == Messages.COMMANDRESET)
            {
                HttpCookie myCookie = new HttpCookie(Messages.DOCCOMBINED);
                myCookie.Value = string.Empty;
                Response.Cookies.Add(myCookie);
                
                return RedirectToAction("Index");
            }
            // if user click on edit button of any doc
            else if (command.StartsWith(Messages.COMMANDEDIT))
            {
                HttpCookie myCookie = new HttpCookie(Messages.DOCCOMBINED);
                myCookie.Value = combinedDocCode;
                Response.Cookies.Add(myCookie);
                
                string[] data = command.Split(Messages.EDITPARAMSEPERATOR);  //  cd:11886-1-IL & chnl:ID & prd:MPP & st:418

                return RedirectToAction("update", new { cd = Encryption.Encrypt(data[1]), st = Encryption.Encrypt(data[2]), prd = Encryption.Encrypt(data[3]), chnl = Encryption.Encrypt(data[4]) });
            }
            // if user click on search button
            else
            {
                HttpCookie myCookie = new HttpCookie(Messages.DOCCOMBINED);
                myCookie.Value = combinedDocCode;
                Response.Cookies.Add(myCookie);
                
                string SelectedDoc = combinedDocCode;
                if (combinedDocCode.Contains(Messages.DOCCOMBINEDSEPERATOR))
                    SelectedDoc = combinedDocCode.Split(new string[] { Messages.DOCCOMBINEDSEPERATOR }, StringSplitOptions.RemoveEmptyEntries)[0];

                var stateDocViewModel = new StateDocViewModel
                {
                    AdminHeaderViewModel = new AdminHeaderViewModel { Admin = SelectedAdmin },
                    DocList = DataService.GetActiveDocCombined(),
                    StateMappingList = (from d in DataService.SearchStateDocMapping(SelectedDoc)
                                        select new StateDocBasicViewModel
                                        {
                                            DocCode = d.DOC_CD,
                                            State = d.State,
                                            StateId = d.StateID,
                                            Product = d.DOC_PRD,
                                            Channel = d.DSTR_CD,
                                            Active = d.Active
                                        }).ToList<StateDocBasicViewModel>(),
                    SelectedDoc = combinedDocCode


                };

                return View(stateDocViewModel);
            }
        }

        [HttpGet]
        public ActionResult Update()
        {
            Doc doc = new Doc();

            string docCode = Encryption.Decrypt(Convert.ToString(Request.QueryString["cd"]));
            string docCd = Encryption.Decrypt(Convert.ToString(Request.QueryString["prd"]));
            string docchn = Encryption.Decrypt(Convert.ToString(Request.QueryString["chnl"]));
            string st = Encryption.Decrypt(Convert.ToString(Request.QueryString["st"]));
            // check if the values are getting decrypted successfully.
            if (string.IsNullOrEmpty(docCd) || string.IsNullOrEmpty(docCode) || string.IsNullOrEmpty(docchn) || string.IsNullOrEmpty(st))
            {
                doc.Message = Messages.NODATAAVAILABLEMESSAGE;
            }
            else
            {
                try
                {
                    doc = DataService.GetStateDocDetails(docCode, docCd, docchn, Convert.ToInt32(st));

                }
                catch (Exception)
                {

                    doc.Message = Messages.NODATAAVAILABLEMESSAGE;
                }
            }


            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var states = DataService.GetStates();
            var combineds = DataService.GetDocCombined();
            var tmodel = new StateDocBasicViewModel(doc, channel, products, states, combineds);
            var stateDocViewModel = new StateDocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View(stateDocViewModel);

        }

        [HttpPost]
        public ActionResult Update(StateDocBasicViewModel stateDocBasic)
        {
            Doc doc = new Doc();
            string errorMessage = string.Empty;

            string docCode = Encryption.Decrypt(Convert.ToString(Request.QueryString["cd"]));
            string docCd = Encryption.Decrypt(Convert.ToString(Request.QueryString["prd"]));
            string docchn = Encryption.Decrypt(Convert.ToString(Request.QueryString["chnl"]));
            string st = Encryption.Decrypt(Convert.ToString(Request.QueryString["st"]));
            // check if the values are getting decrypted successfully.
            if (string.IsNullOrEmpty(docCd) || string.IsNullOrEmpty(docCode) || string.IsNullOrEmpty(docchn) || string.IsNullOrEmpty(st))
            {
                doc.Message = Messages.INVALIDPARAMETERMESSAGE;
            }
            else
            {
                try
                {
                    doc.LST_UPDT_BY_USR_ID = User.Identity.Name;
                    doc.DOC_PRD = stateDocBasic.Product;
                    doc.LST_UPDT_TS = DateTime.Now;
                    doc.DSTR_CD = stateDocBasic.Channel;
                    string[] words = stateDocBasic.DocCodeCombined.Split(new string[] { Messages.DOCCOMBINEDSEPERATOR }, StringSplitOptions.RemoveEmptyEntries);
                    doc.DOC_CD = stateDocBasic.DocCode;
                    doc.DOC_Combined = Convert.ToString(words[0]).Trim();
                    doc.StateID = stateDocBasic.StateId;
                    doc.Active = stateDocBasic.Active;
                    if (!DataService.CheckForActiveDocument(Convert.ToString(doc.DOC_Combined), Convert.ToString(doc.DOC_PRD), Convert.ToString(doc.DSTR_CD), out errorMessage))
                    {

                        bool isUpdated = DataService.UpdateStateDocDetails(docCode, docCd, docchn, Convert.ToInt32(st), doc, out errorMessage);

                    }

                    doc.Message = errorMessage;
                }
                catch (Exception ex)
                {

                    doc.Message = string.Format(Messages.UPDATEEXCEPTIONMESSAGE, ex.Message);
                }
            }

            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var states = DataService.GetStates();
            var combineds = DataService.GetDocCombined();
            var tmodel = new StateDocBasicViewModel(doc, channel, products, states, combineds);
            var stateDocViewModel = new StateDocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View(stateDocViewModel);
        }

        [HttpGet]
        public ActionResult Add()
        {
            Doc doc = new Doc();
            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var states = DataService.GetStates();
            var combineds = DataService.GetDocCombined();
            var tmodel = new StateDocBasicViewModel(doc, channel, products, states, combineds);
            var stateDocViewModel = new StateDocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };

            return View(stateDocViewModel);

        }

        [HttpPost]
        public ActionResult Add(StateDocBasicViewModel stateDocBasic)
        {
            Doc doc = new Doc();
            string errorMessage = string.Empty;
            try
            {
                doc.DOC_PRD = stateDocBasic.Product;
                doc.DSTR_CD = stateDocBasic.Channel;
                string[] words = stateDocBasic.DocCodeCombined.Split(new string[] { Messages.DOCCOMBINEDSEPERATOR }, StringSplitOptions.RemoveEmptyEntries);
                doc.DOC_CD = stateDocBasic.DocCode;
                doc.DOC_Combined = Convert.ToString(words[0]).Trim();
                doc.CRT_TS = DateTime.Now;
                doc.CRT_USR_ID = User.Identity.Name;
                doc.StateID = stateDocBasic.StateId;
                doc.Active = true;
                if (!DataService.CheckForActiveDocument(Convert.ToString(doc.DOC_Combined), Convert.ToString(doc.DOC_PRD), Convert.ToString(doc.DSTR_CD), out errorMessage))
                {
                    bool isAdded = DataService.AddStateDocDetails(doc, out errorMessage);
                }
                doc.Message = errorMessage;
            }
            catch (Exception ex)
            {

                doc.Message = string.Format(Messages.INSERTEXCEPTIONMESSAGE, ex.Message);
            }

            var channel = DataService.GetChannels();
            var products = DataService.GetProducts();
            var states = DataService.GetStates();
            var combineds = DataService.GetDocCombined();
            var tmodel = new StateDocBasicViewModel(doc, channel, products, states, combineds);
            var stateDocViewModel = new StateDocViewModel
            {
                AdminHeaderViewModel = new AdminHeaderViewModel
                {
                    Admin = SelectedAdmin
                },
                TDocBasic = tmodel
            };
            return View(stateDocViewModel);
        }

    }
}
