﻿using System;
using System.Collections.Generic;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Admins.ViewModels
{
    public class DocViewModel
    {
        public AdminHeaderViewModel AdminHeaderViewModel { get; set; }
        public List<DocBasicViewModel> DocList { get; set; }
        public DocBasicViewModel TDocBasic { get; set; }
        public Dictionary<int, string> StateList { get; set; }
        public string SelectedState { get; set; }
        public Dictionary<string, string> ProductList { get; set; }
        public string SelectedProduct { get; set; }
        public Dictionary<string, string> ChannelList { get; set; }
        public string SelectedChannel { get; set; }
        public string Active { get; set; }


    }
}