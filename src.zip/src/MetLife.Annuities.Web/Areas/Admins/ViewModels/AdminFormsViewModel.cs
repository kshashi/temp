﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Admins.ViewModels
{
    public class AdminFormsViewModel 
    {
        public AdminHeaderViewModel AdminHeaderViewModel { get; set; }
        public form[] T_DOC_ST { get; set; }
        public form[] T_DOCS { get; set; }
    }
}
