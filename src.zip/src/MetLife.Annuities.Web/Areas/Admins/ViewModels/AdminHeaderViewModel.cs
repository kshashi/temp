﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web;

namespace MetLife.Annuities.Web.Areas.Admins.ViewModels
{
    public class AdminHeaderViewModel
    {
        public admin Admin { get; set; }
    }
}