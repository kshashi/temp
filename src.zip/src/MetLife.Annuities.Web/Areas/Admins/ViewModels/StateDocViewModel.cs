﻿using System;
using System.Collections.Generic;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Admins.ViewModels
{
    public class StateDocViewModel
    {
        public StateDocBasicViewModel TDocBasic { get; set; }
        public AdminHeaderViewModel AdminHeaderViewModel { get; set; }

        public List<StateDocBasicViewModel> StateMappingList { get; set; }
        public Dictionary<string, string> DocList { get; set; }
        public string SelectedDoc { get; set; }
    }
}