﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.API.Controllers
{
    [Authorize]
    public class TestController : Controller
    {
        public JsonResult Index()
        {
            return Json(new
            {
                user = User.Identity.Name,
                is_authenticated = User.Identity.IsAuthenticated,
                roles = string.Join(", ", System.Web.Security.Roles.GetRolesForUser())
            }, JsonRequestBehavior.AllowGet);
        }

    }
}
