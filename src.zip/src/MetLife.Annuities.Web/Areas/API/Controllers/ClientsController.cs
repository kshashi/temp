﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Advisors;

namespace MetLife.Annuities.Web.Areas.API.Controllers
{
    [Authorize]
    public class ClientsController : Controller
    {
        public IContentService ContentService { get { return new TridianContentService(); } }
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();

        public JsonResult Resources(string type)
        {
            string advisorUniversalID = string.Empty;
            string clientId = string.Empty;
            string clientState = string.Empty;

            if (User.IsInRole("Advisor"))
            {
                var advisorFull = AdvisorService.GetAdvisor(User.Identity.Name);
                advisorUniversalID = advisorFull.universal_id;
            }
            else if (User.IsInRole("RVP"))
            {
                var cookie = Request.Cookies["advisor_id"];                                
                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Decrypt(cookie);
                    int advisor_id = int.Parse(cookie.Value);
                    var advisor = DataService.GetAdvisor(advisor_id);
                    var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
                    advisorUniversalID = advisorFull.universal_id;
                }
                else
                {
                    Response.Redirect("/rvps/dashboard");
                }
            }

            if (User.IsInRole("Client"))
            {
                var client = DataService.GetClient(User.Identity.Name);
                var advisor = DataService.GetAdvisor(client.AdvisorID);
                var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
                advisorUniversalID = advisorFull.universal_id;
                clientState = client.StateCode;                
            }
            else
            {
                var cookie = Request.Cookies["client_id"];

                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Decrypt(cookie);
                    int client_id = int.Parse(cookie.Value);
                    var client = DataService.GetClient(User.Identity.Name);
                    clientState = client.StateCode;
                    advisorUniversalID = DataService.GetAdvisor(client.AdvisorID).UniversalID;
                }
            }

            var items = ContentService.GetClientResources(clientState, advisorUniversalID);
            var output = new resources_collection();
            switch (type)
            {
                case null:
                    output = items;
                    break;
                case "videos":
                    output.videos = items.videos;
                    break;
                case "documents":
                    output.documents = items.documents;
                    break;
                case "glossary":
                    output.glossary = items.glossary;
                    break;
                case "faqs":
                    output.faqs = items.faqs;
                    break;
                default:
                    break;
            }

            return Json(output, JsonRequestBehavior.AllowGet);
        }

    }
}
