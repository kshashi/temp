﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Clients.Models
{
    public class GlossaryModel
    {
        public char[] Letters
        {
            get
            {
                return "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            }
        }

        public GlossaryLetterModel[] Words { get; private set; }

        public bool HasWordsForLetter(char letter)
        {
            foreach (var item in Words)
            {
                if (item.Letter.Equals(letter))
                    return true;
            }

            return false;
        }

        internal static GlossaryModel GenerateFromGlossaryArray(glossary_item[] glossary_item)
        {


            List<GlossaryLetterModel> model = new List<GlossaryLetterModel>();
            var lettersInUse = glossary_item.Where(g => g.term != null).GroupBy(g => g.term.Substring(0, 1))
                .Select(g => g.Key)
                .OrderBy(g => g);


            foreach (var letter in lettersInUse)
            {
                GlossaryLetterModel letters = new GlossaryLetterModel();

                letters.Letter = char.Parse(letter);

                // get the words
                var words = glossary_item.Where(g => g.term.StartsWith(letter));

                letters.Words = (words.Select(g => new GlossaryItemModel
                {
                    Term = g.term,
                    Definition = g.definition
                }).OrderBy(g => g.Term).ToArray());

                model.Add(letters);
            }
            
            return new GlossaryModel { Words = model.ToArray() };
        }

        private GlossaryModel()
        {

        }
    }
}