﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Clients.Models
{
    public class DocumentCategoryModel
    {
        public List<DocumentCategory> Categories { get; set; }


        internal static DocumentCategoryModel GenerateFromDocArray(document_item[] document_item)
        {
            var model = new DocumentCategoryModel();
            var cats = (from c in document_item
                        select c.category.name).Distinct().ToArray();
            model.Categories = new List<DocumentCategory>();

            foreach (var categoryName in cats)
            {
                var current = (from c in document_item
                               where c.category.name == categoryName
                               select c.category).First();

                var cat = new DocumentCategory
                {
                    Name = categoryName,
                    Description = current.description,
                    Id = categoryName,
                    Documents = (from d in document_item
                                 where d.category.name == categoryName
                                 select d).ToArray()

                };

                model.Categories.Add(cat);
            }



            return model;
        }
    }

    public class DocumentCategory
    {
        public document_item[] Documents { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Id { get; set; }
    }

    public class DocumentModel
    {
        public string Title { get; set; }
        public string Url { get; set; }
    }
}