﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Clients.Models
{
    public class GlossaryLetterModel
    {
        public char Letter { get; set; }

        public GlossaryItemModel[] Words { get; set; }
    }

    public class GlossaryItemModel
    {
        public string Term { get; set; }
        public string Definition { get; set; }
    }
}