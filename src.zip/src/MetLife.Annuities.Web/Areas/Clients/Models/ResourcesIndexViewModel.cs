﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Web.Models;

namespace MetLife.Annuities.Web.Areas.Clients.Models
{
	public class ResourcesIndexViewModel
	{

        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public DocumentCategoryModel Documents { get; set; }

		public FaqCategoryModel[] FaqCategories { get; set; }

        public GlossaryModel GlossaryWords { get; set; }

		public VideoCategoryModel  Videos { get; set; }

        public advisor Advisor { get; set; }

        public disclaimer[] Disclaimer { get; set; }

        public persona Persona { get; set; }
    }
}