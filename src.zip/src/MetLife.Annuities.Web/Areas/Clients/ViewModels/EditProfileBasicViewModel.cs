﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ModelBinders;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class EditProfileBasicViewModel
    {
        public ClientBasicViewModel ClientBasic { get; set; }

        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        [BindAlias("client-id")]
        public int ClientID { get; set; }

        public EditProfileBasicViewModel(ClientBasicViewModel model, Client client)
        {
            ClientBasic = model;
            ClientID = model.ClientID.Value;
            ClientHeaderViewModel = new ClientHeaderViewModel { Client = client };
        }

        private EditProfileBasicViewModel()
        {

        }
    }
}