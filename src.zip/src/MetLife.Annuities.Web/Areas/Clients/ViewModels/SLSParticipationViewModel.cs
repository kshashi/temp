﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class SLSParticipationViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public string ConfigData { get; set; }

        public string ClientAnnuity { get; set; }

        public document_item[] RelatedDocuments { get; set; }
    }
}