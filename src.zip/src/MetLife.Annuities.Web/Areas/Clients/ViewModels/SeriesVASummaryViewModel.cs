﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class SeriesVASummaryViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public disclosures Disclosures { get; set; }
        public Services.Annuities.Hypothetical Annuitiy { get; set; }

        public string IllustrationData { get; set; }

        public string AllocationsData { get; set; }

        public Services.Models.allocations AllocationsContent { get; set; }

        public string GuaranteedCompoundingRate { get; set; }
    }
}