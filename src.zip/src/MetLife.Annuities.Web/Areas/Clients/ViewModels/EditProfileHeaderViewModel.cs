﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class EditProfileHeaderViewModel
    {
        public int ClientID { get; set; }
    }
}
