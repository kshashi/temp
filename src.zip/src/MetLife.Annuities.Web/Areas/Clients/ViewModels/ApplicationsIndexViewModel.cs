﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class ApplicationsIndexViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public Client Client { get; set; }
        public advisor Advisor { get; set; }
        public bool DidClientStartApplication { get; set; }

       
        public bool DidClientAgree { get; set; }

        public bool WasProspectusSent { get; set; }

        public bool IsAdvisorView { get; set; }

        public form Prospectus { get; set; }

        public SavedProductItem Annuity { get; set; }
    }
}