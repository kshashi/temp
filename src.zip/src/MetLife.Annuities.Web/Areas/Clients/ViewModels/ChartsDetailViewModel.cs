﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class ChartsDetailViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }
    }
}