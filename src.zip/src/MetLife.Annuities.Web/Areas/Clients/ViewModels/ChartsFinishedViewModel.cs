﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Web.ModelBinders;
using System.Web.Mvc;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class ChartsFinishedViewModel
    {
        [BindAlias("hypo-name")]
        public string HypotheticalName { get; set; }
        public AllocationGroup[] AllocationGroups { get; set; }
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }
        public Hypothetical Annuity { get; set; }
        public allocations Allocations { get; set; }
        public disclosures Disclosures { get; set; }

    }

    public class AllocationGroup
    {
        public string id { get; set; }
        public int percent { get; set; }
        public string name { get; set; }
        public string portfolioname { get; set; }

    }
}