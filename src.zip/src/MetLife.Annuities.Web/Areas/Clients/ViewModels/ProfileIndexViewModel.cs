﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class ProfileIndexViewModel
    {

        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }
        public ClientFullViewModel ClientFullViewModel { get; set; }
    }
}