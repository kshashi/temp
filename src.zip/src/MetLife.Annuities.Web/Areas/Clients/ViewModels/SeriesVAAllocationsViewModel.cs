﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class SeriesVAAllocationsViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }
        public string AllocationsData { get; set; }
        public allocations AllocationsContent { get; set; }
        public  Hypothetical Hypothetical { get; set; }
        public disclosures Disclosures { get; set; }
        public document_item[] RelatedDocuments { get; set; }
    }
}