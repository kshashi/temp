﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class ApplicationsFindViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public Services.Models.form[] Forms { get; set; }

        public bool AgreedToProspectus { get; set; }
        public Services.Annuities.SavedProductItem Annuity { get; set; }
    }
}