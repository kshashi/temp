﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class SLSProtectionViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public string ConfigData { get; set; }

        public string ClientAnnuity { get; set; }

        public Services.Models.document_item[] Documents { get; set; }
    }
}