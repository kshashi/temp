﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{

    [ModelBinder(typeof(AliasModelBinder))]
    public class SLSSetupSaveViewModel
    {

        [BindAlias("slsId")]
        public string ID { get; set; }

        [BindAlias("slsName")]
        public string Name { get; set; }

        [BindAlias("slsInvestment")]
        public int Investment { get; set; }

        [BindAlias("slsRodb")]
        public bool ReturnOfDeathBenefit { get; set; }

        [BindAlias("slsOptions")]
        public string Options { get; set; }

        [BindAlias("slsCreatedBy")]
        public string CreatedBy { get; set; }

        [BindAlias("slsCreatedTime")]
        public int CreatedTime { get; set; }

    }

}