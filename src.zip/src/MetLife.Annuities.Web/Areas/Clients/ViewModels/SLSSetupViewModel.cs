﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ModelBinders;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class SLSSetupViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public string ConfigData { get; set; }
        
        public Client Client { get; set; }

        [BindAlias("sls-investment")]
        public int Investment { get; set; }

        [BindAlias("sls-pdb")]
        public bool PremiumDeathBenefit { get; set; }

        [BindAlias("shield-option")]
        public ShieldOptionType[] ShieldOptions { get; set; }

        public decimal InitialInvestment { get; set; }
    }

    public class ShieldOptionType
    {
        public string product { get; set; }
        public int term { get; set; }
        public string index { get; set; }
        public decimal allocation { get; set; }
        public decimal rate { get; set; }
    }
}