﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class EditProfileFinancialViewModel
    {
        public ClientFinancialViewModel ClientFinancial { get; set; }

        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }
    }
}