﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class ChartsSavedViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public SavedProductItem[] SavedProducts { get; set; }

        public Services.Data.Client Client { get; set; }

        public Services.Data.ClientFinance ClientFinancials { get; set; }

        public string[] ProductList { get; set; }

        public Services.Models.advisor Advisor { get; set; }

        public bool RoleHomeOffice { get; set; }

        public bool UserCanCreateAnnuities { get; set; }

        public bool CanSellSLS { get; set; }

        public string AdvisorProfileUrl { get; set; }

        public bool CanSellVariable { get; set; }

        public string[] VariableProducts { get; set; }

        public object ClientStateCode { get; set; }
    }
}