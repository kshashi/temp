﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class ChartsProductsViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public string AdvisorUniversalId { get; set; }

        public string FirmCode { get; set; }

        public string ClientFirstName { get; set; }

        public string ClientLastName { get; set; }

        public string ClientDOB { get; set; }

        public char ClientGender { get; set; }

        public decimal InitialInvestment { get; set; }

        public string ProductList { get; set; }

        public object ClientStateCode { get; set; }
    }
}