﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class SLSSummaryViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public string ConfigData { get; set; }

        public Client Client { get; set; }
        public string ClientAnnuity { get; set; }


        public ShieldProduct Annuity { get; set; }
    }
}