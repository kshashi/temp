﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    public class SeriesVAGMIBViewModel
    {
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }

        public string IllustrationData { get; set; }

        public document_item[] RelatedDocuments { get; set; }

        public bool HasEDB { get; set; }

        public Services.Annuities.Hypothetical Hypothetical { get; set; }
    }
}