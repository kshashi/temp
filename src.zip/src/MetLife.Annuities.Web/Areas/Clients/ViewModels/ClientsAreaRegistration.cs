﻿using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Clients
{
	public class ClientsAreaRegistration : AreaRegistration
	{
		public override string AreaName
		{
			get
			{
				return "Clients";
			}
		}

		public override void RegisterArea(AreaRegistrationContext context)
		{
			context.MapRoute(
				"Clients_default",
				"clients/{controller}/{action}/{id}",
				new { action = "Index", id = UrlParameter.Optional }
			);
		}
	}
}
