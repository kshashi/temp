﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;

namespace MetLife.Annuities.Web.Areas.Clients.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class EditProfileSettingsViewModel
    {
        [BindAlias("form-editclient-settings")]
        public ClientProfileSettingsViewModel ClientProfileSettingsViewModel { get; set; }
        public ClientHeaderViewModel ClientHeaderViewModel { get; set; }
    }
}