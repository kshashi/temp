﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class SettingsController : Controller
    {  
        public ActionResult Index()
        {
            return View();
        }

    }
}
