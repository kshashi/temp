﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Web.Areas.Clients.Models;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Advisors;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class TestimonialsController : ClientsControllerBase
    {
        private IContentService ContentService = new TridianContentService();
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();

        [HttpGet]
        public ActionResult Index()
        {
            var client = SelectedClient;
            var advisorId = DataService.GetAdvisor(client.AdvisorID).UniversalID;
            var advisor = AdvisorService.GetAdvisor(advisorId);
            var user = DataService.GetUserProfileByExternalId(advisorId);
            var persona = ContentService.GetPersonas().persona.FirstOrDefault(g => g.id == client.BrightcovePlaylistID);
            advisor.profile_image_uri = user.ProfileImageUrl;

            var disclaimer = ContentService.GetDisclaimer("video").ToList();
            ViewBag.Disclaimers = disclaimer.ToArray();

            if (User.IsInRole("Client"))
                DataService.UpdateClientProgress(SelectedClient.ClientID, Services.ClientProgressType.EducationalSegmentReview, advisor);

            var model = new ResourcesIndexViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel { Client = client },
                Advisor = advisor,
                Persona = persona
            };
            return View(model);
        }


    }
}
