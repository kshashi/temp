﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class AllocationsController : ClientsControllerBase
    {
        [HttpPost]
        public ActionResult Index(int id)
        {
            var model = new portfolio_allocation
            {
                name = "Portfolio Name",
                description = "Portfolio description data",
                allocations = new allocation[]
                {
                    new allocation{
                        name="Allocation Type 1",
                        percentage = .10M,
                        description = "Allocation description"
                    },
                    new allocation{
                        name="Allocation Type 2",
                        percentage = .30M,
                        description = "Allocation description"
                    },
                    new allocation{
                        name="Allocation Type 3",
                        percentage = .60M,
                        description = "Allocation description"
                    },
                }
            };
            return Json(model);
        }

        private class allocation
        {
            public string name { get; set; }

            public decimal percentage { get; set; }

            public string description { get; set; }
        }

        private class portfolio_allocation
        {
            public string name { get; set; }
            public string description { get; set; }
            public allocation[] allocations { get; set; }


        }
    }
}
