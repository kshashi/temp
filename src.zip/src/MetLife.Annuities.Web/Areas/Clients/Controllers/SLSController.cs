using System;
using System.Linq;
using System.Web.Mvc;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services;
using Winnovative;
using System.Web.Security;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class SLSController : ClientsControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IContentService ContentService = new TridianContentService();
        private IAdvisorService AdvisorService = new AdvisorService();
        private IAnnuityService AnnuityService = new SqlAnnuityService();

        public ActionResult Setup()
        {
            var client = SelectedClient;
            var config = GetConfigData(client.StateCode);
            var finance = DataService.GetClientFinance(client.ClientID);
            return View(new SLSSetupViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                ConfigData = config,
                Client = client,
                InitialInvestment = finance.InitialInvestment.Value
            });
        }

        [HttpPost]
        public ActionResult Setup(SLSSetupSaveViewModel model)
        {
            ShieldOptionType[] shieldOptions = JsonConvert.DeserializeObject<ShieldOptionType[]>(Request.Form[3].ToString());

            var sls = ContentService.GetSLSConfiguration();
            var indexes = ContentService.GetMarketIndexes();

            var product = new ShieldProduct
            {
                EnhancedDeathBenefit = model.ReturnOfDeathBenefit,
                InitialInvestment = model.Investment,
                Name = model.Name,

            };

            product.ShieldOptions = new ShieldOption[shieldOptions.Length];
            for (int i = 0; i < shieldOptions.Length; i++)
            {
                var opt = new ShieldOption
                {
                    AllocationPercent = shieldOptions[i].allocation,
                    IndexCode = shieldOptions[i].index,
                    ShieldCode = shieldOptions[i].product,
                    TermLength = shieldOptions[i].term,
                    MGOStepRate = shieldOptions[i].rate
                };

                opt.IndexName = indexes.market_index.Single(index => index.code == opt.IndexCode).name;
                opt.ShieldName = sls.options.option.Single(o => o.id == opt.ShieldCode).name;
                var optProtection = sls.options.option.Single(o => o.id == opt.ShieldCode).protection;
                if (optProtection == null) optProtection = "0";
                opt.Protection = decimal.Parse(optProtection);

                product.ShieldOptions[i] = opt;
            }


            int id = DataService.SaveShieldProduct(product, SelectedClient);


            var advisor1 = DataService.GetAdvisor(SelectedClient.AdvisorID);
            var advisor = AdvisorService.GetAdvisor(advisor1.UniversalID);
            DataService.UpdateClientProgress(SelectedClient.ClientID, ClientProgressType.ProductPresentationInProgress, advisor);

            return Json(new
            {
                success = true,
                id = id
            });
        }

        public ActionResult Protection(int id)
        {
            var client = SelectedClient;
            var config = GetConfigData(client.StateCode);
            var annuity = GetSLSAnnuity(id);
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
            var docs = ContentService.GetRelatedDocuments(false, "SA6YR1", client.StateCode, advisorFull.advisor_type);
            var disclaimer = ContentService.GetDisclaimer("SLS");
            ViewBag.Disclaimers = disclaimer;
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            return View(new SLSProtectionViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                ConfigData = config,
                ClientAnnuity = annuity,
                Documents = docs
            });
        }

        public ActionResult Participation(int id)
        {
            var client = SelectedClient;
            var config = GetConfigData(client.StateCode);
            var annuity = GetSLSAnnuity(id);
            var shield = DataService.GetShieldProduct(id);
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
            var resources = ContentService.GetClientResources(SelectedClient.StateCode, advisorFull.universal_id);
            var docs = ContentService.GetRelatedDocuments(false, "SA6YR1", client.StateCode, advisorFull.advisor_type);
            var disclaimer = ContentService.GetDisclaimer("SLS");
            ViewBag.Disclaimers = disclaimer;
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            return View(new SLSParticipationViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                ConfigData = config,
                ClientAnnuity = annuity,
                RelatedDocuments = docs
            });
        }

        public ActionResult Summary(int id)
        {
            var sls = GetSLSAnnuity(id);
            var client = SelectedClient;
            var config = GetConfigData(client.StateCode);
            var annuity = DataService.GetShieldProduct(id);

            var disclaimer = ContentService.GetDisclaimer("SLS");
            ViewBag.Disclaimers = disclaimer;
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            return View(new SLSSummaryViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                ConfigData = config,
                ClientAnnuity = sls,
                Client = client,
                Annuity = annuity
            });
        }

        public ActionResult Recommended(int id)
        {
            var client = SelectedClient;
            var config = GetConfigData(client.StateCode);
            var annuity = GetSLSAnnuity(id);
            var disclaimer = ContentService.GetDisclaimer("SLS");
            ViewBag.Disclaimers = disclaimer;
            return View(new SLSRecommendedViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                ConfigData = config,
                ClientAnnuity = annuity
            });
        }

        public ActionResult ChartPDF(int id)
        {


            var pdfFile = AnnuityService.GetSummaryPDF(id);
            if (pdfFile == null)
            {
                //client_id
                PdfConverter pdfConverter = new PdfConverter();
                pdfConverter.HttpRequestCookies.Add(FormsAuthentication.FormsCookieName, Request.Cookies[FormsAuthentication.FormsCookieName].Value);
                var cookie = Request.Cookies["client_id"];

                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Encrypt(cookie);
                    pdfConverter.HttpRequestCookies.Add(cookie.Name, cookie.Value);
                }

                cookie = Request.Cookies["advisor_id"];
                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Encrypt(cookie);
                    pdfConverter.HttpRequestCookies.Add(cookie.Name, cookie.Value);
                }

                pdfConverter.JavaScriptEnabled = true;
                pdfConverter.MediaType = "screen";
                pdfConverter.TriggeringMode = TriggeringMode.Manual;
                pdfConverter.PdfDocumentOptions.LiveUrlsEnabled = false;
                pdfConverter.PdfDocumentOptions.BottomMargin = 5;
                pdfConverter.PdfDocumentOptions.TopMargin = 5;
                pdfConverter.LicenseKey = SiteConfiguration.WinnovativePDFLicense;
                pdfFile = pdfConverter.GetPdfBytesFromUrl(string.Format("{0}/public/sharepoint/hypo/sls/{1}", SiteConfiguration.BaseUrl, id.ToString()));                
                //Save the pdf to storage
                AnnuityService.SaveSummaryPDF(id, pdfFile);
            }
            return File(pdfFile, "application/pdf", "SLS.pdf");
        }


        public ActionResult SummaryPDF(int id)
        {
            var sls = GetSLSAnnuity(id);
            var client = SelectedClient;
            var config = GetConfigData(client.StateCode);
            var annuity = DataService.GetShieldProduct(id);
            RouteData.DataTokens["area"] = "Clients";
            var disclaimer = ContentService.GetDisclaimer("SLS");
            ViewBag.Disclaimers = disclaimer;
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            RouteData.DataTokens["area"] = "Clients";
            return View(new SLSSummaryViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                ConfigData = config,
                ClientAnnuity = sls,
                Client = client,
                Annuity = annuity
            });
        }

        #region Helper Methods

        private string GetSLSAnnuity(int id)
        {
            //return @"{""slsId"":""10"",""slsName"":""SLS Annuity with RODB"",""slsInvestment"":2670000,""slsRodb"":true,""slsCreatedBy"":""Dave Johnson"",""slsCreatedTime"":1367524386000,""slsOptions"":""[{\""product\"":\""shield10\"",\""term\"":\""1\"",\""index\"":\""nasdaq\"",\""allocation\"":10},{\""product\"":\""shield10\"",\""term\"":\""3\"",\""index\"":\""russell\"",\""allocation\"":10},{\""product\"":\""shield10\"",\""term\"":\""6\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""shield10step\"",\""term\"":\""1\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""shield10step\"",\""term\"":\""3\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""shield15\"",\""term\"":\""3\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""shield25\"",\""term\"":\""6\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""shield100\"",\""term\"":\""1\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""shield100step\"",\""term\"":\""1\"",\""index\"":\""sp\"",\""allocation\"":10},{\""product\"":\""fixed\"",\""term\"":\""1\"",\""index\"":\""fixed\"",\""allocation\"":10}]""}";

            var shield = DataService.GetShieldProduct(id);
            var sls = new slsAnnuity
            {
                slsName = shield.Name,
                slsInvestment = shield.InitialInvestment.ToString(),
                slsRodb = shield.EnhancedDeathBenefit,
                slsCreatedTime = "1367524386000",//shield.CreatedTime,
                slsCreatedBy = "Dave Johnson",
                slsId = id.ToString()
            };

            sls.slsOptions = JsonConvert.SerializeObject((from s in shield.ShieldOptions
                                                          select new slsOptionsSlsOption
                                                          {
                                                              product = s.ShieldCode,
                                                              allocation = s.AllocationPercent.ToString(),
                                                              term = s.TermLength.ToString(),
                                                              index = s.IndexCode,
                                                              rate = s.MGOStepRate.ToString()
                                                          }).ToArray());
            return JsonConvert.SerializeObject(sls);

        }
        private string GetConfigData(string stateCode)
        {
            //return @"{""indexes"":[{""id"":""sp"",""name"":""S&amp;P 500&reg;"",""description"":""S&amp;P 500&reg; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""disclosures"":[""The S&amp;P 500&reg; index disclosure 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""The S&amp;P 500&reg; index disclosure 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.""]},{""id"":""russell"",""name"":""Russell 2000&reg;"",""description"":""Russell 2000&reg; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""disclosures"":[""The Russell 2000&reg; index disclosure 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""The Russell 2000&reg; index disclosure 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.""]},{""id"":""nasdaq"",""name"":""NASDAQ 100&reg;"",""description"":""NASDAQ 100&reg; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""disclosures"":[""The NASDAQ 100&reg; index disclosure 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""The NASDAQ 100&reg; index disclosure 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.""]},{""id"":""msci"",""name"":""MSCI EAFE&reg;"",""description"":""MSCI EAFE&reg; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""disclosures"":[""The MSCI EAFE&reg; index disclosure 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""The MSCI EAFE&reg; index disclosure 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.""]},{""id"":""dow"",""name"":""Dow Jones - UBS Commodity Index&#8480;"",""description"":""Dow Jones - UBS Commodity Index&#8480; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""disclosures"":[""The Dow Jones - UBS Commodity Index&#8480; index disclosure 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""The Dow Jones - UBS Commodity Index&#8480; index disclosure 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.""]},{""id"":""fixed"",""name"":""Fixed Account"",""description"":""Fixed Account Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""disclosures"":[""The Fixed Account index disclosure 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi."",""The Fixed Account index disclosure 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.""]}],""products"":[{""id"":""shield10"",""name"":""Shield 10"",""isStepRate"":false,""protection"":10,""terms"":[{""years"":1,""indexes"":[{""id"":""sp"",""rate"":29,""raterodb"":9,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""russell"",""rate"":11,""raterodb"":10,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""nasdaq"",""rate"":12,""raterodb"":11,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""msci"",""rate"":13,""raterodb"":12,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""dow"",""rate"":14,""raterodb"":13,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]},{""years"":3,""indexes"":[{""id"":""sp"",""rate"":15,""raterodb"":14,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""russell"",""rate"":16,""raterodb"":15,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""nasdaq"",""rate"":17,""raterodb"":16,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""msci"",""rate"":18,""raterodb"":17,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]},{""id"":""dow"",""rate"":19,""raterodb"":18,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]},{""years"":6,""indexes"":[{""id"":""sp"",""rate"":20,""raterodb"":19,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]}]},{""id"":""shield10step"",""name"":""Shield 10 Step Rate"",""isStepRate"":true,""protection"":10,""terms"":[{""years"":1,""indexes"":[{""id"":""sp"",""rate"":21,""raterodb"":20,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]},{""years"":3,""indexes"":[{""id"":""sp"",""rate"":22,""raterodb"":21,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]}]},{""id"":""shield15"",""name"":""Shield 15"",""isStepRate"":false,""protection"":15,""terms"":[{""years"":3,""indexes"":[{""id"":""sp"",""rate"":23,""raterodb"":22,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]},{""years"":6,""indexes"":[{""id"":""sp"",""rate"":24,""raterodb"":23,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]}]},{""id"":""shield25"",""name"":""Shield 25"",""isStepRate"":false,""protection"":25,""terms"":[{""years"":6,""indexes"":[{""id"":""sp"",""rate"":25,""raterodb"":24,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]}]},{""id"":""shield100"",""name"":""Shield 100"",""isStepRate"":false,""protection"":100,""terms"":[{""years"":1,""indexes"":[{""id"":""sp"",""rate"":26,""raterodb"":25,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":20}]}]}]},{""id"":""shield100step"",""name"":""Shield 100 Step Rate"",""isStepRate"":true,""protection"":100,""terms"":[{""years"":1,""indexes"":[{""id"":""sp"",""rate"":27,""raterodb"":26,""historic"":[{""name"":""10% - 15% Loss"",""months"":11,""percent"":27},{""name"":""15% - 20% Loss"",""months"":8,""percent"":20},{""name"":""20% - 25% Loss"",""months"":9,""percent"":22},{""name"":""25% - 30% Loss"",""months"":5,""percent"":12},{""name"":""Greater than 30% Loss"",""months"":8,""percent"":23}]}]}]},{""id"":""fixed"",""name"":""Fixed Account"",""isStepRate"":false,""protection"":0,""terms"":[{""years"":1,""indexes"":[{""id"":""fixed"",""rate"":28,""raterodb"":27,""historic"":[]}]}]}]}";

            var sls = ContentService.GetSLSConfiguration();
            var indexes = ContentService.GetMarketIndexes();

            var config = new sls
            {
                indexes = (from i in indexes.market_index
                           select new index
                           {
                               description = i.description,
                               id = i.code,
                               name = i.name,
                               disclosures = (from d in i.disclosures
                                              select d).ToArray()
                           }).ToArray(),
                products = (from p in sls.options.option.Where(o => !o.name.Contains("100") || (stateCode != "TX" && stateCode != "NY"))
                            select new sls_product
                            {
                                id = p.id,
                                name = p.name,
                                isStepRate = p.type == "Step Rate" ? true : false,
                                protection = p.protection,
                                terms = (from t in p.terms
                                         select new term
                                         {
                                             years = t.years,
                                             indexes = (from i in t.indexes
                                                        select new termIndex
                                                        {
                                                            id = i.id,
                                                            rate = Math.Round(i.rate, 2),
                                                            raterodb = Math.Round(i.premium_rate, 2),
                                                            y_axis_ceiling_down_market = i.y_axis_ceiling_down_market,
                                                            y_axis_ceiling_flat_market = i.y_axis_ceiling_flat_market,
                                                            y_axis_ceiling_up_market = i.y_axis_ceiling_up_market

                                                        }).ToArray()
                                         }).ToArray()

                            }).ToArray()
            };
            return JsonConvert.SerializeObject(config);
        }

        #endregion
    }
}
