﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Security;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Fulfillment;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class ChartsController : ClientsControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IContentService ContentService = new TridianContentService();
        private IAdvisorService AdvisorService = new AdvisorService();
        private IAnnuityService AnnuityService = new SqlAnnuityService();
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Products()
        {
            // get all the products from Tridion
            var advisor = DataService.GetAdvisor(SelectedClient.AdvisorID);
            var migAdvisor = AdvisorService.GetAdvisor(advisor.UniversalID);
            var planCodes = AdvisorService.GetPlanCodesForAdvisor(advisor.UniversalID,SelectedClient.StateCode);
            var finances = DataService.GetClientFinance(SelectedClient.ClientID);

            var model = new ChartsProductsViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = SelectedClient
                },
                AdvisorUniversalId = advisor.UniversalID,
                ClientDOB = SelectedClient.DateOfBirth.ToShortDateString(),
                ClientFirstName = SelectedClient.FirstName,
                ClientLastName = SelectedClient.LastName,
                ClientGender = SelectedClient.Gender,
                FirmCode = migAdvisor.firm.firm_code,
                InitialInvestment = finances.InitialInvestment.Value,
                ProductList = string.Join(",", planCodes),
                ClientStateCode = SelectedClient.StateCode

            };
            return View(model);
        }

        public ActionResult Saved()
        {
            var client = SelectedClient;
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var adv = AdvisorService.GetAdvisor(advisor.UniversalID);
            var financials = DataService.GetClientFinance(client.ClientID);
            var productlist = AdvisorService.GetPlanCodesForAdvisor(advisor.UniversalID,client.StateCode);
            var advisorProfilePic = advisor.UserProfile.ProfileImageUrl;
            SavedProductItem[] saved = DataService.GetSavedAnnuities(client.ClientID);
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress,
                    adv);
            }

            var model = new ChartsSavedViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                SavedProducts = saved,
                Client = client,
                ClientFinancials = financials,
                ProductList = productlist,
                Advisor = adv,
                RoleHomeOffice = User.IsInRole("HomeOffice"),
                UserCanCreateAnnuities = !User.IsInRole("Client"),
                CanSellSLS = AdvisorService.CanSellProductType(advisor.UniversalID,client.StateCode, AnnuityProductType.ShieldLevel),
                CanSellVariable = AdvisorService.CanSellProductType(advisor.UniversalID, client.StateCode, AnnuityProductType.Variable),
                VariableProducts = AdvisorService.GetVeriableProducts(advisor.UniversalID, client.StateCode),
                AdvisorProfileUrl = advisorProfilePic,
                ClientStateCode = client.StateCode
            };
            return View(model);
        }

        [HttpGet]
        public ActionResult Finished(string status, Guid id)
        {
            var client = SelectedClient;
            var saved = DataService.GetAnnuity(id);
            Hypothetical annuity = null;
            ViewBag.Disclaimers = ContentService.GetDisclaimer("pgsinvestment");
            if (saved.HasError == false)
            {
                annuity = AnnuityService.GetHypothetical(id);

            }
            allocations allocations = null;
            if (annuity != null)
            {
                allocations = ContentService.GetAllocations();
                annuity.GuaranteedCompoundingRate = SiteConfiguration.GuaranteedCompoundingRate;
            }
            var model = new ChartsFinishedViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                Annuity = annuity,
                Allocations = allocations,
                Disclosures = ContentService.GetDisclosures()
            };
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Finished(ChartsFinishedViewModel model)
        {
            var hypo = AnnuityService.GetHypothetical(model.Annuity.Id);
            var summary = DataService.GetAnnuity(model.Annuity.Id);

            summary.InitialInvestment = hypo.InitialInvestment;
            summary.ProductTypeName = hypo.ProductTypeName;
            summary.ReceivePayments = hypo.ReceivePayments;
            summary.ProductAddOnNames = hypo.ProductAddOnNames;

            model.AllocationGroups = model.AllocationGroups.Where(g => g.percent > 0).ToArray();


            var allocationGroups = from a in model.AllocationGroups
                                   group a by a.portfolioname into p
                                   select new groups_rootGroups
                                   {
                                       groupName = p.Key,
                                       groupPercent = p.Sum(x => x.percent),
                                       portfolios = (from g in p
                                                     select new groups_rootGroupsPortfolio
                                                     {
                                                         id = g.id,
                                                         name = g.name,
                                                         percent = g.percent
                                                     }).ToArray()

                                   };


            DataService.UpdateSummaryItem(summary);

            hypo.Allocations = new groups_root { groups = allocationGroups.ToArray() };
            hypo.GuaranteedCompoundingRate = SiteConfiguration.GuaranteedCompoundingRate;
            AnnuityService.UpdateHypothetical(model.Annuity.Id, model.HypotheticalName, hypo);


            var id = DataService.GetAdvisor(SelectedClient.AdvisorID);
            var advisor = AdvisorService.GetAdvisor(id.UniversalID);
            DataService.UpdateClientProgress(SelectedClient.ClientID, Services.ClientProgressType.ProductPresentationInProgress,
             advisor);

            return RedirectToAction("saved");
        }
        public ActionResult Detail(int client_id, string status)
        {
            var client = DataService.GetClient(client_id);
            var model = new ChartsDetailViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                }
            };
            return View(model);
        }

        public ActionResult Delete(int id)
        {
            DataService.DeleteHypothetical(id);
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }
    }
}
