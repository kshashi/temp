﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Web.Extensions;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class ActivityController : ClientsControllerBase
    {
        IDataService DataService = new SqlDataService();

        public ActionResult Index()
        {
            var client = SelectedClient;
            return View(new ClientHeaderViewModel { Client = client });
        }


        [HttpPost]
        public ActionResult Index(int page, string sort, string filter)
        {
            var items = new List<ActivityIndexViewModel>();


            var data = DataService.GetClientActivity(SelectedClient.AdvisorID, SelectedClient.ClientID, page, 10, sort, filter);

            items = (from d in data.Items
                     select new ActivityIndexViewModel
                     {
                         FirstName = d.Client.FirstName.ToString(),
                         LastName = d.Client.LastName.ToString(),
                         ActivityType = d.Type,
                         ActivityDescription = d.Description.ToString(),
                         Date = d.Date.ToRelativeDateTime(),
                         Timestamp = d.Date.ToJavascriptTime(),
                         ClientID = d.Client.ClientID,
                         HistoryType = d.HistoryType

                     }).ToList();

            return Json(new
            {
                sort = sort,
                filter = filter,
                total_pages = data.TotalPages,
                current_page = data.CurrentPage,
                items = items.ToArray()
            });
        }

    }
}
