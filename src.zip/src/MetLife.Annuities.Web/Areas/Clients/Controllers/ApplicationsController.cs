﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Fulfillment;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.RVP;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{

    [Authorize(Roles = "Advisor,RVP,Client")]
    public class ApplicationsController : ClientsControllerBase
    {
        IDataService DataService = new SqlDataService();
        IAdvisorService AdvisorService = new AdvisorService();
        ISharePoint SharePointService = new SharePoint();
        IEmailService EmailService = new EmailService();
        IRVPService RVPService = new MLIRVPService();
        private IAnnuityService AnnuityService = new SqlAnnuityService();
        private IContentService ContentService = new TridianContentService();

        public ActionResult Index()
        {

            var client = SelectedClient;
            var applicationAnnuity = DataService.GetApplicationAnnuity(SelectedClient.ClientID);
           
            if (User.IsInRole("Client") && applicationAnnuity.WasPurchased)
            {
                return RedirectToAction("purchase");
            }
            if (SelectedClient.ClientProgress >= ClientProgressType.AccessGrantedToApplicationForms)
            {   
                return RedirectToAction("find");
            }

            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
            advisorFull.profile_image_uri = advisor.UserProfile.ProfileImageUrl;

            var code = GetAnnuityProductCode(applicationAnnuity);

            form prospectus = SharePointService.GetFormList(code, client.StateCode, advisorFull.advisor_type)
                    .SingleOrDefault(g => g.type.ToString() == "Prospectus");


            if (prospectus == null)
                throw new ApplicationException(string.Format("There is no prospectus defined for product code '{0}' and state '{1}'", code, client.StateCode));

            var model = new ApplicationsIndexViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                Client = client,
                Advisor = advisorFull,
                IsAdvisorView = !User.IsInRole("Client"),
                Prospectus = prospectus,
                Annuity = applicationAnnuity
            };
            return View(model);
        }

        public ActionResult Find(bool agree = false)
        {
            var client = SelectedClient;
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var adv = AdvisorService.GetAdvisor(advisor.UniversalID);
            if (!agree)
            {
                agree = (SelectedClient.ClientProgress >= ClientProgressType.AccessGrantedToApplicationForms);
            }
           
            if (User.IsInRole("Client") && agree == true)
            {
                if (client.ClientProgress < ClientProgressType.ProspectusConsentAndAccessConfirmed)
                {

                    var applicationAnnuity = DataService.GetApplicationAnnuity(client.ClientID);
                    Hypothetical hypothetical = null;
                    var code = GetAnnuityProductCode(applicationAnnuity);

                    DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProspectusConsentAndAccessConfirmed, adv);
                    DataService.SaveApplicationConsent(client, applicationAnnuity, hypothetical, code, true, true, adv);
                    DataService.WriteClientHistory(HistoryType.ProspectusDelievered, client.ClientID, null);
                }


                if (client.ClientProgress < ClientProgressType.AccessGrantedToApplicationForms)
                {
                    DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.AccessGrantedToApplicationForms, adv);
                    DataService.WriteClientHistory(HistoryType.ApplicationForms, client.ClientID, null);
                }
            }

            if (User.IsInRole("Client") && agree == false)
            {
                Disagree();
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProspectusDeliveryInProgress, adv);

                return RedirectToAction("index");
            }

            var annuity = DataService.GetApplicationAnnuity(SelectedClient.ClientID);

            ViewBag.WasPurchased = annuity.WasPurchased;

            var productcode = GetAnnuityProductCode(annuity);

            form[] forms = SharePointService.GetFormList(productcode, client.StateCode, adv.advisor_type);

            if (annuity.ProductType == AnnuityProductType.ShieldLevel)
            {
                forms = forms.Where(g => g.distribution.ToString() == adv.advisor_type).ToArray();
            }
            var model = new ApplicationsFindViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                Forms = forms,
                Annuity = annuity,
                AgreedToProspectus = agree
            };
            return View(model);
        }

        public ActionResult Purchase()
        {
            var client = SelectedClient;
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
            var annuity = DataService.GetApplicationAnnuity(client.ClientID);
                      
            DataService.MarkApplicationPurchased(annuity.Id);
            
            var model = new ApplicationsPurchaseViewModel
            {
                Advisor = advisorFull,
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                Annuity = annuity
            };
            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "Client")]
        public ActionResult Disagree()
        {
            var adv = DataService.GetAdvisor(SelectedClient.AdvisorID);
            var advisor = AdvisorService.GetAdvisor(adv.UniversalID);
            var client = DataService.GetClient(SelectedClient.ClientID);
            Hypothetical hypothetical = null;
            client.SocialSecurityNumber = "DECL";
            DataService.SaveClient(client, client.AdvisorID);
            try
            {
                EmailService.SendPaperProspectusEmail(SelectedClient, advisor);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return Redirect("~/public/pages/dnss.html");
            }


            var applicationAnnuity = DataService.GetApplicationAnnuity(client.ClientID);
            var code = GetAnnuityProductCode(applicationAnnuity);
            DataService.SaveApplicationConsent(client, applicationAnnuity, hypothetical, code, false, false, advisor);
            return RedirectToAction("Index");
        }


        [HttpPost]
        [Authorize(Roles = "Client")]
        public ActionResult Agree(FormCollection form)
        {
            var name = form["client-first-name"];
            var ssn = form["client-social"];
            var dob = string.Format("{0}/{1}/{2}", form["client-dob-month"], form["client-dob-day"], form["client-dob-year"]);
            var email = form["client-email[0]"];

            var client = DataService.GetClient(SelectedClient.ClientID);
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var adv = AdvisorService.GetAdvisor(advisor.UniversalID);
            client.SocialSecurityNumber = ssn;

            var applicationAnnuity = DataService.GetApplicationAnnuity(client.ClientID);
             
            var code = GetAnnuityProductCode(applicationAnnuity);

            // get the prospectus
            var forms = SharePointService.GetFormList(code, client.StateCode, adv.advisor_type);
            form prospectus = null;

            if (applicationAnnuity.ProductType == AnnuityProductType.Variable)
                prospectus = SharePointService.GetFormList(code, client.StateCode, adv.advisor_type)
                    .Single(g => g.type.ToString() == "Prospectus");
            else
            {
                prospectus = SharePointService.GetFormList(code, client.StateCode, adv.advisor_type)
                    .Single(g => g.type.ToString() == "Prospectus" && g.distribution.ToString() == adv.advisor_type);
            }
            var file = SharePointService.GetFile(prospectus.path);
            DataService.SaveClient(client, client.AdvisorID);
            EmailService.SendProspectus(client, adv, prospectus, applicationAnnuity, file);
            
            DataService.UpdateClientProgress(client.ClientID, ClientProgressType.ProspectusDeliveryInProgress, adv);
            return RedirectToAction("Index");
        }

        private string GetAnnuityProductCode(SavedProductItem applicationAnnuity)
        {
            var products = ContentService.GetProducts();
            string productCode = string.Empty;
            switch (applicationAnnuity.ProductType)
            {
                case AnnuityProductType.Variable:
                    var typeId = AnnuityService.GetHypothetical(applicationAnnuity.Id).ProductPlanCode;
                    return typeId;

                case AnnuityProductType.ShieldLevel:
                    productCode = products.product.Single(g => g.product_type_id == "shield_annuity_product").plan_code.ToString();
                    return productCode;

                default:
                    break;
            }

            return string.Empty;
        }


        [HttpPost]
        [Authorize(Roles = "Client")]
        public ActionResult Start(int id)
        {
            DataService.StartApplication(id);
            return RedirectToAction("index");
        }


        public ActionResult Download()
        {
            return RedirectToAction("purchase");
        }

    }
}
