﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class ForesightController : Controller
    {

        [HttpGet]
        public ActionResult Reentry(string id)
        {
            return View();
        }

    }
}
