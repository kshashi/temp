﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class EditProfileController : ClientsControllerBase
    {
        public IDataService DataService = new SqlDataService();
        private IUserService UserService = new IBSEUserService();

        public ActionResult Basic()
        {
            var client = SelectedClient;

            var states = DataService.GetStates();
            var marital = DataService.GetMaritalStatuses();
            var genders = DataService.GetGenders();
            var phones = DataService.GetPhoneNumberTypes();

            var model = new ClientBasicViewModel(client, states, marital, phones, genders);

            return View(new EditProfileBasicViewModel(model, client));
        }

        [HttpPost]
        public ActionResult Basic(ClientBasicViewModel model)
        {
            var client = DataService.GetClient(model.ClientID.Value);

            client = model.MapClient(client);

            client = DataService.SaveClient(client, client.AdvisorID);

            DataService.WriteClientHistory(HistoryType.ProfileUpdated, client.ClientID,
                new Dictionary<string, string>(){{"{name}",client.FirstName},
                {"{pronoun}",client.GetPronoun(PronounType.HisHer).ToLower()}});

            return RedirectToAction("financial");
        }


        [HttpGet]
        public ActionResult Financial()
        {
            var client = SelectedClient;
            var finance = DataService.GetClientFinance(client.ClientID);
            var timespans = DataService.GetNeedTimespans();
            var benefits = DataService.GetBenefits();
            var model = new ClientFinancialViewModel(client, finance, timespans, benefits);

            return View(new EditProfileFinancialViewModel { ClientFinancial = model, ClientHeaderViewModel = new ClientHeaderViewModel { Client = client } });
        }

        [HttpPost]
        public ActionResult Financial(ClientFinancialViewModel model)
        {
            var finance = model.MapClientFinance();
            DataService.SaveClientFinance(finance);
            DataService.WriteClientHistory(HistoryType.FinancialProfileUpdated, model.ClientID, new Dictionary<string, string>());
            if (User.IsInRole("Client"))
                return RedirectToAction("settings");
            return Redirect("/clients/profile");
        }


        [Authorize(Roles = "Client")]
        [HttpGet]
        public ActionResult Settings()
        {
            var client = SelectedClient;            
            var questions = UserService.GetUserSecurityQuestions(User.Identity.Name, "");
            var allQuestions = UserService.GetSecurityQuestions();

            var model = new EditProfileSettingsViewModel
            {
                ClientProfileSettingsViewModel = new ClientProfileSettingsViewModel
                {
                    IsAdvisorView = false,
                    ClientPassword = "",
                    SecurityQuestion = questions,
                    Questions = allQuestions,
                    ClientNotificationsEmail = client.EmailAddress
                },
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                }
            };
            return View(model);
        }


        [Authorize(Roles = "Client")]
        [HttpPost]
        public ActionResult Settings(ClientProfileSettingsViewModel model)
        {
            // trying to change the password
            if (model.ChangingPassword)
            {
                if (model.ClientPassword != model.ClientPasswordConfirm)
                {
                    TempData["error-msg"] = "Passwords do not match";
                    return RedirectToAction("settings");
                }
                try
                {
                    string status = string.Empty;                    
                    if (!UserService.ResetPassword(User.Identity.Name, model.ClientPasswordCurrent, model.ClientPassword, out status))
                    {
                        TempData["error-msg"] = status;
                        return RedirectToAction("settings");
                    }
                }
                catch (Exception ex)
                {
                    TempData["error-msg"] = ex.GetBaseException().Message;
                    return RedirectToAction("settings");
                }
            }

            // trying to change password questions
            if (model.ChangingQuestions)
            {
                var response = UserService.SetSecurityQuestions(User.Identity.Name, string.Empty, model.SecurityQuestion, true);
                if (response.Value == "OK")
                {
                    return RedirectToAction("financial");
                }
                else
                {
                    TempData["error-msg"] = response.Value;
                    return RedirectToAction("settings");
                }
            }



            return Redirect("/clients/profile");
        }
    }
}
