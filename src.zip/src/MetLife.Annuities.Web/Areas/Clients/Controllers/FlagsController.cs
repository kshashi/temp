﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using System.Drawing;
using MetLife.Annuities.Services.Data;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    public class FlagsController : ClientsControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IEmailService EmailService = new EmailService();
        private IAdvisorService AdvisorService = new AdvisorService();
        private IAnnuityService AnnuityService = new SqlAnnuityService();

        public ActionResult Chart(int id)
        {
            FlagsChartModel flagsForChart = DataService.GetFlagsForHypothetical(id);

            return Json(flagsForChart, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Chart(SaveChartFlag model)
        {

            int id = 0;
            if (model.action == "delete")
            {
                id = int.Parse(model.data);
                DataService.DeleteFlag(id);

            }
            else
            {
                FlagsChartModel input = JsonConvert.DeserializeObject<FlagsChartModel>(model.data);
                id = DataService.SaveFlag(input.hypothetical_id, 0, input.chart_flags[0].meta, input.chart_flags[0].flags[0], model.action);

                if (model.action == "insert")
                {
                    // get data about the selection
                    var advisor = DataService.GetAdvisor(SelectedClient.AdvisorID);
                    var adv = AdvisorService.GetAdvisor(advisor.UniversalID);
                    var annuity = DataService.GetSavedAnnuities(SelectedClient.ClientID).Single(g => g.Id == input.hypothetical_id);

                    // add to advisor notifcation
                    DataService.WriteClientHistory(HistoryType.FlagsAdded, SelectedClient.ClientID, new Dictionary<string, string>());

                    // send advisor an email
                    try
                    {
                        EmailService.SendAdvisorFlagNotification(adv, SelectedClient, annuity);
                    }
                    catch (MetLife.Annuities.Services.Email.DNSSException)
                    {
                        return new HttpStatusCodeResult(520);
                    }
                }
            }

            return Json(new
            {
                success = true,
                id = id
            });
        }


        [HttpPost]
        public ActionResult Create(FlagsCreateViewModel model)
        {
            int id = DataService.SaveFlag(model.HypotheticalId, model.IllustrationId, model.Meta, model.Flag, "");
            DataService.WriteClientHistory(HistoryType.FlagsAdded, SelectedClient.ClientID, null);
            return Json(new
            {
                success = true,
                id = id
            });
        }


        public ActionResult Redirect(int client_id)
        {
            // get the last flag added
            var flag = DataService.GetLastFlagForClient(client_id);

            if (flag != null)
            {
                var annuity = DataService.GetSavedAnnuities(client_id).Single(g => g.Id == int.Parse(flag.hypothetical_id));
                if (annuity.ProductType == AnnuityProductType.Variable)
                    return Redirect("/clients/seriesva/gmib?id=" + annuity.Id.ToString());
                else
                    return Redirect("/clients/sls/protection?id=" + annuity.Id.ToString());
            }
            else
            {
                return RedirectToAction("saved", "charts");
            }

        }
    }
}
