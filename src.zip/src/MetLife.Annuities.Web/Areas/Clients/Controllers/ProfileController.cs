﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Helpers;


namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class ProfileController : ClientsControllerBase
    {

        private IEmailService EmailService = new EmailService();
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();

        [HttpGet]
        public ActionResult Index()
        {
            var client = SelectedClient;
            persona persona = null;

            var finance = DataService.GetClientFinance(client.ClientID);
            var history = (from a in DataService.GetClientActivity(client.AdvisorID, client.ClientID, 1, 3, "recent", "").Items
                           select new ClientHistory
                           {
                               ActivityDate = a.Date,
                               Description = a.Description,
                               Status = a.Type,
                               Timestamp = DateHelpers.ToJavascriptTimestamp(a.Date.Ticks)
                           }).ToArray();

            var clientProgressCta = new ClientsIndexCTADictionary();
            var progress = DataService.GetClientProgressStates();
            var Progress = new Progress
            {
                Steps = (from s in progress
                         select new ProgressStep
                         {
                             Copy = s.Name,
                             Complete = client.CurrentStatusId >= s.Id,
                             Url = clientProgressCta[s.Id].Url.Replace("{client_id}", client.ClientID.ToString())
                         }).ToArray()

            };
            var model = new ClientFullViewModel(client, finance, persona, null, false, history, Progress);
            var view = new ProfileIndexViewModel
            {
                ClientFullViewModel = model,
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                }
            };
            return View(view);
        }

    }
}
