﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Annuities;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Advisors;
using Winnovative;
using System.Web.Security;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class SeriesVAController : ClientsControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IAnnuityService AnnuityService = new SqlAnnuityService();
        private IContentService ContentService = new TridianContentService();
        private IAdvisorService AdvisorService = new AdvisorService();

        [HttpPost]
        public ActionResult Create()
        {
            var guid = DataService.CreateSeriesVAShell(SelectedClient);
            return Json(new { guid = guid });
        }

        public ActionResult Value()
        {
            var client = SelectedClient;
            return View(new SeriesVAValueViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                }
            });
        }

        public ActionResult GMIB(int id)
        {
            var client = SelectedClient;
            var hypothetical = AnnuityService.GetHypothetical(id);
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
            var docs = ContentService.GetRelatedDocuments(hypothetical.HasEDB, hypothetical.ProductPlanCode, client.StateCode, advisorFull.advisor_type);
            ViewBag.Disclaimers = ContentService.GetProductDisclaimer(hypothetical.HasEDB, hypothetical.ProductPlanCode);
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            return View(new SeriesVAGMIBViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                IllustrationData = JsonConvert.SerializeObject(hypothetical),
                RelatedDocuments = docs,
                HasEDB = hypothetical.HasEDB,
                Hypothetical = hypothetical
            });
        }

        public ActionResult Allocations(int id)
        {
            var client = SelectedClient;
            var hypothetical = AnnuityService.GetHypothetical(id);
            var advisor = DataService.GetAdvisor(client.AdvisorID);
            var advisorFull = AdvisorService.GetAdvisor(advisor.UniversalID);
            var resources = ContentService.GetClientResources(SelectedClient.StateCode, advisorFull.universal_id);
            var docs = ContentService.GetRelatedDocuments(hypothetical.HasEDB, hypothetical.ProductPlanCode, client.StateCode, advisorFull.advisor_type);
            var allocations = ContentService.GetAllocations();
            var disclosures = ContentService.GetDisclosures();
            ViewBag.Disclaimers = ContentService.GetDisclaimer("pgsinvestment");
            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            if (hypothetical.Allocations != null)
            {
                foreach (var item in hypothetical.Allocations.groups)
                {
                    switch (item.groupName)
                    {
                        case "Managed Volatility":
                            item.className = "managed";
                            break;
                        case "Balanced Risk":
                            item.className = "balanced";
                            break;
                        case "Momentum":
                            item.className = "momentum";
                            break;
                        default:
                            break;
                    }
                    foreach (var fund in item.portfolios)
                    {
                        fund.id = fund.id.Replace(" ", "").ToLower();
                    }
                }
            }
            return View(new SeriesVAAllocationsViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                AllocationsData = hypothetical.Allocations != null ? JsonConvert.SerializeObject(hypothetical.Allocations) : null,
                Hypothetical = hypothetical,
                AllocationsContent = allocations,
                RelatedDocuments = docs,
                Disclosures = disclosures
            });
        }

        public ActionResult Summary(int id)
        {
            var client = SelectedClient;
            var hypothetical = AnnuityService.GetHypothetical(id);
            var allocations = ContentService.GetAllocations();
            var disclosures = ContentService.GetDisclosures();
            var disclaimers = ContentService.GetProductDisclaimer(hypothetical.HasEDB, hypothetical.ProductPlanCode).ToList();
            disclaimers.AddRange(ContentService.GetDisclaimer(hypothetical.DocumentProductCode));
            ViewBag.Disclaimers = disclaimers.ToArray();

            if (User.IsInRole("Client"))
            {
                DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewInProgress, null);
            }
            if (hypothetical.Allocations != null)
            {
                foreach (var item in hypothetical.Allocations.groups)
                {
                    switch (item.groupName)
                    {
                        case "Managed Volatility":
                            item.className = "managed";
                            break;
                        case "Balanced Risk":
                            item.className = "balanced";
                            break;
                        case "Momentum":
                            item.className = "momentum";
                            break;
                        default:
                            break;
                    }
                    foreach (var fund in item.portfolios)
                    {
                        fund.id = fund.id.Replace(" ", "").ToLower();
                    }
                }
            }



            return View(new SeriesVASummaryViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                AllocationsData = hypothetical.Allocations != null ? JsonConvert.SerializeObject(hypothetical.Allocations) : null,
                IllustrationData = JsonConvert.SerializeObject(hypothetical),
                Annuitiy = hypothetical,
                AllocationsContent = allocations,
                GuaranteedCompoundingRate = hypothetical.GuaranteedCompoundingRate,
                Disclosures = disclosures

            });
        }

        public ActionResult SummaryPDF(int id)
        {

            var client = SelectedClient;
            var hypothetical = AnnuityService.GetHypothetical(id);
            var allocations = ContentService.GetAllocations();
            var disclosures = ContentService.GetDisclosures();
            var disclaimers = ContentService.GetProductDisclaimer(hypothetical.HasEDB, hypothetical.ProductPlanCode).ToList();
            disclaimers.AddRange(ContentService.GetDisclaimer(hypothetical.DocumentProductCode));
            ViewBag.Disclaimers = disclaimers.ToArray();

            if (hypothetical.Allocations != null)
            {
                foreach (var item in hypothetical.Allocations.groups)
                {
                    switch (item.groupName)
                    {
                        case "Managed Volatility":
                            item.className = "managed";
                            break;
                        case "Balanced Risk":
                            item.className = "balanced";
                            break;
                        case "Momentum":
                            item.className = "momentum";
                            break;
                        default:
                            break;
                    }
                    foreach (var fund in item.portfolios)
                    {
                        fund.id = fund.id.Replace(" ", "").ToLower();
                    }
                }
            }


            RouteData.DataTokens["area"] = "Clients";
            return View(new SeriesVASummaryViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                },
                AllocationsData = hypothetical.Allocations != null ? JsonConvert.SerializeObject(hypothetical.Allocations) : null,
                IllustrationData = JsonConvert.SerializeObject(hypothetical),
                Annuitiy = hypothetical,
                AllocationsContent = allocations,
                GuaranteedCompoundingRate = hypothetical.GuaranteedCompoundingRate,
                Disclosures = disclosures

            });
        }

        public ActionResult ChartPDF(int id)
        {

            var pdfFile = AnnuityService.GetSummaryPDF(id);
            if (pdfFile == null)
            {
                //client_id
                PdfConverter pdfConverter = new PdfConverter();
                pdfConverter.HttpRequestCookies.Add(FormsAuthentication.FormsCookieName, Request.Cookies[FormsAuthentication.FormsCookieName].Value);
                var cookie = Request.Cookies["client_id"];
                
                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Encrypt(cookie);
                    pdfConverter.HttpRequestCookies.Add(cookie.Name, cookie.Value);
                }

                cookie = Request.Cookies["advisor_id"];
                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Encrypt(cookie);
                    pdfConverter.HttpRequestCookies.Add(cookie.Name, cookie.Value);
                }

                pdfConverter.JavaScriptEnabled = true;
                pdfConverter.MediaType = "screen";
                pdfConverter.TriggeringMode = TriggeringMode.Manual;
                pdfConverter.PdfDocumentOptions.LiveUrlsEnabled = false;
                pdfConverter.PdfDocumentOptions.BottomMargin = 5;
                pdfConverter.PdfDocumentOptions.TopMargin = 5;
                pdfConverter.LicenseKey = SiteConfiguration.WinnovativePDFLicense;
                pdfFile = pdfConverter.GetPdfBytesFromUrl(string.Format("{0}/public/sharepoint/hypo/seriesva/{1}", SiteConfiguration.BaseUrl, id.ToString()));
                //Save the pdf to storage
                AnnuityService.SaveSummaryPDF(id, pdfFile);
            }
            return File(pdfFile, "application/pdf", "SeriesVA.pdf");

        }

        public ActionResult Recommended()
        {
            var client = SelectedClient;
            return View(new SeriesVARecommendedViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel
                {
                    Client = client
                }
            });
        }

        public ActionResult DataSeries(int id)
        {
            var hypothetical = new SqlAnnuityService().GetHypothetical(id);
            return Json(hypothetical, JsonRequestBehavior.AllowGet);
        }
    }
}
