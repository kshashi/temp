﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Content;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [HandleError]
    public class ClientsControllerBase : Controller
    {
        private IDataService _dataService = new SqlDataService();
        private IAdvisorService _advisorService = new AdvisorService();
        private IContentService _contentService = new TridianContentService();

        public Client SelectedClient { get; set; }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            string universalId = User.Identity.Name;
            var cookie = Request.Cookies["advisor_id"];

            if (User.IsInRole("RVP"))
            {
                if (cookie != null)
                {
                    cookie = CookieSecurityProvider.Decrypt(cookie);
                    int advisor_id = int.Parse(cookie.Value);
                    var advisor = _dataService.GetAdvisor(advisor_id);
                    var advisorFull = _advisorService.GetAdvisor(advisor.UniversalID);
                    universalId = advisorFull.universal_id;
                }
                else
                {
                    Response.Redirect("/rvp/dashboard");
                    return;
                }
            }

            ViewBag.Disclaimers = _contentService.GetDisclaimer("default_client");

            if (!User.IsInRole("Client"))
            {
                // check for the cookie
                cookie = Request.Cookies["client_id"];

                if (cookie == null)
                {
                    Response.Redirect("/advisors/clients");
                    return;
                }
                cookie = CookieSecurityProvider.Decrypt(cookie);
                int client_id = int.Parse(cookie.Value);

                // make sure the user can access the client

                SelectedClient = _dataService.GetClient(client_id);
            }
            else 
            {
                SelectedClient = _dataService.GetClient(universalId);
                if (!SelectedClient.SecurityQuestionsSet)
                {
                    Response.Redirect("/account/questions");
                }
            }

            if (!User.IsInRole("Client") )
            {
                // get the advisor by id
                var internalAdvisor = _dataService.GetAdvisor(universalId);

                // the selected advisor is the logged in user
                ViewBag.SelectedAdvisor = _advisorService.GetAdvisor(universalId);
                
            }
        }

    }
}
