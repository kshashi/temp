﻿using MetLife.Annuities.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Web.Areas.Clients.Models;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Clients.ViewModels;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.Models;

namespace MetLife.Annuities.Web.Areas.Clients.Controllers
{
    [Authorize(Roles = "Advisor,RVP,Client")]
    public class ResourcesController : ClientsControllerBase
    {
        public IContentService ContentService { get { return new TridianContentService(); } }
        public IDataService DataService { get { return new SqlDataService(); } }
        private IAdvisorService AdvisorService = new AdvisorService();

        public ActionResult Index()
        {
            var ad = DataService.GetAdvisor(SelectedClient.AdvisorID);
            var advisor = AdvisorService.GetAdvisor(ad.UniversalID);
            var items = ContentService.GetClientResources(SelectedClient.StateCode, advisor.universal_id);
            var client = SelectedClient;
            var faqs = FaqCategoryModel.GenerateFromFaqArray(items.faqs);
            var glossary = GlossaryModel.GenerateFromGlossaryArray(items.glossary);
            var docs = DocumentCategoryModel.GenerateFromDocArray(items.documents);
            var vids = VideoCategoryModel.GenerateFromVideoArray(items.videos.Where(g => !g.category.name.StartsWith("_")).ToArray());
            var disclaimer = ContentService.GetDisclaimer("faq").ToList();
            disclaimer.AddRange(ContentService.GetDisclaimer("video").ToList());
            disclaimer.AddRange(ContentService.GetDisclaimer("glossary").ToList());
            disclaimer.AddRange(ContentService.GetDisclaimer("document").ToList());

            if (User.IsInRole("Client"))
                DataService.UpdateClientProgress(SelectedClient.ClientID, Services.ClientProgressType.EducationalSegmentReview, advisor);
            ViewBag.Disclaimers = disclaimer.ToArray();
            var model = new ResourcesIndexViewModel
            {
                ClientHeaderViewModel = new ClientHeaderViewModel { Client = client },
                Documents = docs,
                FaqCategories = faqs,
                GlossaryWords = glossary,
                Videos = vids,
                Disclaimer = disclaimer.ToArray()
            };
            return View(model);
        }

        public JsonResult Videos(string category, string search)
        {
            var ad = DataService.GetAdvisor(SelectedClient.AdvisorID);
            var advisor = AdvisorService.GetAdvisor(ad.UniversalID);
            var items = ContentService.GetClientResources(SelectedClient.StateCode, advisor.universal_id);
            if (category != null && category != "")
            {
                return Json(items.videos.Where(g => g.category.name.ToLower() == category.ToLower()).DistinctBy(g => g.uri), JsonRequestBehavior.AllowGet);
            }

            if (search != null && search != "")
            {
                var results = items.videos.Where(g => g.title.ToLower().Contains(search.ToLower())).DistinctBy(g => g.uri);
                return Json(results, JsonRequestBehavior.AllowGet);
            }

            return Json(items.videos.DistinctBy(g => g.uri), JsonRequestBehavior.AllowGet);
        }
    }
}
