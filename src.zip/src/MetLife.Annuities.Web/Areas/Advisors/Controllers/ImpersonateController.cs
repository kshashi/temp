﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class ImpersonateController : AdvisorControllerBase
    {
        public ActionResult Index(int client_id, string next)
        {
            IDataService DataService = new SqlDataService();

            if (User.IsInRole("Advisor"))
            {

            //Make sure the advisor is authorized to view this client
            var client = DataService.GetClient(client_id);
            var universalId = string.Empty;
            Advisor advisor = new Advisor();

                universalId = User.Identity.Name.ToString();
                advisor = DataService.GetAdvisor(universalId);

                if (client.AdvisorID != advisor.AdvisorID)
                {
                     return Redirect("~/public/pages/unauthorized.html");
                }   
            }
            //Encrypting Cookie
            HttpCookie cookie = new HttpCookie("client_id", client_id.ToString().Replace(Environment.NewLine, string.Empty));
            cookie.Expires = DateTime.Now.AddHours(6);
            HttpCookie encodedCookie = CookieSecurityProvider.Encrypt(cookie);
            Response.Cookies.Add(encodedCookie);

            if (string.IsNullOrEmpty(next))
                return RedirectToAction("index", new { controller = "testimonials", area = "clients" });
            else
                return Redirect(next);
        }

    }
}
