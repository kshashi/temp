﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class EditClientController : AdvisorControllerBase
    {
        private IEmailService EmailService = new EmailService();
        private IContentService ContentService = new TridianContentService();
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();

        [HttpGet]
        public ActionResult Basic(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var states = DataService.GetStates();
            var marital = DataService.GetMaritalStatuses();
            var phones = DataService.GetPhoneNumberTypes();
            var genders = DataService.GetGenders();
            var advisor = SelectedAdvisor;

            var model = new ClientBasicViewModel(client, states, marital, phones, genders);

            var view = new EditClientBasicViewModel { ClientBasicViewModel = model, Header = new EditClientHeaderViewModel(client, "basic", advisor) };

            return View(view);
        }

        [HttpPost]
        public ActionResult Basic(ClientBasicViewModel model)
        {
            var client = DataService.GetClient(model.ClientID.Value);

            client = model.MapClient(client);

            client = DataService.SaveClient(client, SelectedAdvisor.id);

            DataService.WriteClientHistory(HistoryType.ProfileUpdated, client.ClientID,
                new Dictionary<string, string>(){{"{name}",client.FirstName},
                {"{pronoun}",client.GetPronoun(PronounType.HisHer).ToLower()}});

            return RedirectToAction("financial", "editclient", new { client_id = model.ClientID });
        }

        [HttpGet]
        public ActionResult Financial(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var finance = DataService.GetClientFinance(client.ClientID);
            var timespans = DataService.GetNeedTimespans();
            var benefits = DataService.GetBenefits();

            var model = new ClientFinancialViewModel(client, finance, timespans,benefits);

            var header = new EditClientHeaderViewModel(client, "financial", advisor);

            return View(new EditClientFinancialViewModel { Header = header, ClientFinancial = model });

        }

        [HttpPost]
        public ActionResult Financial(ClientFinancialViewModel model)
        {
            var finance = model.MapClientFinance();
            DataService.SaveClientFinance(finance);
            DataService.WriteClientHistory(HistoryType.FinancialProfileUpdated, model.ClientID, new Dictionary<string, string>());
            return RedirectToAction("profile", "clients", new { client_id = model.ClientID });
        }

        /*
        [HttpGet]
        public ActionResult Settings(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var model = new EditClientSettingsViewModel
            {
                ClientProfileSettingsViewModel = new ClientProfileSettingsViewModel
                {
                    IsAdvisorView = true,
                    ClientGuests = client.ClientGuests,
                    flags = new string[] { "", "", "", "", "" },
                    reminders = new string[] { "", "", "", "", "" }
                },
                Header = new EditClientHeaderViewModel(client, "settings", advisor)
            };
            return View(model);
        }

        [HttpPost]
        public ActionResult Settings(ClientProfileSettingsViewModel model)
        {
            return RedirectToAction("settings", new { client_id = model.ClientID });
        }
         */

    }
}
