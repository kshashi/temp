﻿using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Web.Models;
using System.Linq;
using MetLife.Annuities.Services.Models;
namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class HelpController : AdvisorControllerBase
    {
        IContentService ContentService = new TridianContentService();

        public ActionResult Index()
        {
            var tutorials = ContentService.GetAdvisorTutorials();
            var faqs = ContentService.GetAdvisorFAQs();
            var faqModel = FaqCategoryModel.GenerateFromFaqArray(faqs.faq);

            var model = new HelpIndexViewModel
            {
                AdvisorHeaderViewModel = new AdvisorHeaderViewModel
                {
                    Advisor = SelectedAdvisor
                },
                Tutorials = tutorials,
                Faqs = faqModel,
                FeaturedTutorial = tutorials.videos.FirstOrDefault()
            };
            return View(model);
        }

    }
}
