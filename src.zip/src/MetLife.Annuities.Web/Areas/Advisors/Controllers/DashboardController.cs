﻿using System.Linq;
using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Advisors.Models;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Services.Content;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class DashboardController : AdvisorControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();
        private IContentService ContentService = new TridianContentService();
        /// <summary>
        /// Displays the advisor's dashboard view for either the
        /// advisor or an authorized RVP
        /// </summary>   
        [HttpGet]
        public ActionResult Index()
        {
            var profile = DataService.GetUserProfileByExternalId(User.Identity.Name);
            bool first_login = Request.QueryString["first_login"] == "1" ? true : false;
            var tutorial = ContentService.GetAdvisorTutorials();

            // TODO:  wire up to photo upload
            var model = new DashboardIndexViewModel
            {
                UserProfile = profile,
                HasUploadedPhoto = false,
                FirstTimeLogin = first_login,
                Tutorials = tutorial,
                FeaturedTutorial = tutorial.videos.FirstOrDefault(),
                AdvisorHeaderViewModel = new AdvisorHeaderViewModel
                {
                    Advisor = SelectedAdvisor
                }
            };
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(int advisor_id)
        {

            var clients = DataService.GetRecentClientsForAdvisor(SelectedAdvisor.id);
            var progress = DataService.GetClientProgressStates();
            var models = from c in clients.Items
                         select new ClientsIndexViewModel
                         {
                             FirstName = c.FirstName,
                             City = c.City,
                             StateCode = c.StateCode,
                             ClientID = c.ClientID,
                             LastName = c.LastName,
                             CurrentStatus = c.CurrentStatus,
                             CTAText = "Testing",
                             CTALink = "#",
                             Progress = new
                             {
                                 Steps = new object[] {
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 1",
                                          Url="step url 1"
                                      },
                                      new {
                                          Complete=false,
                                          Copy="tooltip copy 2",
                                          Url="step url 1"
                                      },
                                      new {
                                          Complete=false,
                                          Copy="tooltip copy 3",
                                          Url="step url 1"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 4",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 5",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=false,
                                          Copy="tooltip copy 6",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 7",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 8",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 9",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 10",
                                          Url="step url 4"
                                      },
                                      new {
                                          Complete=true,
                                          Copy="tooltip copy 11",
                                          Url="step url 4"
                                      }
                                  }
                             },
                             Flag = new
                             {
                                 Flag = "View Flag",
                                 FlagUrl = "flag url"
                             }
                         };
            return Json(new
            {
                total_pages = clients.TotalPages,
                current_page = clients.CurrentPage,
                items = models.ToArray()
            });
        }
    }
}
