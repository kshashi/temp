﻿using System;
using System.Web.Mvc;
using MetLife.Annuities.Services;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Annuities;
using System.Linq;
using MetLife.Annuities.Services.Security;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Fulfillment;
namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class AddClientController : AdvisorControllerBase
    {

        private IContentService ContentService = new TridianContentService();
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();
        private IUserService UserService = new IBSEUserService();
        private IEmailService EmailService = new EmailService();
        
        [HttpGet]
        public ActionResult Basic(int? client_id)
        {
            Client client = new Client();
            if (client_id.HasValue && client_id > 0)
                client = DataService.GetClient(client_id.Value);

            var states = DataService.GetStates();
            var marital = DataService.GetMaritalStatuses();
            var phones = DataService.GetPhoneNumberTypes();
            var genders = DataService.GetGenders();

            var model = new ClientBasicViewModel(client, states, marital, phones, genders);
            var header = new AddClientHeaderViewModel(client, 1, SelectedAdvisor);

            return View(new AddClientBasicViewModel { Header = header, ClientBasic = model });
        }

        [HttpPost]
        public ActionResult Basic(ClientBasicViewModel model)
        {
            Client client = new Client();
            
            if (model.ClientID.HasValue && model.ClientID > 0)
                client = DataService.GetClient(model.ClientID.Value);

            client = model.MapClient(client);

            client = DataService.SaveClient(client, SelectedAdvisor.id);

            var user = DataService.GetClient(client.EmailAddress);
            if (user != null)
            {
                TempData["error-msg"] = "Email address already exists.";
                return RedirectToAction("basic", new { client_id = client.ClientID });
            }

            return RedirectToAction("Financial", new { client_id = client.ClientID });
        }

        [HttpGet]
        public ActionResult Financial(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var finance = DataService.GetClientFinance(client.ClientID);
            var timespans = DataService.GetNeedTimespans();
            var benefits = DataService.GetBenefits();
            if (finance == null)
                finance = new ClientFinance();

            var model = new ClientFinancialViewModel(client, finance, timespans, benefits);

            var header = new AddClientHeaderViewModel(client, 2, SelectedAdvisor);

            return View(new AddClientFinancialViewModel { Header = header, ClientFinancial = model });
        }

        [HttpPost]
        public ActionResult Financial(ClientFinancialViewModel model)
        {
            var finance = model.MapClientFinance();

            DataService.SaveClientFinance(finance);

            return RedirectToAction("Product", new { client_id = model.ClientID });
        }

        [HttpGet]
        public ActionResult Product(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var universalID = DataService.GetAdvisor(client.AdvisorID).UniversalID;

            var model = new AddClientProductViewModel
            {
                SelectedProduct = 0,
                ClientID = client.ClientID,
                Header = new AddClientHeaderViewModel(client, 3, SelectedAdvisor),
                CanSellSLS = AdvisorService.CanSellProductType(universalID,client.StateCode, AnnuityProductType.ShieldLevel),
                CanSellVariable = AdvisorService.CanSellProductType(universalID, client.StateCode, AnnuityProductType.Variable),
            };

            return View(model);
        }

        [HttpPost]
        public ActionResult Product(AddClientProductViewModel model)
        {
            var client = DataService.GetClient(model.ClientID);
            client.PreferredAnnuityProductType = (AnnuityProductType)model.SelectedProduct;
            DataService.SaveClient(client, SelectedAdvisor.id);
            return RedirectToAction("videos", new { client_id = model.ClientID });
        }


        [HttpGet]
        public ActionResult Videos(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var personas = ContentService.GetPersonas();

            var model = new AddClientPersonaViewModel
            {
                ClientPersona = new ClientPersonaViewModel
                {
                    Personas = personas.persona,
                    ClientID = client.ClientID,
                    PreferredAnnuityProduct = client.PreferredAnnuityProductType
                },
                Header = new AddClientHeaderViewModel(client, 4, SelectedAdvisor)
            };

           
            if (AdvisorService.CanSellProductType(SelectedAdvisor.universal_id, client.StateCode, AnnuityProductType.Variable))
            {
            model.SeriesVAVideoQueue = ContentService.GetVideosByCategory("_SeriesVA");
            }
            if (AdvisorService.CanSellProductType(SelectedAdvisor.universal_id, client.StateCode, AnnuityProductType.ShieldLevel))
            {
                model.ShieldLevelVideoQueue = ContentService.GetVideosByCategory("_Shield");
            }

            return View(model);
        }


        [HttpPost]
        public ActionResult Videos(FormCollection form)
        {
            var persona = new ClientPersona
            {
                ClientID = int.Parse(form["client-id"])
                
            };

            if (form["persona-id"] != null)
                persona.BrightcovePlaylistID = form["persona-id"];

            DataService.SaveClientPersona(persona);
            DataService.UpdateClientProgress(persona.ClientID, ClientProgressType.ClientSetup, SelectedAdvisor);
            return RedirectToAction("Email", new { client_id = persona.ClientID });
        }

        [HttpGet]
        public ActionResult Email(int client_id)
        {
            var client = DataService.GetClient(client_id);
            persona persona = null;
            if (client.TestimonialPersonaID.HasValue)
                persona = ContentService.GetPersona(client.TestimonialPersonaID.Value);
            var model = new AddClientEmailViewModel
            {
                Advisor = SelectedAdvisor,
                ClientID = client_id,
                Client = client,
                Header = new AddClientHeaderViewModel(client, 5, SelectedAdvisor)
            };
            return View(model);
        }

        [HttpPost]
        public ActionResult Email(AddClientEmailViewModel model)
        {
            // Send the email!
            var client = DataService.GetClient(model.ClientID);
            var advisor = SelectedAdvisor;
            var inviteUrl = Url.Action("createpassword", "account", new { area = "", id = client.ClientID, g = client.UniqueId });
            try
            {
                EmailService.SendNewClientEmail(client.PreferredAnnuityProductType, client, advisor, inviteUrl);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return Redirect("~/public/pages/dnss.html");
            }
            

            // Update status
            DataService.UpdateClientProgress(model.ClientID, ClientProgressType.WelcomeEmailSent, SelectedAdvisor);

            var advisorStatus = (AdvisorStatus)SelectedAdvisor.current_status_id;
            if (advisorStatus != AdvisorStatus.ClientSetup && advisorStatus != AdvisorStatus.ActiveClients)
                AdvisorService.UpdateAdvisorStatus(advisor.universal_id, advisor.system_id, AdvisorStatus.ClientSetup);

            return RedirectToAction("finished", new { client_id = model.ClientID });
        }

        [HttpGet]
        public ActionResult Finished(int client_id)
        {
            var client = DataService.GetClient(client_id);
            persona persona = null;
            if (client.TestimonialPersonaID.HasValue)
                persona = ContentService.GetPersona(client.TestimonialPersonaID.Value);
            var finance = DataService.GetClientFinance(client_id);
            var persona_videos = new video[] { }; // ContentService.GetPersonaVideosForIds(client.SelectedPersonaVideos);
            var history = DataService.GetClientHistory(client_id);
            var clientProgressCta = new ClientsIndexCTADictionary();
            var progress = DataService.GetClientProgressStates();
            var Progress = new Progress
            {
                Steps = (from s in progress
                         select new ProgressStep
                         {
                             Copy = s.Name,
                             Complete = client.CurrentStatusId >= s.Id,
                             Url = clientProgressCta[s.Id].Url.Replace("{client_id}", client.ClientID.ToString())
                         }).ToArray()

            };
            var model = new ClientFullViewModel(client, finance, persona, persona_videos, true, history.Items, Progress);

            var view = new AddClientFinishedViewModel
            {
                ClientFullVieModel = model,
                Header = new AddClientHeaderViewModel(client, 6, SelectedAdvisor)
            };

            return View(view);
        }

    }
}
