﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    public class AlertsController : Controller
    {
        private IDataService DataService = new SqlDataService();

        [HttpPost]
        public ActionResult Mark(int client_id)
        {
            var client = DataService.GetClient(client_id);
            client.HasAlerts = false;
            DataService.SaveClient(client, client.AdvisorID);
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

    }
}
