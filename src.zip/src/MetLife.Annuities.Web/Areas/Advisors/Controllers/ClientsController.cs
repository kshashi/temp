﻿using System.Linq;
using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Advisors.Models;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Web.ViewModels;
using Newtonsoft.Json;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Extensions;
using System;
using MetLife.Annuities.Web.Helpers;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class ClientsController : AdvisorControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IAdvisorService AdvisorService = new AdvisorService();

        [HttpGet]
        public ActionResult Index()
        {
            var model = new AdvisorHeaderViewModel { Advisor = SelectedAdvisor };
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(int page, string filter, string sort)
        {
            int pageSize = 10;
            var clients = DataService.GetClientsForAdvisor(SelectedAdvisor.id, page, pageSize, filter, sort);
            var dictionary = new AdvisorsActivityCTADictionary();
            var progress = DataService.GetClientProgressStates();
            var clientProgressCta = new ClientsIndexCTADictionary();
            var models = from c in clients.Items
                         select new ClientsIndexViewModel
                         {
                             FirstName = c.FirstName,
                             City = c.City,
                             StateCode = c.StateCode,
                             ClientID = c.ClientID,
                             LastName = c.LastName,
                             CurrentStatus = c.CurrentStatus,
                             CurrentStatusId = c.CurrentStatusId,
                             LastActivityDate = c.LastActivityDate == DateTime.MinValue || c.LastActivityDate == null ? "" : c.LastActivityDate.Value.ToRelativeDateTime(),
                             CTAText = clientProgressCta[c.CurrentStatusId].Text,
                             CTALink = clientProgressCta[c.CurrentStatusId].Url.Replace("{client_id}", c.ClientID.ToString()),
                             Progress = new Progress
                             {
                                 Steps = (from s in progress
                                          select new ProgressStep
                                          {
                                              Copy = s.Name,
                                              Complete = c.CurrentStatusId >= s.Id,
                                              Url = clientProgressCta[s.Id].Url.Replace("{client_id}", c.ClientID.ToString())
                                          }).ToArray()

                             },
                             Flag = c.HasAlerts == false || c.LatestActivity == null || string.IsNullOrEmpty(dictionary[c.LatestActivity.HistoryType].Text) ? null : new
                             {
                                 Flag = dictionary[c.LatestActivity.HistoryType].Text,
                                 FlagUrl = dictionary[c.LatestActivity.HistoryType].Url.Replace("{client_id}", c.ClientID.ToString()),
                                 FlagTitle = "",
                                 Description = "",
                                 LinkText = ""
                             }

                         };


            return Json(new
            {
                sort = sort,
                filter = filter,
                total_pages = clients.TotalPages,
                current_page = clients.CurrentPage,
                items = models.ToArray()
            });
        }


        [HttpGet]
        public new ActionResult Profile(int client_id)
        {
             //Make sure the advisor is authorized to view this client
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            //var advisor1 = DataService.GetAdvisor(User.Identity.Name.ToString());
            if (client.AdvisorID != advisor.id)
            {
                return Redirect("~/public/pages/unauthorized.html");
            }
           
            persona persona = null;

            var finance = DataService.GetClientFinance(client_id);

            var history = (from a in DataService.GetClientActivity(client.AdvisorID, client.ClientID, 1, 3, "recent", "").Items
                           select new ClientHistory
                           {
                               ActivityDate = a.Date,
                               Description = a.Description,
                               Status = a.Type,
                               Timestamp = DateHelpers.ToJavascriptTimestamp(a.Date.Ticks)
                           }).ToArray();

            var clientProgressCta = new ClientsIndexCTADictionary();
            var progress = DataService.GetClientProgressStates();
            var Progress = new Progress
                             {
                                 Steps = (from s in progress
                                          select new ProgressStep
                                          {
                                              Copy = s.Name,
                                              Complete = client.CurrentStatusId >= s.Id,
                                              Url = clientProgressCta[s.Id].Url.Replace("{client_id}", client.ClientID.ToString())
                                          }).ToArray()

                             };
            
            var model = new ClientFullViewModel(client, finance, persona, null, true, history, Progress);

            var view = new ClientsProfileViewModel
            {
                ClientFullViewModel = model,
                AdvisorHeaderViewModel = new AdvisorHeaderViewModel { Advisor = advisor }

            };
            return View(view);
        }

        [HttpGet]
        public ActionResult Email(int client_id)
        {
            var advisor = SelectedAdvisor;
            var client = DataService.GetClient(client_id);
            var products = DataService.GetSavedAnnuities(client_id);

            var view = new ClientsEmailViewModel
            {
                AdvisorHeaderViewModel = new AdvisorHeaderViewModel { Advisor = advisor },
                Client = client,
                Products = products
            };

            return View(view);
        }


        [HttpPost]
        public ActionResult ViewedAlert(int client_id)
        {
            // TODO:  add viewed alert flag
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

    }
}
