﻿using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services;


namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class EmailController : AdvisorControllerBase
    {
        private IDataService DataService = new SqlDataService();
        private IEmailService EmailService = new EmailService();
        private IContentService ContentService = new TridianContentService();
        private IAnnuityService AnnuityService = new SqlAnnuityService();

        public ActionResult NewClient(int client_id, int product_type)
        {
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var body = EmailService.PreviewNewClientEmail((AnnuityProductType)product_type, client, advisor, "#");
            return Content(body);
        }

        #region Reengage Email
        public ActionResult Reengage(int client_id)
        {
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var body = EmailService.PreviewReengageEmail(client, advisor);
            return Content(body);
        }

        [HttpPost]
        public ActionResult Reengage(FormCollection form)
        {
            int client_id = int.Parse(Request.QueryString["client_id"]);
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            try
            {
                EmailService.SendReengageEmail(client, advisor);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return new HttpStatusCodeResult(520);
            }
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }
        #endregion

        #region Interactive Chart

        public ActionResult Charts_Sls(int client_id, int hypothetical_id)
        {
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var annuity = DataService.GetShieldProduct(hypothetical_id);
            var body = EmailService.PreviewChartEnabled(AnnuityProductType.ShieldLevel, client, advisor, annuity);
            return Content(body);
        }

        [HttpPost]
        public ActionResult Charts_Sls(FormCollection form)
        {
            var client = DataService.GetClient(int.Parse(Request.QueryString["client_id"]));
            var advisor = SelectedAdvisor;
            var sls = DataService.GetShieldProduct(int.Parse(Request.QueryString["hypothetical_id"]));
            try
            {
                EmailService.SendChartEnabled(AnnuityProductType.ShieldLevel, client, advisor, sls);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return new HttpStatusCodeResult(520);
            }


            DataService.UpdateClientProgress(client.ClientID, ClientProgressType.ProductReviewEmailSent, advisor);

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

        public ActionResult Charts_Va(int client_id, int hypothetical_id)
        {
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var hypothetical = AnnuityService.GetHypothetical(hypothetical_id);
            var body = EmailService.PreviewChartEnabled(AnnuityProductType.Variable, client, advisor, hypothetical);
            return Content(body);
        }

        [HttpPost]
        public ActionResult Charts_Va(FormCollection form)
        {
            var client = DataService.GetClient(int.Parse(Request.QueryString["client_id"]));
            var advisor = SelectedAdvisor;
            var hypo = AnnuityService.GetHypothetical(int.Parse(Request.QueryString["hypothetical_id"]));
            try
            {
                EmailService.SendChartEnabled(AnnuityProductType.Variable, client, advisor, hypo);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return new HttpStatusCodeResult(520);
            }

            DataService.UpdateClientProgress(client.ClientID, Services.ClientProgressType.ProductReviewEmailSent, advisor);

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

        #endregion

        #region Welcome Email


        public ActionResult Welcome(int client_id)
        {

            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var inviteUrl = Url.Action("createpassword", "account", new { area = "", id = client.ClientID, g = client.UniqueId }, Request.Url.Scheme);
            var body = EmailService.PreviewNewClientEmail(client.PreferredAnnuityProductType, client, advisor, inviteUrl);
            return Content(body);

        }

        [HttpPost]
        public ActionResult Welcome(FormCollection form)
        {

            var client_id = int.Parse(Request.QueryString["client_id"]);
            var client = DataService.GetClient(client_id);
            var advisor = SelectedAdvisor;
            var inviteUrl = Url.Action("createpassword", "account", new { area = "", id = client.ClientID, g = client.UniqueId });
            try
            {
                EmailService.SendNewClientEmail(client.PreferredAnnuityProductType, client, advisor, inviteUrl);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return new HttpStatusCodeResult(520);
            }
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);

        }

        #endregion

    }
}
