﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Web.Areas.Advisors.Models;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class HypotheticalController : AdvisorControllerBase
    {
        private IAnnuityService AnnuitiyService = new SqlAnnuityService();
        private IDataService DataService = new SqlDataService();

        public ActionResult New()
        {
            var advisor = SelectedAdvisor;
            var products = AnnuitiyService.GetAvailableProducts(SelectedProfile.ExternalID);
            HypotheticalNewViewModel model = new HypotheticalNewViewModel
            {
                AnnuuityProducts = products,
                AdvisorHeaderViewModel = new AdvisorHeaderViewModel
                {
                    Advisor = advisor
                }
            };
            return View(model);
        }


        [HttpPost]
        public ActionResult Toggle(string state, string clientId)
        {
            try
            {
                state = state.Equals("off") ? "on" : "off";
                DataService.ToggleHypotheticalView(state, clientId, SelectedAdvisor);

                return Json(new { status = 200, state = state });
            }
            catch (Exception)
            {
                return Json(new { status = 500, state = state });
            }


        }

    }
}
