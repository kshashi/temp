﻿using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Models;
using System;
using MetLife.Annuities.Services.Content;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [HandleError]
    public class AdvisorControllerBase : Controller
    {
        private IAdvisorService _advisorService = new AdvisorService();
        private IDataService _dataService = new SqlDataService();
        private IContentService _contentService = new TridianContentService();

        public advisor SelectedAdvisor { get; set; }
        public UserProfile SelectedProfile { get; set; }
        public footer AdvisorFooter { get; set; }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            ViewBag.Disclaimers = _contentService.GetDisclaimer("default_advisor");

            string universalId = User.Identity.Name;
            Advisor internalAdvisor = null;
            
            if (User.IsInRole("Advisor"))
            {
                // get the advisor by id
                internalAdvisor = _dataService.GetAdvisor(universalId);
                
                // the selected advisor is the logged in user
                SelectedAdvisor = _advisorService.GetAdvisor(universalId);
            }
            else if (User.IsInRole("RVP"))
            {
                // get the advisor using the cookie
                var cookie = Request.Cookies["advisor_id"];

                if (cookie == null)
                {
                    Response.Redirect("/rvps/dashboard");
                    return;
                }
                
                cookie = CookieSecurityProvider.Decrypt(cookie);
                int advisor_id = int.Parse(cookie.Value);

                // TODO:  check that the RVP can view this advisor's info

                // get the advisor by id
                internalAdvisor = _dataService.GetAdvisor(advisor_id);

                // get the advisor info from MIG
                var advisor = _advisorService.GetAdvisor(internalAdvisor.UniversalID);

                SelectedAdvisor = advisor;
            }

            SelectedAdvisor.id = internalAdvisor.AdvisorID;
            SelectedProfile = internalAdvisor.UserProfile;
            ViewBag.SelectedAdvisor = SelectedAdvisor;
        }

    }
}