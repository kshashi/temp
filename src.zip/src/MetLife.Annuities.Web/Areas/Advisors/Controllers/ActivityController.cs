﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Web.Helpers;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class ActivityController : AdvisorControllerBase
    {
        IDataService DataService = new SqlDataService();
        IAdvisorService AdvisorService = new AdvisorService();

        public ActionResult Index(int? client_id)
        {
            ViewBag.ClientID = client_id;
            var model = new AdvisorHeaderViewModel
            {
                Advisor = SelectedAdvisor
            };

            return View(model);
        }

        [HttpPost]
        public ActionResult Index(int page, string sort, string filter)
        {
            var items = new List<ActivityIndexViewModel>();

            var data = DataService.GetClientActivity(SelectedAdvisor.id, null, page, 10, sort, filter);

            var dictionary = new AdvisorsActivityCTADictionary();
            items = (from d in data.Items
                     select new ActivityIndexViewModel
                     {
                         FirstName = d.Client.FirstName.ToString(),
                         LastName = d.Client.LastName.ToString(),
                         ActivityType = d.Type,
                         ActivityDescription = d.Description.ToString(),
                         Date = d.Date.ToShortDateString(),
                         Timestamp = DateHelpers.ToJavascriptTimestamp(d.Timestamp),
                         ClientID = d.Client.ClientID,
                         HistoryType = d.HistoryType,
                         CTA = dictionary[d.HistoryType].Url.Replace("{client_id}", d.Client.ClientID.ToString()),
                         CTAText = dictionary[d.HistoryType].Text
                     }).ToList();

            return Json(new
            {
                sort = sort,
                filter = filter,
                total_pages = data.TotalPages,
                current_page = data.CurrentPage,
                items = items.ToArray()
            });
        }



    }
}
