﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    public class IntroController : AdvisorControllerBase
    {
        IAdvisorService DataService = new AdvisorService();

        public ActionResult Index()
        {
            if (SelectedAdvisor.current_status_id == (int)AdvisorStatus.Invited)
                DataService.UpdateAdvisorStatus(SelectedAdvisor.universal_id, SelectedAdvisor.system_id, AdvisorStatus.AccountActivated);
            var model = new IntroIndexViewModel
            {
                AdvisorHeaderViewModel = new AdvisorHeaderViewModel
                {
                    Advisor = SelectedAdvisor
                }
            };

            return View(model);
        }

    }
}
