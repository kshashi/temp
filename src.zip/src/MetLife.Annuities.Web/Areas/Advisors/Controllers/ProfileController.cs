﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Web.Areas.Advisors.Controllers
{
	[Authorize(Roles = "Advisor,RVP")]
	public class ProfileController : AdvisorControllerBase
	{
		private IDataService DataService = new SqlDataService();
		private IUserService UserService = new IBSEUserService();

		public ActionResult Index()
		{

			var model = new ProfileIndexViewModel
			{
				AdvisorProfileViewModel = new AdvisorProfileViewModel
				{
					FirmName = SelectedAdvisor.firm.firm_name,
					City = SelectedAdvisor.address.city.ToString(),
					State = SelectedAdvisor.address.state.ToString(),
					FullName = SelectedAdvisor.first_name + " " + SelectedAdvisor.last_name,
					EmailAddress = SelectedAdvisor.email.ToString(),
					Zip = SelectedAdvisor.address.zip.ToString(),
					UserProfile = SelectedProfile,
                    PhoneNumbers = SelectedAdvisor.phone_numbers.Select(g => g.number).ToArray()
				},
				AdvisorHeaderViewModel = new AdvisorHeaderViewModel
				{
					Advisor = SelectedAdvisor
				}
			};
			return View(model);
		}

		[HttpGet]
		public ActionResult Photo()
		{
			return View(new ProfilePhotoViewModel
			{
				AdvisorID = SelectedAdvisor.id,
				UploadedPhotoUrl = SelectedProfile.ProfileImageUrl,
				AdvisorHeaderViewModel =
						new AdvisorHeaderViewModel { Advisor = SelectedAdvisor },
				ProfileNavViewModel = new ProfileNavViewModel
				{
					Advisor = SelectedAdvisor,
					NavigationArea = "photo"
				}
			});
		}

		[HttpPost]
		public ActionResult Photo(string image_url)
		{

			var profile = SelectedProfile;

			profile.ProfileImageUrl = image_url;

			DataService.SaveUserProfile(profile);

			return RedirectToAction("Index");
		}

		[HttpPost]
		public ActionResult Upload(HttpPostedFile file)
		{
			var f = Request.Files[0];
			var fileName = Guid.NewGuid().ToString() + Path.GetExtension(f.FileName);
			byte[] fileData = null;
			using (var binaryReader = new BinaryReader(f.InputStream))
			{
				fileData = binaryReader.ReadBytes(f.ContentLength);
				UserService.UploadProfileImage(fileData, fileName);
			}
			string path = Path.Combine(Server.MapPath("~/sharepoint/assets/images/profile_images/"), fileName);
			//f.SaveAs(path);
			string url = path.Replace(Request.ServerVariables["APPL_PHYSICAL_PATH"], "/").Replace(@"\", "/");
			return View("Photo", new ProfilePhotoViewModel
			{
				UploadedPhotoUrl = url,
				AdvisorID = SelectedAdvisor.id,
				AdvisorHeaderViewModel = new AdvisorHeaderViewModel { Advisor = SelectedAdvisor },
				ProfileNavViewModel = new ProfileNavViewModel { NavigationArea = "photo", Advisor = SelectedAdvisor }
			});
		}

		[HttpGet]
		public ActionResult Settings()
		{

			var model = new ProfileSettingsViewModel
			{
				AdvisorHeaderViewModel =
						new AdvisorHeaderViewModel { Advisor = SelectedAdvisor },
				ProfileNavViewModel = new ProfileNavViewModel
				{
					Advisor = SelectedAdvisor,
					NavigationArea = "settings"
				}
			};

			return View(model);

		}

		[HttpGet]
		public ActionResult Basic()
		{

			var model = new ProfileBasicViewModel
			{
				ProfileNavViewModel = new ProfileNavViewModel { Advisor = SelectedAdvisor, NavigationArea = "basic" },
				AdvisorHeaderViewModel = new AdvisorHeaderViewModel { Advisor = SelectedAdvisor }
			};

			model.FullName = SelectedAdvisor.first_name + " " + SelectedAdvisor.last_name;
			model.PhoneNumbers = SelectedAdvisor.phone_numbers.Select(g => g.number).ToArray();
			model.EmailAddress = SelectedAdvisor.email.ToString();
            model.CompanyName = SelectedAdvisor.firm.firm_name.ToString();
			model.AddressLine1 = SelectedAdvisor.address.address_line_1.ToString();
			model.City = SelectedAdvisor.address.city.ToString();
			model.State = SelectedAdvisor.address.state.ToString();
			model.Zip = SelectedAdvisor.address.zip.ToString();

			return View(model);

		}

	}
}

