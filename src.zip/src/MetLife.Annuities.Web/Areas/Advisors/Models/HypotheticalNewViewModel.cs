﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.Models
{
    public class HypotheticalNewViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public annuity_product_category[] AnnuuityProducts { get; set; }
    }
}