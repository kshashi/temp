﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.Areas.Advisors.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.Models
{
    public class DashboardIndexViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public client[] Clients { get; set; }
        public UserProfile UserProfile { get; set; }

        public bool HasUploadedPhoto { get; set; }

        public bool FirstTimeLogin { get; set; }

        public advisor_tutorials Tutorials { get; set; }

        public videos FeaturedTutorial { get; set; }
    }
}