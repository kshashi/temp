﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.Models
{
    public class ClientsIndexViewModel
    {
        public int ClientID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public string CurrentStatus { get; set; }
        public string CTAText { get; set; }


        public string CTALink { get; set; }

        public object Progress { get; set; }

        public object Flag { get; set; }


        public int CurrentStatusId { get; set; }

        public string LastActivityDate { get; set; }
    }
}