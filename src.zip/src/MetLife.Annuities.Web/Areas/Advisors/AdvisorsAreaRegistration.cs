﻿using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Advisors
{
    public class AdvisorsAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Advisors";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Advisors_default",
                "advisors/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
