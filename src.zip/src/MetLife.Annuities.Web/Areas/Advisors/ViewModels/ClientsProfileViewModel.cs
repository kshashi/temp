﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class ClientsProfileViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public ClientFullViewModel ClientFullViewModel { get; set; }
         
    }
}