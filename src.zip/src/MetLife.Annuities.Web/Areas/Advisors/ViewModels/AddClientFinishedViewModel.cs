﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class AddClientFinishedViewModel
    {
        public ClientFullViewModel ClientFullVieModel { get; set; }
        public AddClientHeaderViewModel Header { get; set; }
    }
}