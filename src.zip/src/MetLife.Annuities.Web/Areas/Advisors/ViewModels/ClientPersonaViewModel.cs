﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ModelBinders;
using MetLife.Annuities.Services.Models;
using System.Web.Http.ModelBinding;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class ClientPersonaViewModel
    {
        public persona[] Personas { get; set; }

        [BindAlias("client-id")]
        public int ClientID { get; set; }

        [BindAlias("persona-id")]
        public int TestimonialPersonaId { get; set; }

        [BindAlias("persona-video")]
        public List<int> SelectedVideos { get; set; }
        
        public ClientPersonaViewModel()
        {
            SelectedVideos = new List<int>();
        }

        public Services.Annuities.AnnuityProductType PreferredAnnuityProduct { get; set; }
    }
}