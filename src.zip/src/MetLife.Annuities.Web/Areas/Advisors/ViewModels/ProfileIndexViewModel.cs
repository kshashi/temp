﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class ProfileIndexViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public AdvisorProfileViewModel AdvisorProfileViewModel { get; set; }
    }
}