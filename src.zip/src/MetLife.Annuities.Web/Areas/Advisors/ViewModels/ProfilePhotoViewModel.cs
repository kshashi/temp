﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class ProfilePhotoViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public int AdvisorID { get; set; }
        public string UploadedPhotoUrl { get; set; }

        public ProfileNavViewModel ProfileNavViewModel { get; set; }
    }
}