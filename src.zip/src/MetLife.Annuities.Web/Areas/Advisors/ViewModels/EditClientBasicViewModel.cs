﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class EditClientBasicViewModel
    { 
        public EditClientHeaderViewModel Header { get; set; }
        public ClientBasicViewModel ClientBasicViewModel { get; set; }
    }
}