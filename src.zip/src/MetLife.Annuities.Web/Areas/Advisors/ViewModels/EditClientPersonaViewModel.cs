﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class EditClientPersonaViewModel
    {
        public EditClientHeaderViewModel Header { get; set; }
        public ClientPersonaViewModel ClientPersona { get; set; }
    }
}