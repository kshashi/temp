﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;
using MetLife.Annuities.Web.ModelBinders;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class FindIndexViewModel
    {
        [BindAlias("filterFirstName")]
        public string FirstName { get; set; }

        [BindAlias("filterLastName")]
        public string LastName { get; set; }

        [BindAlias("filterState")]
        public string State { get; set; }

        [BindAlias("filterFirmName")]
        public string FirmName { get; set; }

        [BindAlias("filterMyTerritory")]
        public bool OnlyMyTerritory { get; set; }

        [BindAlias("filterAdvisorId")]
        public int AdvisorID { get; set; }

        [BindAlias("page")]
        public int Page { get; set; }

        [BindAlias("sort")]
        public string Sort { get; set; }

        [BindAlias("filter")]
        public string Filter { get; set; }

    }
}