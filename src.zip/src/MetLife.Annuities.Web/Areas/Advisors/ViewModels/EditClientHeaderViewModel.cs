﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class EditClientHeaderViewModel
    {
        public Client Client { get; set; }
        public string CurrentTab { get; set; }
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        private EditClientHeaderViewModel()
        {

        }
        public EditClientHeaderViewModel(Client client, string currentTab, advisor advisor)
        {
            Client = client;
            CurrentTab = currentTab;
            AdvisorHeaderViewModel = new AdvisorHeaderViewModel { Advisor = advisor };
        }
    }
}