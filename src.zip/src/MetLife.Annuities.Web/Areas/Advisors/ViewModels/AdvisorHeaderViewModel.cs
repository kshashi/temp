﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class AdvisorHeaderViewModel
    {
        public advisor Advisor { get; set; }
    }
}