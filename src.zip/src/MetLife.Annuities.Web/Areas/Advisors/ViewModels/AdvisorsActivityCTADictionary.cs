﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class AdvisorsActivityCTADictionary : Dictionary<HistoryType, LinkItem>
    {
        public AdvisorsActivityCTADictionary()
        {
            this.Add(HistoryType.ApplicationForms, new LinkItem("Create A New Interactive Chart", "/advisors/impersonate?client_id={client_id}&next=/clients/charts/saved"));
            this.Add(HistoryType.FlagsAdded, new LinkItem("View Flags", "/advisors/impersonate?client_id={client_id}&next=/clients/flags/redirect?client_id={client_id}"));
            this.Add(HistoryType.NewAnnuity, new LinkItem("View Client Portal", "/advisors/impersonate?client_id={client_id}"));
            this.Add(HistoryType.ProfileUpdated, new LinkItem("View Profile", "/advisors/clients/profile?client_id={client_id}"));
            this.Add(HistoryType.ProspectusDelievered, new LinkItem("View Forms", "/advisors/impersonate?client_id={client_id}&next=/clients/applications"));
            this.Add(HistoryType.FinancialProfileUpdated, new LinkItem("View Profile", "/advisors/clients/profile?client_id={client_id}"));
            this.Add(HistoryType.Other, new LinkItem("", ""));


        }
    }
}