﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.Areas.RVPs.ViewModels;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Models;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class HelpIndexViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public FaqCategoryModel[] Faqs { get; set; }
        public advisor_tutorials Tutorials { get; set; }


        public videos FeaturedTutorial { get; set; }
    }
}