﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class ProfileBasicViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }

        public string FullName { get; set; }
        public string[] PhoneNumbers { get; set; }
        public string EmailAddress { get; set; }
        public string CompanyName { get; set; }
        public string AddressLine1 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }

        public ProfileNavViewModel ProfileNavViewModel { get; set; }
    }
}