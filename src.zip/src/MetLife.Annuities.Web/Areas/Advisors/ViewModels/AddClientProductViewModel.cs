﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class AddClientProductViewModel
    {
        public int ClientID { get; set; }
        public AddClientHeaderViewModel Header { get; set; }

        public int SelectedProduct { get; set; }

        public bool CanSellSLS { get; set; }

        public bool CanSellVariable { get; set; }
    }
}