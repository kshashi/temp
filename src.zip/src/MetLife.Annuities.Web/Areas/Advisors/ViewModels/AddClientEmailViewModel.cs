﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    [ModelBinder(typeof(AliasModelBinder))]
    public class AddClientEmailViewModel
    {
        [BindAlias("client-id")]
        public int ClientID { get; set; }
        public advisor Advisor { get; set; }
        public AddClientHeaderViewModel Header { get; set; }
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }

        public Services.Data.Client Client { get; set; }
    }
}