﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ModelBinders;
using MetLife.Annuities.Services.Models;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    
    public class AddClientPersonaViewModel
    {
        public ClientPersonaViewModel ClientPersona { get; set; }
        public video[] SeriesVAVideoQueue { get; set; }
        public video[] ShieldLevelVideoQueue { get; set; }
        public AddClientHeaderViewModel Header { get; set; }
    }
}