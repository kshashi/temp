﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class ProfileSettingsViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public ProfileNavViewModel ProfileNavViewModel { get; set; }
        public string[] SendFlags { get; set; }
        public string[] SendEmails { get; set; }
        public string[] SendMeetings { get; set; }
    }
}