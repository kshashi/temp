﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class ClientsEmailViewModel
    {
        public Client Client { get; set; }
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }

        public Services.Annuities.SavedProductItem[] Products { get; set; }
    }
}