﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{
    public class IntroIndexViewModel
    {
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
    }
}