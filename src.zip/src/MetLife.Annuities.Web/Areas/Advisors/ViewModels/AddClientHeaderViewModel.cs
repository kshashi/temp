﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.Advisors.ViewModels
{

    public class AddClientHeaderViewModel
    {
        public int CurrentStep { get; set; }
        public string ClientFirstName { get; set; }
        public string ClientLastName { get; set; }
        public int ClientID { get; set; }
        public string[] ClientGoals { get; set; }
        public AdvisorHeaderViewModel AdvisorHeaderViewModel { get; set; }
        public AddClientHeaderViewModel(Client client, int currentStep, advisor advisor)
        {
            ClientFirstName = client.FirstName;
            ClientLastName = client.LastName;
            CurrentStep = currentStep;
            ClientID = client.ClientID;
            ClientGoals = client.Goals;
            AdvisorHeaderViewModel = new AdvisorHeaderViewModel { Advisor = advisor };
        }

        private AddClientHeaderViewModel()
        {

        }
    }
}