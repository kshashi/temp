﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    public class SettingsController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

    }
}
