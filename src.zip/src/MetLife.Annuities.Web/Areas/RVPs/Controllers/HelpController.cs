﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.RVPs.ViewModels;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Web.Models;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    public class HelpController : RVPControllerBase
    {
        IContentService ContentService = new TridianContentService();
        public ActionResult Index()
        {
            var tutorials = ContentService.GetAdvisorTutorials();
            var faqs = ContentService.GetAdvisorFAQs();
            var faqModel = FaqCategoryModel.GenerateFromFaqArray(faqs.faq);

            return View(new HelpIndexViewModel
            {
                RVPHeaderViewModel = new RVPHeaderViewModel { Rvp = SelectedRvp },
                HelpViewModel = new Advisors.ViewModels.HelpIndexViewModel
                {
                    Tutorials = tutorials,
                    Faqs = faqModel,
                    FeaturedTutorial = tutorials.videos.FirstOrDefault()
                }

            });
        }

    }
}
