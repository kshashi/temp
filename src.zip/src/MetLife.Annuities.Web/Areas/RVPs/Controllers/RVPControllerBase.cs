﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.RVP;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    [HandleError]
    public class RVPControllerBase : Controller
    {
        private IRVPService _rvpService = new MLIRVPService();
        private IDataService _dataService = new SqlDataService();

        public rvp SelectedRvp { get; set; }
      

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            var rvp = _rvpService.GetRVP(User.Identity.Name);
            SelectedRvp = rvp;

        }

    }
}
