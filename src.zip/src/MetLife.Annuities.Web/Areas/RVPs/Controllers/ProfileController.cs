﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using MetLife.Annuities.Web.Areas.RVPs.ViewModels;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.RVP;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    public class ProfileController : Controller
    {
        IDataService DataService = new SqlDataService();
        IRVPService RVPService = new MLIRVPService();
        IUserService UserService = new IBSEUserService();

        public ActionResult Index()
        {
            var rvp = RVPService.GetRVP(User.Identity.Name);
            var profile = DataService.GetUserProfileByExternalId(User.Identity.Name);
            var model = new ProfileIndexViewModel
            {
                UserProfile = profile,
                RVPProfileViewModel = new RVPProfileViewModel
                {
                    FullName = rvp.first_name + " " + rvp.last_name,
                    UserProfile = profile,
                    UploadedPhotoUrl = profile.ProfileImageUrl
                },
                RVPHeaderViewModel = new RVPHeaderViewModel
                {
                    Rvp = rvp
                }
            };
            return View(model);
        }


        [HttpGet]
        public ActionResult Photo()
        {
            var rvp = RVPService.GetRVP(User.Identity.Name);
            var profile = DataService.GetUserProfileByExternalId(User.Identity.Name);
            return View(new ProfilePhotoViewModel
            {
                RVPHeaderViewModel = new RVPHeaderViewModel { Rvp = rvp },
                UserProfileID = profile.UserProfileID,
                UploadedPhotoUrl = profile.ProfileImageUrl
            });
        }

        [HttpPost]
        public ActionResult Photo(string image_url, int user_profile_id)
        {

            int userProfile = user_profile_id;
            var profile = DataService.GetUserProfile(userProfile);

            profile.ProfileImageUrl = image_url;

            DataService.SaveUserProfile(profile);

            return RedirectToAction("Index");
        }


        [HttpPost]
        public ActionResult Upload(HttpPostedFile file, int user_profile_id)
        {
            var f = Request.Files[0];
            byte[] fileData = null;
            using (var binaryReader = new BinaryReader(f.InputStream))
            {
                fileData = binaryReader.ReadBytes(f.ContentLength);
            }
            string filename = Guid.NewGuid() + Path.GetExtension(f.FileName);
            UserService.UploadProfileImage(fileData, filename);

            var rvp = RVPService.GetRVP(User.Identity.Name);
            string url = filename;
            return View("Photo", new ProfilePhotoViewModel { UploadedPhotoUrl = url, UserProfileID = user_profile_id, RVPHeaderViewModel = new RVPHeaderViewModel { Rvp = rvp } });
        }

        [HttpGet]
        public ActionResult Settings()
        {

            var model = new ProfileSettingsViewModel();
            var rvp = RVPService.GetRVP(User.Identity.Name);

            model.SendEmails = new string[] { "checked", "", "", "" };

            model.SendFlags = new string[] { "checked", "", "", "" };

            model.SendMeetings = new string[] { "checked", "", "", "", "" };
            model.RVPHeaderViewModel = new RVPHeaderViewModel
            {
                Rvp = rvp
            };

            return View(model);

        }

        [HttpGet]
        public ActionResult Basic()
        {

            var model = new ProfileBasicViewModel();
            var rvp = RVPService.GetRVP(User.Identity.Name);
            model.FullName = string.Format("{0} {1}", rvp.first_name, rvp.last_name).Trim();
            if (rvp.phone_numbers != null)
                model.PhoneNumbers = rvp.phone_numbers.Select(p => string.Format("{0} {1}", p.number, p.extension).Trim()).ToArray();
            model.EmailAddress = (rvp.email != null ? (string)rvp.email : string.Empty);
            model.RVPHeaderViewModel = new RVPHeaderViewModel { Rvp = rvp };
            return View(model);

        }

    }
}

