﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Web.Areas.RVPs.Models;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.RVP;
using MetLife.Annuities.Services.Content;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    public class DashboardController : RVPControllerBase
    {
        public IDataService DataService = new SqlDataService();
        private IContentService ContentService = new TridianContentService();

        [HttpGet]
        public ActionResult Index()
        {
            var states = DataService.GetStates();
            bool first_login = Request.QueryString["first_login"] == "1" ? true : false;
            var tutorial = ContentService.GetAdvisorTutorials();
            var model = new DashboardIndexViewModel
            {
                FirstTimeLogin = first_login,
                AdvisorStatusDictionary = new AdvisorStatusDictionary(),
                RVPHeaderViewModel = new ViewModels.RVPHeaderViewModel
                {
                    Rvp = SelectedRvp
                },
                States = new SelectList(states, "Value", "Value"),
                Tutorials = tutorial,
                FeaturedTutorial = tutorial.videos.FirstOrDefault()
            };

            return View(model);
        }


    }
}
