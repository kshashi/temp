﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    public class ImpersonateController : Controller
    {
        IDataService DataService = new SqlDataService();
        IAdvisorService AdvisorService = new AdvisorService();

        public ActionResult Index(string advisor_id)
        {
            //Encrypting Cookie
            var advisor = DataService.GetAdvisorBySystemId(advisor_id);
            HttpCookie cookie = new HttpCookie("advisor_id", advisor.AdvisorID.ToString());
            cookie.Expires = DateTime.Now.AddHours(6);
            HttpCookie encodedCookie = CookieSecurityProvider.Encrypt(cookie);
            Response.Cookies.Add(encodedCookie);
            return RedirectToAction("index", new { controller = "dashboard", area = "advisors" });
        }

        public ActionResult SSO(string systemId)
        {
            try
            {
                var advisor = DataService.GetAdvisorBySystemId(systemId);
                if (advisor != null)
                    return this.Index(systemId);
                else
                    return RedirectToAction("index", new { controller = "dashboard", area = "rvps" });
            }
            catch 
            {
                return RedirectToAction("index", new { controller = "dashboard", area = "rvps" });             
            }   
        }
    }
}
