﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Areas.RVPs.ViewModels;
using MetLife.Annuities.Services;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.RVP;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Content;
using System.Web.Routing;

namespace MetLife.Annuities.Web.Areas.RVPs.Controllers
{
    [Authorize(Roles = "RVP")]
    public class AdvisorsController : RVPControllerBase
    {
        private IAdvisorService AdvisorService = new AdvisorService();
        private IEmailService EmailService = new EmailService();
        private TridionContainer Tridion = new TridionContainer();
        IRVPService RVPService = new MLIRVPService();

        public ActionResult Status(int id)
        {
            return View();
        }

        public ActionResult Firms()
        {
            var firms = AdvisorService.GetEntitledFirms();

            var results = from g in firms
                          select new
                          {
                              firm_name = g.firm_name,
                              entitled = g.entitled ? 1 : 0
                          };

            return Json(results, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult Find(AdvisorsFindViewModel model)
        {

            PagedList<advisor> results = new PagedList<advisor>();

            results = AdvisorService.FindAdvisors(User.Identity.Name, model.FirstName,
                model.LastName, model.FirmName, model.AdvisorID.HasValue ? model.AdvisorID.Value.ToString() : "",
                model.State,
                model.Page, 10, model.OnlyMyTerritory, model.Filter, model.Sort);

            var dictionary = new AdvisorsFindCTADictionary();
            var items = from a in results.Items
                        select new
                        {
                            first_name = a.first_name,
                            last_name = a.last_name,
                            address = a.address,
                            firm = a.firm,
                            id = a.system_id,
                            current_status = a.current_status,
                            current_status_id = a.current_status_id,
                            CTAText = dictionary[a.current_status_id].Text,
                            CTALink = dictionary[a.current_status_id].Url.Replace("{advisor_id}", a.system_id),
                            universal_id = a.universal_id
                        };
            return Json(new
            {
                sort = model.Sort,
                filter = model.Filter,
                total_pages = results.TotalPages,
                current_page = results.CurrentPage,
                items = items.ToArray()
            });
        }

        [HttpPost]
        public ActionResult Invite(string id)
        {
            var advisor = AdvisorService.GetAdvisor("", id);

            var inviteUrl = Url.Action("index", "intro", new { area = "advisors" });
            var rvp = RVPService.GetRVP(User.Identity.Name);
            var rvpName = rvp.first_name + " " + rvp.last_name;
            try
            {
                EmailService.SendAdvisorInvite(advisor, rvpName, inviteUrl);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return new HttpStatusCodeResult(520);
            }

            AdvisorService.UpdateAdvisorStatus("", id, AdvisorStatus.Invited);
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
        }

    }
}
