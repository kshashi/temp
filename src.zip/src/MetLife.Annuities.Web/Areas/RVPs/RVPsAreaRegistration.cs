﻿using System.Web.Mvc;

namespace MetLife.Annuities.Web.Areas.RVPs
{
    public class RVPsAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "rvps";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "rvps_default",
                "rvps/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
