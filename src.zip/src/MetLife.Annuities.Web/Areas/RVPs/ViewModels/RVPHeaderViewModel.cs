﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web.Areas.RVPs.ViewModels
{
    public class RVPHeaderViewModel
    {
        public rvp Rvp { get; set; }
    }
}