﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.RVPs.ViewModels
{
    public class RVPProfileViewModel
    {
        public string FullName { get; set; }

        public string FirmName { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public string EmailAddress { get; set; }

        public UserProfile UserProfile { get; set; }

        public string UploadedPhotoUrl { get; set; }
    }
}