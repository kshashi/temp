﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Web.Areas.RVPs.ViewModels
{
    public class ProfileIndexViewModel
    {
        public UserProfile UserProfile { get; set; }

        public RVPHeaderViewModel RVPHeaderViewModel { get; set; }

        public RVPProfileViewModel RVPProfileViewModel { get; set; }
    }
}