﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MetLife.Annuities.Web.ViewModels;

namespace MetLife.Annuities.Web.Areas.RVPs.ViewModels
{
    public class AdvisorsFindCTADictionary : Dictionary<int, LinkItem>
    {
        public AdvisorsFindCTADictionary()
        {
            this.Add(1, new LinkItem("Send Invite Email", "/rvps/advisors/invite?id={advisor_id}"));
            this.Add(2, new LinkItem("Resend Invite Email", "/rvps/advisors/invite?id={advisor_id}"));
            this.Add(3, new LinkItem("View Advisor Portal", "/rvps/impersonate?advisor_id={advisor_id}&next=/advisors/dashboard"));
            this.Add(4, new LinkItem("View Advisor Portal", "/rvps/impersonate?advisor_id={advisor_id}&next=/advisors/dashboard"));
            this.Add(5, new LinkItem("View Advisor Portal", "/rvps/impersonate?advisor_id={advisor_id}&next=/advisors/dashboard"));
            this.Add(6, new LinkItem("View Advisor Portal", "/rvps/impersonate?advisor_id={advisor_id}&next=/advisors/dashboard"));
            this.Add(7, new LinkItem("View Advisor Portal", "/rvps/impersonate?advisor_id={advisor_id}&next=/advisors/dashboard"));
            this.Add(8, new LinkItem("Not Portal Registered", "#"));
        }
    }
}