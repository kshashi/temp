﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.ModelBinders;

namespace MetLife.Annuities.Web.Areas.RVPs.ViewModels
{

    [ModelBinder(typeof(AliasModelBinder))]
    public class AdvisorsFindViewModel
    {
         
        [BindAlias("filterFirstName")]
        public string FirstName { get; set; }

        [BindAlias("filterLastName")]
        public string LastName { get; set; }

        [BindAlias("filterState")]
        public string State { get; set; }

        [BindAlias("filterFirmName")]
        public string FirmName { get; set; }

        [BindAlias("filterMyTerritory")]
        public bool OnlyMyTerritory { get; set; }

        [BindAlias("filterAdvisorId")]
        public int? AdvisorID { get; set; }
        
         
        public int Page { get; set; }

       
        public string Sort { get; set; }

        
        public string Filter { get; set; }

       
    }
}