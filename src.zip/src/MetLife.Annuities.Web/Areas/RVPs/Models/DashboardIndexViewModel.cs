﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Web.Areas.RVPs.ViewModels;

namespace MetLife.Annuities.Web.Areas.RVPs.Models
{
    public class DashboardIndexViewModel
    {
      
        public RVPHeaderViewModel RVPHeaderViewModel { get; set; }
        public videos FeaturedTutorial { get; set; }
        public bool FirstTimeLogin { get; set; }

        public Services.Advisors.AdvisorStatusDictionary AdvisorStatusDictionary { get; set; }

        public IEnumerable<SelectListItem> States { get; set; }

        public advisor_tutorials Tutorials { get; set; }
    }
}