﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Web
{
    public class SiteConfiguration
    {
        private static IContentService _contentService;

        public static string GuaranteedCompoundingRate
        {
            get
            {
                if (_contentService == null)
                    _contentService = new TridianContentService();
                string rate = _contentService.GetGlobalConfiguration().guaranteed_compounding_rate.ToString();
                if (!string.IsNullOrEmpty(rate))
                    return rate;
                else
                    return "4";
            }
        }

        public static string CacheBustVersion
        {
            get
            {
                if (ConfigurationManager.AppSettings.AllKeys.Contains("CacheBustVersion"))
                    return ConfigurationManager.AppSettings["CacheBustVersion"];
                return DateTime.Now.Ticks.ToString();
            }
        }


        public static bool EnableOptimizations
        {
            get
            {
                return bool.Parse(ConfigurationManager.AppSettings["EnableOptimizations"]);
            }
        }

        public static string ForgotPasswordLink
        {
            get
            {
                return ConfigurationManager.AppSettings["ForgotPasswordLink"];
            }
        }

        public static string MLIPortal
        {
            get
            {
                return ConfigurationManager.AppSettings["MLIPortal"];
            }
        }

        public static string MLFPortal
        {
            get
            {
                return ConfigurationManager.AppSettings["MLFPortal"];
            }
        }

        public static string NEFPortal
        {
            get
            {
                return ConfigurationManager.AppSettings["NEFPortal"];
            }
        }

        public static string ForesightGETUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["ForesightGETUrl"];
            }
        }

        public static string SiteminderHeaderKey
        {
            get
            {
                return ConfigurationManager.AppSettings["SiteminderHeaderKey"];
            }
        }

        public static string SiteminderLogoutUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["SiteminderLogoutUrl"];
            }
        }

        public static string ForesightPOSTUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["ForesightPOSTUrl"];
            }
        }


        public static string BaseUrl
        {
            get
            {
                return ConfigurationManager.AppSettings["baseurl"];
            }
        }

        public static string WinnovativePDFLicense
        {
            get
            {
                return ConfigurationManager.AppSettings["WinnovativePDFLicense"];
            }
        }

        public static bool SecureCookies 
        {
            get
            {
                return (string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["SecureCookies"]) || ConfigurationManager.AppSettings["SecureCookies"].ToLower() != "true" ? false : true);
            }
        }

        public static bool DisplayDiagnostics
        {
            get
            {
                return (string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["DisplayDiagnostics"]) || ConfigurationManager.AppSettings["DisplayDiagnostics"].ToLower() != "1" ? false : true);
            }
        }
    }
}