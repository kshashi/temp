﻿using System.Web.Mvc;

namespace MetLife.Annuities.Web
{
    public class SecureCookiesAttribute: FilterAttribute, IResultFilter
    {
        public void OnResultExecuting(ResultExecutingContext filterContext)
        {
            foreach (string cookieName in filterContext.HttpContext.Response.Cookies.AllKeys)
                filterContext.HttpContext.Response.Cookies[cookieName].HttpOnly = true;

            if (filterContext.HttpContext.Request.IsLocal)
                return;

            foreach (string cookieName in filterContext.HttpContext.Response.Cookies.AllKeys)
                filterContext.HttpContext.Response.Cookies[cookieName].Secure = SiteConfiguration.SecureCookies;
        }

        public void OnResultExecuted(ResultExecutedContext filterContext) { }
    }
}