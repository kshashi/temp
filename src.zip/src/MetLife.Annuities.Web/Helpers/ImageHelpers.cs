﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;

namespace MetLife.Annuities.Web.Helpers
{
    public class ImageHelpers
    {
        private static WebImage CropImage(HttpPostedFileBase sourceImage)
        {
            var newImage = new WebImage(sourceImage.InputStream);

            var width = newImage.Width;
            var height = newImage.Height;

            if (width > height)
            {
                var leftRightCrop = (width - height) / 2;
                newImage.Crop(0, leftRightCrop, 0, leftRightCrop);
            }
            else if (height > width)
            {
                var topBottomCrop = (height - width) / 2;
                newImage.Crop(topBottomCrop, 0, topBottomCrop, 0);
            }
             

            return newImage;
        }
    }
}