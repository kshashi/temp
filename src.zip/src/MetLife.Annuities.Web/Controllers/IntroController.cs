﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MetLife.Annuities.Services.Content;
using MetLife.Annuities.Web.Models;

namespace MetLife.Annuities.Web.Controllers
{
    [Authorize(Roles = "Advisor,RVP")]
    [HandleError]
    public class IntroController : Controller
    {
        private IContentService ContentService = new TridianContentService();

        [HttpGet]
        public ActionResult Index()
        {
            var videos = ContentService.GetAdvisorIntroTutorials(User.Identity.Name);
            var model = new IntroIndexViewModel { Videos = videos };
            return View(model);
        }

        [HttpPost]
        public ActionResult Skip()
        {

            if (Roles.IsUserInRole(AnnuitiesRoles.RVP))
            {
                // redirect to RVP
                return RedirectToAction("index", "dashboard", new { area = "rvps" });
            }
            else
            {
                //redirect to Advisors
                return RedirectToAction("index", "dashboard", new { area = "advisors" });
            }


        }
         

    }
}
