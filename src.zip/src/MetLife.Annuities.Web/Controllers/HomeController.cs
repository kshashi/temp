﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MetLife.Annuities.Web.Mailers;
using System.Security.Authentication;
using MetLife.Annuities.Services.Content;

namespace MetLife.Annuities.Web.Controllers
{
    [Authorize]
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (User.IsInRole("Client"))
                return Redirect("/clients/testimonials");
            else if (User.IsInRole("RVP"))
                return Redirect("/rvps/dashboard");
            else if (User.IsInRole("Advisor"))         
                return Redirect("/advisors/dashboard");
            else if (User.IsInRole("Admin"))
                return Redirect("/admins/Doc");

            throw new AuthenticationException();
        }

    }
}
