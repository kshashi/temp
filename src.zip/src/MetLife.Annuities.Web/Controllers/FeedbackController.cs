﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using MetLife.Annuities.Web.ViewModels;
using MetLife.Annuities.Services.Email;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Services.RVP;

namespace MetLife.Annuities.Web.Controllers
{
    [HandleError]
    [Authorize]
    public class FeedbackController : Controller
    {
        IEmailService EmailService = new EmailService();
        IAdvisorService AdvisorService = new AdvisorService();
        IDataService DataService = new SqlDataService();
        IRVPService RVPService = new MLIRVPService();

        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            var type = form["feedback-type"];
            var content = form["feedback-content"];
            if (string.IsNullOrEmpty(content))
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError);

            string email = string.Empty;
            string name = string.Empty;
            if (User.IsInRole("Advisor"))
            {
                var advisor = AdvisorService.GetAdvisor(User.Identity.Name);
                email = advisor.email;
                name = advisor.first_name + " " + advisor.last_name;
            }

            if (User.IsInRole("RVP"))
            {
                var rvp = RVPService.GetRVP(User.Identity.Name);
                email = rvp.email.ToString();
                name = rvp.first_name + " " + rvp.last_name;
            }

            try
            {
                EmailService.SendFeedbackEmail(type, content, email, name);
            }
            catch (MetLife.Annuities.Services.Email.DNSSException)
            {
                return new HttpStatusCodeResult(520);
            }
            return new HttpStatusCodeResult(HttpStatusCode.OK);
        }

    }
}
