﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Configuration;

namespace MetLife.Annuities.Web.Controllers
{
	public class SharepointAssetsController : Controller
	{		
		[OutputCache(Duration = 21600)]
		public FileContentResult Index(string path)
		{
			var usrService = new MetLife.Annuities.Services.Security.IBSEUserService();
			var memStream = new System.IO.MemoryStream();
			var response = usrService.GetProfileImage(path);
			response.GetResponseStream().CopyTo(memStream);			
			return new FileContentResult(memStream.ToArray(), response.ContentType);
		}

        [OutputCache(Duration = 21600)]
        public FileContentResult Documents(string path)
        {
            var usrService = new MetLife.Annuities.Services.Security.IBSEUserService();
            var memStream = new System.IO.MemoryStream();
            var response = usrService.GetDocument(path);
            response.GetResponseStream().CopyTo(memStream);
            return new FileContentResult(memStream.ToArray(), response.ContentType);
        }



	}
}
