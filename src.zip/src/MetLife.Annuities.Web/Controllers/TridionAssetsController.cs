﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Configuration;

namespace MetLife.Annuities.Web.Controllers
{
	public class TridionAssetsController : Controller
	{
		private string tridionURL = ConfigurationManager.AppSettings["TridionWebServiceAssetUrl"];
		[OutputCache(Duration = 21600)]
		public FileContentResult Index(string path)
		{			
			WebRequest client = WebRequest.Create(tridionURL + path);
			var response = client.GetResponse();
			var memStream = new System.IO.MemoryStream();
			response.GetResponseStream().CopyTo(memStream);			
			return new FileContentResult(memStream.ToArray(), response.ContentType);
		}


	}
}
