
// Tests : Clients - Annuities

var i, // testing iframe.
	w; // testing iframe's window object.

module('Clients - Resources - Videos', {

	setup: function() {

		stop();

		iframeLoad('/clients/resources', function(iframe){

			i = iframe;
			w = i.contentWindow;
			w.qunits = {};

			w.require(['app-global'], function(AppGlobal) {

				var eventTimeout = setTimeout(function(){
					start();
					ok(false, 'resources:videos:ready didn\'t fire within 1000ms.');
				}, 1000);

				w.App.on('resources:videos:ready', function(){
					clearTimeout(eventTimeout);
					start();
				});

				AppGlobal.utilities.init();
				AppGlobal.init();

				w.location.hash = "#videos/";
			});
		});
	},

	teardown: function() {
		iframeUnload(i);
	}

});

test('Brightcove Video Loads On Click', function() {

	stop();

	w.location.hash = w.$('a[href*="#videos/video/"]').first().attr('href')

	ok( w.$('a[href*="#videos/video/"]').length > 0, 'Video links are present on page' );

	setTimeout(function(){
		start();
		var brightcove = w.$('.BrightcoveExperience');
		equal( brightcove.length, 1, 'Brightcove Objects Loaded within 250ms' );
	}, 250);

});

test('Brightcove Loads New Video When Clicking A Different Item', function() {

	stop();

	ok( w.$('a[href*="#videos/video/"]').length > 0, 'Video links are present on page' );

	var firstBrightcove,
		secondBrightcove,
		firstHref = w.$('a[href*="#videos/video/"]').first().attr('href');

	w.location.hash = firstHref;

	setTimeout(function(){

		var otherVideos = w.$('a[href*="#videos/video/"][href!="' + firstHref + '"]');

		firstBrightcove = w.$('.BrightcoveExperience');

		if ( otherVideos.length === 0 ) {
			start();
			ok( true, 'No Other Videos To Verify');
			return;
		}

		w.location.hash = otherVideos.first().attr('href');

		setTimeout(function(){
			start();
			secondBrightcove = w.$('.BrightcoveExperience');
			ok( firstBrightcove !== secondBrightcove, 'Videos Changed' );
		}, 250);

	}, 250);

});

test('Going to #video loads the video section', function(){

	// Hash change handled in setup.

	equal(w.$('#section_videos').length, 1, 'Video section container is loaded in the DOM');
	equal(w.$("#section_videos").is(':visible'), true, 'Video section container is visible');

});

test('Browsing with the resources nav loads and unloads new sections', function(){

	stop();

	w.location.hash = "#documents/";

	setTimeout(function(){

		start();

		equal(w.$('#section_documents').length, 1, 'Documents section container is loaded in the DOM');
		equal(w.$("#section_documents").is(':visible'), true, 'Documents section container is visible');

		stop();

		w.location.hash = "#videos/";

		setTimeout(function(){

			start();

			equal(w.$('#section_videos').length, 1, 'Video section container is loaded in the DOM');
			equal(w.$("#section_videos").is(':visible'), true, 'Video section container is visible');

		}, 1000);

	}, 1000);

});

test('Video nav : Changing the dropdown value filters video list appropriately.', function(){

	var $dropdown = w.$('#videos-category');

	$dropdown.val(2);

	var category = $dropdown.val();

	var $matched = w.$('#resources-video-list a').filter(function() {
		return w.$(this).data("category") == category
	});

	var $notMatched = w.$('#resources-video-list a').filter(function() {
		return w.$(this).data("category") != category
	});

	notEqual($matched.length, 0, 'At least one video is matched');
	notEqual($notMatched.length, 0, 'At least one video is not matched');
	equal($notMatched.filter(':visible').length, 0, 'No unmatched videos are visible.')

	var testVisible = true;

	w.$('#resources-video-list a:visible').each(function(){
		if(w.$(this).data("category") !== category ) testVisible = false;
	})

	equal(testVisible, true, "All visible links match the category.");

});

test('Video pagination : 20 video thumbnails visible at a time.', function(){

	var $activeLinks = w.$('#resources-video-list a.active');

	if ( $activeLinks.length === 0 ) {
		ok(false, 'No videos links in the DOM.');
	}

	if ( $activeLinks.length <= 20 ) {
		ok(true, 'Not enough videos to run test.');
	}

	ok($activeLinks.filter(':visible').length <= 20, 'No more than 20 thumbnails are visible.');

});

test('Video pagination : Clicking a number loads the correct offset page of videos.', function(){

	var $activeLinks = w.$('#resources-video-list a.active');

	if ( $activeLinks.length === 0 ) {
		ok(false, 'No videos links in the DOM.');
	}

	if ( $activeLinks.length <= 20 ) {
		ok(true, 'Not enough videos to run test.');
		return;
	}

	stop();

	w.location.hash = "#videos/page/2";

	setTimeout(function(){

		var indexOne = $activeLinks.index($activeLinks.filter(':visible').eq(0));

		w.location.hash = "#videos/page/1";

		setTimeout(function(){

			start();

			var indexTwo = $activeLinks.index($activeLinks.filter(':visible').eq(0));

			equal(indexTwo, indexOne - 20, 'Clicking "1" moved the index 20 spaces.')

		}, 1000);

	}, 1000);

});

test('Video pagination : Clicking "next" loads next set of videos.', function(){

	var $activeLinks = w.$('#resources-video-list a.active');

	if ( $activeLinks.length === 0 ) {
		ok(false, 'No videos links in the DOM.');
	}

	if ( $activeLinks.length <= 20 ) {
		ok(true, 'Not enough videos to run test.');
		return;
	}

	stop();

	w.location.hash = "#videos/page/1";

	setTimeout(function(){

		var indexOne = $activeLinks.index($activeLinks.filter(':visible').eq(0));

		w.App.trigger('resources:videos:pagination:next');

		setTimeout(function(){

			start();

			var indexTwo = $activeLinks.index($activeLinks.filter(':visible').eq(0));

			equal(indexTwo, indexOne + 20, 'Clicking back moved the index 20 spaces.')

		}, 1000);

	}, 1000);

});

test('Video pagination : Clicking "back" loads previous set of videos.', function(){

	var $activeLinks = w.$('#resources-video-list a.active');

	if ( $activeLinks.length === 0 ) {
		ok(false, 'No videos links in the DOM.');
	}

	if ( $activeLinks.length <= 20 ) {
		ok(true, 'Not enough videos to run test.');
		return;
	}

	stop();

	w.location.hash = "#videos/page/2";

	setTimeout(function(){

		var indexOne = $activeLinks.index($activeLinks.filter(':visible').eq(0));

		w.App.trigger('resources:videos:pagination:back');

		setTimeout(function(){

			start();

			var indexTwo = $activeLinks.index($activeLinks.filter(':visible').eq(0));

			equal(indexTwo, indexOne - 20, 'Clicking back moved the index 20 spaces.')

		}, 1000);

	}, 1000);

});
