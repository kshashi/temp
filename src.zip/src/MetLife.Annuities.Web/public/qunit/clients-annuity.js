
// Tests : Clients - Annuities

var i, // testing iframe.
	w; // testing iframe's window object.

module('Clients - Annuities', {

	setup: function() {

		stop();

		iframeLoad('/clients/annuity', function(iframe){

			i = iframe;
			w = i.contentWindow;
			w.qunits = {};

			w.require(['app-global'], function(AppGlobal) {
				AppGlobal.utilities.init();
				AppGlobal.init();
			});

			start();

		});

	},

	teardown: function() {
		iframeUnload(i);
	}

});

test('Brightcove Video Loads On Click', function() {

	stop();

	w.location.hash = w.$('a[href*="#video/"]').first().attr('href')

	ok( w.$('a[href*="#video/"]').length > 0, 'Video links are present on page' );

	setTimeout(function(){
		start();
		var brightcove = w.$('.BrightcoveExperience');
		equal( brightcove.length, 1, 'Brightcove Objects Loaded within 250ms' );
	}, 250);

});

test('Brightcove Loads New Video When Clicking A Different Item', function() {

	stop();

	ok( w.$('a[href*="#video/"]').length > 0, 'Video links are present on page' );

	var firstBrightcove,
		secondBrightcove,
		firstHref = w.$('a[href*="#video/"]').first().attr('href');

	w.location.hash = firstHref;

	setTimeout(function(){

		var otherVideos = w.$('a[href*="#video/"][href!="' + firstHref + '"]');

		firstBrightcove = w.$('.BrightcoveExperience');

		if ( otherVideos.length === 0 ) {
			start();
			ok( true, 'No Other Videos To Verify');
			return;
		}

		w.location.hash = otherVideos.first().attr('href');

		setTimeout(function(){
			start();
			secondBrightcove = w.$('.BrightcoveExperience');
			ok( firstBrightcove !== secondBrightcove, 'Videos Changed' );
		}, 250);

	}, 250);

});
