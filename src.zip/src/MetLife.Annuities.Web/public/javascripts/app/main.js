/**
 * @module main
 */
(function () {

	'use strict';

	require(['config'], function () {

		require(['global', 'helpers/utilities'], function (App, Utilities) {

			var area = document.getElementById('requirejs').getAttribute('data-area') || '',
				has;

			// Polyfill has() when not provided via Requirejs optimizer.
			// see helpers/utilities#polyfillHas for more info.
			has = has || Utilities.polyfillHas({
				'useMin': false
			});
			require(['domReady'], function (domReady) {
			  domReady(function () {
			    App.init();
			  });
			});
			

		});

	});

}());
