/**
 * @module global
 */

define(function (require, exports, module) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Modernizr = require('modernizr'),
		Backbone = require('backbone'),
		Utilities = require('helpers/utilities'),
		App = require('app/index');

	require('dropkick');
	require('highcharts');
	require('timeago');
	require('touchswipe');

	_.extend(App, {

		/**
		 * Initialize Application. Responsible for instantiating Backbone router
		 * and starting Backbone history.
		 * @method App.init
		 * @param config {Object} JS App configuration object, typically passed from the middle tier.
		 */
		'init': function (config) {

			var self = this,
				appView;

			config = config || {};

			Utilities.init();

			this.config = new App.models.AppConfig(config);
			this.router = new App.routers.AppRouter();

			Backbone.history.start();

			appView = new App.views.AppView({
				'el': document.body
			});

			log('Global : Initialized');
		}
	}, Backbone.Events);

	exports = _.extend(exports, App);

});
