/**
 * @module router/ResourcesRouter
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.Router.extend({

		initialize: function () {

			var hash = Backbone.history.getHash();

			Backbone.history.loadUrl(hash);

			log('Backbone : Router : ResourcesRouter : Initialized');
		},

		'routes': {
			// default route to videos section
			'': 'videos',
			'videos': 'videos',
			'videos/video/:id': 'videos',
			'videos/playlist/:id': 'playlist',
			'documents': 'documents',
			'faqs': 'faqs',
			'glossary': 'glossary'
		},

		'videos': function (id) {
			App.trigger('resources:navigate', 'videos');
			if (!_.isUndefined(id)) {
				App.trigger('resources:videos:load', id);
				App.trigger('resources:videos:videoView');
			}
		},

		'playlist': function (id) {

			App.trigger('resources:navigate', 'playlist');
			if (!_.isUndefined(id)) {
				App.trigger('resources:playlist:load', id);
				App.trigger('resources:playlist:videoView');
			}
		},

		'documents': function (id) {
			App.trigger('resources:navigate', 'documents');
		},

		'faqs': function (id) {
			App.trigger('resources:navigate', 'faqs');
		},

		'glossary': function (id) {
			App.trigger('resources:navigate', 'glossary');
		}

	});

});
