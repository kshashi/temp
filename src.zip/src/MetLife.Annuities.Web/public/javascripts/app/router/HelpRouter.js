/**
 * @module areas/advisors/router/HelpRouter
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.Router.extend({

		initialize: function () {

			var hash = Backbone.history.getHash();

			Backbone.history.loadUrl(hash);

			log('Backbone : Router : HelpRouter : Initialized');
		},

		'routes': {
			'': 'landing',
			'faqs': 'faqs',
			'tutorials': 'tutorials',
			'tutorials/:id': 'tutorials'
		},

		'landing': function (id) {
			App.trigger('help:navigate', 'landing');
		},

		'faqs': function (id) {
			App.trigger('help:navigate', 'faqs');
		},

		'tutorials': function (id) {
			App.trigger('help:navigate', 'tutorials');
			if (!_.isUndefined(id)) {
				App.trigger('help:tutorialVid', id);
			}
		}

	});

});
