//additional methods for new regex
//note this is made optional - if you want it required put an additional class on the input
$.validator.addMethod(
  "postcode",
  function (value, element) {
      //can add additional parameters ie (value, element, regex) 
      //if you need to pass stuff in from being defined somewhere else

      //broad standard UK postcode regex (not GIR0)
      var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])([0-9][a-zA-z][a-zA-z]){1}$/;
      var re = new RegExp(regPostcode);
      return this.optional(element) || re.test(value);
  }, "" //error message left blank so it hides
);

$.validator.addMethod(
  "phone",
  function (value, element) {
      return this.optional(element) || (value.length > 9 && value.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/));
  }, "" //suppress error message with empty string
);

//reset standard error messages
$.validator.messages.required = "";
$.validator.messages.email = "";
$.validator.messages.minlength = "";
$.validator.messages.url = "";

//main validation declaration
$(document).ready(function () { //once the page has loaded
    $("#form").validate({
        errorPlacement: function (error, element) {
            $(element).attr({ "ss": error.append() });
        },
        highlight: function (element, errorClass, validClass) { //what happens when the validation fails
            //$(element).siblings('div').addClass('error'); //pick all the local text
            $('#updtMsg').html("");
            $(element).next().next('.msg').show(); //pick all the local text
            //Because this setting overrides the default behaviour we need to add it back in, to get the red borders
            if (element.type === 'radio') {
                $(element).next().next().next('.msg').show();
                this.findByName(element.name).addClass(errorClass).removeClass(validClass);
            } else {
                $(element).addClass(errorClass).removeClass(validClass);
            }
        },

        unhighlight: function (element, errorClass, validClass) { //unhighlight rather than success as that gets stopped by blank error messages
            // $(element).siblings('div').removeClass('error');
            $(element).next().next('.msg').hide();
            //Because this setting overrides the default behaviour we need to add it back in, to get the red borders
            if (element.type === 'radio') {
                $(element).next().next().next('.msg').hide();
                this.findByName(element.name).removeClass(errorClass).addClass(validClass);
            } else {
                $(element).removeClass(errorClass).addClass(validClass);
            }
        },
        showErrors: function (errorMap, errorList) {//additional act on validate to show summary control
            var errors = this.numberOfInvalids(); //go through the collection of validators
            if (errors) {
                //                $("#summary label").html('Whoops! ' + errors + ' errors'); //could be place in the html if it doesn't change
                //                $("#summary").show();
            } else {
                // $("#summary").hide();
            }
            this.defaultShowErrors();
        }
    });
});