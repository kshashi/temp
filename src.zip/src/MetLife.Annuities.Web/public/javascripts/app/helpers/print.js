(function () {
	window.print();
}());
