/**
 * @module model/BrightcovePlaylistModel
 */

define(function (require) {

	'use strict';

	var Backbone = require('backbone');

	return Backbone.Model.extend({

		'defaults': {
			'id': 0,
			'playlistId': 0,
			'name': '',
			'videoIds': [],
			'videos': []
		},

		'initialize': function () {}

	});

});
