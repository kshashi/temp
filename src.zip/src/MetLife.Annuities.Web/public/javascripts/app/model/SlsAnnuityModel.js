/**
 * @module model/SlsAnnuityModel
 */

define(function (require) {

	'use strict';

	var Backbone = require('backbone'),
		App = require('global');

	return Backbone.Model.extend({

		'defaults': {
			'slsId': '',
			'slsName': '',
			'slsInvestment': 0,
			'slsRodb': false,
			'slsOptions': '',
			'slsCreatedBy': '',
			'slsCreatedTime': 0
		},

		'initialize': function () {},

		'getOptionsCollection': function () {
			return new App.collections.SlsOptionCollection(JSON.parse(this.get('slsOptions')));
		},

		'formatCurrency': function () {
			var val = Math.round(this.get('slsInvestment'));
			while (/(\d+)(\d{3})/.test(val.toString())) {
				val = val.toString().replace(/(\d+)(\d{3})/, '$1' + ',' + '$2');
			}
			return '$' + val;
		},

		'formatCreatedTime': function () {
			var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
			var dt = new Date(this.get('slsCreatedTime'));
			var hour = dt.getHours();
			var amPm = (hour >= 12) ? 'pm' : 'am';
			if (hour > 12) hour = hour - 12;
			return months[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear() + ' ' + hour + ':' + dt.getMinutes() + amPm;
		}

	});

});
