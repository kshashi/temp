/**
 * @module model/AllocationsModel
 */

define(function (require) {

	'use strict';

	var Backbone = require('backbone');

	return Backbone.Model.extend({

		'defaults': {
			'id': 0
		},

		'initialize': function () {}

	});

});
