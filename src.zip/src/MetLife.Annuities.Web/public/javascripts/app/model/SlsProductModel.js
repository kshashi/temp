/**
 * @module model/SlsProductModel
 */

define(function (require) {

	'use strict';

	var Backbone = require('backbone');

	return Backbone.Model.extend({

		'defaults': {
			'id': '',
			'name': '',
			'isStepRate': false,
			'protection': 0,
			'terms': []
		},

		'initialize': function () {},

		'getRate': function (term, indexId, rodb) {
			var rate = 0;
			var prodTerms = this.get('terms');
			for (var x = 0; x < prodTerms.length; x++) {
				var prodTerm = prodTerms[x];
				if (prodTerm.years == term) {
					for (var y = 0; y < prodTerm.indexes.length; y++) {
						var termIndex = prodTerm.indexes[y];
						if (termIndex.id == indexId) {
							if (rodb === true) rate = termIndex.raterodb;
							else rate = termIndex.rate;
							break;
						}
					};
				}
			}
			return rate;
		},
		
		'getYAxis': function (term, indexId) {
			var yAxis = {
				up: 100,
				down: 100,
				flat: 100
			};
			var prodTerms = this.get('terms');
			for (var x = 0; x < prodTerms.length; x++) {
				var prodTerm = prodTerms[x];
				if (prodTerm.years == term) {
					for (var y = 0; y < prodTerm.indexes.length; y++) {
						var termIndex = prodTerm.indexes[y];
						if (termIndex.id == indexId) {
							yAxis.up = termIndex.y_axis_ceiling_up_market;
							yAxis.down = termIndex.y_axis_ceiling_down_market;
							yAxis.flat = termIndex.y_axis_ceiling_flat_market;
							break;
						}
					};
				}
			}
			return yAxis;
		},
		
		'isFixed': function () {
			var prodId = this.id.toLowerCase();
			return (prodId.indexOf('fixed') >= 0);
		}

	});

});
