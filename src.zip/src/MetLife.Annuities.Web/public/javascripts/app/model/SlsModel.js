/**
 * @module model/SlsModel
 */

define(function (require) {

	'use strict';

	var Backbone = require('backbone'),
		App = require('global');

	return Backbone.Model.extend({

		'defaults': {
			'indexes': null,
			'disclosures': null,
			'products': null,
			'termLengths': null
		},

		'initialize': function () {
			// Assumes that server-side code sets the slsConfig variable
			var model = this;
			var products = new App.collections.SlsProductCollection();
			var termLengths = [];
			var indexes = new App.collections.SlsIndexCollection();
			var disclosures = {};
			var alphabetArray = "a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz".toUpperCase().split(' ');
			var alphabetIndex = 0;
			for (var i = 0; i < slsConfig.indexes.length; i++) {
				var index = slsConfig.indexes[i];
				var indexDisclosures = [];
				for (var d = 0; d < index.disclosures.length; d++) {
					var letter = alphabetArray[alphabetIndex];
					disclosures[letter] = index.disclosures[d];
					indexDisclosures.push(letter);
					alphabetIndex++;
				}
				indexes.push(new App.models.SlsIndexModel({
					id: index.id,
					name: index.name,
					description: index.description,
					disclosures: indexDisclosures
				}));
			}
			for (var p = 0; p < slsConfig.products.length; p++) {
				var product = slsConfig.products[p];
				_.each(product.terms, function (term) {
					if (termLengths.indexOf(term.years) < 0) termLengths.push(term.years);
				});
				products.push(new App.models.SlsProductModel(product));
			}
			// Set properties
			products.sort();
			termLengths.sort();
			this.set({
				'indexes': indexes,
				'disclosures': disclosures,
				'products': products,
				'termLengths': termLengths
			});
		}

	});

});
