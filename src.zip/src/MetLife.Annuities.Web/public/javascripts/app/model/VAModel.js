/**
 * @module model/VAModel
 */

define(function (require) {

	'use strict';

	var Backbone = require('backbone');

	return Backbone.Model.extend({

		'defaults': {
			'id': 0,
			'yAxis': [],
			'xAxis': [],
			'benifit': [],
			'account': []
		},

		'initialize': function () {}

	});

});
