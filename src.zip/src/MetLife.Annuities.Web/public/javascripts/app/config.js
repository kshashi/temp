/**
 * @module config
 */

(function () {

	'use strict';

	require.config({

		// Disable timeout for scripts.
		'waitSeconds': 0,

		'baseUrl': '/public/javascripts',

		'paths': {

			'config': 'app/config',

			// Core Libraries
			'jquery': 'lib/jquery-1.8.2.min',
			'underscore': 'lib/underscore-min',
			'backbone': 'lib/backbone-min',
			'videojs': 'lib/video.min',
			'modernizr': 'lib/modernizr-2.6.2.min',

			// Plugins
			'dropkick': 'plugins/jquery.dropkick',
			'highcharts': 'plugins/highcharts',
			'brightcoveExperiences': '//sadmin.brightcove.com/js/BrightcoveExperiences',
			'brighcoveModules': '//sadmin.brightcove.com/js/APIModules_all',
			'timeago': 'plugins/jquery.timeago',
			'touchswipe': 'plugins/jquery.touchswipe.min',
			'domReady': 'plugins/domReady',

			// Backbone Submodule Directories
			'router': 'app/router',
			'model': 'app/model',
			'collection': 'app/collection',
			'view': 'app/view',
			'template': 'app/template',

			// Helper Modules
			'helpers': 'app/helpers',

			// Application
			'global': 'app/global'

		},

		// Sets the configuration for your third party scripts that are not AMD compatible
		'shim': {

			'modernizr': {
				'exports': 'Modernizr'
			},

			'videojs': {
				'exports': '_V_'
			},

			'underscore': {
				'exports': '_'
			},

			'backbone': {
				'deps': ['underscore', 'jquery'],
				'exports': 'Backbone'
			},

			'dropkick': {
				'deps': ['jquery'],
				'exports': 'dropkick'
			},

			'highcharts': {
				'deps': ['jquery'],
				'exports': 'highcharts'
			},

			'timeago': {
				'deps': ['jquery'],
				'exports': 'timeago'
			},

			'touchswipe': {
				'deps': ['jquery'],
				'exports': 'touchswipe'
			}

		}

	});

	// Require global here for optimizer build.
	require(['global', 'helpers/utilities'], function (App, Utilities) {

		var has;

		// Polyfill has() when not provided via Requirejs optimizer.
		// see helpers/utilities#polyfillHas for more info.
		has = has || Utilities.polyfillHas({
			'debugMode': true
		});

		// debugMode property provided by requirejs build task.
		window.isDebugMode = (has('debugMode')) ? true : false;

	});

}());
