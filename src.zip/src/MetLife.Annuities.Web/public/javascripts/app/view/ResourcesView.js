/**
 * @module view/ResourcesView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {},

		'initialize': function (options) {

			_.bindAll(this);

			this.render();

			log('Backbone : View : ResourcesView : Initialized');
		},

		'render': function () {

			this.resourcesVideoView = new App.views.ResourcesVideoView({
				'el': '#section-resources-videos'
			});
			
			this.resourcesVideoFilterView = new App.views.FilterView({
				'el': '#section-resources-videos',
				'name': 'videos',
				'customFilter': true
			});

			this.documentsView = new App.views.DocumentsView({
				'el': '#section-resources-documents'
			});

			this.documentsFilterView = new App.views.FilterView({
				'el': '#section-resources-documents',
				'name': 'documents',
				'customFilter': false
			});

			this.glossaryView = new App.views.GlossaryView({
				'el': '#section-resources-glossary'
			});

			this.tooltipView = new App.views.TooltipView({
				'el': '#section-content'
			});

			this.resourcesNavView = new App.views.ResourcesNavView({
				'el': '#section-content'
			});

			// Load router last to trigger routes on deep link
			this.resourcesRouter = new App.routers.ResourcesRouter();

		}

	});

});
