/**
 * @module view/TooltipView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'mouseenter .tooltip': 'handleTooltipMouseover',
			'mouseleave .tooltip': 'handleTooltipMouseout',
			'click .tooltip-sticky': 'handleTooltipClick'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.addingFlag = false;
			var view = this;
			App.on('follow-up-flag:start', function () {
				view.addingFlag = true;
			});
			App.on('follow-up-flag:end', function () {
				view.addingFlag = false;
			});

			this.tooltipTemplate = App.templates.TooltipTemplate;

			this.render();

			log('Backbone : View : TooltipView : Initialized');
		},

		'render': function () {
			var view = this;
			if($('#tooltip-container').length === 0) {
				view.$tooltipContainer = $('<div/>', {
					'id': 'tooltip-container'
				}).addClass('hidden');
				view.$el.append(view.$tooltipContainer);
				view.bindTooltipContainerMouseout();
			} else view.$tooltipContainer = $('#tooltip-container');
		},
		
		'bindTooltipContainerMouseout': function () {
			var view = this;
			view.$tooltipContainer.hover(function () {
				view.$tooltipContainer.addClass('active').removeClass('hidden');
			}, function () {
				var stickyId = view.$tooltipContainer.attr('data-sticky-id');
				if(stickyId === '' || stickyId === undefined) view.$tooltipContainer.addClass('hidden').removeClass('active');
			});
		},
		
		'handleTooltipClick': function (e) {
			var view = this,
				$target = $(e.currentTarget);
			
			if ($target.attr('data-sticky-id') == view.$tooltipContainer.attr('data-sticky-id') && view.$tooltipContainer.hasClass('active')) {
				if (view.attributes && view.attributes.handleStickyClose) view.attributes.handleStickyClose($target.attr('data-sticky-id'));
				view.handleTooltipMouseout(e);
			} else view.handleTooltipMouseover(e);
		},

		'handleTooltipMouseover': function (e) {
			if (this.addingFlag === false) {

				var $target = $(e.currentTarget),
					content = $target.data('tooltip'),
					$tooltip = $(_.template(this.tooltipTemplate, {
						'content': content
					})),
					stickyId = $target.attr('data-sticky-id') || '';

				this.$tooltipContainer.html($tooltip).attr('data-sticky-id', stickyId);

				this.showTooltip($target);

			}
		},

		'handleTooltipMouseout': function (e) {
			var view = this;
			view.$tooltipContainer.addClass('hidden').removeClass('active');
		},

		'showTooltip': function ($target) {
			var $targetOffset = $target.offset(),
				targetCenter = $target.outerWidth() / 2,
				tooltipCenter = this.$tooltipContainer.outerWidth() / 2,
				tooltipHeight = this.$tooltipContainer.outerHeight(true),
				tooltipOffsetLeft = -(tooltipCenter) + targetCenter;

			this.$tooltipContainer.css({
				'left': $targetOffset.left,
				'top': $targetOffset.top - tooltipHeight,
				'margin-left': tooltipOffsetLeft
			});
			this.$tooltipContainer.addClass('active').delay(10).queue(function () {
				$(this).removeClass('hidden').dequeue();
			});
			if (this.attributes && this.attributes.bindEvents) this.attributes.bindEvents();
		}

	});

});
