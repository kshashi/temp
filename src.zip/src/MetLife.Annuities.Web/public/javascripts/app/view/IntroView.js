/**
 * @module view/IntroView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .video-play-button': 'initVideoView',
			'click .video': 'initVideoView'
		},

		'initialize': function (options) {
			var view = this;
			_.bindAll(this);

			view.$videoWrapper = $('.video-wrapper');
			view.$contentWrapper = $('.content-wrapper');
			view.$videoDescription = $('.video-description');
			this.render();

			log('Backbone : View : IntroView : Initialized');
		},

		'render': function () {

			var view = this;

			App.on('resources:playlist:load', this.renderPlaylist);

			view.resourcesRouter = new App.routers.ResourcesRouter();

		},

		'renderPlaylist': function (id) {
			var view = this;

			view.brightcovePlaylistPlayerView = new App.views.BrightcovePlaylistPlayerView({
				'el': view.$videoWrapper,
				'id': 'brightcove-video',
				'parentView': view,
				'playlistId': id
			});
		},

		'initVideoView': function () {
			var view = this;

			view.$contentWrapper.addClass('video-view');
			view.$videoWrapper.show();

		}
	});

});
