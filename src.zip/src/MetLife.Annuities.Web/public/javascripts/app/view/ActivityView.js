/**
 * @module view/ActivityView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global')

		return Backbone.View.extend({

			'events': {
				'click .page-nav': 'handlePaginationClick'
			},

			'initialize': function (options) {

				_.bindAll(this);

				this.$activityContainer = $('#activity-template-container');
				this.activityFeedTemplate = App.templates.ActivityTemplate;
				this.$activityTemplate;
				this.feedUrl = window.location.href;
				this.advisorId = 2;
				this.currentPage = 1;
				this.filter = 'All';
				this.sort = 'most recent';
				this.$noData = $('.no-data');
				this.$loading = $('.spinner');
				this.$paginator = $('.controls-wrapper');
				App.on('filter-activities:customSelect:change', this.handleFilterChange);
				App.on('sort-activities:customSelect:change', this.handleSortChange);
				this.render();

				log('Backbone : View : ActivityView : Initialized');
			},

			'render': function () {
				this.getFeed();
			},

			'handleFilterChange': function (value) {
				var filter = value;
				this.getFeed({
					'page': 1,
					'filter': filter
				});
			},

			'handleSortChange': function (value) {
				var sort = value;
				this.getFeed({
					'page': 1,
					'sort': sort
				});
			},

			'handlePaginationClick': function (e) {
				e.preventDefault();
				$('html, body').animate({
					scrollTop: 0
				}, 0);
				var $target = $(e.currentTarget),
					page = $target.data('position');
				this.getFeed({
					'page': page
				});
			},

			'getFeed': function (args) {
				var view = this;

				args = args || {};
				args.advisor_id = view.advisorId;
				args.filter = args.filter || view.filter;
				view.filter = args.filter;
				args.sort = args.sort || view.sort;
				view.sort = args.sort;
				args.page = args.page || view.currentPage;
				view.currentPage = args.page;

				view.$activityContainer.empty();
				view.$noData.hide();
				view.$loading.show();

				$.ajax({
					type: "POST",
					url: view.feedUrl,
					data: args,
					success: function (data) {
						view.$loading.hide();
						view.$loading.hide();
						if (data.items.length == 0) {
							view.$paginator.hide();
							view.$noData.html("There were no activities found.").show();
						} else {
							view.$activityTemplate = $(_.template(view.activityFeedTemplate, data));
							view.$activityContainer.html(view.$activityTemplate);
							$('p.time').timeago();
						}
					},
					error: function (data) {

					}
				});
			}

		});

});
