/**
 * @module view/FeedbackTabView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #feedback-tab': 'openFeedbackModal'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$feedbackTab = $(_.template(App.templates.FeedbackTabTemplate, {}));
			this.$feedbackModal = $('.feedback-modal');
			this.$body = $(document.body);

			this.render();

			$(window).scroll(_.throttle(this.updateTabPosition, 300));

			this.$body.on('click', '#mask', this.closeModal)
				.on('click', '#modal-close', this.closeModal);

			log('Backbone : Global : FeedbackTabView : Initialized');
		},

		'render': function () {
			var feedbackFormView;

			this.$el.append(this.$feedbackTab);

			App.on('modal:FeedbackModal', function () {
				feedbackFormView = new App.views.FeedbackFormView({
					'el': '.feedback-form'
				});
			})

			this.updateTabPosition();
		},

		'openFeedbackModal': function () {
			var modalView;

			modalView = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'FeedbackModalTemplate'
			});
		},
		'closeModal': function () {

			this.$feedbackModal.find('form')
				.removeClass('show-messages show-errors')
				.find('textarea').val('')
				.removeClass('error');
		},

		'updateTabPosition': function () {
			var scrollTop = $(document).scrollTop() + 450,
				contentBottom = this.$el.outerHeight(true);

			if (scrollTop > contentBottom - 100) {
				scrollTop = contentBottom - 100;
			}

			this.$feedbackTab.stop().animate({
				'top': scrollTop + 'px'
			}, 200);
		}

	});

});
