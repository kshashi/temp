/**
 * @module view/ResourcesVideoView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .play-button': 'renderVideos'
		},

		'initialize': function () {

			var view = this;
			_.bindAll(this);

			view.$videoWrapper = $('#resources-video');
			view.$videoPool = [];
			view.$el.find('.video-thumbs li').each(function () {
				view.$videoPool.push($(this).clone());
			});
			view.$videoCarousel = view.$el.find('.carousel-list');
			view.carouselView = null;

			this.render();

			log('Backbone : View : ResourcesVideoView : Initialized');
		},

		'render': function () {

			var view = this;

			App.on('resources:videos:load', this.renderVideos);
			App.on('resources:videos:filter', this.filterVideos);

			view.resourcesRouter = new App.routers.ResourcesRouter();

		},

		'renderVideos': function (e) {

			e.preventDefault();

			var view = this,
				$target = $(e.currentTarget),
				id = $target.attr('id'),
				videoID = $target.attr('data-video-id');

			view.$videoWrapper.addClass('active');

			view.brightcovePlayerView = new App.views.BrightcovePlayerView({
				'el': view.$videoWrapper,
				'videoId': videoID
			});

		},
		
		'displayThumbnails': function() {
			var view = this,
				thumbCount = 0,
				$newPage = $(_.template(App.templates.VideoCarouselItemTemplate, {})),
				usedIds = [];
				
			view.$videoCarousel.html('');
			view.$el.find('.controls-wrapper').remove();
			view.$videoCarousel.append($newPage);
			
			_.each(view.$videoPool, function (vidItem) {
				var vidId = vidItem.find('a').attr('id');
				if(vidItem.hasClass('active') && usedIds.indexOf(vidId) < 0) {
					usedIds.push(vidId);
					thumbCount++;
					if(thumbCount == 9) {
						$newPage = $(_.template(App.templates.VideoCarouselItemTemplate, {}));
						view.$videoCarousel.append($newPage);
						thumbCount = 1;
					}
					$newPage.find('.video-thumbs').append(vidItem.clone());
				}
			});
			
			if(view.carouselView !== null) {
				view.carouselView.$carousel.css('left', '0');
				view.carouselView.undelegateEvents();
				view.carouselView = null;
			}
			view.carouselView = new App.views.CarouselView({
				'el': '#section-resources-videos',
				'pagination': true
			});
		},
		
		'filterVideos': function (category, search) {
			var view = this;
			_.each(view.$videoPool, function ($vidItem) {
				$vidItem.removeClass('active');
			});
			_.each(view.$videoPool, function ($vidItem) {
				var cat = $vidItem.data('filter-category');
				var item = $vidItem.data('filter-item').toLowerCase();
				if(search !== '') {
					if (item.indexOf(search) >= 0 && (category == 'All' || category == cat)) {
						$vidItem.addClass('active');
					}
				} else if (category == 'All' || category == cat) {
					$vidItem.addClass('active');
				}
			});
			this.displayThumbnails();
		}
		
	});

});
