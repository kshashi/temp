/**
 * @module view/ResourcesNavView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #nav-resources a': 'handleNavItemClick'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$sections = $('.section');
			this.$sectionResourcesContent = $('#section-resources-content');

			App.bind('resources:navigate', this.handleResourcesDeepLink);

			this.render();

			log('Backbone : ResourcesNavView : Initialized');
		},

		'render': function () {
			this.$sections.not('.active').addClass('hidden');
		},

		'handleNavItemClick': function (e) {
			var $target = $(e.currentTarget),
				section = $target.data('section'),
				$section = this.$sectionResourcesContent.find('#section-resources-' + section);

			App.trigger('resourcesSection:' + section);

			if ($section.hasClass('active')) {
				return;
			}

			this.showActiveSection($section);

		},

		'handleResourcesDeepLink': function (section) {
			var view = this,
				$section = this.$sectionResourcesContent.find('#section-resources-' + section);

			view.addSelectedState(section);

			this.showActiveSection($section);
		},

		'showActiveSection': function ($section) {
			this.$sections.addClass('hidden').removeClass('active');

			$section.addClass('active').delay().queue(function () {
				$(this).removeClass('hidden').dequeue();
			});
			if ($('#section-resources-faqs').hasClass('active')) {
				$('#disclaimer_faq').show();
				App.trigger('pause:video');
			} else {
				$('#disclaimer_faq').hide();
			}
			if ($('#section-resources-videos').hasClass('active')) {
				$('#disclaimer_video').show();
			} else {
				$('#disclaimer_video').hide();
			}
			if ($('#section-resources-documents').hasClass('active')) {
				$('#disclaimer_document').show();
				App.trigger('pause:video');
			} else {
				$('#disclaimer_document').hide();
			}
			if ($('#section-resources-glossary').hasClass('active')) {
				$('#disclaimer_glossary').show();
				App.trigger('pause:video');
			} else {
				$('#disclaimer_glossary').hide();
			}
		},

		'addSelectedState': function (section) {
			var view = this;

			view.$el.find('#nav-resources').find('.selected').removeClass('selected');
			view.$el.find('.' + section).addClass('selected');
		}

	});

});
