/**
 * @module view/BrightcovePlayerView
 */
define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');
	require('videojs');

	return Backbone.View.extend({

		'events': {
			'click #volume': 'setVolume',
			'click #mute': 'toggleMute',
			'click #play': 'togglePlay',
			'click #progress': 'seek'
		},

		'defaults': {
			'height': '505',
			'width': '960',
			'volume': 40
		},

		'initialize': function (options) {

			var view = this;

			view.o = $.extend(view.defaults, options);
			view.template = _.template(App.templates.BrightcovePlayerTemplate);

			_.bindAll(this);

			this.options = options;

			this.render();

			log('Backbone : Global : BrightcovePlayerView : Initialized : ID=' + view.o.videoID);
		},

		'render': function (autoPlay) {

			var view = this;

			view.autoPlay = (_.isUndefined(autoPlay)) ? view.autoPlay : autoPlay;
			view.hasPlayed = false;
			view.isPlaying = false;
			view.isEnded = false;
			view.isReady = false;
			view.isMuted = false;
			view.video = {};
			view.videoDuration = 0;
			view.percentLoaded = 0;
			view.secondsPlayed = 0;
			view.lastBuffered = 0;
			view.prevSecondsPlayed = 0;
			view.playProgress = 0;

			view.$el.html(view.template({
				'id': view.o.id,
				'videoID': view.o.videoID,
				'height': view.o.height,
				'width': view.o.width,
				'autoPlay': view.autoPlay
			})).addClass('active stopped');

			view.$buffer = view.$('#buffer');
			view.$play = view.$('#play');
			view.$volume = view.$('#volume');
			view.$volumeLevel = view.$volume.find('#level');
			view.$elapsedTime = view.$('#elapsed');
			view.$controls = view.$('#controls');
			view.$counter = view.$('#counter');
			view.$duration = view.$('#duration');

			_V_(view.o.id, {
				'controls': false,
				'techOrder': ["html5", "flash"]
			}, function () {
				view.bindAppEventHandlers();
				view.bindPlayerEventHandlers(this);
			});

			view.$el.find('.vjs-tech').css({
				'width': view.o.width,
				'height': view.o.height
			})

		},

		'bindPlayerEventHandlers': function (player) {
			var view = this;

			view.player = player;
			view.player.addEvent("ended", view.handleVideoComplete);
			view.player.addEvent("play", function () {
				view.trigger('play:video');
			});
			view.player.addEvent("pause", function () {
				view.trigger('pause:video');
			});
			view.player.addEvent("timeupdate", function () {
				view.trigger('progress:video');
			});
			view.player.addEvent("loadedmetadata", function () {
				view.videoDuration = view.player.duration();
				view.updateControls();
			});
			view.player.addEvent('loadstart', view.buffer);
			view.videoReady();
		},

		'bindAppEventHandlers': function () {
			var view = this;

			view.on('play:video', function (e) {
				if (!view.isPlaying) {
					view.isPlaying = true;
					view.$el.removeClass('stopped').addClass('playing');
				}

				if (!view.hasPlayed) {
					view.hasPlayed = true;
				}

				log('Brightcove : Player : Playing');
			})
				.on('pause:video', function () {
				view.isPlaying = false;
				view.$el.removeClass('playing');

				log('Brightcove : Player : Paused');
			})
				.on('progress:video', _.throttle(function () {
				var currentPosition = view.player.currentTime();
				view.updateProgress(currentPosition);
			}, 100));
		},

		'handleVideoComplete': function () {
			log('Brightcove : Player : Complete');
		},

		'videoReady': function (evt) {
			var view = this;
			view.isReady = true;
			view.player.volume(view.o.volume / 100);
			log('Brightcove : Player : Ready');
		},

		'buffer': function () {
			var view = this,
				buffer;

			buffer = setInterval(function () {
				var bufferedPercent = view.player.bufferedPercent();

				if (bufferedPercent < 1) {
					view.$buffer.css('width', Math.round(bufferedPercent * 100) + '%');
				} else {
					view.$buffer.css('width', '100%');
					clearInterval(buffer);
				}
			});
		},

		'setVolume': function (e) {
			var view = this;
			if (!view.isReady) {
				return;
			}

			var offset = (e.offsetX == undefined) ? (e.clientX - view.$volume.offset().left) : e.offsetX;
			view.o.volume = Math.round(offset / (view.$volume.width() + 7) * 100);
			view.player.volume(view.o.volume / 100);
			view.$volumeLevel.css('width', view.o.volume + '%');
		},

		'toggleMute': function () {
			var view = this;
			if (!view.isReady) {
				return;
			}

			if (view.isMuted) {
				view.player.volume(view.o.volume / 100);
				view.$volumeLevel.css('width', view.o.volume + '%');
				view.isMuted = false;
			} else {
				view.player.volume(0);
				view.$volumeLevel.css('width', '0%');
				view.isMuted = true;
			}
		},

		'stop': function () {
			if (!this.isReady) {
				return;
			}

			this.player.api('pause');
			this.trigger('stop:video');
		},

		'togglePlay': function (e) {
			if (!this.isReady) {
				return;
			}

			if (this.isPlaying) {
				this.player.pause();
			} else {
				this.player.play();
			}
		},

		'seek': function (e) {
			var view = this;
			if (!view.isReady) {
				return;
			}
			var offset = view.normalizeEvent(e);
			var ratio = offset.offsetX / ($('#progress').width() + 7);
			var seek = Math.round(view.videoDuration * ratio);
			view.$elapsedTime.css('width', ratio * 100 + '%');
			view.$counter.html(view.formatTime(seek));
			view.player.currentTime(seek);
		},

		'updateControls': function () {
			var view = this;
			view.$el.find('#duration').html(view.formatTime(view.videoDuration));
		},

		'updateProgress': function (currentPosition) {
			var view = this,
				percent = (currentPosition / view.videoDuration) * 100;
			view.$elapsedTime.css('width', Math.round(percent * 10) / 10 + '%');
			view.$counter.html(view.formatTime(Math.ceil(currentPosition)));
		},

		'normalizeEvent': function (event) {
			if (!event.offsetX) {
				event.offsetX = (event.pageX - $(event.target).offset().left);
				event.offsetY = (event.pageY - $(event.target).offset().top);
			}
			return event;
		},

		'formatTime': function (second, hour, minute) {
			if (second > 3600) {
				var ore = Math.floor(second / 3600);
				if (ore < 10) {
					ore = '0' + ore;
				}
				var rest = Math.ceil(second % 3600);
				var format = this.formatTime(rest, ore);
			} else if (second > 60) {
				var minuti = Math.floor(second / 60);
				if (minuti < 10) {
					minuti = '0' + minuti;
				}
				var rest = Math.ceil(second % 60);
				var format = this.formatTime(rest, ore, minuti);
			} else if (second < 60) {
				if (!hour) {
					hour = '00';
				}
				if (!minute) {
					minute = '00';
				}
				if (!second) {
					second = '00';
				} else {
					second = Math.round(second);
					if (second < 10) {
						second = '0' + second;
					}
				}
				var format = minute + ':' + second;
			}
			return format;
		}
	});

});
