/**
 * @module view/PrettyCheckboxesView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'focus .pretty-checkbox': 'handleFocusCheckbox',
			'blur .pretty-checkbox': 'handleBlurCheckbox',
			'click .pretty-checkbox': 'toggleCheckbox',
			'change input[type="checkbox"]': 'updateCheckboxes'
		},

		'initialize': function (options) {

			_.bindAll(this);

			var view = this;

			this.$checkboxes = this.$el.find('input[type="checkbox"]');
			this.$prettyCheckboxes = $();
			this.maxSelect = this.$el.data('maxSelect');

			this.$el.closest('form').on('reset', function () {
				view.resetCheckboxes();
			});

			this.render();

			log('Backbone : View : Shared : PrettyCheckboxesView : Initialized');
		},

		'render': function () {
			var view = this,
				prettyCheckboxTemplate = _.template(App.templates.PrettyCheckboxTemplate, {});

			this.$checkboxes.each(function () {
				var $prettyCheckbox = $(prettyCheckboxTemplate);
				if ($(this).attr('tabindex') !== '') {
					$prettyCheckbox.attr('tabindex', $(this).attr('tabindex'));
				}
				$(this).after($prettyCheckbox);
				view.$prettyCheckboxes = view.$prettyCheckboxes.add($prettyCheckbox);
			});

			this.saveCheckboxDefaults();
			this.updateCheckboxes();
		},

		'handleFocusCheckbox': function (e) {
			$(e.currentTarget).addClass('focus');

			this.$el.on('keyup.focus', this.handleKeyPress);
		},

		'handleBlurCheckbox': function (e) {
			$(e.currentTarget).removeClass('focus');

			this.$el.off('keyup.focus');
		},

		'handleKeyPress': function (e) {
			var $target = $(e.currentTarget);
			switch (e.keyCode) {
				case 37:
					// Left Arrow
				case 38:
					// Up Arrow
					this.togglePrev();
					return false;
					break;
				case 39:
					// Right Arrow
				case 40:
					// Down Arrow
					this.toggleNext();
					return false;
					break;
				case 13:
				case 32:
					this.toggleFocusedCheckbox();
			}
		},

		'togglePrev': function () {
			var currentCheckbox = this.$('.focus'),
				index = this.$prettyCheckboxes.index(currentCheckbox);

			this.$prettyCheckboxes.blur();

			if (index > 0) {
				this.$prettyCheckboxes.eq(index - 1).focus();
			} else {
				this.$prettyCheckboxes.last().focus();
			}
		},

		'toggleNext': function () {
			var currentCheckbox = this.$('.focus'),
				index = this.$prettyCheckboxes.index(currentCheckbox);

			this.$prettyCheckboxes.blur();

			if (index < this.$prettyCheckboxes.length - 1) {
				this.$prettyCheckboxes.eq(index + 1).focus();
			} else {
				this.$prettyCheckboxes.first().focus();
			}
		},

		'toggleCheckbox': function (e) {
			e.preventDefault();

			var $target = $(e.currentTarget),
				$source = this.$checkboxes.eq(this.$prettyCheckboxes.index($target));

			if (!$source.is(':checked')) {
				if (this.maxSelect && this.$checkboxes.filter(':checked').length >= this.maxSelect) {
					return;
				}
				$source.attr('checked', true);
				$target.addClass('checked');
			} else {
				$source.attr('checked', false);
				$target.removeClass('checked');
			}
		},

		'toggleFocusedCheckbox': function () {
			var $target = this.$('.focus'),
				$source = this.$checkboxes.eq(this.$prettyCheckboxes.index($target));

			if (!$source.is(':checked')) {
				if (this.maxSelect && this.$checkboxes.filter(':checked').length >= this.maxSelect) {
					return;
				}
				$source.attr('checked', true);
				$target.addClass('checked');
			} else {
				$source.attr('checked', false);
				$target.removeClass('checked');
			}
		},

		'saveCheckboxDefaults': function () {
			this.$checkboxes.filter(':checked').data('defaultState', 'checked');
		},

		'resetCheckboxes': function () {
			this.$checkboxes.each(function () {
				if ($(this).data('defaultState') === 'checked') {
					$(this).attr('checked', true);
				} else {
					$(this).attr('checked', false);
				}
			});
			this.updateCheckboxes();
		},

		'updateCheckboxes': function () {
			var view = this;

			this.$prettyCheckboxes.removeClass('checked');

			this.$checkboxes.each(function () {
				if ($(this).is(':checked')) {
					view.$prettyCheckboxes.eq(view.$checkboxes.index($(this))).addClass('checked');
				}
			});
		}

	});

});
