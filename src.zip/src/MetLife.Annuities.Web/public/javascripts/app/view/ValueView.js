/**
 * @module view/ValueView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .view-table': 'handleViewTable',
			'click .view-chart': 'handleViewChart'
		},

		'initialize': function (options) {

			_.bindAll(this);

			log('Backbone : Clients : ValueView : Initialized');
		},

		'render': function () {},

		'handleViewTable': function (e) {
			e.preventDefault();

			var view = this,
				$target = $(e.currentTarget);

			view.$el.find('.selected').removeClass('selected');
			$target.addClass('selected');

			view.$el.find('.table-view').show();
			view.$el.find('#chart-container, .chart-interactions, #chart-info').hide();
		},

		'handleViewChart': function (e) {
			e.preventDefault();

			var view = this,
				$target = $(e.currentTarget);

			view.$el.find('.selected').removeClass('selected');
			$target.addClass('selected');

			view.$el.find('.table-view').hide();
			view.$el.find('#chart-container, .chart-interactions, #chart-info').show();
		}
	});

});
