/**
 * @module view/SavedAnnuityView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .close': 'handleCloseAnnuity',
			'click .create-annuity': 'toggleCreateAnnuity',
			'click #create-va-chart': 'createVaChart',
			'click #create-sls-chart': 'createSlsChart'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$changedAnnuity = this.$el.find('.changed');
			this.$changedAnnuityAdvisor = this.$el.find('.changed-advisor');
			this.$createContainer = $('.create-container');
			this.render();

			log('Backbone : SavedAnnuityView : Initialized');
		},

		'render': function () {

			var view = this,
				tooltipsView, enableHypoView;

			enableHypoView = new App.views.EnableHypoView({
				'el': '#section-saved-annuities'
			});
			tooltipsView = new App.views.TooltipView({
				'el': '#section-content'
			});

			view.handleAnnuityChange();
			App.on('delete:annuity', this.handleDeletedAnnuity);
			App.on('exit:delete', this.handleDoNotDeleteAnnuity);
			var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
			view.$el.find('.created-date').each(function(){
				var dt = new Date(parseInt($(this).attr('data-timestamp')));
				var hours = dt.getHours();
				var minutes = dt.getMinutes();
				var ampm = (hours < 12) ? 'AM' : 'PM';
				hours = (hours == 0) ? 12 : (hours > 12) ? hours - 12 : hours;
				minutes = (minutes < 10) ? '0' + minutes : minutes;
				$(this).html(months[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear() + ' ' + hours + ':' + minutes + ' ' + ampm);
			});
			
			var qs = view.getQueryStringVars();
			if (qs.view == 'expanded') {
				$('.create-annuity').toggleClass('selected');
				view.$createContainer.show().promise().done(function(){
					view.resizeColumns();
				});
			}
		},
		
		'createSlsChart': function (e) {
			e.preventDefault();
			if($('.products.shield.disabled').length > 0) {
				var modalView = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'SlsUnavailableTemplate'
				});
				modalView.handleModalSelection();
			} else window.location.href = $(e.currentTarget).attr('href');
		},

		'createVaChart': function (e) {
			e.preventDefault();
			var $this = $(e.currentTarget);
			var guidUrl = '/clients/seriesva/create?client_id=' + $this.attr('data-client-id');
			$.ajax({
				type: "POST",
				url: guidUrl,
				data: {},
				success: function (data) {
					if (data.guid) {
						$('#GUID').val(data.guid);
						$('#GUID').parent().submit();
					} else alert('An error occurred');
				},
				error: function (data) {
					alert('An error occurred');
				}
			});
		},

		'handleAnnuityChange': function () {
			var view = this,
				$changeAlert = $(_.template(App.templates.ChangedAnnuityTemplate, {})),
				$changeAlertAdvisor = $(_.template(App.templates.ChangedAnnuityAdvisorTemplate, {}));

			view.$changedAnnuity.find('.annuity-controls').after($changeAlert);
			view.$changedAnnuityAdvisor.find('.annuity-controls').after($changeAlertAdvisor);
		},

		'handleCloseAnnuity': function (e) {

			e.preventDefault();

			var view = this,
				$this = $(e.currentTarget),
				annId = $this.data('annuity-id'),
				modalView;

			modalView = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'DeleteAnnuityModalTemplate'
			});

			$this.closest('.saved-annuity').addClass('candidate-for-deletion');

		},

		'handleDeletedAnnuity': function (e) {
			var view = this,
				annId = $('.candidate-for-deletion').data('annuity-id');

			$.ajax({
				type: "POST",
				url: '/clients/charts/delete?id=' + annId,
				success: function (data) {
					view.$el.find('.candidate-for-deletion').fadeOut().remove();
				},
				error: function (data) {}
			});
		},

		'handleDoNotDeleteAnnuity': function () {

			var view = this;

			view.$el.find('.candidate-for-deletion').removeClass('candidate-for-deletion');
		},
		'toggleCreateAnnuity': function (e) {
			e.preventDefault();
			var view = this;
			$(e.currentTarget).toggleClass('selected');
			this.$createContainer.slideToggle('slow').promise().done(function(){
				view.resizeColumns();
			});

		},
		
		'resizeColumns': function () {
			var prodHeight = 0;
			var $prods = $('#product-wrapper').find('.products');
			$prods.each(function(){
				if($(this).height() > prodHeight) prodHeight = $(this).height();
			});
			$prods.each(function(){
				if($(this).height() < prodHeight) {
					var diff = prodHeight - $(this).height();
					var $btn = $(this).find('.create-chart');
					var top = parseInt($btn.css('margin-top')) + diff + 'px';
					$btn.css('margin-top', top);
				}
			});
		},

		'getQueryStringVars': function () {
			var vars = {}, hash;
			var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
			for (var i = 0; i < hashes.length; i++) {
				hash = hashes[i].split('=');
				vars[hash[0]] = hash[1];
			}
			return vars;
		}
	});

});
