/**
 * @module view/ClientFullView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .video-toggle': 'handleVideoSectionToggle'
		},

		'initialize': function (options) {

			_.bindAll(this);
			this.$progressContainer = $('#progress');
			this.tooltipTemplate = App.templates.TooltipTemplate;
			this.progressData = progress;
			this.render();

			log('Backbone : ClientFullView : Initialized');
		},

		'render': function () {
			var finishedCarouselView, enableHypoView;

			this.renderProgress(this.progressData);

			this.$tooltipContainer = $('<div/>', {
				'id': 'tooltip-container'
			}).addClass('hidden');

			this.$progressContainer.append(this.$tooltipContainer);

			enableHypoView = new App.views.EnableHypoView({
				'el': '#section-client-full'
			});

			finishedCarouselView = new App.views.CarouselView({
				'el': '#chosen-persona-videos',
				'pagination': false,
				'visible': 5
			});

			$('#persona-carousel').width($('#persona-carousel').find('.carousel-list').width());
		},

		'handleVideoSectionToggle': function (e) {
			var $this = $(e.currentTarget);

			e.preventDefault();

			$this.toggleClass('open');
			$('.persona-video-wrapper').slideToggle();
		},

		'renderProgress': function (data) {
			log(data)
			var seriesArray = [],
				colors = ['#E0E1E5', '#0CB1CA', '#52DDF1'];
			_.each(data.Steps, function (obj) {
				var color = '#E0E1E5';
				if (obj.Complete == true) {
					color = '#0CB1CA'
				}
				var progressItem = {
					name: obj.Copy,
					y: 10,
					color: color,
					url: obj.Url
				};
				seriesArray.push(progressItem)
			});

			$('#progress-chart').highcharts({
				chart: {
					backgroundColor:'rgba(255, 255, 255, 0.1)',
					height: 260
				},
				title: {
					text: null
				},
				credits: {
					enabled: false
				},
				legend: {
					enabled: false
				},
				tooltip: {
					borderWidth: 0,
					backgroundColor: "rgba(255,255,255,0)",
					shadow: false,
					useHTML: true,
					positioner: function () {
						return {
							x: 0,
							y: 195
						};
					},
					formatter: function () {
						var s = '<b>' + this.point.name + '</b>';
							
						return '<div class="chart-tooltip">' + s + '</div>';
					}
				},
				plotOptions: {
					series: {
						states: {
							hover: {
								color: '#52DDF1'
							}
						},
						point: {
							events: {
								click: function () {
									
								}
							}
						}
					},
					pie: {
						size: 155,
						height: 200,
						center: [69, 69],
						innerSize: '80%',
						allowPointSelect: false,
						cursor: 'pointer',
						dataLabels: {
							enabled: false
						}
					}
				},
				series: [{
						type: 'pie',
						name: 'site progress',
						states: {
							hover: {
								enabled: true,
								marker: {
									fillColor: '#52DDF1'
								}
							}
						},
						data: seriesArray
					}
				]
			});
		}
	});

});
