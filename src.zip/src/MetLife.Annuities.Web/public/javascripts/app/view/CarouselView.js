/**
 * @module view/CarouselView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .carousel-nav': 'handleCarouselNav',
			'click .numerical-nav': 'handleCarouselNav',
			'click .view-carousel': 'handleViewCarousel',
			'click .close': 'toggleControls'
		},
		'defaults': {
			'visible': 1,
			'pagination': true
		},

		'initialize': function (options) {

			var view = this;
			_.bindAll(this);

			view.options.defaults = $.extend({}, view.defaults, options);

			view.$carouselItem = view.$el.find('.carousel-item');
			view.$carousel = view.$el.find('.carousel-list');
			view.itemWidth = view.$carouselItem.outerWidth(true);
			view.length = view.$carouselItem.length;
			view.currentPage = 1;
			view.lastPage = view.length - view.options.defaults.visible;
			view.isAnimating = false;
			view.carouselInteraction = false;

			log('Backbone : View : Shared : CarouselView : Initialized');
			this.render();
		},

		'render': function () {

			var view = this;

			if (view.$el.find('.controls-wrapper').length === 0 && view.length > view.options.defaults.visible) {
				view.createCarouselNav();
			};
			view.setCarouselWidth();
			
			view.$el.find('.carousel-item').swipe({
				swipeLeft: function(e) {
					view.$el.find('.carousel-next').trigger('click');
				},
				swipeRight: function(e) {
					view.$el.find('.carousel-prev').trigger('click');
				},
				threshold: 75
			});
			
			if(view.attributes && view.attributes.autoPlay) view.handleAutoPlay();
		},

		'createCarouselNav': function () {

			var view = this,
				count = 0,
				$navControls = $(_.template(App.templates.CarouselThumbNavTemplate, {})),
				$navItem = "";

			view.$el.append($navControls);
			if (view.options.defaults.pagination === true) {
				view.$el.find('.carousel-prev').after('<ul class="controls" />')
				view.$el.find('.carousel-item').each(function () {
					count += 1;
					$navItem = $(_.template(App.templates.CarouselNavItemTemplate, {
						'count': count
					}));

					view.$el.find('.controls').append($navItem);

				});
			}

			if (view.$el.find('.selected').length === 0) {
				view.addSelectedStateToNav()
			}
		},

		'setCarouselWidth': function () {

			var view = this,
				listLength = view.$carouselItem.length,
				carouselWidth = view.itemWidth * listLength;

			view.$carousel.css('width', carouselWidth);
		},
		
		'handleCarouselNav': function (e) {
			this.carouselInteraction = true;
			this.setPageNumberToScroll(e);
		},

		'setPageNumberToScroll': function (e) {

			e.preventDefault();

			var view = this,
				$this = $(e.currentTarget),
				position = parseInt($this.attr('data-position')),
				leftPosition = view.$carousel.position().left,
				scrollDistance, pagesToScroll, newPosition;

			if (!view.isAnimating) {
				if ($this.hasClass('carousel-prev')) {
					if(view.currentPage === 1) position = view.lastPage + 1
					else {
						pagesToScroll = -1;
						view.currentPage -= 1;
					}
				}
				if ($this.hasClass('carousel-next')) {
					if(view.currentPage <= view.lastPage) {
						pagesToScroll = 1;
						view.currentPage += 1;
					} else position = 1;
				}
				if (position) {
					pagesToScroll = position - view.currentPage;
					view.currentPage = position;
				}
				if (pagesToScroll) {
					scrollDistance = pagesToScroll * view.itemWidth;

					newPosition = leftPosition - scrollDistance;
					view.animateCarousel(newPosition);
					if (view.options.defaults.pagination === true) {
						view.addSelectedStateToNav();
					}
				}
			}
		},
		
		'handleAutoPlay': function() {
			var view = this;
			setTimeout(function(){
				if(view.carouselInteraction === false) {
					var pagesToScroll, scrollDistance, newPosition,
						leftPosition = view.$carousel.position().left;
					if(view.currentPage <= view.lastPage) {
						pagesToScroll = 1;
						view.currentPage += 1;
					} else {
						pagesToScroll = 1 - view.currentPage;
						view.currentPage = 1;
					}
					scrollDistance = pagesToScroll * view.itemWidth;
					newPosition = leftPosition - scrollDistance;
					view.animateCarousel(newPosition);
					if (view.options.defaults.pagination === true) {
						view.addSelectedStateToNav();
					}
					view.handleAutoPlay();
				}
			}, view.attributes.autoPlay);
		},
		
		'animateCarousel': function (newPosition) {

			var view = this;

			if (!view.isAnimating) {
				view.isAnimating = true;
				view.$carousel.animate({
					'left': (newPosition)
				}, 600, function () {
					view.isAnimating = false;
				});
			}

		},
		'addSelectedStateToNav': function () {

			var view = this;

			view.$el.find('.selected').removeClass('selected');
			view.$el.find('#nav-position-' + view.currentPage).addClass('selected');
		},
		'handleViewCarousel': function (e) {

			var view = this,
				$this = $(e.currentTarget);

			if ($this.attr('data-position') === '1') {
				view.animateCarousel(0);
				view.currentPage = 1;
				view.addSelectedStateToNav();
			} else {
				view.currentPage = 1;
				view.setPageNumberToScroll(e);
			}

			view.toggleControls();
		},
		'toggleControls': function () {

			var view = this;

			view.$el.find('.controls-wrapper').toggle(350);
		}
	});

});
