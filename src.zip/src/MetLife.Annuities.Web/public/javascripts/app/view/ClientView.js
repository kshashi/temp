/**
 * @module view/ClientView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .page-nav': 'handlePaginationClick',
			'submit': 'handleFormSubmit'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$clientContainer = $('#client-template-container');
			this.clientFeedTemplate = App.templates.ClientTemplate;
			this.$clientTemplate;
			this.feedUrl = '/advisors/clients';
			this.loc = document.location.href.toLowerCase();
			this.advisorId = $('#advisor-id').val();
			this.currentPage = 1;
			this.search = '';
			this.sort = 'last_name';
			this.$noData = $('.no-data');
			this.$loading = $('.spinner');
			this.$paginator = $('.controls-wrapper');
			this.$filterSearchInput = $('.filter-search');
			App.on('sort-clients:customSelect:change', this.handleSortChange);
			this.render();

			log('Backbone : View : ClientView : Initialized');

		},

		'render': function () {
			this.getFeed();
			var view = this;
			var clientFormView = new App.views.FormView({
				'el': '#filter-clients'
			});
			this.tooltipView = new App.views.TooltipView({
				'el': '#section-content',
				'attributes': {
					'bindEvents': function(){
						var $tooltip = view.tooltipView.$tooltipContainer;
						$tooltip.find('a').on('click', function(e){
							e.preventDefault();
							view.tooltipView.$tooltipContainer.addClass('hidden').removeClass('active');
							view.markFlagAsSeen($(this).attr('data-client'), $(this).attr('href'), $(this).attr('target'));
						});
					},
					'handleStickyClose': view.markFlagAsSeen
				}
			});
		},

		'handleFormSubmit': function (e) {
			e.preventDefault();
			var searchVal = this.$filterSearchInput.val();

			this.getFeed({
				'page': 1,
				'filter': searchVal
			});

		},

		'handleSortChange': function (value) {
			var sort = value;
			this.getFeed({
				'page': 1,
				'sort': sort
			});
		},

		'handlePaginationClick': function (e) {
			e.preventDefault();
			$('html, body').animate({
				scrollTop: 0
			}, 0);
			var $target = $(e.currentTarget),
				page = $target.data('position');
			this.getFeed({
				'page': page
			});
		},

		'getFeed': function (args) {
			var view = this;

			args = args || {};
			args.advisor_id = view.advisorId;
			args.filter = args.filter || view.filter;
			args.sort = args.sort || view.sort;
			view.sort = args.sort;
			args.page = args.page || view.currentPage;
			view.currentPage = args.page;
			if (view.loc.match(/dashboard/)) {
				args.sort = "recent";
				view.sort = args.sort;
			}
			view.$clientContainer.empty();
			view.$noData.hide();
			view.$loading.show();

			$.ajax({
				type: "POST",
				url: view.feedUrl,
				data: args,
				success: function (data) {
					view.$loading.hide();
					if (data.items.length == 0) {
						view.$paginator.hide();
						view.$noData.html("There were no clients found.").show();
					} else {
						view.$clientTemplate = $(_.template(view.clientFeedTemplate, data));
						view.$clientContainer.html(view.$clientTemplate);
					}
				},
				error: function (data) {

				}
			});
		},
		
		'markFlagAsSeen': function(clientId, navUrl, target) {
			var view = this;
			$.ajax({
				type: "POST",
				url: '/advisors/alerts/mark?client_id=' + clientId,
				data: {},
				complete: function (data) {
					$('.tooltip-sticky[data-sticky-id="' + clientId + '"]').remove();
					if(navUrl && target == '_blank') window.open(navUrl);
					else if (navUrl) window.location.href = navUrl;
				}
			});
		}

	});

});
