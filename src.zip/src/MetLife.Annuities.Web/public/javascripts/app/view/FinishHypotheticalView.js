/**
 * @module view/FinishHypotheticalView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'keyup input': 'updateTotals',
			'keyup #hypo-name': 'updateCharCount',
			'click .form-save': 'handleFormSubmit',
			'click .define-link': 'setModal'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$body = $(document.body);
			this.$allocationInput = $('.allocation-form').find('input[type=text]');
			this.$allocationTotalEl = $('.allocation-percent');
			this.$section1TotalEl = $('.section-1 .percent');
			this.$section2TotalEl = $('.section-2 .percent');
			this.$section3TotalEl = $('.section-3 .percent');
			this.$allocationError = $('.allocation-error');
			this.$submitButton = $('.form-save');
			this.$hypotheticalName = $('#hypo-name');
			this.$countdown = $('.countdown');
			this.render();

			log('Backbone : Global : FinishHypotheticalView : Initialized');
		},

		'render': function () {

			var toolTipView = new App.views.TooltipView({
				'el': '#section-content'
			});
			var allocationFormView = new App.views.FormView({
				'el': '#section-allocations'
			});
			this.updateTotals();
			this.updateCharCount();
		},

		'updateTotals': function () {
			var allocationsTotal = 0,
				section1Total = 0,
				section2Total = 0,
				section3Total = 0;
			this.$allocationInput.each(function () {
				var $this = $(this),
					fieldVal = $this.val();
				if (fieldVal == "") {
					fieldVal = 0;
				}
				var totalInt = parseInt(fieldVal);

				allocationsTotal += totalInt;
				if ($this.parents('.section-1').length) {
					section1Total += totalInt;
				}
				if ($this.parents('.section-2').length) {
					section2Total += totalInt;
				}
				if ($this.parents('.section-3').length) {
					section3Total += totalInt;
				}
			});
			if (allocationsTotal != 100) {
				this.$allocationTotalEl.removeClass('done');
				this.$allocationError.show();
			} else {
				this.$allocationTotalEl.addClass('done');
				this.$allocationError.hide();
			}
			this.$allocationTotalEl.html(allocationsTotal);
			this.$section1TotalEl.html(section1Total);
			this.$section2TotalEl.html(section2Total);
			this.$section3TotalEl.html(section3Total);
		},

		'updateCharCount': function () {
			var remaining = this.$hypotheticalName.data('max-chars') - this.$hypotheticalName.val().length;
			this.$countdown.text(remaining + ' characters remaining.');
		},

		'handleFormSubmit': function (e) {
			if (this.$allocationError.is(':visible')) {
				e.preventDefault();
				$('html, body').animate({
					'scrollTop': this.$allocationError.offset().top - 100 + 'px'
				});
			}

		},
		'setModal': function () {

			var allocationModal;

			allocationModal = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'AllocationsModalTemplate'
			});
		}
	});

});
