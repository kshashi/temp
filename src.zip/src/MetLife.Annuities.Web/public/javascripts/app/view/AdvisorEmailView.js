/**
 * @module view/AdvisorEmailView
 */

define(function (require) {

    'use strict';

    var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global')

    return Backbone.View.extend({

        'events': {
            'click #email-template-nav li a': 'changeTemplate',
            'change #saved-annuities input[name=saved-annuity]': 'changeAnnuity',
            'click #send-email-btn': 'sendEmail'
        },

        'initialize': function (options) {
            var view = this;
            this.clientId = $('#email-template-nav').attr('data-client-id');
            this.qs = this.getQueryStringVars();
            this.qs.template = (this.qs.template) ? this.qs.template : 'reengage';
            if (this.qs.hypothetical_id) $('#saved-annuities input[name="saved-annuity"][value="' + this.qs.hypothetical_id + '"]').trigger('click');
            _.bindAll(this);
            this.render();
            log('Backbone : View : AdvisorEmailView : Initialized');
        },

        'render': function () {
            this.updateIFrame($('#email-template-nav li[data-template="' + this.qs.template + '"]'));
            if (this.qs.hypothetical_id && this.qs.type == 'sls') {
                $('#back-btn span').html('Back To Summary');
                $('#back-btn').css('width', '155px').attr('href', '/clients/sls/summary?id=' + this.qs.hypothetical_id);
            } else if (this.qs.hypothetical_id && this.qs.type == 'va') {
                $('#back-btn span').html('Back To Summary');
                $('#back-btn').css('width', '155px').attr('href', '/clients/seriesva/summary?id=' + this.qs.hypothetical_id);
            }
            $('#back-btn').css('display', 'block');
            var view = this,
					months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            view.$el.find('.created-date').each(function () {
                var dt = new Date(parseInt($(this).attr('data-timestamp')));
                var hours = dt.getHours();
                var minutes = dt.getMinutes();
                var ampm = (hours < 12) ? 'AM' : 'PM';
                hours = (hours == 0) ? 12 : (hours > 12) ? hours - 12 : hours;
                minutes = (minutes < 10) ? '0' + minutes : minutes;
                $(this).html(months[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear() + ' ' + hours + ':' + minutes + ' ' + ampm);
            });
        },

        'changeAnnuity': function (e) {
            this.updateIFrame($('#email-template-nav .current'));
        },

        'changeTemplate': function (e) {
            e.preventDefault();
            var btn = $(e.currentTarget).parent();
            if (!btn.hasClass('current')) this.updateIFrame($(e.currentTarget).parent());
        },

        'updateIFrame': function (btn) {
            $('#email-template-nav .current').removeClass('current').addClass('not_visited');
            btn.removeClass('not_visited').addClass('current');
            var template = btn.attr('data-template');
            if (template == 'charts') {
                $('#saved-annuities').css('display', 'block');
                var hypoId = $('#saved-annuities input[name="saved-annuity"]:checked').val();
                var radioBtn = $('#saved-annuities input[name="saved-annuity"][value="' + hypoId + '"]');
                var url = '/advisors/email/charts_' + radioBtn.attr('data-type') + '?client_id=' + this.clientId + '&hypothetical_id=' + hypoId;
                $('#email-template-iframe').attr('src', '/advisors/email/charts_' + radioBtn.attr('data-type') + '?client_id=' + this.clientId + '&hypothetical_id=' + hypoId);
            } else {
                $('#saved-annuities').css('display', 'none');
                $('#email-template-iframe').attr('src', ' /advisors/email/' + template + '?client_id=' + this.clientId);
            }
        },

        'sendEmail': function (e) {
            e.preventDefault();
            $.ajax({
                type: "POST",
                url: $('#email-template-iframe').attr('src'),
                data: { fake: Math.random() },
                async: false,								
                complete: function (data, status) {                    
                    if (data.status == '520')
                        window.location.href = '/public/pages/dnss.html';
                    else
                        window.location.href = $('#back-btn').attr('href');

                }
            });
        },

        'getQueryStringVars': function () {
            var vars = {}, hash;
            var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
            for (var i = 0; i < hashes.length; i++) {
                hash = hashes[i].split('=');
                vars[hash[0]] = hash[1];
            }
            return vars;
        }

    });

});
