/**
 * @module view/AddClientCommonView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .form-cancel': 'cancelForm'
		},

		'initialize': function (options) {

			_.bindAll(this);

			log('Backbone : View : AddClientCommonView : Initialized');
		},

		'render': function () {},

		'cancelForm': function () {
			window.location.href = $('#back-button').attr('href');
		}

	});

});
