/**
 * @module view/ResourcesNavView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #glossary-nav a': 'handleLetterClick',
			'click #show-all': 'resetGlossary'
		},

		'initialize': function () {
			var view = this;
			_.bindAll(this);
			view.$glossaryNav = $('#glossary-nav-wrapper');
			view.$glossaryWrapper = $('#glossary-wrapper');
			view.$glossaryNavOffset = view.$glossaryNav.offset();

			this.render();

			log('Backbone : GlossaryView : Initialized');
		},

		'render': function () {
			var view = this;

			view.stickyGlossaryNav(view.$glossaryNav, view.$glossaryNavOffset);

			view.disableClickNoResults();
		},

		'stickyGlossaryNav': function ($elm, dropdownOffset) {
			var view = this;
			$(window).scroll(function () {
				var scrollTop = $(window).scrollTop();
				if (scrollTop > 430) {
					$elm.addClass('fixed');
					view.$glossaryWrapper.addClass('sticky');
				} else {
					$elm.removeClass('fixed');
					view.$glossaryWrapper.removeClass('sticky');
				}
			});
		},

		'handleLetterClick': function (e) {
			var view = this,
				$target = $(e.currentTarget),
				letter = $target.text();

			e.preventDefault();

			if (!($target.hasClass('selected'))) {
				view.$el.find('.selected').removeClass('selected');
				$target.addClass('selected');
				view.hideShowSelection(letter);
			}


		},
		'disableClickNoResults': function () {
			var view = this;

			view.$el.find('.no-items').click(false);

		},
		'hideShowSelection': function (letter) {

			var view = this,
				$letter = $('#glossary-' + letter),
				$shownLetter = view.$el.find('.shown-letter');

			if (view.$el.find('.active-letter').length === 0) {
				view.$el.find('#glossary-wrapper').addClass('active-letter')
				view.$el.find('.glossary-letter').fadeOut();
			}
			if ($shownLetter.length > 0) {
				$shownLetter.removeClass('shown-letter').fadeOut(function () {
					$letter.addClass('shown-letter').fadeIn();
				});
			} else {
				$letter.addClass('shown-letter').fadeIn();
			}

			view.$el.find('#show-all').addClass('active');

		},
		'resetGlossary': function (e) {
			
			e.preventDefault();
			
			var view = this;

			view.$el.find('.shown-letter').removeClass('shown-letter;');
			view.$el.find('.active-letter').removeClass('active-letter');
			view.$el.find('.selected').removeClass('selected');
			view.$el.find('.glossary-letter').show();
			$(e.currentTarget).removeClass('active');

		}

	});

});
