/**
 * @module view/HelpNavView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #help-nav a': 'handleNavItemClick',
			'click #section-help-tutorials .play-button': 'handlePlayTutorial'
		},

		'initialize': function (options) {

			_.bindAll(this);

			var view = this;

			this.$sections = $('.section');
			this.$sectionHelpContent = $('#section-help-content');

			App.bind('help:navigate', this.handleHelpDeepLink);

			App.on('help:tutorialVid', function (id) {
				view.handleTutorialVideo(id);
			})

			this.render();

			log('Backbone : HelpNavView : Initialized');
		},

		'render': function () {
			this.$sections.not('.active').addClass('hidden');
		},

		'handleNavItemClick': function (e) {
			var $target = $(e.currentTarget),
				section = $target.data('section'),
				$section = this.$sectionHelpContent.find('#section-help-' + section);

			App.trigger('helpSection:' + section);

			if ($section.hasClass('active')) {
				return;
			}

			this.showActiveSection($section);
		},

		'handleHelpDeepLink': function (section) {
			var view = this,
				$section = this.$sectionHelpContent.find('#section-help-' + section);

			view.addSelectedState(section);

			this.showActiveSection($section);
		},

		'showActiveSection': function ($section) {
			this.$sections.addClass('hidden').removeClass('active');

			$section.addClass('active').delay().queue(function () {
				$(this).removeClass('hidden').dequeue();
			});
		},

		'addSelectedState': function (section) {
			var view = this;

			view.$el.find('#help-nav').find('.selected').removeClass('selected');
			view.$el.find('.' + section).addClass('selected');
		},
		'handleTutorialVideo': function (id) {

			var view = this;

			view.$el.find('#section-help-tutorials').find('#' + id).trigger('click');


		},
		'handlePlayTutorial': function (e) {

			e.preventDefault();

			var view = this,
				modalView;

			modalView = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'VideoModalTemplate'
			});

		}

	});

});
