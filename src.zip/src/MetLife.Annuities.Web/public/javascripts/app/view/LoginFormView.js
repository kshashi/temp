/**
 * @module view/LoginFormView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'blur .required': 'handleBlurValidate',
			'blur .min-char': 'handleBlurValidate',
			'keyup input': 'handleKeyUpInput',
			'keyup textarea': 'handleKeyUpInput',
			'submit': 'handleFormSubmit'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.characterClasses = {
				'comment': /[^\w\s\d\-\.\',]/g,
				'currency': /[^\d\.,]/g,
				'email': /[^\w\d\-_.@]/g,
				'text-strict': /[^A-Za-z\s\']/g,
				'text-hyphenated': /[^A-Za-z\s\-\.\']/g,
				'alpha-numeric': /[^\w\s\d\-\.\']/g,
				'number': /[^\d]/g,
				'password': ''
			};

			this.render();

			log('Backbone : View : LoginFormView : Initialized');
		},

		'render': function () {

			var view = this;

			this.$inputs = this.$('input, textarea');
			this.messageTemplate = _.template(App.templates.MessageTemplate);

			this.setRequiredFields();

			App.on('customSelect:change', this.handleChangeCustomSelect);
		},

		'handleBlurValidate': function (e) {
			var $target = $(e.currentTarget),
				valid = true;

			if ($target.hasClass('min-char') && $target.val().length > 0 && valid) {
				valid = this.isMinChar($target);
				this.createErrorMessage($target, 'min-char');
			}

			if ($target.hasClass('required') && valid) {
				valid = !this.isEmpty($target);
				this.createErrorMessage($target, 'required');
			}

			if ($target.hasClass('valid-email') && valid) {
				valid = /^\S+@\S+\.\S+$/.test($target.val());
			}

			if ($target.hasClass('confirm-password') && valid) {
				valid = $target.val() === $('#' + $target.data('confirm-password')).val();
				this.createErrorMessage($target, 'confirm-password');
			}

			if (!valid) {
				this.addError($target);
			} else {
				this.removeError($target);
			}

		},

		'handleChangeCustomSelect': function (value, label, id) {

			// make sure custom select is part of view.
			var $select = this.$('#' + id);

			if ($('.used-'+id).length) {
				$('.used-'+id).removeClass('used-question used-'+id);
			}

			if ($select.length) {
				if (this.isEmpty($select)) {
					this.addError($select);
				} else {
					this.removeError($select);
				}
			}

			$('.dk_container').not('#dk_container_'+id).find('.dk_options_inner li:contains('+label+')').addClass('used-question used-'+id);

		},

		'handleKeyUpInput': function (e) {

			var $target = $(e.currentTarget),
				keynum = e.which;
			if ($('#create-password').length) {
				if (keynum == 13) { 
					$('.required, .min-char').blur();
					$('#login-submit').click(); 
				}
			}
			this.sanitizeInput($target);
		},

		'handleFormSubmit': function (e) {
			var view = this;

			this.$inputs.each(function () {
				view.sanitizeInput($(this));
			});

			this.$errors = this.$el.find('.error');

			if (this.$errors.length) {
				e.preventDefault();
				this.$el.addClass('show-errors');
				$('html, body').animate({
					'scrollTop': this.$errors.first().offset().top - 50 + 'px'
				});
			}
		},

		'isEmpty': function ($target) {
			if ($target.val() === '') {
				return true;
			}

			return false;
		},

		'isMinChar': function ($target) {
			if ($target.val().length < $target.data('minChars')) {
				return false;
			}

			return true;
		},

		'createErrorMessage': function ($target, error) {
			var article = $target.data('article') || 'A ',
				errorPhrase = '';

			switch (error) {
				case 'required':
					errorPhrase = $target.data('errorRequired') || 'Required field.';
					break;
				case 'confirm-password':
					errorPhrase = 'Passwords do not match';
					break;
				case 'min-char':
					errorPhrase = $target.data('errorMinChar') || 'Minimum number of characters not met.';
					break;

			}

			$target.data('errorMsg', errorPhrase);
		},

		'addError': function ($target) {
			var $errorContainer = $target.closest('.error-container');

			$target.addClass('error');
			$errorContainer.addClass('show-error-msg');

			if ($target.hasClass('custom-select')) {
				$('#dk_container_' + $target.attr('name')).addClass('dk_error');
			}

			if ($target.data('errorMsg')) {
				var $errorMsg = $(this.messageTemplate({
					'message': $target.data('errorMsg')
				})).addClass('error-msg');

				$errorContainer.find('.message').remove();
				$errorContainer.append($errorMsg);
			}
		},

		'removeError': function ($target) {
			var $errorContainer = $target.closest('.error-container');

			$target.removeClass('error');

			if ($target.hasClass('custom-select')) {
				$('#dk_container_' + $target.attr('name')).removeClass('dk_error');
			}

			if (!$errorContainer.find('.error').length) {
				$errorContainer.removeClass('show-error-msg');
			}
		},

		'sanitizeInput': function ($target) {
			if (_.isUndefined($target)) {
				return;
			}

			var value = $target.val(),
				targetCharacterClass = $target.data('allowedChars'),
				regex;

			if (_.has(this.characterClasses, targetCharacterClass)) {
				regex = this.characterClasses[targetCharacterClass];
				value = value.replace(regex, "");
			} else {
				value = value.replace(/[^\w\d\s]/g, "");
			}

			if ($target.data('maxChars')) {
				var charLimit = $target.data('maxChars');

				value = value.substring(0, charLimit);
			}

			$target.val(value);
		},

		'setRequiredFields': function () {

			var view = this;

			this.$requiredFields = this.$el.find('.required');

			this.$requiredFields.each(function () {
				// Add default error class to required fields to prevent form submission.
				if (view.isEmpty($(this))) {
					view.createErrorMessage($(this), 'required');
					view.addError($(this));
				}
			});
		}

	});

});
