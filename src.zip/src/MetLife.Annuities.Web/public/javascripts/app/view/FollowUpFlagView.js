/**
 * @module view/FollowUpFlagView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #add-flag': 'addFlagClick',
			'click #hide-flags': 'hideFlagsClick'
		},

		'initialize': function (options) {
			this.hypotheticalId = -1;
			this.flagOffsetLeft = 0;
			this.flagOffsetTop = 0;
			this.flags = null;
			this.flagMeta = '';
			_.bindAll(this);
			this.render();
			log('Backbone : View : FollowUpFlagView : Initialized');
		},

		'render': function () {
			this.$addFlagBtn = $('#add-flag');
			this.$hideFlagsBtn = $('#hide-flags');
			this.$activeFlag = null;
			this.$flagArea = $(this.attributes.flagContainer);
			$(document).on('mousemove', this.mousemove);
			$(document).on('mousedown', this.mousedown);
			$(document).on('touchstart', this.touchstart);
		},

		'changeFlagFilter': function (id, meta) {
			this.hypotheticalId = id;
			this.flagMeta = JSON.stringify(meta);
			if (this.flags === null) {
				var view = this;
				$.ajax({
					type: "GET",
					url: '/clients/flags/chart?id=' + id,
					success: function (data) {
						view.flags = {};
						for (var x = 0; x < data.chart_flags.length; x++) {
							var chartFlag = data.chart_flags[x];
							view.flags[JSON.stringify(chartFlag.meta)] = chartFlag.flags;
						}
						view.reloadFlags();
					},
					error: function (data) {
						view.flags = {};
						view.reloadFlags();
					}
				});
			} else this.reloadFlags();

		},

		'hideFlagsClick': function (e) {
			e.preventDefault();
			if (this.$hideFlagsBtn.hasClass('flags-hidden')) this.reloadFlags();
			else this.clearAllFlags();
			this.$hideFlagsBtn.toggleClass('flags-hidden');
		},

		'clearAllFlags': function () {
			$('.flag-icon').remove();
			$('#flag-form').remove();
			this.$activeFlag = null;
			this.$addFlagBtn.removeClass('disabled');
			App.trigger('follow-up-flag:end');
		},

		'reloadFlags': function () {
			this.clearAllFlags();
			if (this.flags[this.flagMeta]) {
				var view = this;
				var areaOffset = this.$flagArea.offset();
				var flags = this.flags[this.flagMeta];
				_.each(flags, function (flag) {
					var $flag = $(_.template(App.templates.FollowUpFlagTemplate, {
						'type': view.attributes.type,
						'created_time': flag.created_time_js
					})).css({
						'top': areaOffset.top + flag.position.y + 'px',
						'left': areaOffset.left + flag.position.x + 'px'
					}).attr('data-id', flag.id).attr('data-topic', flag.selected_option);
					$('body').append($flag);
					$flag.on('click', function () {
						view.flagClick(flag.id);
					});
				});
			}
		},

		'addFlagClick': function (e) {
			e.preventDefault();
			if (this.$addFlagBtn.hasClass('disabled') === false) {
				if (this.$hideFlagsBtn.hasClass('flags-hidden')) this.hideFlagsClick(e);
				this.$addFlagBtn.addClass('disabled');
				this.$activeFlag = $(_.template(App.templates.FollowUpFlagTemplate, {
					'type': this.attributes.type,
					'created_time': new Date().getTime()
				}));
				if (!Modernizr.touch) {
					$('body').append(this.$activeFlag);
					this.positionFlag();
				}
				App.trigger('follow-up-flag:start');
			}
		},

		'positionFlag': function () {
			App.trigger('follow-up-flag:move');
			this.$activeFlag.css({
				'top': this.flagOffsetTop + 'px',
				'left': this.flagOffsetLeft + 'px'
			});
		},

		'flagClick': function (id) {
			if ($('#flag-form').length === 0 && this.$addFlagBtn.hasClass('disabled') === false) {
				this.$addFlagBtn.addClass('disabled');
				this.openFlagForm(id);
				App.trigger('follow-up-flag:start');
			}
		},

		'openFlagForm': function (id) {
			var $flag = $('.flag-icon[data-id="' + id + '"]');
			var offset = $flag.offset();
			var topic = $flag.attr('data-topic');
			var $flagForm = $(_.template(App.templates.FollowUpFlagFormTemplate, {
				'id': id,
				'type': this.attributes.type,
				'created_time': this.formatCreatedTime(parseInt($flag.attr('data-created')))
			})).css({
				'top': offset.top + 'px',
				'left': (offset.left + 30) + 'px'
			});
			$flagForm.find('#flag-topic option[value="' + topic + '"]').attr('selected', 'selected');
			$('body').append($flagForm);
			this.bindFlagFormEvents();
		},

		'bindFlagFormEvents': function () {
			var view = this;
			$('#close-flag').on('click', function (e) {
				e.preventDefault();
				$('#flag-form').remove();
				view.$addFlagBtn.removeClass('disabled');
				App.trigger('follow-up-flag:end');
			});
			$('#move-flag').on('click', function (e) {
				e.preventDefault();
				var id = $('#flag-form').attr('data-id');
				$('#flag-form').remove();
				view.$activeFlag = $('.flag-icon[data-id="' + id + '"]');
				if (Modernizr.touch) view.$activeFlag.remove();
				else view.positionFlag();
			});
			$('#delete-flag').on('click', function (e) {
				e.preventDefault();
				var id = $('#flag-form').attr('data-id');
				view.deleteFlag(id);
			});
			$('#flag-topic').dropkick({
				'startSpeed': 0,
				'change': function (value, label) {
					var id = $('#flag-form').attr('data-id');
					var topic = $('#flag-topic').val();
					var $flag = $('.flag-icon[data-id="' + id + '"]');
					$flag.attr('data-topic', topic);
					view.saveFlag($flag, function (id) {});
				}
			});
		},

		'getFlagJson': function ($flag, x, y) {
			return JSON.stringify({
				'hypothetical_id': parseInt(this.hypotheticalId),
				'hypothetical_type': this.attributes.type,
				'chart_flags': [{
						'meta': JSON.parse(this.flagMeta),
						'flags': [{
								'id': parseInt($flag.attr('data-id')),
								'created_time': parseInt($flag.attr('data-created')),
								'selected_option': $flag.attr('data-topic'),
								'position': {
									'x': Math.round(x),
									'y': Math.round(y)
								}
							}
						]
					}
				]
			});
		},

		'saveFlag': function ($flag, callback) {
			var view = this;
			var id = $flag.attr('data-id');
			var areaOffset = view.$flagArea.offset();
			var flagOffset = $flag.offset();
			var flagX = flagOffset.left - areaOffset.left;
			var flagY = flagOffset.top - areaOffset.top;
			if (id == "-1") {
				$.ajax({
					type: "POST",
					url: '/clients/flags/chart',
					data: {
						'action': 'insert',
						'data': view.getFlagJson($flag, flagX, flagY)
					},
					success: function (data) {
						if (data.success === true) {
							id = data.id;
							$flag.attr('data-id', id);
							if (!Modernizr.touch) $flag.on('click', function () {
									view.flagClick(id);
								});
							view.insertFlag($flag, flagX, flagY);
							callback(id);
						} else {
							alert('error saving follow up flag'); // replace with modal?
							callback(false);
						}
					},
					error: function (data) {
						alert('error saving follow up flag'); // replace with modal?
						callback(false);
					}
				});
			} else {
				$.ajax({
					type: "POST",
					url: '/clients/flags/chart',
					data: {
						'action': 'update',
						'data': view.getFlagJson($flag, flagX, flagY)
					},
					success: function (data) {
						if (data.success === true) {
							view.updateFlag($flag, flagX, flagY);
							callback(id);
						} else alert('error saving follow up flag'); // replace with modal?
					},
					error: function (data) {
						alert('error saving follow up flag'); // replace with modal?
					}
				});
			}
		},

		'deleteFlag': function (id) {
			var view = this;
			$.ajax({
				type: "POST",
				url: '/clients/flags/chart',
				data: {
					'action': 'delete',
					'data': id
				},
				success: function (data) {
					if (data.success === true) {
						$('#flag-form').remove();
						$('.flag-icon[data-id="' + id + '"]').remove();
						view.$addFlagBtn.removeClass('disabled');
						App.trigger('follow-up-flag:end');
						var index = -1;
						var flags = view.flags[view.flagMeta];
						for (var x = 0; x < flags.length; x++) {
							var flag = flags[x];
							if (flag.id == id) {
								index = x;
								break;
							}
						}
						if (index > -1) flags.splice(index, 1);
					} else alert('error deleting follow up flag'); // replace with modal?
				},
				error: function (data) {
					alert('error deleting follow up flag'); // replace with modal?
				}
			});
		},

		'insertFlag': function ($flag, x, y) {
			if (!this.flags[this.flagMeta]) this.flags[this.flagMeta] = [];
			var flags = this.flags[this.flagMeta];
			flags.push({
				'id': $flag.attr('data-id'),
				'data-created': $flag.attr('data-created'),
				'selected_option': $flag.attr('data-topic'),
				'position': {
					'x': x,
					'y': y
				}
			});
		},

		'updateFlag': function ($flag, x, y) {
			_.each(this.flags[this.flagMeta], function (flag) {
				if (flag.id == $flag.attr('data-id')) {
					flag.selected_option = $flag.attr('data-topic');
					flag.position.x = x;
					flag.position.y = y;
				}
			});
		},

		'mousemove': function (e) {
			this.flagOffsetLeft = e.pageX - 10;
			this.flagOffsetTop = e.pageY - 30;
			if (this.$activeFlag !== null) this.positionFlag();
		},

		'mousedown': function (e) {
			if (this.$activeFlag !== null) {
				var areaOffset = this.$flagArea.offset();
				var areaRight = areaOffset.left + this.$flagArea.width();
				var areaBottom = areaOffset.top + this.$flagArea.height();
				if (this.flagOffsetLeft >= areaOffset.left && this.flagOffsetLeft <= areaRight && this.flagOffsetTop >= areaOffset.top && this.flagOffsetTop <= areaBottom) {
					var view = this;
					var $currentFlag = this.$activeFlag;
					this.saveFlag(this.$activeFlag, function (id) {
						if(id !== false) view.openFlagForm(id);
						else {
							$currentFlag.remove();
							view.$addFlagBtn.removeClass('disabled');
							App.trigger('follow-up-flag:end');
						}
					});
					this.$activeFlag = null;
				} else {
					this.$activeFlag.remove();
					this.$activeFlag = null;
					this.$addFlagBtn.removeClass('disabled');
					App.trigger('follow-up-flag:end');
				}
			}
		},

		'touchstart': function (e) {
			if (this.$activeFlag !== null) {
				this.flagOffsetLeft = e.originalEvent.touches[0].pageX - 10;
				this.flagOffsetTop = e.originalEvent.touches[0].pageY - 30;
				$('body').append(this.$activeFlag);
				var view = this;
				this.$activeFlag.on('click', function () {
					view.flagClick($(this).attr('data-id'));
				});
				this.positionFlag();
				this.mousedown(e);
			}
		},

		'formatCreatedTime': function (time) {
			var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
			var dt = new Date(time);
			var hour = dt.getHours();
			var amPm = (hour >= 12) ? 'pm' : 'am';
			if (hour > 12) hour = hour - 12;
			return months[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear() + ' ' + hour + ':' + dt.getMinutes() + amPm;
		}

	});

});
