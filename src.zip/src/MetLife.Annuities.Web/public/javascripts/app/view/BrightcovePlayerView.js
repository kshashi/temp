/**
 * @module view/BrightcovePlayerView
 */
define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');
	require('videojs');
	

	return Backbone.View.extend({

		'events': {
			'click #volume': 'setVolume',
			'click #mute': 'toggleMute',
			'click #play': 'togglePlay',
			'click .progress': 'seek'
		},

		'defaults': {
			'height': '535',
			'width': '960',
			'volume': 40
		},

		'initialize': function (options) {

			var view = this;

			view.o = $.extend(view.defaults, options);
			view.template = _.template(App.templates.BrightcovePlayerTemplate);

			_.bindAll(this);

			this.options = options;
			App.on('reset:videos', view.handleResetVideo);
			view.getVideo();

			log('Backbone : Global : BrightcovePlayerView : Initialized : ID=' + view.o.videoId);
		},

		'getVideo': function (data) {
			var view = this;

			window.onBrightcoveAPIResponse = function (data) {
				view.o.videoUrl = data.FLVURL;
				view.render();
			};

			var getVideoData = $.ajax({
				'url': 'https://api.brightcove.com/services/library?command=find_video_by_id&video_id=' + view.o.videoId + '&video_fields=id%2Cname%2CshortDescription%2ClongDescription%2Clength%2CFLVURL&media_delivery=http&callback=onBrightcoveAPIResponse&token=FldXIe7WiK0cujO3gVvJx--tnnwIgjJhzRni4GU7LNGQFaKfC0-ZnQ..',
				'dataType': 'jsonp'
			});
		},

		'render': function (autoPlay) {

			var view = this;

			view.players = [];
			view.players.push(view.o.videoId);
			
			view.autoPlay = (_.isUndefined(autoPlay)) ? view.autoPlay : autoPlay;
			view.hasPlayed = false;
			view.isPlaying = false;
			view.isEnded = false;
			view.isReady = false;
			view.isMuted = false;
			view.video = {};
			view.videoDuration = 0;
			view.playlistDuration = 0;
			view.percentLoaded = 0;
			view.secondsPlayed = 0;
			view.lastBuffered = 0;
			view.prevSecondsPlayed = 0;
			view.playProgress = 0;
			view.videoIndex = 0;
			view.loadVideoIndex = 0;
			view.totalComplete = 0;

			

			view.tooltipView = new App.views.TooltipView({
				'el': '#section-content'
			});

			view.$playlistSegments = view.$('.playlist-segment');
			view.$buffers = view.$('.buffer');
			view.$elapsedTimes = view.$('.elapsed');

			view.$videoPlayersContainer = $('.video-players-container');
			view.$play = view.$('#play');
			view.$volume = view.$('#volume');
			view.$volumeLevel = view.$volume.find('#level');
			view.$controls = view.$('#controls');
			view.$segmentTooltipContainer = view.$('#segment-tooltip-container');
			view.$counter = view.$('#counter');
			view.$duration = view.$('#duration');

			view.bindAppEventHandlers();
			view.loadVideoPlayer();
			view.showVideo();

			
			
		},

		'showVideo': function (video) {
			var view = this,
				$videoPlayers = view.$('.video-player');

			video = video || view.videoIndex;

			$videoPlayers.removeClass('active');

			$videoPlayers.eq(view.videoIndex).addClass('active');

		},

		'loadVideoPlayer': function () {
			var view = this,
				$prevId = $('.video-js').attr('id');
			log($prevId)
			if ($prevId) {
				_V_($prevId).destroy();
				log('done')
			}


			view.$el.html(view.template({
				'id': view.o.videoId,
				'videoID': view.o.videoId,
				'height': view.o.height,
				'width': view.o.width,
				'autoPlay': view.autoPlay,
				'videoUrl': view.o.videoUrl
			}));

			var playerIndex = view.loadVideoIndex;
			_V_("video-" + view.o.videoId, {
				'controls': true,
				'techOrder': ["html5", "flash"],
				'autoplay': true
			}, function () {
				
			});

			
		},

		'bindAppEventHandlers': function () {
			var view = this;

			view.on('loaded:video', function () {
				//view.loadNextVideo();
			})
				.on('play:video', function (e) {
				if (!view.isPlaying) {
					view.isPlaying = true;
					view.$el.removeClass('stopped').addClass('playing');
				}

				if (!view.hasPlayed) {
					view.hasPlayed = true;
				}

				log('Brightcove : Player : Playing');
			})
				.on('pause:video', function () {
				view.isPlaying = false;
				view.$el.removeClass('playing');

				log('Brightcove : Player : Paused');
			})
				
		},

		

		'playNextVideo': function () {
			var view = this;

			if (view.videoIndex < view.videos.length - 1) {
				view.videoIndex++;
				view.showVideo();
				if(view.players[view.videoIndex] !== null) view.players[view.videoIndex].play();
			} else if (view.videoIndex === view.videos.length - 1) {
				view.gotoStart();
				log('Brightcove : Playlist : Complete');
			}

			view.updateTotalComplete();
		},

		'updateTotalComplete': function () {
			var view = this,
				totalComplete = 0;

			for (var i = 0; i < view.videoIndex; i++) {
				totalComplete += view.videos[i].length;
			}

			view.totalComplete = totalComplete;
		},

		'gotoStart': function () {
			var view = this;

			App.trigger('playlist:ended');

		},

		'setPlaylistSegmentWidths': function () {
			var view = this

				view.$playlistSegments.css('width', '100%');
			
		},

		'buffer': function (playerIndex) {

			var view = this,
				buffer;

			//	Dynamic buffering not working reliably with html5/flash video
			//	buffer = setInterval(function () {
			//		var bufferedPercent = view.players[playerIndex].bufferedPercent();

			//		if (bufferedPercent < 1) {
			//			view.$buffers.eq(playerIndex).css('width', Math.round(bufferedPercent * 100) + '%');
			//		} else {
			//			view.$buffers.eq(playerIndex).css('width', '100%');
			//			clearInterval(buffer);
			//		}
			//	});

			// Fake buffer all videos on load.
			view.$buffers.eq(playerIndex).css('width', '100%');

			view.updateControls();
			
		},

		'setVolume': function (e) {
			var view = this;
			if (!view.isReady) {
				return;
			}

			var offset = (e.offsetX == undefined) ? (e.clientX - view.$volume.offset().left) : e.offsetX;
			view.o.volume = Math.round(offset / (view.$volume.width() + 7) * 100);
			_.each(view.players, function (player) {
				if(player !== null) player.volume(view.o.volume / 100);
			});
			view.$volumeLevel.css('width', view.o.volume + '%');
		},

		'toggleMute': function () {
			var view = this;
			if (!view.isReady) {
				return;
			}

			if (view.isMuted) {
				_.each(view.players, function (player) {
					if(player !== null) player.volume(view.o.volume / 100);
				});
				view.$volumeLevel.css('width', view.o.volume + '%');
				view.isMuted = false;
			} else {
				_.each(view.players, function (player) {
					if(player !== null) player.volume(0);
				});
				view.$volumeLevel.css('width', '0%');
				view.isMuted = true;
			}
		},

		'stop': function () {
			var view = this;

			if (!view.isReady) {
				return;
			}

			view.players[view.videoIndex].api('pause');
			view.trigger('stop:video');
		},

		'togglePlay': function (e) {
			var view = this;

			if (!view.isReady) {
				return;
			}

			if (view.isPlaying) {
				view.players[view.videoIndex].pause();
			} else {
				view.players[view.videoIndex].play();
			}
		},

		'seek': function (e) {
			var view = this,
				$target = $(e.currentTarget);

			view.videoIndex = view.$playlistSegments.index($target);

			view.updateTotalComplete();

			if (!view.isReady) {
				return;
			}
			var offset = view.normalizeEvent(e);
			var ratio = offset.offsetX / (view.$playlistSegments.eq(view.videoIndex).width() + 7);
			var seek = Math.round((view.videos[view.videoIndex].length / 1000) * ratio);

			view.$elapsedTimes.each(function (index) {

				if (index < view.videoIndex) {
					$(this).css('width', '100%');
				} else if (index === view.videoIndex) {
					$(this).css('width', ratio * 100 + '%');
				} else {
					$(this).css('width', '0');
				}
			});
			_.each(view.players, function (player, index) {
				if(player !== null) {
					if (index === view.videoIndex) {
						player.currentTime(seek);
						if (view.isPlaying) {
							player.play();
						}
					} else {
						player.pause();
						player.currentTime(0);
					}
				}
			});
			view.updateProgress(seek);
			view.showVideo();
		},

		'updateControls': function () {
			var view = this;
			view.$duration.html(view.formatTime(view.playlistDuration / 1000));
		},

		'updateProgress': function (currentPosition) {
			var view = this,
				currentPlaylistElapsed,
				currentVideoPercent;

			currentPlaylistElapsed = currentPosition + (view.totalComplete / 1000);
			currentVideoPercent = (currentPosition * 1000) / view.videos[view.videoIndex].length;

			view.$elapsedTimes.eq(view.videoIndex).css('width', Math.round(currentVideoPercent * 100) + '%');
			view.$counter.html(view.formatTime(Math.ceil(currentPlaylistElapsed)));
		},

		'normalizeEvent': function (event) {
			if (!event.offsetX) {
				event.offsetX = (event.pageX - $(event.target).offset().left);
				event.offsetY = (event.pageY - $(event.target).offset().top);
			}
			return event;
		},

		'formatTime': function (second, hour, minute) {
			if (second > 3600) {
				var ore = Math.floor(second / 3600);
				if (ore < 10) {
					ore = '0' + ore;
				}
				var rest = Math.ceil(second % 3600);
				var format = this.formatTime(rest, ore);
			} else if (second > 60) {
				var minuti = Math.floor(second / 60);
				if (minuti < 10) {
					minuti = '0' + minuti;
				}
				var rest = Math.ceil(second % 60);
				var format = this.formatTime(rest, ore, minuti);
			} else if (second < 60) {
				if (!hour) {
					hour = '00';
				}
				if (!minute) {
					minute = '00';
				}
				if (!second) {
					second = '00';
				} else {
					second = Math.round(second);
					if (second < 10) {
						second = '0' + second;
					}
				}
				var format = minute + ':' + second;
			}
			return format;
		},

		'handleMouseenterPlaylistSegment': function (e) {
			var view = this,
				$target = $(e.currentTarget),
				index = $target.data('index');

			view.$segmentTooltipContainer
				.html(this.segmentTooltipTemplate(view.videos[index]));

			view.showSegmentTooltip($target);
		},

		'handleMouseleavePlaylistSegment': function (e) {
			var view = this;
			view.$segmentTooltipContainer.addClass('hidden').removeClass('active');
		},

		'showSegmentTooltip': function ($target) {
			var view = this,
				$targetOffset = $target.position(),
				targetCenter = $target.outerWidth() / 2,
				tooltipCenter = this.$segmentTooltipContainer.outerWidth() / 2,
				tooltipHeight = this.$segmentTooltipContainer.outerHeight(true),
				tooltipOffsetLeft = -(tooltipCenter) + targetCenter,
				length = $('.length').text().split(':'),
				formattedLength = view.formatLength(length[1]);

			this.$segmentTooltipContainer.css({
				'left': $targetOffset.left,
				'top': $targetOffset.top - tooltipHeight,
				'margin-left': tooltipOffsetLeft
			});

			$('.length').text('Length: ' + formattedLength);
			this.$segmentTooltipContainer.addClass('active').delay(10).queue(function () {
				$(this).removeClass('hidden').dequeue();
			});
		},
		'handleResetVideo': function () {
			var view = this;

			view.videoIndex = 0;
			view.showVideo();
			view.$elapsedTimes.css('width', '0');

			view.$el.find('#play').trigger('click');


		},
		'formatLength': function (length) {

			var seconds = Math.floor((length / 1000) % 60),
				minutes = Math.floor((length / (60 * 1000)) % 60),
				formattedLength = minutes + ":" + seconds;

			return formattedLength;
		}
	});
});
