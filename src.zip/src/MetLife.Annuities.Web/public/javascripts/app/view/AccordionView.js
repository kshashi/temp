/**
 * @module view/AccordionView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click li': 'handleClickItem'
		},

		'initialize': function (options) {

			log('Backbone : Global : AccordionView : Initialized');
		},

		'handleClickItem': function (e) {

			e.preventDefault();

			var $target = $(e.currentTarget);

			if ($target.hasClass('active')) {
				$target.removeClass('active');
			} else {
				$target.addClass('active').siblings().removeClass('active');
			}
		}

	});

});
