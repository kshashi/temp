/**
 * @module view/EnableHypoView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .enable-hypo': 'handleEnableHypoClick'
		},

		'initialize': function (options) {

			_.bindAll(this);
			this.enableHypoTemplate = App.templates.EnableHypotheticalTemplate;
			this.$enableHypoLinkContainer = $('#enable-container');
			this.clientId = this.$enableHypoLinkContainer.data('client-id');
			this.enabledState = this.$enableHypoLinkContainer.data('enabled-state');
			this.$enableHypoLink;

			this.render();

			log('Backbone : EnableHypoView : Initialized');
		},

		'render': function () {

			this.$enableHypoLink = $(_.template(this.enableHypoTemplate, {
				'enabled': this.enabledState
			}));
			this.$enableHypoLinkContainer.html(this.$enableHypoLink);
		},

		'handleEnableHypoClick': function (e) {
			this.handleHypotheticalStatus();
			e.preventDefault();
		},

		'handleHypotheticalStatus': function () {
			var view = this;
			$.ajax({
				type: 'POST',
				url: '/advisors/hypothetical/toggle',
				dataType: 'json',
				data: {
					'state': this.enabledState,
					'clientId': this.clientId
				},
				success: function (data) {
					var state = data.state;
					view.$enableHypoLink = $(_.template(view.enableHypoTemplate, {
						'enabled': state
					}));
					view.$enableHypoLinkContainer.html(view.$enableHypoLink);
					view.enabledState = state;
				},
				error: function (data) {

				}
			});
		}

	});

});
