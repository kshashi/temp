/**
 * @module view/ModalPopUpView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #section-help-tutorials .play-button': 'handleVideoModalClick',
			'click .video-modal': 'handleVideoModalClick',
			'click  .shield-in-action': 'handleModalSelection',
			'click .define-link': 'handleModalSelection',
			'click .form-do-not-agree': 'handleModalSelection',
			'click #feedback-tab': 'handleModalSelection',
			'click .saved-annuity .close': 'handleDeleteSavedAnnuity',
			'click .agree': 'toggleModal',
			'click #mask': 'handleModalToggle',
			'click #modal-close': 'handleModalToggle',
			'click .error-try-again': 'handleUploadAgain',
			'click .do-not-delete-annuity': 'handleDoNotDeleteAnnuity',
			'click .delete-annuity': 'handleDeleteAnnuity',
			'click .decline-modal #modal-close': 'handleDeclined',
			'click .decline-modal .button-close': 'handleDeclined',
			'click .decline-modal .do-not-agree': 'handleDoNotAgree',
			'click .sls-delete-modal .button-close': 'toggleModal',
			'click .sls-delete-modal .no-cancel': 'toggleModal',
			'click .sls-delete-modal .yes-delete': 'handleDeleteSlsOption',
			'click .sls-disclosures-modal .button-close': 'toggleModal',
			'click .sls-disclosures-modal .close': 'toggleModal',
			'click .view-table': 'handleViewTable',
			'click .view-chart': 'handleViewChart'
		},
		'defaults': {
			'template': 'VideoModalTemplate'
		},

		'initialize': function (options) {

			_.bindAll(this);
			$(this.el).undelegate();
			this.delegateEvents();

			this.options.defaults = $.extend({}, this.defaults, options);
			App.on('open:uploadError', this.handleModalSelection);
			this.render();

			log('Backbone : ModalPopUp : Initialized');
		},

		'render': function () {
			var view = this;

			if (view.$el.find('#mask').length === 0) {
				view.addMask();
			}

			$('html, body').animate({
				scrollTop: 200
			}, 0);

		},
		'addMask': function () {

			var view = this;

			view.$el.prepend('<div id="mask"/>');
		},
		'handleDeleteSavedAnnuity': function (e) {

			var view = this;

			view.handleModalSelection(e);
			view.populateDeleteSavedModal(e);
		},
		'handleDeleteAnnuity': function (e) {

			var view = this;

			view.toggleModal();
			App.trigger('delete:annuity');

		},
		'handleDoNotDeleteAnnuity': function (e) {

			var view = this;

			view.toggleModal();
			App.trigger('exit:delete');
		},
		'populateDeleteSavedModal': function (e) {
			var view = this,
				$this = $(e.currentTarget),
				title = $this.closest('.saved-annuity').find('.annuity-name').text(),
				$savedAnnuity = $this.closest('.saved-annuity'),
				seriesName = $savedAnnuity.find('.series-name').text(),
				seriesInfo = $savedAnnuity.find('.series-info').text();

			view.$el.find('#deleted-annuity-title').text(title);
			view.$el.find('#deleted-series-name').text(seriesName);
			view.$el.find('#deleted-series-info').text(seriesInfo);
		},
		'handleModalSelection': function (e) {
			var viewData = this.attributes || {};
			var view = this,
				$this,
				modalSelection,
				$template = $(_.template(App.templates[view.options.template], viewData));

			if (view.$el.find('#modal')) {
				view.$el.find('#modal').not('.allocations-modal').remove();
			}
			view.$el.find('#mask').after($template);

			if (e) {
				$this = $(e.currentTarget),
				modalSelection = $this.attr('data-modal');
			}
			App.trigger('modal:' + modalSelection);
			view.toggleModal();
			if ($(e.currentTarget).hasClass('define-link')) {
				var pound = $(e.currentTarget).text();
				$('.risk-wrapper').scrollTop(0);
				$('.risk-wrapper').animate({scrollTop: $("#"+pound).position().top-110}, 'slow');
			}
			$('.feedback-modal .custom-select').dropkick({
				'startSpeed': 0,
				'change': function (value, label) {
					var name = $(this).attr('name');
					App.trigger(name + ':customSelect:change', value, label, $(this).attr('id'));
				}
			});
		},
		'handleFeedbackInit': function () {

		},
		'handleVideoModalClick': function (e) {
			e.preventDefault();
			var view = this,
				$this = $(e.currentTarget),
				id = $this.attr('id'),
				videoId = $this.attr('data-video-id');

			view.handleModalSelection(e);
			view.renderVideos(id, videoId);
		},
		'toggleModal': function () {

			var view = this;

			App.off('open:uploadError');
			view.$el.find('#mask').fadeToggle('slow');
			view.$el.find('#modal').fadeToggle('slow');
			return false;
		},
		'renderVideos': function (id, videoId) {

			var view = this,
				brightcovePlayerView = '';

			brightcovePlayerView = new App.views.BrightcovePlayerView({
				'el': '.modal-video',
				'id': id,
				'videoId': videoId
			});
		},
		'handleDoNotAgree': function () {
			var view = this;

			$('#decline-modal-form').on('submit', function(event){
			    event.preventDefault(); 
			    $.ajax({
			        url: $(this).attr('action'),
			        type: $(this).attr('method'),
			        async: false,
			        data: $(this).serialize(),
			        success: function(html) {
			        }
			    });
			    //return false; 
			});

			view.$el.find('#decline-modal-form').submit();


			view.$el.find('#decline-conformation').fadeToggle(function () {
				view.$el.find('#decline-confirmed').fadeToggle();
			});
		},
		'handleUploadAgain': function () {

			var view = this;

			view.toggleModal();
			view.$el.find('#file-upload').trigger('click');

		},
		'handleDeleteSlsOption': function (e) {

			this.toggleModal();
			App.trigger('delete:sls-option-' + this.attributes.id);

		},
		'handleViewTable': function (e) {
			e.preventDefault();

			var view = this,
				$target = $(e.currentTarget);

			view.$el.find('.selected').removeClass('selected');
			$target.addClass('selected');

			view.$el.find('.view-table-pop-up').show();
			view.$el.find('.view-chart-pop-up').hide();
		},
		'handleViewChart': function (e) {
			e.preventDefault();

			var view = this,
				$target = $(e.currentTarget);

			view.$el.find('.selected').removeClass('selected');
			$target.addClass('selected');
			view.$el.find('.view-table-pop-up').hide();
			view.$el.find('.view-chart-pop-up').show();
		},
		'handleModalToggle': function () {

			var view = this,
				$video = $('#modal').find('video');

			view.toggleModal();
			if ($video.length) {

				setTimeout(function () {
					$video.remove()
				}, 500);
			}
		},
		'handleDeclined': function () {

			var view = this;

			view.toggleModal();
			location.reload();
		}
	});

});
