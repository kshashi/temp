/**
 * @module view/GMIBView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .follow-up': 'handleFlags',
			'click .hide': 'handleHideFlags'
		},

		'initialize': function (options) {

			_.bindAll(this);

			log('Backbone : View : GMIBView : Initialized');
		},

		'render': function () {},

		'handleFlags': function (e) {

			e.preventDefault()
			var view = this;

			view.$el.find('.hide').removeClass('disabled');
		},

		'handleHideFlags': function (e) {
			var $this = $(e.currentTarget)

			if ($this.hasClass('disabled')) {
				e.preventDefault();
			}
		}

	});

});
