/**
 * @module view/ChartDetailView
 */
var winPDF = 0;
var loops = 0;
define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global')

		return Backbone.View.extend({

			'events': {
				'click .close-rates': 'closeRates',
				'click .define-link': 'setModal',
				'click .button-cta.start': 'handleSubmitApplication'
			},

			'initialize': function (options) {
				_.bindAll(this);
				this.addingFlag = false;
				this.$chartContainer = $('#chart-container');
				this.$pieContainer = $('#pie-container');
				this.$lineChart = $('#line-chart');
				this.$toggle = $('#dragLine');
				this.isMouseDown = false;
				this.originMouseX = 0;
				this.$pvaContainer = $('#pva-select');
				this.pvaSelectTemplate = App.templates.PvaSelectTemplate;
				this.$pvaTemplate;
				
				
				this.render();

				log('Backbone : View : ChartDetailView : Initialized');
			},
			'render': function () {
				var allocationsCarousel,
					enableHypoView,
					modalView,
					view = this;
				
				if (this.$chartContainer.length) {
					this.chartData = illustration;
					log(this.chartData)
					view.$pvaTemplate = $(_.template(view.pvaSelectTemplate, this.chartData));
					$('.pva').append(view.$pvaTemplate);
					
					view.updateChart($('#pva-select').val());
				}
				$('#pva-select').dropkick({
						'startSpeed': 0,
					'change': function (value, label) {
						view.updateChart(value);
						}
					});
				App.on('pva:customSelect:change', this.updateChart);

				App.on('follow-up-flag:start', function () {
					view.addingFlag = true;
				});
				App.on('follow-up-flag:end', function () {
					view.addingFlag = false;
				});

				if (this.$pieContainer.length) {
				    this.renderPieChart(allocations);
				} else {
				    winPDF++;
				}
				if ($('.allocations-slides').length) {
					allocationsCarousel = new App.views.CarouselView({
						'el': '.carousel-wrapper',
						'attributes': {
							'autoPlay': 5000
						}
					});
				}
				if ($('#enable-container').length) {
					enableHypoView = new App.views.EnableHypoView({
						'el': '#charts-summary'
					});
				}

				modalView = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'DeclineModalTemplate'
				});

				var tooltipView = new App.views.TooltipView({
					'el': '#section-content'
				});

				var intrvl = self.setInterval(function () { if (winPDF > 1 || loops >= 100) { try { wnvPdfConverter.startConversion(); } catch (e) { } intrvl = clearInterval(intrvl); } else { loops++; } }, 100);
			},


			'handleSubmitApplication': function (e) {

				e.preventDefault();

				var view = this;
			
				view.$el.find('#form-application-start').submit();
			},

			'setModal': function () {

				var allocationModal;

				allocationModal = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'AllocationsModalTemplate'
				});
			},

			'handleViewTable': function (e) {
				e.preventDefault();

				var view = this,
					$target = $(e.currentTarget);
				view.attributes.flagView.clearAllFlags();
				view.$el.find('.selected').removeClass('selected');
				$target.addClass('selected');

				view.$el.find('.scrollableContainer').show();
				view.$el.find('#drag-container, .chart-interactions, #chart-info').hide();

			},

			'handleViewChart': function (e) {
				e.preventDefault();

				var view = this,
					$target = $(e.currentTarget),
					pva = $('#pva-select option:selected').val();

				view.$el.find('.selected').removeClass('selected');
				$target.addClass('selected');

				view.$el.find('.scrollableContainer').hide();
				view.$el.find('#drag-container, .chart-interactions, #chart-info').show();
				view.attributes.flagView.reloadFlags();
				view.updateChart(pva);
			},

			'updateChart': function (value) {
				var view = this,
					pva = value,
					chartCodes = ['MODEL_CONSERVATIVE_GROSS', 'MODEL_CONSERVATIVE_NET', 'MODEL_MODERATE_GROSS', 'MODEL_AGGRESSIVE_GROSS'],
					pvaCode = $('#pva-select option[value="' + pva + '"]').attr('data-code');
				this.attributes.flagView.changeFlagFilter(this.chartData.Id, {
					'market': pva
				});
				if (chartCodes.indexOf(pvaCode) < 0) {
					this.renderChart(this.chartData, pva);
					view.$el.find('#drag-container, .chart-interactions, #chart-info').hide();
					
				} else {
					
					view.$el.find('#drag-container, .chart-interactions, #chart-info').show();
					this.renderChart(this.chartData, pva);
					
					
				}
			},

			'renderPieChart': function (data) {
				(function (H) {
					H.wrap(H.Legend.prototype, 'render', function (proceed) {
						var chart = this.chart;
						proceed.call(this);
						if (this.options.adjustChartSize && this.options.verticalAlign === 'bottom') {
							chart.chartHeight += this.legendHeight;
							chart.marginBottom += this.legendHeight;
							chart.container.style.height = chart.container.firstChild.style.height = chart.chartHeight + 'px';

							this.group.attr({
								translateY: this.group.attr('translateY') + this.legendHeight
							});
						}
					});

				}(Highcharts));
				var pieArray = [];
				var colorArray = ['#36bee7', '#027ec5', '#83daf1', '#edf6da', '#fab704'];
				var colorIndex = 0;
				_.each(data.groups, function (obj, i) {
					_.each(obj.portfolios, function (seriesObj) {
						if(colorIndex == colorArray.length) colorIndex = 0;
						var color = colorArray[colorIndex];
						colorIndex++;
						var pieValue = {
							name: seriesObj.name + ' - ' + Math.round(seriesObj.percent) + '%',
							y: seriesObj.percent,
							id: seriesObj.id,
							color: color
						}
						pieArray.push(pieValue)
					});
				});
				var legendWidth = 400;
				// if ($('#charts-summary').length) {
				// 	legendWidth = 200;
				// }
				this.$pieContainer.highcharts({
				    chart: {
				        animation: false,
				        backgroundColor: 'rgba(255, 255, 255, 0.1)',
				        events: {
				            load: function (evt) { winPDF++; }
				        }
					},
					title: {
						text: null
					},
					credits: {
						enabled: false
					},
					legend: {
						layout: 'vertical',
						verticalAlign: 'bottom',
						borderWidth: 0,
						backgroundColor: null,
						marginTop: 0,
						x: 0,
						y: 0,
						adjustChartSize: false,
						itemStyle: {
							paddingBottom: '10px',
							width: legendWidth
						}
					},
					tooltip: {
						enabled: false,
						borderWidth: 0,
						backgroundColor: "rgba(255,255,255,0)",
						shadow: false,
						useHTML: true,
						formatter: function () {

							// var s = '<b>'+ this.point.percentage +'%</b> ' + this.point.name;
							//var y = this.y,
							var seriesId = this.series.options.id;
							// return '<div class="chart-tooltip ' + seriesId + '">' + s + '</div>';
							$('.portfolio').hide()
							$('.' + seriesId).show();

						},
						hideDelay: 1000,
						shared: false
					},
					plotOptions: {
					    pie: {
                            animation: false,
							point: {
								events: {
									legendItemClick: function () {
										var seriesId = this.id;
										$('.group-percent').hide();
										$('.portfolio').hide();
										$('.' + seriesId).show();
										return false;
									},
									click: function () {
										var seriesId = this.id;
										$('.group-percent').hide();
										$('.portfolio').hide();
										$('.' + seriesId).show();
									}
								}
							},
							allowPointSelect: false,
							cursor: 'pointer',
							dataLabels: {
								enabled: false,
								connectorWidth: 0,
								format: '{point.percentage}%',
								distance: 10
							},
							showInLegend: true
						}
					},
					series: [{
							type: 'pie',
							name: 'Allocation total',
							data: pieArray
						}
					]
				});
			},

			'closeRates': function (e) {
				var view = this;
				e.preventDefault();
				var $target = $(e.currentTarget);
				$target.removeClass('active');
				var chart = $('#chart-container').highcharts();
				chart.xAxis[0].removePlotLine("myPlotLine");
				view.attributes.flagView.clearAllFlags();
				$('#chart-ul').slideToggle('slow').promise().done(function () {
					view.attributes.flagView.reloadFlags();
				});

			},

			'renderChart': function (data, pva) {
				Number.prototype.formatMoney = function (c, d, t) {
					var n = this,
						c = isNaN(c = Math.abs(c)) ? 2 : c,
						d = d == undefined ? "." : d,
						t = t == undefined ? "," : t,
						s = n < 0 ? "-" : "",
						i = parseInt(n = Math.round(+n || 0).toFixed(c)) + "",
						j = (j = i.length) > 3 ? j % 3 : 0;
					return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
				};
				if (!pva || $('#charts-summary').length) {
					pva = 0;
					for(var illIndex = 0; illIndex < data.Illustrations.length; illIndex++){
						var Illustration = data.Illustrations[illIndex];
						if(Illustration.MarketTypeCode == 'MODEL_MODERATE_GROSS') pva = illIndex;
					};
				}
				var view = this,
					lineSet = data.Illustrations[pva].ChartLines,
					joint = data.Illustrations[pva].IsJointIllustration,
					ageArray = [],
					jointAgeArray = [],
					youngerAgeArray = [],
					xAxisArray = [],
					accountValueArray = [],
					stepUpArray = [],
					benefitArray = [],
					deathBenefitArray = [],
					netRateArray = [],
					withdrawalArray = [],
					totalWithdraws = 0;

				_.each(lineSet, function (obj) {
					if (obj.VectorName == "VECTOR_VA_PRIMARYAGES") {
						_.each(obj.DataSeries, function (seriesObj) {
							var ageValue = seriesObj.Value;
							ageArray.push(ageValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_JOINTAGES") {
						_.each(obj.DataSeries, function (seriesObj) {
							var jointAgeValue = seriesObj.Value;
							jointAgeArray.push(jointAgeValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_TOTAL_DEATHBENEFITS") {
						_.each(obj.DataSeries, function (seriesObj) {
							var deathBenefitValue = seriesObj.Value;
							deathBenefitArray.push(deathBenefitValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_NETRATE") {
						_.each(obj.DataSeries, function (seriesObj) {
							var netRateValue = seriesObj.Value;
							netRateArray.push(netRateValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_GMIB_INDICATOR") {
						_.each(obj.DataSeries, function (seriesObj) {
							var stepUpValue = seriesObj.IsPointOfInterest;
							stepUpArray.push(stepUpValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_ACCOUNT_VALUES") {
						_.each(obj.DataSeries, function (seriesObj) {
							var accountValue = {
								y: parseInt(seriesObj.Value),
								marker: {
									enabled: false,
									radius: 10
								},
								text: ""
							}
							accountValueArray.push(accountValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_GMIB_INCOMEBASE") {
						_.each(obj.DataSeries, function (seriesObj) {
							if (seriesObj == obj.DataSeries[obj.DataSeries.length - 1]) {
								var benefitValue = {
									y: parseInt(seriesObj.Value),
									marker: {
										enabled: true,
										radius: 8
									},
									text: " "
								};
							} else {
								if (parseInt(seriesObj.Value) > 0) {
									var benefitValue = parseInt(seriesObj.Value);
								} else {
									var benefitValue = null;
								}
							}
							benefitArray.push(benefitValue)
						});
					}
					if (obj.VectorName == "VECTOR_VA_WITHDRAWALS") {
						var firstIndex = _.find(obj.DataSeries, function (val, i) {
							if (val.Value !== 0) {
								return i
							}
						});
						_.each(obj.DataSeries, function (seriesObj, i) {
							if (seriesObj.Value == 0) {
								var withdrawalValue = {
									y: parseInt(seriesObj.Value),
									marker: {
										enabled: false
									}
								};
							} else if (firstIndex == seriesObj) {
								var withdrawalValue = {
									y: parseInt(seriesObj.Value),
									text: "Withdrawal Start<br />Starting at age 77, 4% withdrawals of the <br />income/benefit base are taken."
								};
							} else {
								var withdrawalValue = parseInt(seriesObj.Value);
							}
							withdrawalArray.push(withdrawalValue);
							if(withdrawalValue > 0) totalWithdraws++;
						});
					}
				});

				var initInvest = data.InitialInvestment.formatMoney(0, '.', ','),
					endAccountValue = parseInt(accountValueArray.slice(-1)[0].y).formatMoney(0, '.', ','),
					endBenefitBase = parseInt(benefitArray.slice(-1)[0].y).formatMoney(0, '.', ','),
					totalXaxisPoints = parseInt(ageArray.length - 2) + .5,
					accountWithStep = [],
					grossRate = data.Illustrations[pva].GrossAverageAnnualRateOfReturn,
					netRate = data.Illustrations[pva].NetAverageAnnualRateOfReturn;

					if (ageArray[0] > jointAgeArray[0]) {
						xAxisArray = ageArray;
						youngerAgeArray = jointAgeArray;
					} else {
						xAxisArray = jointAgeArray;
						youngerAgeArray = ageArray;
					}

				_.each(accountValueArray, function (avObj, i) {
					if (stepUpArray[i] == true) {
						var accountWithStepValue = {
							y: avObj.y,
							marker: {
								enabled: true,
								radius: 10
							},
							text: "Assumes an optional step-up is elected<br />  because the account value exceeds the<br />  current year's 4% income/benefit base."
						}
					} else {
						var accountWithStepValue = {
							y: avObj.y,
							marker: {
								enabled: false,
								radius: 10
							}
						}
					}
					accountWithStep.push(accountWithStepValue)
				});

				$('.GROSS_RATE').html(grossRate);
				$('.NET_RATE').html(netRate);
				$('.init-invest').html('$' + initInvest);
				$('.end-benefit-base').html(endBenefitBase);
				$('.end-account-value').html('$' + endAccountValue);

				$('.scrollableContainer').remove();
				view.$lineChart.append(_.template(App.templates.VaDataTableTemplate, {
					'lineSet': lineSet,
					'iter': xAxisArray,
					'joint': joint
				}));
				
				if($('#charts-summary').length === 0) {
					
				(function (Highcharts) {
					var each = Highcharts.each;
					Highcharts.wrap(Highcharts.Legend.prototype, 'renderItem', function (proceed, item) {
						proceed.call(this, item);
						var series = this.chart.series,
							element = item.legendGroup.element;
						element.onmouseover = function () {
							$('#series-desc-' + item._i).show();
							each(series, function (seriesItem) {
								if (seriesItem !== item) {

									each(['group', 'markerGroup'], function (group) {
										seriesItem[group].attr('opacity', 0.25);

									});
								}
							});
						}
						element.onmouseout = function () {
							$('#series-desc-' + item._i).hide();
							each(series, function (seriesItem) {
								if (seriesItem !== item) {
									each(['group', 'markerGroup'], function (group) {
										seriesItem[group].attr('opacity', 1);
									});
								}
							});
						}

					});
				}(Highcharts));
				
				}

				Highcharts.setOptions({
					colors: ['#76d5f1', '#26bae5'],
				});
				var chartWidth = 960;
				var chartz = new Highcharts.Chart({
					chart: {
						renderTo: 'chart-container',
						alignTicks: false,
						marginTop: 30,
						backgroundColor: '#f3f3f3',
						plotBackgroundColor: '#ffffff',
						height: 550,
						width: chartWidth,
                        animation: false,
						events: {
						    load: function (evt) { winPDF++; },
							click: function (evt) {
								if ($('.gmib-view').length) {
									if (view.addingFlag === false) {
										var myPlotLineId = "myPlotLine";
										var chart = this;
										var xIndex = chart.inverted ? chart.plotHeight + chart.plotTop - evt.chartY : evt.chartX - chart.plotLeft;
										var xValue = chart.series[0].tooltipPoints[xIndex].x;
										var xAxis = evt.xAxis[0].axis;

										$.each(xAxis.plotLinesAndBands, function () {
											if (this.id === myPlotLineId) {
												this.destroy();
											}
										});

										$('.close-rates').addClass('active');


										xAxis.addPlotLine({
											value: xValue,
											color: '#fe6c3b',
											width: 3,
											zIndex: 1000,
											id: myPlotLineId
										});
										view.attributes.flagView.clearAllFlags();
										$('#chart-ul').slideDown('slow').promise().done(function () {          
											view.attributes.flagView.reloadFlags();        
										});

										$('.death-benefit').html('$' + parseInt(deathBenefitArray[xValue]).formatMoney(0, '.', ','));
										$('.return-rate').html(parseFloat(netRateArray[xValue] * 100).toFixed(2) + '%');
										$('.benefit-base').html('$' + parseInt(benefitArray[xValue]).formatMoney(0, '.', ','));
										$('.account-value').html('$' + parseInt(accountWithStep[xValue].y).formatMoney(0, '.', ','));
										


									}
								}

							}

						}
					},
					title: {
						text: null
					},
					credits: {
						enabled: false
					},
					legend: {
						align: 'bottom',
						borderWidth: 0,
						layout: 'vertical',
						symbolWidth: 46,
						itemMarginTop: 10,
						x: 80
					},
					xAxis: {
						min: .5,
						max: totalXaxisPoints,
						minPadding: 10,
						maxPadding: 10,
						categories: xAxisArray,
						labels: {
							useHTML: true,
							formatter: function () {
								var xLabel = this.value;
								var jointXLabel = this.value + '/' + youngerAgeArray[xAxisArray.indexOf(this.value)];
								if (data.Illustrations[pva].IsJointIllustration) {
									return ('<span class="joint-x-label">' + jointXLabel + '</span>');
								} else {
									return ('<span class="x-label">' + xLabel + '</span>');
								}
							},
							align: 'left',
							y: 28,
							x: -4,
							step: 2
						},
						title: {
							text: 'Age',
							align: 'low',
							margin: 20

						},
						tickColor: '#fe6c3b',
						tickmarkPlacement: 'on',
						tickLength: 15
					},
					yAxis: {
						title: {
							text: ''
						},
						labels: {
							useHTML: true,
							formatter: function () {
								var yLabel = '$' + this.value / 1000 + 'k';
								if (this.value == data.InitialInvestment) {
									return ('<span class="chart-label init">' + yLabel + '<br /><span class="title">Initial<br />Investment</span></span>');
								} else {
									return ('<span class="chart-label">' + yLabel + '</span>');
								}
							},
							style: {
								marginRight: 20
							}
						},
						showFirstLabel: false
					},
					tooltip: {
						borderWidth: 0,
						backgroundColor: "rgba(255,255,255,0)",
						shadow: false,
						useHTML: true,
						formatter: function () {
							if (view.addingFlag === false) {
								//var $addBtn = $('#hide-flags');
								//if (!$addBtn.hasClass('flags-hidden')) $addBtn.addClass('force-show').trigger('click');
								var s = '<b>Age: ' + this.x + '</b>';
								var y = this.y,
									addText = this.point.text !== undefined ? '<p>' + this.point.text + '</p>' : '',
									seriesId = this.series.options.id,
									money = y.formatMoney(0, '.', ',');
								if (seriesId == 'benefit-series' && addText == "") {
									s = "<p>The income/benefit base equal your purchase payments compounded through the contract anniversary prior to the oldest contract owner's 91st birthday at the greater of: (a) 4% or (b) your required minimum distribution (RMD) as a percentage of the benefit base, adjusted for withdrawals.</p><br /><p>There is also a GMIB Max Highest Anniversary Value (HAV) income base and an EDB Max HAV benefit base that lock in any account value gains on each contract anniversary, adjusted proportionately for withdrawals, prior to the oldest contract owner's 81st birthday.</p><br /><p>The income/benefit base is used to determine the amount of withdrawals you can take each year, as well as your future lifetime income. To see yearly income/benefit base amounts, please refer to the tabular chart.</p><br />"
								} else {
									s += '<br/>' + this.series.name + ': <br />' + money;
								}
								if (seriesId == 'withdraw-series') {
									addText = addText.replace('77', this.x)
								}

								return '<div class="chart-tooltip ' + seriesId + '">' + s + addText + '</div>';

							} else {
								return false;
							}



						},
						hideDelay: 100,
						shared: false
					},
					plotOptions: {
					    series: {
					        animation: false,
							marker: {
								states: {
									hover: {
										radius: 10
									}
								}
							},
							events: {
								legendItemClick: function () {
									return false;
								},
								mouseOut: function () {
									//var $addBtn = $('#hide-flags');
									//if ($addBtn.hasClass('force-show')) $addBtn.removeClass('force-show').trigger('click');
								}
							}
						},
						area: {
							fillColor: {
								linearGradient: {
									x1: 0,
									y1: 1,
									x2: 0,
									y2: 0
								},
								stops: [
									[0, Highcharts.getOptions().colors[1]],
									[1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0.5).get('rgba')]
								]
							}
						}
					},
					series: [{
							name: 'Benefit Base',
							type: 'line',
							id: 'benefit-series',
							lineWidth: 3,
							marker: {
								enabled: false,
								lineColor: '#fff',
								lineWidth: 1,
								fillColor: '#333',
								radius: 5

							},
							color: '#333',
							data: benefitArray,
							zIndex: 2
						}, {
							name: 'Account Value',
							type: 'area',
							lineWidth: 3,
							id: 'account-series',
							marker: {
								lineColor: '#fff',
								lineWidth: 1,
								radius: 5,
								enabled: false
							},
							color: '#26bae5',
							data: accountWithStep,
							zIndex: 4
						}, {
							name: 'Annual Withdrawal',
							type: 'line',
							lineWidth: 0,
							id: 'withdraw-series',
							marker: {
								radius: 5,
								enabled: true
							},
							color: '#fe6c3b',
							data: withdrawalArray,
							zIndex: 6
						}
					]
				});
			}

		});

});
