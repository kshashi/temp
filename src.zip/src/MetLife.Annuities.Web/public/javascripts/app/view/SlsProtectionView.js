/**
 * @module view/SlsProtectionView
 */

define(function (require) {

    'use strict';

    var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global'),
		fakeZero = 0.0;

    return Backbone.View.extend({

        'events': {
            'click #market-up': 'marketUp',
            'click #market-down': 'marketDown',
            'click #market-flat': 'marketFlat',
            'mouseenter .legend-tooltip': 'legendTooltipMouseover',
            'mouseleave .legend-tooltip': 'legendTooltipMouseout'
        },

        'initialize': function (options) {
            _.bindAll(this);
            this.chart = null;
            this.legendHover = false;
            this.addingFlag = false;
            // Set SLS Model - Products, Indexes, Current Rates, Historical Rates, Disclosures
            this.slsData = new App.models.SlsModel();
            // Set SLS Saved Annuity - "slsAnnuity" is a variable set server-side in the HEAD by SLS controller
            this.slsAnnuity = new App.models.SlsAnnuityModel(slsAnnuity);
            // Set SLS Saved Annuity Options - options are saved as a single JSON string, so load it into a Backbone.js collection
            this.slsOptions = this.slsAnnuity.getOptionsCollection();
            // Render the page after data is set
            this.render();
            log('Backbone : View : SlsProtectionView : Initialized');
        },

        'render': function () {
            // The "scenario 1" and "scenario 2" sub titles for the graphs have tooltips
            this.tooltipView = new App.views.TooltipView({
                'el': '#section-content',
                'attributes': {}
            });
            var view = this;
            App.on('change:sls-option', this.changeOption);
            App.on('follow-up-flag:start', function () {
                view.addingFlag = true;
            });
            App.on('follow-up-flag:end', function () {
                view.addingFlag = false;
            });
        },

        'mapLegendToChart': function (target) {
            var point = {
                series: 0,
                index: 10
            };
            if (target == 'protection') point.series = 1;
            else if (target == 'index') {
                point.series = 2;
                point.index = 2;
            } else if (target == 'investment') {
                point.series = 3;
                point.index = 6;
            }
            return point;
        },

        'legendTooltipMouseover': function (e) {
            this.legendHover = true;
            var target = $(e.currentTarget).attr('data-id');
            var point = this.mapLegendToChart(target);
            this.chart.series[point.series].data[point.index].setState('hover');
            this.chart.tooltip.refresh(this.chart.series[point.series].data[point.index]);
        },

        'legendTooltipMouseout': function (e) {
            this.legendHover = false;
            var target = $(e.currentTarget).attr('data-id');
            var point = this.mapLegendToChart(target);
            this.chart.series[point.series].data[point.index].setState();
            this.chart.tooltip.hide();
        },

        'marketUp': function (e) {
            e.preventDefault();
            if (!$('#market-up').hasClass('disabled')) {
                $('#market-direction-btns a').removeClass('active');
                $('#market-up').addClass('active');
                this.changeOption();
            }
        },

        'marketDown': function (e) {
            e.preventDefault();
            if (!$('#market-down').hasClass('disabled')) {
                $('#market-direction-btns a').removeClass('active');
                $('#market-down').addClass('active');
                this.changeOption();
            }
        },

        'marketFlat': function (e) {
            e.preventDefault();
            if (!$('#market-flat').hasClass('disabled')) {
                $('#market-direction-btns a').removeClass('active');
                $('#market-flat').addClass('active');
                this.changeOption();
            }
        },

        'changeOption': function () {
            var $flat = $('#market-flat');
            var optIndex = $('#sls-product').val();
            var option = this.slsOptions.at(optIndex);
            var product = this.slsData.get('products').get(option.get('product'));
            var isStepRate = product.get('isStepRate');
            var isFixed = product.isFixed();
            var isShield100 = (product.id.indexOf('shield100') >= 0) ? true : false;
            $('.market-dir-btn').removeClass('disabled');
            // Charts are not displayed for "fixed" SLS product. Flat market scenario is only enabled for "step rate" SLS products.
            if (!isFixed) {
                if (isStepRate === false) {
                    $flat.addClass('disabled');
                    if ($flat.hasClass('active')) {
                        $flat.removeClass('active');
                        $('#market-down').addClass('active');
                    }
                }
                var dir = $('#market-direction-btns a.active').attr('id');
                var term = option.get('term');
                $('#sls-chart-header').css('display', 'block');
                $('#sls-legend').css('display', 'block');
                this.renderGraph(dir, isStepRate, term, product.getYAxis(term, option.get('index')), isShield100);
            } else {
                $('#sls-chart-header').css('display', 'none');
                $('#sls-legend').css('display', 'none');
                $('.market-dir-btn').addClass('disabled');
                $('#sls-chart-graph').html(_.template(App.templates.SlsProtectionChartEmptyTemplate));
            }
            this.attributes.flagView.changeFlagFilter(this.slsAnnuity.get('slsId'), {
                'product': product.id,
                'term': $('#sls-term').attr('data-years'),
                'index': $('#sls-index').attr('data-index'),
                'market': dir
            });
        },

        'renderGraph': function (dir, isStepRate, term, yAxis, isShield100) {
            // Set chart variables based on product and market direction. Up and down markets have 2 scenarios and flat market has 1 scenario.
            if (isStepRate === true) {
                $('.mgo-only').css('display', 'none');
                $('.step-only').css('display', 'block');
            } else {
                $('.mgo-only').css('display', 'block');
                $('.step-only').css('display', 'none');
            }
            var rate = parseFloat($('#sls-mgo').html().replace('%', ''));
            var pv = parseInt($('#sls-protection').html().replace('%', ''));
            var pa = (pv > 0) ? -pv : -fakeZero;
            var indexPerf1, indexPerf2, yourPerf1, yourPerf2, yMinMax;
            if (dir == 'market-up') {
                yMinMax = yAxis.up;
                indexPerf1 = parseFloat((rate * .75).toFixed(2));
                indexPerf2 = parseFloat((rate * 1.15).toFixed(2));
                yourPerf1 = parseFloat(((isStepRate === true) ? rate : rate * .75).toFixed(2));
                yourPerf2 = rate;
                $('#sls-chart-graph').css('width', '100%');
                if (isStepRate === true) {
                    var stepDiff = rate - Math.abs(indexPerf1);
                    $('#scenario1').data('tooltip', 'At the end of the ' + term + 'yr term, the index performance is up by ' + Math.abs(indexPerf1) + '%. So long as the index does not perform negatively the Step Rate option allows you to gain the locked in/predetermined percentage of growth, in this case the account value increases by ' + rate + '%, ' + stepDiff + '% gains over index performance.');
                    $('#scenario2').show().data('tooltip', 'At the end of the ' + term + 'yr term, the index performance is up by ' + Math.abs(indexPerf2) + '%, surpassing the Step Rate. The account value grows by ' + rate + '%, since that is the pre-determined Step Rate percentage of growth.');
                } else {
                    $('#scenario1').data('tooltip', 'At the end of the ' + term + 'yr term, the index performance is up by ' + Math.abs(indexPerf1) + '%, still within the Maximum Growth Opportunity. The account value increases by the same amount of index gains, ' + Math.abs(yourPerf1) + '%');
                    $('#scenario2').show().data('tooltip', 'At the end of the ' + term + 'yr term, the index performance is up by ' + Math.abs(indexPerf2) + '%, surpassing the Maximum Growth Opportunity. The account value can only grow by the max ' + rate + '%, since that is the Maximum Growth Opportunity.');
                }
            } else if (dir == 'market-down') {
                yMinMax = yAxis.down;
                indexPerf1 = (isShield100) ? -parseFloat((rate * 4)).toFixed(2) : -parseFloat((pv * .75)).toFixed(2);
                indexPerf2 = -parseFloat((pv * 1.15)).toFixed(2);
                yourPerf1 = fakeZero;
                yourPerf2 = -parseFloat(((pv * 1.15) - pv)).toFixed(2);
                var yourDiff = Math.abs(indexPerf2) - pv;
                if (isShield100) {
                    $('#sls-chart-graph').css('width', '53%');
                    $('#scenario2').hide();
                } else $('#sls-chart-graph').css('width', '100%');
                if (isStepRate === true) {
                    $('#scenario1').data('tooltip', 'At the end of the ' + term + 'yr term, the index is down by ' + Math.abs(indexPerf1) + '% but still within the ' + pv + '% protection amount. There would be no gain or loss on the account value since MetLife absorbed the entire loss.');
                    if (!isShield100) $('#scenario2').show().data('tooltip', 'At the end of the ' + term + 'yr term, the index performance is down by ' + Math.abs(indexPerf2) + '%, ' + yourDiff + '% below protection amount. However, the account value would decline by only ' + Math.abs(yourPerf2) + '% because MetLife absorbs the first ' + pv + '% of the loss.');
                } else {
                    $('#scenario1').data('tooltip', 'At the end of the ' + term + 'yr term, the index is down by ' + Math.abs(indexPerf1) + '% but still within the ' + pv + '% protection amount. There would be no gain or loss on the account value since MetLife absorbed the entire loss.');
                    if (!isShield100) $('#scenario2').show().data('tooltip', 'At the end of the ' + term + 'yr term, the index performance is down by ' + Math.abs(indexPerf2) + '%, ' + yourDiff + '% below protection amount. However, the account value would decline by only ' + Math.abs(yourPerf2) + '% because MetLife absorbs the first ' + pv + '% of the loss.');
                }
            } else {
                $('#sls-chart-graph').css('width', '53%');
                $('#scenario2').hide();
                yMinMax = yAxis.flat;
                indexPerf1 = fakeZero;
                yourPerf1 = rate;
                $('#scenario1').data('tooltip', 'At the end of the ' + term + 'yr term, the index performance has neither grown or fallen. So long as the index does not perform negatively the Step Rate option allows you to gain the locked in/pre-determined percentage of growth, in this case the account value increases by ' + rate + '%.');
            }
            // Since SLS graph doesn't fit perfectly in a "column/bar" chart, we are using the "area" chart to get the desired graph.
            // The X axis is broken into 22 points, 11 points for each scenario. Data for each graph column is created by combining null values
            // and releated actual values.
            var view = this;

            // Since y-axis is now set via config data, we need to adjust data points so that tooltips work properly.
            var pa1 = (pa > yMinMax) ? yMinMax : (pa < -yMinMax) ? -yMinMax : pa;
            var rate1 = (rate > yMinMax) ? yMinMax : (rate < -yMinMax) ? -yMinMax : rate;
            var indexPerf1a = (indexPerf1 > yMinMax) ? yMinMax : (indexPerf1 < -yMinMax) ? -yMinMax : indexPerf1;
            var indexPerf2a = (indexPerf2 > yMinMax) ? yMinMax : (indexPerf2 < -yMinMax) ? -yMinMax : indexPerf2;
            var yourPerf1a = (yourPerf1 > yMinMax) ? yMinMax : (yourPerf1 < -yMinMax) ? -yMinMax : yourPerf1;
            var yourPerf2a = (yourPerf2 > yMinMax) ? yMinMax : (yourPerf2 < -yMinMax) ? -yMinMax : yourPerf2;

            view.chart = new Highcharts.Chart({
                chart: {
                    renderTo: 'sls-chart-graph',
                    type: 'area',
                    backgroundColor: '#f6f6f6',
                    plotBackgroundColor: '#ffffff',
                    zoomType: 'xy'
                },
                legend: {
                    enabled: false
                },
                title: {
                    text: null
                },
                credits: {
                    enabled: false
                },
                xAxis: {
                    // 2 scenarios for up and down market, 1 scenario for flat market
                    categories: (dir != 'market-flat') ? ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22'] : ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'],
                    // We only show the X axis label for "0yr" and the selected option's term length. HTML is used to better position the labels
                    labels: {
                        enabled: true,
                        formatter: function () {
                            var val = '';
                            if (this.value == '1' || this.value == '12') val = '0yr';
                            else if (this.value == '10' || this.value == '21') val = term + 'yr';
                            return _.template(App.templates.SlsProtectionXAxisTemplate, {
                                'label': val
                            });
                        },
                        useHTML: true
                    },
                    title: {
                        text: null
                    },
                    tickLength: 10,
                    tickColor: 'rgba(243, 117, 37, 1)',
                    tickmarkPlacement: 'on',
                    tickPositions: (dir != 'market-flat') ? [0, 1, 10, 12, 21] : [0, 1, 10]
                },
                yAxis: {
                    labels: {
                        formatter: function () {
                            return _.template(App.templates.SlsProtectionYAxisTemplate, {
                                'label': this.value
                            });
                        },
                        useHTML: true
                    },
                    title: {
                        text: null
                    },
                    lineColor: 'rgba(243, 117, 37, 1)',
                    lineWidth: 1,
                    min: -yMinMax,
                    max: yMinMax,
                    tickInterval: (yMinMax % 4 === 0) ? yMinMax / 4 : (yMinMax % 3 === 0) ? yMinMax / 3 : (yMinMax % 2 === 0) ? yMinMax / 2 : yMinMax
                },
                tooltip: {
                    enabled: true,
                    hideDelay: 1,
                    borderWidth: 0,
                    backgroundColor: "rgba(255,255,255,0)",
                    shadow: false,
                    useHTML: true,
                    /* UNCOMMENT THIS IF WE WANT TO FIX THE POSITION OF THE TOOLTIP
                    positioner: function (labelWidth, labelHeight, point) {
                    var scenario = (point.plotX < 450) ? 1 : 2;
                    return {
                    x: (scenario == 1) ? 75 : 525,
                    y: 10
                    };
                    },
                    */
                    formatter: function () {
                        if (view.addingFlag === false) {
                            var scenario = (parseInt(this.x) <= 11) ? 1 : 2;
                            var tooltipCopy = '';
                            var tooltipCssClass = '';
                            if (this.series.name == 'Step Rate') tooltipCssClass = 'step';
                            else if (this.series.name == 'Maximum Growth Opportunity') tooltipCssClass = 'mgo';
                            else if (this.series.name == 'Protection Amount') tooltipCssClass = 'protection';
                            else if (this.series.name == 'Index Performance') tooltipCssClass = 'index';
                            else if (this.series.name == 'Your Performance') tooltipCssClass = 'investment';
                            if (view.legendHover === true) {
                                if (this.series.name == 'Step Rate') tooltipCopy = 'The Step Rate locks in a pre-determined percentage of growth if the index is either flat or up at the end of the term. Rates will be set at contract issue, and are locked in for the term selected.';
                                else if (this.series.name == 'Maximum Growth Opportunity') tooltipCopy = 'In exchange for protection against negative index performance, the account only has the potential to grow up to the Maximum Growth Opportunity. Rates will be set at contract issue, and are locked in for the term selected.';
                                else if (this.series.name == 'Protection Amount') tooltipCopy = 'Choose from Shield 10, Shield 15, Shield 25 or Shield 100. MetLife will absorb the first 10%, 15%, 25% or 100% of any index loss, respectively.';
                                else if (this.series.name == 'Index Performance') tooltipCopy = 'Index performance is used in conjunction with the level of protection you chose and your Maximum Growth Opportunity or Step Rate to determine your account value. Not all indices are available with every Shield Option.';
                                else if (this.series.name == 'Your Performance') tooltipCopy = 'Your Performance represents the potential gains or losses of your account value at the end of the term.';
                            } else if (isStepRate === true) {
                                if (dir == 'market-flat') {
                                    if (this.series.name == 'Step Rate') tooltipCopy = 'The Step Rate is a pre-determined percentage of guaranteed growth when your index is either flat or up at the end of your term. In exchange for this extra certainty, your growth percentage may be a bit lower than one you’d get without the Step Rate. For this shield option it is currently ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term, the index performance has neither grown or fallen. Your account value increases by the pre-determined Step Rate of ' + rate + '%.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'Your account value increases by the predetermined Step Rate of ' + rate + '%.';
                                } else if (dir == 'market-up' && scenario == 1) {
                                    if (this.series.name == 'Step Rate') tooltipCopy = 'The Step Rate is a pre-determined percentage of guaranteed growth when your index is either flat or up at the end of your term. In exchange for this extra certainty, your growth percentage may be a bit lower than one you’d get without the Step Rate. For this shield option it is currently ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term the index performance is up by ' + Math.abs(indexPerf1) + '%. Your account value increases by the pre-determined Step Rate of ' + rate + '%.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'Your account value increases by the predetermined Step Rate of ' + rate + '%.';
                                } else if (dir == 'market-up' && scenario == 2) {
                                    if (this.series.name == 'Step Rate') tooltipCopy = 'The Step Rate is a pre-determined percentage of guaranteed growth when your index is either flat or up at the end of your term. In exchange for this extra certainty, your growth percentage may be a bit lower than one you’d get without the Step Rate. For this shield option it is currently ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term, the index performance is up by ' + Math.abs(indexPerf2) + '%. Your account value increases by the pre-determined Step Rate of ' + rate + '%.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'Your account value increases by the predetermined Step Rate of ' + rate + '%.';
                                } else if (dir == 'market-down' && scenario == 1) {
                                    if (this.series.name == 'Step Rate') tooltipCopy = 'The Step Rate is a pre-determined percentage of guaranteed growth when your index is either flat or up at the end of your term. In exchange for this extra certainty, your growth percentage may be a bit lower than one you’d get without the Step Rate. For this shield option it is currently ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term the index performance is down by ' + Math.abs(indexPerf1) + '%, but still within the ' + pv + '% protection amount. MetLife absorbs the entire loss.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'There would be no gain or loss of the account value.';
                                } else if (dir == 'market-down' && scenario == 2) {
                                    if (this.series.name == 'Step Rate') tooltipCopy = 'The Step Rate is a pre-determined percentage of guaranteed growth when your index is either flat or up at the end of your term. In exchange for this extra certainty, your growth percentage may be a bit lower than one you’d get without the Step Rate. For this shield option it is currently ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term, the index performance is down by ' + Math.abs(indexPerf2) + '%. However, because of the protection amount, MetLife absorbs the first ' + pv + '% of the loss.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'The account value would decline by only ' + Math.abs(yourPerf2) + '% because MetLife absorbs the first ' + pv + '% of the loss.';
                                }
                            } else {
                                if (dir == 'market-up' && scenario == 1) {
                                    if (this.series.name == 'Maximum Growth Opportunity') tooltipCopy = 'In exchange for protection against negative index performance, the account value only has the potential to grow up to the Maximum Growth Opportunity (MGO). Currently the MGO for this shield option is ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term the index performance is up by ' + Math.abs(indexPerf1) + '%. Your account value increases by the same ' + Math.abs(yourPerf1) + '% gains.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'The account value grows by the same gains as the market performance, ' + Math.abs(yourPerf1) + '%.';
                                } else if (dir == 'market-up' && scenario == 2) {
                                    if (this.series.name == 'Maximum Growth Opportunity') tooltipCopy = 'In exchange for protection against negative index performance, the account value only has the potential to grow up to the Maximum Growth Opportunity (MGO). Currently the MGO for this shield option is ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term, the index performance is up by ' + Math.abs(indexPerf2) + '%. However, because of the Maximum Growth Opportunity your account value increases by a max ' + rate + '%.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'The account value grows by the Maximum Growth Opportunity of ' + rate + '%.';
                                } else if (dir == 'market-down' && scenario == 1) {
                                    if (this.series.name == 'Maximum Growth Opportunity') tooltipCopy = 'In exchange for protection against negative index performance, the account value only has the potential to grow up to the Maximum Growth Opportunity (MGO). Currently the MGO for this shield option is ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term the index performance is down by ' + Math.abs(indexPerf1) + '%, but still within the ' + pv + '% protection amount. MetLife absorbs the entire loss.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'There would be no gain or loss of the account value.';
                                } else if (dir == 'market-down' && scenario == 2) {
                                    if (this.series.name == 'Maximum Growth Opportunity') tooltipCopy = 'In exchange for protection against negative index performance, the account value only has the potential to grow up to the Maximum Growth Opportunity (MGO). Currently the MGO for this shield option is ' + rate + '%.';
                                    else if (this.series.name == 'Protection Amount') tooltipCopy = 'Shield ' + pv + ' protects the account value up to the first ' + pv + '% of index loss.';
                                    else if (this.series.name == 'Index Performance') tooltipCopy = 'At the end of the ' + term + 'yr term, the index performance is down by ' + Math.abs(indexPerf2) + '%. However, because of the protection amount, MetLife absorbs the first ' + pv + '% of the loss.';
                                    else if (this.series.name == 'Your Performance') tooltipCopy = 'The account value would decline by only ' + Math.abs(yourPerf2) + '% because MetLife absorbs the first ' + pv + '% of the loss.';
                                }
                            }
                            if (tooltipCopy != '') {
                                //var $addBtn = $('#hide-flags');
                                //if (!$addBtn.hasClass('flags-hidden')) $addBtn.addClass('force-show').trigger('click');
                                return _.template(App.templates.SlsProtectionTooltipTemplate, {
                                    'tooltip': tooltipCopy,
                                    'cssClass': tooltipCssClass
                                });
                            } else return false;
                        } else return false;
                    }
                },
                plotOptions: {
                    area: {
                        trackByArea: true,
                        pointPlacement: 'on',
                        marker: {
                            enabled: false,
                            symbol: 'square',
                            radius: 8,
                            states: {
                                hover: {
                                    enabled: true
                                }
                            }
                        },
                        point: {
                            events: {
                                mouseOut: function () {
                                    //var $addBtn = $('#hide-flags');
                                    //if ($addBtn.hasClass('force-show')) $addBtn.removeClass('force-show').trigger('click');
                                }
                            }
                        }
                    }
                },
                series: [{
                    name: (isStepRate === true) ? 'Step Rate' : 'Maximum Growth Opportunity',
                    data: (dir == 'market-flat' || (dir == 'market-down' && isShield100))
							? [null, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, null]
							: [null, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, null, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, rate1, null],
                    fillColor: (isStepRate === true) ? 'rgba(131, 196, 5, 0.3)' : 'rgba(243, 117, 37, 0.3)',
                    lineColor: (isStepRate === true) ? 'rgba(131, 196, 5, 1)' : 'rgba(243, 117, 37, 1)',
                    dashStyle: 'dash',
                    marker: {
                        fillColor: (isStepRate === true) ? 'rgba(131, 196, 5, 1)' : 'rgba(243, 117, 37, 1)'
                    }
                }, {
                    name: 'Protection Amount',
                    data: (dir == 'market-flat' || (dir == 'market-down' && isShield100))
							? [null, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, null]
							: [null, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, null, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, pa1, null],
                    fillColor: 'rgba(114, 210, 236, 0.3)',
                    lineColor: 'rgba(114, 210, 236, 1)',
                    marker: {
                        fillColor: 'rgba(114, 210, 236, 1)'
                    }
                }, {
                    name: 'Index Performance',
                    data: (dir == 'market-flat' || (dir == 'market-down' && isShield100))
							? [null, null, indexPerf1a, indexPerf1a, indexPerf1a, indexPerf1a, null, null, null, null, null, null]
							: [null, null, indexPerf1a, indexPerf1a, indexPerf1a, indexPerf1a, null, null, null, null, null, null, null, indexPerf2a, indexPerf2a, indexPerf2a, indexPerf2a, null, null, null, null, null],
                    fillColor: 'rgba(39, 190, 235, 1)',
                    lineColor: 'rgba(39, 190, 235, 1)',
                    dataLabels: {
                        enabled: true,
                        useHTML: true,
                        verticalAlign: (dir == 'market-up') ? 'top' : 'bottom',
                        formatter: function () {
                            if (this.x == '2' || this.x == '13') return _.template(App.templates.SlsProtectionDataLabelTemplate, {
                                'value': (this.x == '2') ? indexPerf1 : indexPerf2,
                                'label': $('#sls-index').html()
                            });
                            else return null;
                        }
                    },
                    marker: {
                        fillColor: 'rgba(39, 190, 235, 1)'
                    }
                }, {
                    name: 'Your Performance',
                    data: (dir == 'market-flat' || (dir == 'market-down' && isShield100))
							? [null, null, null, null, null, null, yourPerf1a, yourPerf1a, yourPerf1a, yourPerf1a, null, null]
							: [null, null, null, null, null, null, yourPerf1a, yourPerf1a, yourPerf1a, yourPerf1a, null, null, null, null, null, null, null, yourPerf2a, yourPerf2a, yourPerf2a, yourPerf2a, null, null],
                    fillColor: 'rgba(250, 183, 4, 1)',
                    lineColor: 'rgba(250, 183, 4, 1)',
                    dataLabels: {
                        enabled: true,
                        useHTML: true,
                        verticalAlign: (dir == 'market-down') ? 'bottom' : 'top',
                        formatter: function () {
                            if (this.x == '6' || this.x == '17') return _.template(App.templates.SlsProtectionDataLabelTemplate, {
                                'value': (this.x == '6') ? yourPerf1 : yourPerf2,
                                'label': 'Your Performance'
                            });
                            else return null;
                        }
                    },
                    marker: {
                        fillColor: 'rgba(250, 183, 4, 1)'
                    }
                }
				]

            });
        }

    });
});
