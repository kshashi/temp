/**
 * @module view/FeedbackFormView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'submit': 'handleFormSubmit',
			'keyup textarea': 'handleKeyUpInput'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$textarea = this.$el.find('textarea');
			this.$msgContainer = this.$el.find('.msg-container');
			this.$message = $(_.template(App.templates.MessageTemplate, {
				'message': ''
			}));
			this.characterClasses = {
				'comment': /[^\w\s\d\-\.\'\\?\(\)\!,:;]/g
			};

			this.render();

			log('Backbone : Global : FeedbackFormView : Initialized');
		},

		'render': function () {
			this.$msgContainer.append(this.$message);
		},

		'handleKeyUpInput': function (e) {

			var $target = $(e.currentTarget);

			this.sanitizeInput($target);
		},

		'handleFormSubmit': function (e) {
			e.preventDefault();

			this.sanitizeInput(this.$textarea);

			if (this.$textarea.val() === '') {
				this.showErrors();
				return;
			} else {
				this.hideErrors();
			}

			var feedback = $.ajax({
				'url': '/feedback',
				'data': this.$el.serialize(),
				'type': 'post',
				'success': this.feedbackSuccess,
				'error': this.feedbackError
			});
		},

		'sanitizeInput': function ($target) {
			if (_.isUndefined($target)) {
				return;
			}

			var value = $target.val(),
				targetCharacterClass = $target.data('allowedChars'),
				regex;

			if (_.has(this.characterClasses, targetCharacterClass)) {
				regex = this.characterClasses[targetCharacterClass];

				value = value.replace(regex, "");
			} else {
				value = value.replace(/[^\w\d\s]/g, "");
			}

			if ($target.data('maxChars')) {
				var charLimit = $target.data('maxChars');

				value = value.substring(0, charLimit);
			}

			$target.val(value);
		},

		'feedbackSuccess': function (data) {
			this.clearForm();
			this.showStatus('Thank you for your feedback.');
		},

		'feedbackError': function (error) {
			this.showStatus('An error has occurred. Please try again later.');
		},

		'clearForm': function () {
			this.$textarea.val('');
			this.hideErrors();
			this.hideStatus();
		},

		'showErrors': function (error) {
			this.$textarea.addClass('error');
			this.$message.html('Please enter your message.');
			this.$el.addClass('show-messages show-errors');
			this.$msgContainer.addClass('show-message');
		},

		'hideErrors': function () {
			this.$textarea.removeClass('error');
			this.$el.removeClass('show-messages show-errors');
			this.$msgContainer.removeClass('show-message');
			this.$message.html('');
		},

		'showStatus': function (status) {
			this.$el.addClass('show-messages');
			this.$message.html(status);
			this.$msgContainer.addClass('show-message');
		},

		'hideStatus': function (status) {
			this.$el.removeClass('show-messages');
			this.$msgContainer.removeClass('show-message');
			this.$message.html('');
		}

	});

});
