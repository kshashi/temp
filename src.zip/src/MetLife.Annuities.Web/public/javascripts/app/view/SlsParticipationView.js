/**
 * @module view/SlsParticipationView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global')

		return Backbone.View.extend({

			'events': {},

			'initialize': function (options) {
				var view = this;
				_.bindAll(this);
				this.render();
				log('Backbone : View : SlsParticipationView : Initialized');
			},

			'render': function () {
				this.tooltipView = new App.views.TooltipView({
					'el': '#section-content',
					'attributes': {}
				});
			}

		});

});
