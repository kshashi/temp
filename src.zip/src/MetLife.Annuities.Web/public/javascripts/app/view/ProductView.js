/**
 * @module view/ProductView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .create': 'handleFormSubmit'
		},

		'initialize': function (options) {

			_.bindAll(this);

			log('Backbone : View : ProductView : Initialized');
		},

		'render': function () {},

		'handleFormSubmit': function () {
			var view = this;

			view.$el.find('form').submit();
		}

	});

});
