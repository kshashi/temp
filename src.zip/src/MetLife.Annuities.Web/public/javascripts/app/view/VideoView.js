/**
 * @module view/VideoView.js
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'defaults': {
			'height': '420',
			'width': '740',
			'volume': 40
		},

		'events': {
			'click #volume': 'setVolume',
			'click #mute': 'toggleMute',
			'click #play': 'togglePlay',
			'click #progress': 'seek',
			'click #fullscreen': 'toggleFullscreen',
			'mouseover': 'showControls',
			'mouseout': 'hideControls'
		},

		'showControls': function () {
			if (!this.isReady) {
				return;
			}
			this.isHovered = true;
			this.$el.addClass('hover');
		},

		'hideControls': function () {
			if (!this.isReady) {
				return;
			}
			this.isHovered = false;
			this.$el.removeClass('hover');
		},

		'initialize': function (options) {
			_.bindAll(this);

			var view = this;
			view.o = $.extend(true, view.defaults, options);

			clearInterval(App.cache.intervals.bufferInterval);

			// escape key support for full screen mode
			$(document).on('keyup', view.toggleFullscreen);

			Events.bind('load:image', view.stop);
			Events.bind('route:client', view.stop);
			Events.bind('route:page', view.stop);
			Events.bind('route:modal', view.stop);
			Events.bind('route:campaign', view.stop);

			view.bind('end:video', function () {
				clearInterval(App.cache.intervals.bufferInterval);
				view.isPlaying = false;
				view.isEnded = true;
				view.$el.removeClass('playing').addClass('stopped');
				Events.trigger('end:video');
				Events.trigger('progress:video', {
					'client': view.o.client,
					'title': view.o.title,
					'elapsed': 100
				});
			});

			view.bind('play:video', function (e) {
				if (!view.isPlaying) {
					view.isPlaying = true;
					App.cache.intervals.bufferInterval = setInterval(view.updateProgress, 1000);
					view.$el.removeClass('stopped').addClass('playing');
					view.updateControls();
					if (!this.isHovered) {
						view.hideControls();
					}
					Events.trigger('play:video', {
						'client': this.o.client,
						'title': this.o.title
					});
				}

				if (!view.hasPlayed) {
					view.hasPlayed = true;
				}
			});

			view.bind('pause:video', function () {
				clearInterval(App.cache.intervals.bufferInterval);
				view.isPlaying = false;
				view.$el.removeClass('playing');
				Events.trigger('pause:video');
			});

			view.bind('stop:video', function () {
				var view = this;
				clearInterval(App.cache.intervals.bufferInterval);
				view.isPlaying = false;
				if (view.hasPlayed && !view.isEnded) {
					Events.trigger('stop:video', {
						'client': view.o.client,
						'title': view.o.title
					});
				}
			});

			view.bind('buffer:video', function () {
				Events.trigger('buffer:video', {
					'client': this.o.client,
					'title': this.o.title
				});
			});

			view.bind('load:video', view.loadById);

			view.render();

			log('Backbone : VideoView : Initialized');
		},

		'render': function (autoPlay) {
			var view = this;

			view.autoPlay = (_.isUndefined(autoPlay)) ? view.autoPlay : autoPlay;
			view.hasPlayed = false;
			view.isPlaying = false;
			view.isEnded = false;
			view.isReady = false;
			view.isMuted = false;
			view.percentLoaded = 0;
			view.secondsPlayed = 0;
			view.lastBuffered = 0;
			view.prevSecondsPlayed = 0;
			view.playProgress = 0;

			view.$el.html(view.template({
				'id': view.o.title,
				'videoId': view.o.id,
				'height': view.o.height,
				'width': view.o.width,
				'autoPlay': view.autoPlay
			})).addClass('active stopped').siblings().removeClass('active');

			var iframe = $('#player-' + view.o.title)[0];

			view.player = $f(iframe);

			view.player.addEvent('ready', view.onPlayerReady);

			return this;
		},

		'onPlayerReady': function () {
			var view = this,
				color = view.getColorHexValue($('#campaigns .description h3 strong').css('color')),
				trackBuffer = _.debounce(function () {
					view.trigger('buffer:video');
				}, 1000);

			view.$buffer = view.$el.find('#buffer');
			view.$play = view.$el.find('#play');
			view.$volume = view.$el.find('#volume');
			view.$volumeLevel = view.$volume.find('#level');
			view.$elapsedTime = view.$el.find('#elapsed');
			view.$controls = view.$el.find('#controls');
			view.$counter = view.$el.find('#counter');
			view.$duration = view.$el.find('#duration');

			view.player.api('getDuration', function (val) {
				view.videoDuration = val;
				view.updateControls();
			});
			view.player.api('setVolume', view.o.volume / 100);
			view.player.api('setColor', color);

			view.player.addEvent('finish', function () {
				view.trigger('end:video');
			});
			view.player.addEvent('loadProgress', function (val) {
				view.percentLoaded = val.percent;
				view.$buffer.css('width', Math.round(view.percentLoaded * 100) + '%');
			});
			view.player.addEvent('playProgress', function (val) {
				view.prevSecondsPlayed = view.secondsPlayed;
				view.playProgress = val.percent;
				view.secondsPlayed = Math.round(val.seconds * 10) * 10;
				if (view.playProgress > 0 && view.playProgress < 100 && Math.round(view.secondsPlayed / 100) !== Math.round(view.lastBuffered / 100)) {
					if (view.playProgress >= view.percentLoaded || view.secondsPlayed == view.prevSecondsPlayed) {
						trackBuffer();
						view.lastBuffered = view.secondsPlayed;
					}
				}
			});
			view.player.addEvent('play', function () {
				view.trigger('play:video');
			});
			view.player.addEvent('pause', function () {
				view.trigger('pause:video');
			});

			view.isReady = true;
		},

		'getColorHexValue': function (rgb) {
			var view = this;
			var rgbString = rgb; // get this in whatever way.
			var parts = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);

			delete parts[0];
			for (var i = 1; i <= 3; ++i) {
				parts[i] = parseInt(parts[i]).toString(16);
				if (parts[i].length == 1) parts[i] = '0' + parts[i];
			}

			return parts.join('').toUpperCase();
		},

		'loadById': function (id) {
			var view = this;
			if (id === view.o.id) {
				view.player.api('play');
			} else {
				view.stop();
				view.o.id = id;
				delete view.player;
				view.render(true);
			}
			view.$el.addClass('active').siblings().removeClass('active');
		},

		'updateControls': function () {
			var view = this;
			view.$el.find('#duration').html(view.formatTime(view.videoDuration));
			view.updateSharing();
		},

		'updateProgress': function () {
			var view = this;
			view.player.api('getCurrentTime', function (val) {
				var currentTime = val,
					elapsedTime = currentTime / view.videoDuration * 100;
				view.$elapsedTime.css('width', elapsedTime + '%');
				view.$counter.html(view.formatTime(Math.ceil(currentTime)));

				if (elapsedTime < 100) {
					Events.trigger('progress:video', {
						'client': view.o.client,
						'title': view.o.title,
						'elapsed': elapsedTime
					});
				}
			});
		},

		'setVolume': function (e) {
			var view = this;
			if (!view.isReady) {
				return;
			}

			var offset = (e.offsetX == undefined) ? (e.clientX - view.$volume.offset().left) : e.offsetX;
			view.o.volume = Math.round(offset / (view.$volume.width() + 7) * 100);
			view.player.api('setVolume', view.o.volume / 100);
			view.$volumeLevel.css('width', view.o.volume + '%');
		},

		'toggleMute': function () {
			var view = this;
			if (!view.isReady) {
				return;
			}

			if (view.isMuted) {
				view.player.api('setVolume', view.o.volume / 100);
				view.$volumeLevel.css('width', view.o.volume + '%');
				view.isMuted = false;
			} else {
				view.player.api('setVolume', 0);
				view.$volumeLevel.css('width', '0%');
				view.isMuted = true;
			}
		},

		'stop': function () {
			if (!this.isReady) {
				return;
			}

			this.player.api('pause');
			this.trigger('stop:video');
		},

		'togglePlay': function (e) {
			if (!this.isReady) {
				return;
			}

			if (this.isPlaying) {
				this.player.api('pause');
			} else {
				this.player.api('play');
			}
		},

		'seek': function (e) {
			var view = this;
			if (!view.isReady) {
				return;
			}
			var offset = view.normalizeEvent(e);
			var ratio = offset.offsetX / ($('#progress').width() + 7);
			var seek = Math.round(view.videoDuration * ratio);
			view.$elapsedTime.css('width', ratio * 100 + '%');
			view.$counter.html(view.formatTime(seek));
			view.player.api('seekTo', seek);

			Events.trigger('seek:video', {
				'client': view.o.client,
				'title': view.o.title,
				'seek': view.formatTime(seek)
			});
		},

		'normalizeEvent': function (event) {
			if (!event.offsetX) {
				event.offsetX = (event.pageX - $(event.target).offset().left);
				event.offsetY = (event.pageY - $(event.target).offset().top);
			}
			return event;
		},

		'formatTime': function (second, hour, minute) {
			if (second > 3600) {
				var ore = Math.floor(second / 3600);
				if (ore < 10) {
					ore = '0' + ore;
				}
				var rest = Math.ceil(second % 3600);
				var format = this.formatTime(rest, ore);
			} else if (second > 60) {
				var minuti = Math.floor(second / 60);
				if (minuti < 10) {
					minuti = '0' + minuti;
				}
				var rest = Math.ceil(second % 60);
				var format = this.formatTime(rest, ore, minuti);
			} else if (second < 60) {
				if (!hour) {
					hour = '00';
				}
				if (!minute) {
					minute = '00';
				}
				if (!second) {
					second = '00';
				} else {
					second = Math.round(second);
					if (second < 10) {
						second = '0' + second;
					}
				}
				var format = minute + ':' + second;
			}
			return format;
		},

		'updateSharing': function () {
			var view = this;
			if (view.subviews.shareView == undefined) {
				view.subviews.shareView = new App.views.ShareView({
					'el': view.$el.find('#share'),
					'model': new App.models.ShareModel({
						'shareCopy': 'Scoured the CP+B Library. Nothing about the alien base under Antarctica, but I did find this:',
						'networks': {
							'Facebook': {
								'appendUrlToDescription': true,
								'uiVars': {
									'app_id': App.config.get('facebook_app_id'),
									'name': view.$el.data('client') + ' - ' + view.$el.data('campaign'),
									'picture': window.location.protocol + "//" + window.location.host + '/images/icon.cpb200x200.png',
									'caption': 'CP+B'
								}
							}
						}
					})
				});
			}
		},

		'toggleFullscreen': function (e) {
			if (!this.isReady) {
				return;
			}
			var $body = $(document.body);

			if ((typeof e.keyCode != 'undefined' && !($body.hasClass('fullscreen'))) || (typeof e.keyCode != 'undefined' && e.keyCode != 27)) {
				return;
			}

			if ($body.hasClass('fullscreen')) {
				$body.removeClass('fullscreen');
			} else {
				$body.addClass('fullscreen video');
			}
		},

		'onClose': function () {
			$(document).off('keyup');
			this.isReady = false;
			delete this.player;
		}
	});
});
