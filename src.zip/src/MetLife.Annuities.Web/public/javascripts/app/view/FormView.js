/**
 * @module view/FormView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	require('dropkick');

	return Backbone.View.extend({

		'events': {
			'blur .required': 'handleBlurValidate',
			'blur .min-char': 'handleBlurValidate',
			'keyup input': 'handleKeyUpInput',
			'keyup textarea': 'handleKeyUpInput',
			'change .more-details': 'handleChangeMoreDetails',
			'change .less-details': 'handleChangeLessDetails',
			'click .add-field': 'handleClickAddField',
			'submit': 'handleFormSubmit'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.characterClasses = {
				'comment': /[^\w\s\d\-\.\',]/g,
				'currency': /[^\d\.]/g,
				'email': /[^\w\d\-_.@]/g,
				'text-strict': /[^A-Za-z\s\']/g,
				'text-hyphenated': /[^A-Za-z\s\-\.\']/g,
				'alpha-numeric': /[^\w\s\d\-\.\']/g,
				'number': /[^\d]/g,
				'number-month': /[^\d]/g,
				'number-day': /[^\d]/g,
				'number-year': /[^\d]/g,
				'phone-number': /[^\d\(\)\.\-\s]/g,
				'password':'',
			};

			this.render();

			log('Backbone : View : FormView : Initialized');
		},

		'render': function () {

			var view = this;

			$('.radio-slider').each(function () {
				new App.views.RadioSliderView({
					'el': $(this)
				});
			});
			$('.pretty-checkboxes').each(function () {
				new App.views.PrettyCheckboxesView({
					'el': $(this)
				});
			});
			$('.pretty-radios').each(function () {
				new App.views.PrettyRadiosView({
					'el': $(this)
				});
			});
			$('.incremental-input').each(function () {
				new App.views.IncrementalInputView({
					'el': $(this)
				});
			});
			$('.hidden-form-container').each(function () {
				new App.views.HiddenFormView({
					'el': $(this),
					'form': view.$el
				});
			});

			this.$inputs = this.$('input, textarea');

			this.setRequiredFields();

			this.checkMoreDetails();

			App.on('customSelect:change', this.handleChangeCustomSelect);
		},

		'handleBlurValidate': function (e) {
			var $target = $(e.currentTarget),
				valid = true;

			if ($target.hasClass('min-char') && $target.val().length > 0 && valid) {
				valid = this.isMinChar($target);
			}

			if ($target.hasClass('required') && valid) {
				valid = !this.isEmpty($target);
			}

			if ($target.hasClass('valid-email') && valid) {
				valid = /^\S+@\S+\.\S+$/.test($target.val());
			}

			if (!valid) {
				this.addError($target);
			} else {
				this.removeError($target);
			}

		},

		'handleChangeCustomSelect': function (value, label, id) {

			// make sure custom select is part of view.
			var $select = this.$('#' + id);

			if ($select.length) {
				if (this.isEmpty($select)) {
					this.addError($select);
				} else {
					this.removeError($select);
				}
			}
		},

		'handleKeyUpInput': function (e) {

			var $target = $(e.currentTarget),
				id = $target.parent().attr('id'),
				tab = parseInt($target.attr('tabindex')),
				maxCharacters = $target.attr('data-max-chars'),
				charCount = $target.val().length;

			this.sanitizeInput($target);

			if (id === 'field-client-dob' && charCount >= maxCharacters && tab != 6) {
				tab += 1;
				$('.tab' + tab).focus();
			}
		},

		'handleChangeMoreDetails': function (e) {
			var $target = $(e.currentTarget);

			this.moreDetails($target);
		},

		'handleChangeLessDetails': function (e) {
			var $target = $(e.currentTarget);

			this.lessDetails($target);
		},

		'handleClickAddField': function (e) {
			e.preventDefault();

			var $target = $(e.currentTarget),
				$clonesContainer = $(_.template(App.templates.FormCloneTemplate, {})),
				fields = $target.data('cloneFields').split(' '),
				cloneCount = $target.siblings('.clone').length,
				cloneMax = $target.data('cloneMax');

			if (cloneCount === cloneMax) {
				return;
			}

			_.each(fields, function (field) {
				var $clone = $(field).clone(),
					cloneNameBase = $clone.data('cloneName').split('*'),
					cloneName = cloneNameBase[0] + (cloneCount + 1) + cloneNameBase[1],
					cloneId = cloneNameBase[0] + (cloneCount + 1) + cloneNameBase[1];

				cloneId = $.trim(cloneId.replace(/[\[\]\.]/g, ' ')).replace(/\s+/g, '-');

				$clone.attr('id', cloneId).attr('name', cloneName).val('').removeClass('required error');

				$clonesContainer.append($clone).queue(function () {});

				if ($clone.hasClass('custom-select')) {
					$clone.delay().queue(function () {
						$(this).dropkick({
							'startSpeed': 0,
							'change': function (value, label) {
								var name = $(this).attr('name');
								App.trigger(name + ':select:change', value, label);
							}
						}).dequeue();
					});
				}
				if ($clone.hasClass('min-char')) {
					$clonesContainer.prepend($clone)
				}
			});

			$target.before($clonesContainer);

			if (cloneCount + 1 === cloneMax) {
				$target.addClass('hidden');
			}
		},

		'handleFormSubmit': function (e) {
			var view = this,
				dateGroup = {};

			this.$inputs.each(function () {
				var $input = $(this);
				if ($input.attr('data-skip-sanitize') != 'true') view.sanitizeInput($input);
				if ($input.data('allowedChars') == 'number-month') dateGroup.month = $input;
				else if ($input.data('allowedChars') == 'number-day') dateGroup.day = $input;
				else if ($input.data('allowedChars') == 'number-year') dateGroup.year = $input;
			});

			if (dateGroup.month && dateGroup.day && dateGroup.year) {
				var dt = new Date(parseInt(dateGroup.year.val()), parseInt(dateGroup.month.val()) - 1, parseInt(dateGroup.day.val()), 1, 0, 0, 0);
				var now = new Date();
				var yr = parseInt(dateGroup.year.val());
				if (yr < 1753 || yr > now.getFullYear()) view.addError(dateGroup.year);
				else if (!view.isDateValid(parseInt(dateGroup.day.val()), parseInt(dateGroup.month.val()) - 1, dateGroup.year.val())) {
					view.addError(dateGroup.month);
					view.addError(dateGroup.day);
					view.addError(dateGroup.year);
				} else {
					view.removeError(dateGroup.month);
					view.removeError(dateGroup.day);
					view.removeError(dateGroup.year);
				}
			}
			
			this.validateConfirmMatch();
			this.validateUniqueGroups();

			this.$errors = this.$el.find('.error');

			if (this.$errors.length) {
				e.preventDefault();
				this.$el.addClass('show-errors');
				$('html, body').animate({
					'scrollTop': this.$errors.first().offset().top - 50 + 'px'
				});
			}
		},
		
		'validateConfirmMatch': function () {
			var view = this;
			this.$el.find('.confirm-match').each(function(){
				var $match1 = $(this);
				var $match2 = $('#' + $match1.attr('data-confirm-match'));
				if($match1.val() != $match2.val()) {
					view.addError($match1);
					view.addError($match2);
				} else {
					view.removeError($match1);
					view.removeError($match2);
				}
			});
		},
		
		'validateUniqueGroups': function () {
			var view = this,
				used = {};
			this.$el.find('.unique-group').each(function(){
				var $input = $(this);
				var group = $input.attr('data-unique-group');
				var val = $input.val();
				if(val != '') {
					if(!used[group]) used[group] = {};
					if(!used[group][val]) {
						used[group][val] = $input;
						view.removeError($input);
					} else {
						view.addError($input);
						view.addError(used[group][val]);
					}
				}
			});
		},

		'isDateValid': function (d, m, y) {
			return m >= 0 && m < 12 && d > 0 && d <= this.daysInMonth(m, y);
		},

		'daysInMonth': function (m, y) { // m is 0 indexed: 0-11
			switch (m) {
				case 1:
					return (y % 4 == 0 && y % 100) || y % 400 == 0 ? 29 : 28;
				case 8:
				case 3:
				case 5:
				case 10:
					return 30;
				default:
					return 31
			}
		},

		'isEmpty': function ($target) {
			if ($target.val() === '') {
				return true;
			}

			return false;
		},

		'isMinChar': function ($target) {
			if ($target.val().length < $target.data('minChars')) {
				return false;
			}

			return true;
		},

		'addError': function ($target) {
			var $errorContainer = $target.closest('.error-container');

			$target.addClass('error');
			$errorContainer.addClass('show-error-msg');

			if ($target.hasClass('custom-select')) {
				if($('#dk_container_' + $target.attr('name')).length > 0) $('#dk_container_' + $target.attr('name')).addClass('dk_error');
				else $('#dk_container_' + $target.attr('id')).addClass('dk_error');
			}
		},

		'removeError': function ($target) {
			var $errorContainer = $target.closest('.error-container');

			$target.removeClass('error');

			if ($target.hasClass('custom-select')) {
				if($('#dk_container_' + $target.attr('name')).length > 0) $('#dk_container_' + $target.attr('name')).removeClass('dk_error');
				else $('#dk_container_' + $target.attr('id')).removeClass('dk_error');
			}

			if (!$errorContainer.find('.error').length) {
				$errorContainer.removeClass('show-error-msg');
			}
		},

		'checkMoreDetails': function () {
			var view = this;
			this.$el.find('.more-details').each(function () {
				view.moreDetails($(this));
			});
		},

		'lessDetails': function ($target) {
			var $details = $target.closest('.field').find('.details');

			if ($target.is(':checked')) {
				$details.removeClass('active');
				$details.find('input').each(function () {
					$(this).attr('disabled', true);
				});
			}
		},

		'moreDetails': function ($target) {
			var $details = $target.closest('.field').find('.details');

			if ($target.is(':checked')) {
				$details.addClass('active');
				$details.find('input').each(function () {
					$(this).attr('disabled', false);
				});
			}
		},

		'sanitizeInput': function ($target) {
			if (_.isUndefined($target)) {
				return;
			}

			var value = $target.val(),
				origVal = value,
				targetCharacterClass = $target.data('allowedChars'),
				regex;

			if (_.has(this.characterClasses, targetCharacterClass)) {
				regex = this.characterClasses[targetCharacterClass];

				value = value.replace(regex, "");
			} else {
				value = value.replace(/[^\w\d\s]/g, "");
			}

			if ($target.data('maxChars')) {
				var charLimit = $target.data('maxChars');

				value = value.substring(0, charLimit);
			}

			if ($target.data('allowedChars') == 'number-month') {
				if (parseInt(value) < 1) value = '';
				if (parseInt(value) > 12) value = '';
			} else if ($target.data('allowedChars') == 'number-day') {
				if (parseInt(value) < 1) value = '';
				if (parseInt(value) > 31) value = '';
			} else if ($target.data('allowedChars') == 'number-year') {
				if (parseInt(value) < 1) value = '';
				if (parseInt(value) > 9999) value = '';
			}

			if(origVal != value) $target.val(value);
		},

		'setRequiredFields': function () {

			var view = this;

			this.$requiredFields = this.$el.find('.required');

			this.$requiredFields.each(function () {
				// Add default error class to required fields to prevent form submission.
				if (view.isEmpty($(this))) {
					view.addError($(this));
				}
			});
		}

	});

});
