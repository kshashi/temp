/**
 * @module view/EditClientSettingsView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'blur input': 'handleBlurInput',
			'click .hidden-form-show': 'handleClickHiddenFormShow',
			'click .hidden-form-cancel': 'handleClickHiddenFormHide',
			'click .hidden-form-submit': 'handleClickHiddenFormSubmit',
			'click .remove': 'handleClickRemoveItem'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$hiddenForm = this.$el.find('.hidden-form');
			this.$hiddenFormContent = this.$el.find('.hidden-form-content');
			this.$hiddenInputs = this.$hiddenForm.find('input');
			this.hiddenFormTemplate = _.template(App.templates[this.$el.data('hiddenFormTemplate')]);

			this.render();

			log('Backbone : Global : EditClientSettingsView : Initialized');
		},

		'render': function () {
			var view = this;

			this.checkEmpty();

			this.options.form.submit(function () {
				view.disableHiddenInputs();
			});
		},

		'handleBlurInput': function (e) {
			var $target = $(e.currentTarget);

			if ($target.val() !== '') {
				this.removeError($target);
			}
		},

		'handleClickHiddenFormShow': function (e) {
			e.preventDefault();

			this.enableHiddenInputs(this.$hiddenForm);

			this.$el.addClass('active');
		},

		'handleClickHiddenFormHide': function (e) {
			e.preventDefault();

			if (!this.checkEmpty()) {
				this.$el.removeClass('active');
			}

		},

		'handleClickHiddenFormSubmit': function (e) {
			e.preventDefault();

			var view = this,
				$target = $(e.currentTarget),
				templateVars = {
					'index': this.$hiddenFormContent.children().length
				};

			this.$hiddenInputs.each(function () {
				if ($(this).val() === '') {
					view.addError($(this));
				} else {
					templateVars[$(this).data('templateVar')] = $(this).val();
					view.removeError($(this));
				}
			});

			if (this.$el.find('.hidden-error').length) {
				this.$el.addClass('show-errors');
			} else {
				this.disableHiddenInputs();

				this.$hiddenFormContent.append(this.hiddenFormTemplate(templateVars));

				this.$el.removeClass('active empty show-errors');
			}
		},

		'handleClickRemoveItem': function (e) {
			e.preventDefault();

			var $target = $(e.currentTarget);

			$target.parent().remove();

			this.checkEmpty();
		},

		'disableHiddenInputs': function () {
			this.$hiddenInputs.each(function () {
				$(this).val('').attr('disabled', true);
			});
		},

		'enableHiddenInputs': function () {
			this.$hiddenInputs.each(function () {
				$(this).val('').attr('disabled', false);
			});
		},

		'checkEmpty': function () {
			if (this.$hiddenFormContent.children().length === 0) {
				this.$el.addClass('active empty');
				this.enableHiddenInputs();
				return true;
			} else {
				return false;
			}
		},

		'addError': function ($target) {
			var $errorContainer = $target.closest('.error-container');

			$target.addClass('hidden-error');
			$errorContainer.addClass('show-error-msg');
		},

		'removeError': function ($target) {
			var $errorContainer = $target.closest('.error-container');

			$target.removeClass('hidden-error');

			if (!$errorContainer.find('.hidden-error').length) {
				$errorContainer.removeClass('show-error-msg');
			}
		}

	});

});
