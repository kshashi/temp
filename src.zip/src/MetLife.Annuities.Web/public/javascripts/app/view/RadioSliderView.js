/**
 * @module view/RadioSliderView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'focus': 'handleSliderFocus',
			'blur': 'handleSliderBlur',
			'click .segment': 'handleSegmentClick',
			'mousedown .toggle': 'handleToggleClick',
			'mouseup': 'handleToggleRelease',
			'mouseleave': 'handleToggleRelease',
			'touchstart .toggle': 'handleToggleClick',
			'touchend': 'handleToggleRelease'
		},

		'initialize': function (options) {

			_.bindAll(this);

			var view = this;

			this.$radios = this.$el.find('input[type="radio"]');
			this.$radioSlider = $(_.template(App.templates.RadioSliderTemplate, {
				'segments': this.$radios.length
			}));
			this.$segments = this.$radioSlider.find('.segment'), this.$toggle = this.$radioSlider.find('.toggle');

			this.isMouseDown = false;
			this.originMouseX = 0;

			this.$el.closest('form').on('reset', function () {
				view.resetRadios();
			});

			this.render();

			log('Backbone : View : RadioSliderView : Initialized');
		},

		'render': function () {
			var $checked = this.$el.find('input[checked="checked"]');

			this.$el.prepend(this.$radioSlider);
			this.setSliderWidth();
			this.saveRadioDefaults();
			if ($checked.length) {
				var index = this.$radios.index($checked);
				this.snapToggle(index);
			} else {
				this.snapToggle(2);
			}
		},

		'handleSliderFocus': function () {
			this.$el.on('keyup.focus', this.handleKeyPress);
			this.$el.addClass('focus');
		},

		'handleSliderBlur': function () {
			this.$el.off('keyup.focus');
			this.$el.removeClass('focus');
		},

		'handleKeyPress': function (e) {
			var $target = $(e.currentTarget);
			switch (e.keyCode) {
				case 37:
					// Left Arrow
				case 38:
					// Up Arrow
					this.togglePrev();
					return false;
					break;
				case 39:
					// Right Arrow
				case 40:
					// Down Arrow
					this.toggleNext();
					return false;
					break;
			}
		},

		'togglePrev': function () {
			var index = this.$radios.filter(':checked').index();

			if (index > 0) {
				this.snapToggle(index - 1);
			} else {
				this.snapToggle(this.$radios.length - 1);
			}
		},

		'toggleNext': function () {
			var index = this.$radios.filter(':checked').index();

			if (index < this.$radios.length - 1) {
				this.snapToggle(index + 1);
			} else {
				this.snapToggle(0);
			}
		},

		'handleToggleClick': function (e) {
			e.preventDefault();

			this.$toggle.addClass('drag');

			this.isMouseDown = true;
			this.originMouseX = (Modernizr.touch) ? e.originalEvent.touches[0].clientX : e.pageX;
			this.originToggleLeft = this.$toggle.position().left;

			this.$el.on('mousemove', this.handleToggleDrag);
			this.$el.on('touchmove', this.handleToggleDrag);
		},

		'handleSegmentClick': function (e) {
			e.preventDefault();

			this.snapToggle($(e.currentTarget).index());
		},

		'handleToggleRelease': function (e) {
			this.isMouseDown = false;

			this.$toggle.removeClass('drag');

			this.$el.off('mousemove', this.handleToggleDrag);
			this.$el.off('touchmove', this.handleToggleDrag);

			this.snapToggle();
		},

		'handleToggleDrag': function (e) {
			var mouseX = (Modernizr.touch) ? e.originalEvent.touches[0].clientX : e.pageX,
				deltaMouseX = mouseX - this.originMouseX,
				toggleLeft = this.$toggle.position().left,
				newToggleLeft = toggleLeft + deltaMouseX;

			if (newToggleLeft < 0) {
				this.$toggle.css({
					'left': 0
				});
			} else if (newToggleLeft + this.toggleWidth > this.sliderWidth) {
				this.$toggle.css({
					'left': this.sliderWidth - this.toggleWidth
				});
			} else {
				this.$toggle.css({
					'left': toggleLeft + deltaMouseX
				});
			}

			this.originMouseX = mouseX;
		},

		'setSliderWidth': function () {
			this.segmentWidth = this.$segments.outerWidth(true);
			this.sliderWidth = this.segmentWidth * this.$segments.length;
			this.toggleWidth = this.$toggle.width();
			this.$radioSlider.css({
				'width': this.sliderWidth
			});
		},

		'snapToggle': function (segment) {
			var toggleLeft = this.$toggle.position().left,
				toggleSnapLeft = 0,
				nearestSegment = (!_.isUndefined(segment)) ? segment : Math.round(toggleLeft / this.segmentWidth),
				fineTune = -2;

			if (this.$segments.eq(nearestSegment).hasClass('first')) {
				toggleSnapLeft = 0;
			} else if (this.$segments.eq(nearestSegment).hasClass('last')) {
				toggleSnapLeft = (nearestSegment * this.segmentWidth) + (this.segmentWidth - this.toggleWidth);
			} else {
				toggleSnapLeft = (nearestSegment * this.segmentWidth) + ((this.segmentWidth / 2) - (this.toggleWidth / 2)) + fineTune;
			}

			this.$toggle.css({
				'left': toggleSnapLeft
			});

			this.updateSourceRadios(nearestSegment);
		},

		'saveRadioDefaults': function () {
			this.$radios.filter(':checked').data('defaultState', 'checked');
		},

		'resetRadios': function () {
			var view = this;
			this.$radios.each(function () {
				if ($(this).data('defaultState') === 'checked') {
					view.updateSourceRadios($(this));
					view.snapToggle(view.$radios.index($(this)));
				}
			});
		},

		'updateSourceRadios': function (selected) {
			var $selectedRadio = this.$radios.eq(selected);
			if (!$selectedRadio.is(':checked')) {
				$selectedRadio.attr('checked', true);
			}
		}

	});

});
