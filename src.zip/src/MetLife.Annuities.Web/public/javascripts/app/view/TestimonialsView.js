/**
 * @module view/TestimonailsView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #video-list a': 'acitivateNavItem',
			'click #considerations-nav .view-carousel': 'showConsiderCarousel',
			'click .close': 'hideConsiderCarousel',
			'click .video-play-button': 'initVideoView',
			'click .video': 'initVideoView',
			'click .testimonials-cta': 'handleReloadVideos'
		},

		'initialize': function (options) {
			var view = this;
			_.bindAll(this);

			view.$videoWrapper = $('.video-wrapper');
			view.$contentWrapper = $('.content-wrapper');
			view.$considerationsWrapper = $('.considerations-wrapper');
			view.$considerationsNav = $('#considerations-nav');
			view.$considerationsNavLink = $('#considerations-nav .view-carousel');
			view.$considerationsCarousel = $('#considerations-carousel');
			view.$videoListWrapper = $('#video-list-wrapper');
			view.$videoList = $('#video-list');
			view.$videoDescription = $('.video-description');
			this.render();
			App.on('playlist:ended', view.showConsiderPanel);
			log('Backbone : View : TestimonialsView : Initialized');
		},

		'render': function () {

			var view = this;

			App.on('resources:videos:videoView', this.initVideoView);
			App.on('resources:playlist:load', this.renderPlaylist);

			view.resourcesRouter = new App.routers.ResourcesRouter();
			view.renderCarousel();

			$('#disclaimer_video').show();

		},

		'transitionView': function (el1, el2) {
			el1.fadeOut(200, function () {
				el2.fadeIn(200);
			});
		},

		'showConsiderPanel': function () {
			var view = this;
			view.$contentWrapper.removeClass('video-view');
			view.$videoList.removeClass('video-view');
			view.transitionView(view.$videoWrapper, view.$considerationsWrapper);
			view.$videoListWrapper.animate({
				'height': 116
			}, 500)
		},

		'acitivateNavItem': function (e) {
			var $this = $(e.currentTarget);
			$this.addClass('selected').parent().siblings().find('a').removeClass('selected');
		},

		'renderCarousel': function () {
			var view = this;
			view.carouselView = new App.views.CarouselView({
				'el': '.considerations-wrapper',
				'pagination': true
			});

		},

		'showConsiderCarousel': function (e) {
			var view = this;
			e.preventDefault();
			view.transitionView(view.$considerationsNav, view.$considerationsCarousel);
		},

		'hideConsiderCarousel': function (e) {
			var view = this;
			e.preventDefault();

			view.transitionView(view.$considerationsCarousel, view.$considerationsNav);
		},

		'renderPlaylist': function (id) {
			var view = this;

			view.brightcovePlaylistPlayerView = new App.views.BrightcovePlaylistPlayerView({
				'el': view.$videoWrapper,
				'id': 'brightcove-video',
				'parentView': view,
				'playlistId': id
			});
		},

		'initVideoView': function () {
			var view = this;
			view.$contentWrapper.addClass('video-view');
			view.$videoWrapper.show();
			view.$videoList.addClass('video-view');

			$(view.$considerationsWrapper, view.$videoDescription).fadeOut(200, function () {
				view.$videoListWrapper.animate({
					'height': 69
				}, 500, function () {
					view.$videoWrapper.css('z-index', 3);
				});
			});
		},
		'handleReloadVideos': function () {

			var view = this;

			App.trigger('reset:videos');

			view.initVideoView();

		}
	});

});
