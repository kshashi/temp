/**
 * @module view/SlsRecommendedView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {},

		'initialize': function (options) {
			var view = this;
			_.bindAll(this);
			// Set SLS Model
			this.slsData = new App.models.SlsModel();
			this.slsAnnuity = new App.models.SlsAnnuityModel(slsAnnuity);
			this.slsOptions = this.slsAnnuity.getOptionsCollection();
			this.render();
			log('Backbone : View : SlsRecommendedView : Initialized');
		},

		'render': function () {
			$('#recommended-option').html(_.template(App.templates.SlsRecommendedTemplate, {
				'products': this.slsData.get('products'),
				'indexes': this.slsData.get('indexes'),
				'annuity': this.slsAnnuity,
				'options': this.slsOptions
			}));
		}

	});

});
