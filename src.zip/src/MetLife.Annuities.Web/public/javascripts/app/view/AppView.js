/**
 * @module view/AppView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click #add-client-nav .not_visited': 'handleSubNav'
		},

		'initialize': function (options) {

			_.bindAll(this);

			var view = this,
				feedbackTabView, clientFormView, feedbackFormView, finishHypotheticalView, chartDetailView, testimonialsView, resourcesView, activityView, tooltipsView, savedAnnuityView, applicationView, productView, gmibView, addClientView, clientFullView, personaView, editClientSettingsView, financialAdvisorView, clientView, activityView, personaCarousel, modalPopUpView, helpNavView, helpRouter, photoView, slsSetupView, slsRecommendedView, slsProtectionView, slsParticipationView, slsSummaryView, slsOptionsPartialView, valueView, addClientCommon, addClientBasic, addClientProduct, introView, advisorEmailView;

			view.initCustomSelect();
			view.initFeedbackForm();

			if(!$('body').hasClass('is-client')) {
				feedbackTabView = new App.views.FeedbackTabView({
					'el': '#section-content'
				});
			}

			if ($('form').length) {
				clientFormView = new App.views.FormView({
					'el': 'form'
				});
			}

			$('.login-form').each(function () {
				if($(this).attr('data-formview') != 'true') {
					new App.views.LoginFormView({
						'el': $(this)
					});
				}
			});

			if ($('.finish-hypo').length) {
				finishHypotheticalView = new App.views.FinishHypotheticalView({
					'el': '#section-content'
				});
			}

			if ($('#section-charts').length) {
				chartDetailView = new App.views.ChartDetailView({
					'el': '#section-charts',
					'attributes': {
						'flagView': new App.views.FollowUpFlagView({
							'el': '#section-charts',
							'attributes': {
								'flagContainer': '#chart-container',
								'type': 'seriesva'
							}
						})
					}
				});
			}

			if ($('#section-sls-setup').length) {
				slsSetupView = new App.views.SlsSetupView({
					'el': '#section-sls-setup'
				});
			}

			if ($('#section-sls-recommended').length) {
				slsRecommendedView = new App.views.SlsRecommendedView({
					'el': '#section-sls-recommended'
				});
			}

			if ($('#section-sls-protection').length) {
				slsProtectionView = new App.views.SlsProtectionView({
					'el': '#section-sls-protection',
					'attributes': {
						'flagView': new App.views.FollowUpFlagView({
							'el': '#section-sls-protection',
							'attributes': {
								'flagContainer': '#valid-flag-area',
								'type': 'sls'
							}
						})
					}
				});
				slsOptionsPartialView = new App.views.SlsOptionsPartialView({
					'el': '#section-sls-protection',
					'attributes': {
						'optionSelector': true
					}
				});
			}

			if ($('#section-sls-participation').length) {
				slsParticipationView = new App.views.SlsParticipationView({
					'el': '#section-sls-participation'
				});
				slsOptionsPartialView = new App.views.SlsOptionsPartialView({
					'el': '#section-sls-participation',
					'attributes': {
						'optionSelector': false
					}
				});
			}

			if ($('#section-sls-summary').length) {
				slsSummaryView = new App.views.SlsSummaryView({
					'el': '#section-sls-summary'
				});
				slsOptionsPartialView = new App.views.SlsOptionsPartialView({
					'el': '#section-sls-summary',
					'attributes': {
						'optionSelector': false
					}
				});
			}

			if ($('.testimonials').length) {
				testimonialsView = new App.views.TestimonialsView({
					'el': '.testimonials'
				});
			}

			if ($('.intro-wrapper').length) {
				introView = new App.views.IntroView({
					'el': '.intro-wrapper'
				});
			}

			if ($('#section-products').length) {
				productView = new App.views.ProductView({
					'el': '#section-products'
				})
			}

			if ($('.gmib-wrapper').length) {
				gmibView = new App.views.GMIBView({
					'el': '.gmib-wrapper'
				})
			}

			if ($('.client-resources').length) {
				resourcesView = new App.views.ResourcesView({
					'el': '.client-resources'
				});
			}

			if ($('.client-activity').length) {
				activityView = new App.views.ActivityView({
					'el': '#section-activity'
				});
			}

			if ($('#section-client-full').length) {
				clientFullView = new App.views.ClientFullView({
					'el': '#section-client-full'
				});
			}
			if ($('#section-saved-annuities').length) {
				savedAnnuityView = new App.views.SavedAnnuityView({
					'el': '#section-saved-annuities'
				});
			}

			if ($('#section-applications').length) {
				applicationView = new App.views.ApplicationView({
					'el': '#section-applications'
				});
			}

			if ($('#add-photo-wrapper').length) {
				photoView = new App.views.PhotoView({
					'el': '#add-photo-wrapper'
				});
			}

			$('.video-modal').on('click', function (e) {
				e.preventDefault();
				modalPopUpView = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'VideoModalTemplate'
				});
			})

			if ($('#section-addclient-persona').length) {
				personaView = new App.views.PersonaView({
					'el': '#section-addclient-persona'
				});
				personaCarousel = new App.views.CarouselView({
					'el': '.persona-carousel-wrapper',
					'pagination': false,
					'visible': 5
				});
			}

			if ($('#section-financial-advisors').length) {
				financialAdvisorView = new App.views.FinancialAdvisorView({
					'el': '#section-financial-advisors'
				});
			}

			if ($('#section-clients').length) {
				clientView = new App.views.ClientView({
					'el': '#section-clients'
				});
            }
            
			if ($('.client-activity').length) {
				activityView = new App.views.ActivityView({
					'el': '#section-activity'
				});
			}

			$('.faq-accordion').each(function () {
				var accordionView = new App.views.AccordionView({
					'el': $(this)
				});
			});

			if ($('.advisors-help').length) {
				helpNavView = new App.views.HelpNavView({
					'el': '#section-content'
				});

				// Load router last to trigger routes on deep link
				helpRouter = new App.routers.HelpRouter();
			}
			if ($('#section-addclient-basic').length) {
				addClientBasic = new App.views.AddClientBasicView({
					'el': '#section-addclient-basic'
				});
			}
			if ($('#section-addclient-financial').length) {
				addClientCommon = new App.views.AddClientCommonView({
					'el': '#section-addclient-financial'
				});
			}
			if ($('#section-addclient-product').length) {
				addClientProduct = new App.views.AddClientProductView({
					'el': '#section-addclient-product'
				});
			}
			if ($('#section-addclient-email').length) {
				addClientCommon = new App.views.AddClientCommonView({
					'el': '#section-addclient-email'
				});
			}
			if ($('#advisor-email').length) {
				advisorEmailView = new App.views.AdvisorEmailView({
					'el': '#advisor-email'
				});
			}

			log('Backbone : Global : AppView : Initialized');
		},

		'initCustomSelect': function () {
			$('.custom-select').each(function () {
				$(this).dropkick({
					'startSpeed': 0,
					'change': function (value, label) {
						var name = $(this).attr('name');
						App.trigger(name + ':customSelect:change', value, label, $(this).attr('id'));
						App.trigger('customSelect:change', value, label, $(this).attr('id'));
					}
				});
			});
			$(document.body).on('mouseleave', '.dk_container', function () {
				$(this).attr('data-mouse', 'mouseleave');
				var $this = $(this);
				if($this.hasClass('dk_open')) {
					setTimeout(function () {
						if($this.attr('data-mouse') != 'mouseenter') $this.removeClass('dk_open');
					}, 2000);
				}
			});
			$(document.body).on('mouseenter', '.dk_container', function () {
				$(this).attr('data-mouse', 'mouseenter');
			});
		},

		'initFeedbackForm': function () {
			$('.feedback-form').each(function () {
				new App.views.FeedbackFormView({
					'el': $(this)
				});
			});
		},
		'handleSubNav': function (e) {

			e.preventDefault();

		}


	});

});
