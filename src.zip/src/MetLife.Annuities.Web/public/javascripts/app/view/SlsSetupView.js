/**
 * @module view/SlsSetupView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global')

		return Backbone.View.extend({

			'events': {
				'click #sls-add': 'addOptionRow',
				'blur #sls-investment': 'initialInvestmentChange',
				'change #sls-name': 'slsNameChange',
				'keyup #sls-name': 'slsNameChange',
				'click #sls-save': 'saveSlsOptions',
				'click #sls-learn-toggle': 'toggleIndexInfo',
				'click #form-cancel': 'cancelForm'
			},

			'initialize': function (options) {
				var view = this;
				_.bindAll(this);
				// Set SLS Model
				this.slsData = new App.models.SlsModel();
				// Template for each SLS option
				this.optionTemplate = App.templates.SlsSetupOptionTemplate;
				// Since user can add and delete, we'll keep a sequence for form element IDs
				this.optionIdSeq = 0;
				// Users can add up to 10 options
				this.optionMax = 10;
				// The product drop down doesn't change, so store select options in variable to add to template on render'
				this.productsSelect = _.template(App.templates.SlsSetupProductSelectTemplate, {
					'products': this.slsData.get('products')
				});
				this.render();
				log('Backbone : View : SlsSetupView : Initialized');
			},

			'render': function () {
				// Add first option on page load
				this.addOptionRow();
				// Render the index disclosure info table
				var products = this.slsData.get('products');
				var termLengths = this.slsData.get('termLengths');
				var table = $('#slsIndexInfoTable');
				var colWidth = (100 / (products.length + 1)) + '%';
				table.append(_.template(App.templates.SlsSetupIndexTableTemplate, {
					'products': products,
					'termLengths': termLengths,
					'indexes': this.slsData.get('indexes')
				}));
				// Initialize tooltips
				this.tooltipView = new App.views.TooltipView({
					'el': '#section-content',
					'attributes': {
						'bindEvents': this.bindTooltipEvents
					}
				});
			},

			'loadProductList': function (id) {
				var view = this;
				// Initialize drop kick for the product listing
				$('#sls-product-' + id).dropkick({
					'startSpeed': 0,
					'change': function (value, label) {
						if ($(this).hasClass('sls-product')) {
							view.changeOptionRowProduct(id, value);
						}
					}
				});
				// Load the term drop down list, will be set to "None" until product is selected
				view.loadTermList(id);
			},

			'loadTermList': function (id) {
				var view = this;
				// Get the selected product
				var productId = $('#sls-product-' + id).val();
				var q = 'sls-term-' + id;
				var $select = $('#' + q);
				// Drop kick doesn't have a functional "reset" method, so we remove and re-initialize
				$select.html('').removeData("dropkick");
				// If a product is selected, update term select options from master product data
				var prodTerms = (productId != 'none') ? view.slsData.get('products').get(productId).get('terms') : [];
				$select.html(_.template(App.templates.SlsSetupTermSelectTemplate, {
					'years': _.pluck(prodTerms, 'years').sort()
				}));
				// Drop kick doesn't have a functional "reset" method, so we remove and re-initialize
				$('#dk_container_' + q).remove();
				$select.dropkick({
					'startSpeed': 0,
					'change': function (value, label) {
						// When the term drop down list is changed, reload the index list
						view.loadIndexList(id);
						if (value != 'none') $('#dk_container_sls-term-' + id + ' .dk_toggle').removeClass('error');
					}
				});
				// Load the index drop down list, will be set to "None" until product and term is selected
				view.loadIndexList(id);
			},

			'loadIndexList': function (id) {
				var view = this;
				// Get the selected product
				var productId = $('#sls-product-' + id).val();
				// Get the selected term
				var termYears = $('#sls-term-' + id).val();
				var q = 'sls-index-' + id;
				var $select = $('#' + q);
				// Drop kick doesn't have a functional "reset" method, so we remove and re-initialize
				$select.html('').removeData("dropkick");
				// If a product and term is selected, update index select options from master product data
				var termIndexes = [];
				if (productId != 'none' && termYears != 'none') {
					var product = view.slsData.get('products').get(productId);
					var productTerms = product.get('terms');
					for (var t = 0; t < productTerms.length; t++) {
						var term = productTerms[t];
						if (term.years == termYears) {
							termIndexes = term.indexes;
							break;
						}
					}
				}
				$select.html(_.template(App.templates.SlsSetupIndexSelectTemplate, {
					'termIndexes': termIndexes,
					'allIndexes': view.slsData.get('indexes')
				}));
				// Drop kick doesn't have a functional "reset" method, so we remove and re-initialize
				$('#dk_container_' + q).remove();
				$select.dropkick({
					'startSpeed': 0,
					'change': function (value, label) {
						if (value != 'none') $('#dk_container_sls-index-' + id + ' .dk_toggle').removeClass('error');
					}
				});
			},

			'changeOptionRowProduct': function (id, productId) {
				// When the term drop down list is changed, update the protection percentage
				if (productId == 'none') {
					$('#sls-protection-' + id).html('0%');
					$('#sls-allocation-' + id).val('0%');
				} else {
					$('#dk_container_sls-product-' + id + ' .dk_toggle').removeClass('error');
					var product = this.slsData.get('products').get(productId);
					var protectionDisplay = (product.isFixed()) ? 'N/A' : product.get('protection') + '%';
					$('#sls-protection-' + id).html(protectionDisplay);
					// Only auto set to 100% if it is set to 0% currently and there is only one SLS option
					if ($(this.el).find('.sls-option').length == 1 && $('#sls-allocation-' + id).val() == '0%') $('#sls-allocation-' + id).val('100%');
				}
				// When the product drop down list is changed, reload the term list
				this.loadTermList(id);
			},

			'toggleAddOptionRowBtn': function () {
				// If we hit the limit, disable the add another button
				if ($(this.el).find('.sls-option').length < this.optionMax) $('#sls-add-another').removeClass('disabled');
				else $('#sls-add-another').removeClass('disabled').addClass('disabled');
			},

			'addOptionRow': function () {
				// If there aren't already 10 options, add a new one
				if ($(this.el).find('.sls-option').length < this.optionMax) {
					var $option = $(_.template(this.optionTemplate, {
						id: this.optionIdSeq,
						products: this.productsSelect
					}));
					$option.insertBefore($('#sls-add-another'));
					// Apply drop kick to the product select list
					this.loadProductList(this.optionIdSeq);
					// Bind option drop down change and button click events
					this.bindOptionRowEvents(this.optionIdSeq);
					// Update the element ID sequence
					this.optionIdSeq++;
					// Toggle the add another button
					this.toggleAddOptionRowBtn();
				}
				return false;
			},

			'bindTooltipEvents': function () {
				var view = this;
				$('#tooltip-content a').on('click', function () {
					view.openDisclosures($(this).html());
					return false;
				});
			},

			'openDisclosures': function (letter) {
				var modalView = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'SlsSetupDisclosuresTemplate',
					'attributes': {
						'disclosures': this.slsData.get('disclosures'),
						'indexes': this.slsData.get('indexes'),
						'letter': letter || 'A'
					}
				});
				modalView.handleModalSelection();
				var el = $('#disclosure-' + letter);
				var elA = $('#disclosure-A');
				$('#sls-disclosures ul').scrollTop(el.offset().top - elA.offset().top);
			},

			'deleteOptionRow': function (id) {
				// If there are more than 1 options, go ahead and delete
				if ($(this.el).find('.sls-option').length > 1) {
					var modalView = new App.views.ModalPopUpView({
						'el': 'body',
						'template': 'SlsSetupDeleteOptionTemplate',
						'attributes': {
							'id': id,
							'product': $('#sls-product-' + id + ' option:selected').text(),
							'protection': $('#sls-protection-' + id).html(),
							'term': $('#sls-term-' + id + ' option:selected').text(),
							'index': $('#sls-index-' + id + ' option:selected').text()
						}
					});
					modalView.handleModalSelection();
				}
				return false;
			},

			'bindOptionRowEvents': function (id) {
				var view = this;
				// Bind option delete button click
				$('#sls-delete-' + id).on('click', function () {
					view.deleteOptionRow($(this).attr('id').replace('sls-delete-', ''));
					return false;
				});
				// Bind the allocation blur
				$('#sls-allocation-' + id).on('blur', function () {
					var val = view.getAllocation(id);
					$(this).val(val + '%');
				});
				// Bind delete option handling event
				App.on('delete:sls-option-' + id, function () {
					$('#sls-option-' + id).remove();
					// Toggle the add another button
					view.toggleAddOptionRowBtn();
				});
			},

			'slsNameChange': function () {
				var $el = $('#sls-name');
				var name = $el.val();
				var remaining = 30 - name.length;
				$('#sls-name-remaining span').html(remaining);
			},

			'initialInvestmentChange': function () {
				var val = this.getInitialInvestment();
				$('#sls-investment').val(this.formatCurrency(val));
			},

			'getInitialInvestment': function () {
				var val = $('#sls-investment').val();
				val = val.replace(/[^\d\.]/g, '');
				if (val.indexOf('.') >= 0) val = val.substring(0, val.indexOf('.'));
				val = (val == '') ? 0 : parseInt(val, 10);
				return val;
			},

			'getAllocation': function (id) {
				var val = $('#sls-allocation-' + id).val();
				val = val.replace(/[^\d\.]/g, '');
				if (val.indexOf('.') >= 0) val = val.substring(0, val.indexOf('.'));
				val = (val == '') ? 0 : parseInt(val, 10);
				if (val < 0) val = 0;
				else if (val > 100) val = 100;
				return val;
			},

			'formatCurrency': function (val) {
				while (/(\d+)(\d{3})/.test(val.toString())) {
					val = val.toString().replace(/(\d+)(\d{3})/, '$1' + ',' + '$2');
				}
				return '$' + val;
			},

			'saveSlsOptions': function (e) {
				e.preventDefault();
				$('#sls-error').html('');
				$('#sls-form input').removeClass('error');
				$('#sls-form .dk_toggle').removeClass('error');
				var hasErrors = false;
				var errorMsg = '';
				var options = $(this.el).find('.sls-option');
				var initInvest = this.getInitialInvestment();
				if (initInvest <= 0 || initInvest >= 1000000000) {
					hasErrors = true;
					$('#sls-investment').addClass('error');
					errorMsg += 'The purchase payment must be greater than $0 and less than $1,000,000,000. ';
				}
				var allocationTotal = 0;
				var name = $('#sls-name').val();
				if (name === '' || name.length > 30 || /^[a-zA-Z0-9\'\.\-\ ]*$/i.test(name) === false) {
					hasErrors = true;
					$('#sls-name').addClass('error');
					errorMsg += 'The annuity name must be between 1 and 30 characters and can only contain letters, numbers, dashes, apostrophes, periods and spaces. ';
				}
				var slsOptions = new App.collections.SlsOptionCollection();
				var usedCombos = [];
				var keyError = false;
				var allocationError = false;
				var productError = false;
				var termError = false;
				var indexError = false;
				var rodb = ($('#sls-pdb').attr('checked') == 'checked') ? true : false;
				for (var x = 0; x < options.length; x++) {
					var id = $(options[x]).attr('data-id');
					var allocation = this.getAllocation(id);
					if (allocation <= 0 || allocation > 100) {
						hasErrors = true;
						$('#sls-allocation-' + id).addClass('error');
						if (allocationError === false) {
							errorMsg += 'The allocation amount for each option must be greater than 0% and less than or equal to 100%. ';
							allocationError = true;
						}
					}
					allocationTotal += allocation;
					var productId = $('#sls-product-' + id).val();
					if (productId == 'none') {
						hasErrors = true;
						$('#dk_container_sls-product-' + id + ' .dk_toggle').addClass('error');
						if (productError === false) {
							errorMsg += 'You must select a shield product for each option. ';
							productError = true;
						}
					}
					var termYears = $('#sls-term-' + id).val();
					if (termYears == 'none') {
						hasErrors = true;
						$('#dk_container_sls-term-' + id + ' .dk_toggle').addClass('error');
						if (termError === false) {
							errorMsg += 'You must select a term length for each option. ';
							termError = true;
						}
					}
					var indexId = $('#sls-index-' + id).val();
					if (indexId == 'none') {
						hasErrors = true;
						$('#dk_container_sls-index-' + id + ' .dk_toggle').addClass('error');
						if (indexError === false) {
							errorMsg += 'You must select an index for each option. ';
							indexError = true;
						}
					}
					var comboKey = productId + '|' + termYears + '|' + indexId + '|';
					if (comboKey.indexOf('none|') < 0) {
						if (usedCombos.indexOf(comboKey) >= 0) {
							hasErrors = true;
							$('#dk_container_sls-product-' + id + ' .dk_toggle').removeClass('error').addClass('error');
							$('#dk_container_sls-term-' + id + ' .dk_toggle').removeClass('error').addClass('error');
							$('#dk_container_sls-index-' + id + ' .dk_toggle').removeClass('error').addClass('error');
							if (keyError === false) {
								errorMsg += 'You can only use a given shield product, term and index once. ';
								keyError = true;
							}
						} else usedCombos.push(comboKey);
					}
					if (productId != 'none') {
						slsOptions.push(new App.models.SlsOptionModel({
							'product': productId,
							'term': termYears,
							'index': indexId,
							'allocation': allocation,
							'rate': this.slsData.get('products').get(productId).getRate(termYears, indexId, rodb)
						}));
					}
				}
				if (allocationTotal != 100) {
					hasErrors = true;
					$('#sls-form .sls-allocation').addClass('error');
					errorMsg += 'The allocation amounts must total exactly 100%. ';
				}
				if (hasErrors === false) {
					this.persistAnnuity(new App.models.SlsAnnuityModel({
						'slsName': name,
						'slsInvestment': initInvest,
						'slsRodb': rodb,
						'slsOptions': JSON.stringify(slsOptions)
					}));
				} else $('#sls-error').html(errorMsg);
			},

			'toggleIndexInfo': function () {
				$('#slsIndexInfo').slideToggle();
				$('#sls-learn-toggle').toggleClass('close');
				return false;
			},

			'persistAnnuity': function (slsAnnuity) {
				$.ajax({
					type: "POST",
					url: '/clients/sls/setup',
					data: slsAnnuity.toJSON(),
					success: function (data) {
						if (data.success === true && data.id) window.location.href = '/clients/sls/summary?id=' + data.id;
						else $('#sls-error').html('Unable to save annuity, an error occurred.');
					},
					error: function (data) {
						$('#sls-error').html('Unable to save annuity, an error occurred.');
					}
				});
			},

			'cancelForm': function (e) {
				e.preventDefault();
				window.location.href = '/clients/charts/saved';
			}

		});

});
