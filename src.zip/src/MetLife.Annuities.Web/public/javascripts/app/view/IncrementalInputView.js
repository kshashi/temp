/**
 * @module view/IncrementalInputView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .more': 'handleClickMore',
			'click .less': 'handleClickLess',
			'blur input': 'handleBlurInput'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.$input = this.$('input');

			this.render();

			log('Backbone : Global : IncrementalInputView : Initialized');
		},

		'render': function () {

			this.$el.append($(_.template(App.templates.IncrementalInputTemplate, {})));

		},

		'handleClickMore': function (e) {
			var inputVal = (isNaN(parseInt(this.$input.val(), 10))) ? 1 : parseInt(this.$input.val(), 10);

			if (this.$input.data('maxVal')) {
				if (this.$input.val() >= parseInt(this.$input.data('maxVal'), 10)) {
					return;
				}
			}

			this.$input.val(inputVal + 1);
		},

		'handleClickLess': function (e) {
			if (this.$input.val() > 1) {
				this.$input.val(this.$input.val() - 1);
			}
		},

		'handleBlurInput': function (e) {
			if (this.$input.data('maxVal')) {
				var maxVal = parseInt(this.$input.data('maxVal'), 10);
				if (this.$input.val() >= maxVal) {
					this.$input.val(maxVal);
				}
			}
		}

	});

});
