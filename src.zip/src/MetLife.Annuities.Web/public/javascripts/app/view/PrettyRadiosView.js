/**
 * @module view/PrettyRadiosView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .pretty-radio': 'handleClickRadio',
			'focus .pretty-radio': 'handleFocusRadio',
			'blur .pretty-radio': 'handleBlurRadio',
			'change input[type="radio"]': 'updateRadios'
		},

		'initialize': function (options) {

			_.bindAll(this);

			var view = this;

			this.$radios = this.$el.find('input[type="radio"]');
			this.$prettyRadios = $();

			this.$el.closest('form').on('reset', function () {
				view.resetRadios();
			});

			this.render();

			log('Backbone : View : Shared : PrettyRadiosView : Initialized');
		},

		'render': function () {
			var view = this,
				prettyRadioTemplate = _.template(App.templates.PrettyRadioTemplate, {});

			this.$radios.each(function (i) {
				var $prettyRadio = $(prettyRadioTemplate);
				$(this).after($prettyRadio);
				if (i === 0) {
					$prettyRadio.addClass('first');
				}
				if ($(this).attr('tabindex') !== '') {
					$prettyRadio.attr('tabindex', $(this).attr('tabindex'));
				}
				view.$prettyRadios = view.$prettyRadios.add($prettyRadio);
			});

			this.saveRadioDefaults();
			this.updateRadios();
		},

		'handleClickRadio': function (e) {
			e.preventDefault();

			var $target = $(e.currentTarget);

			this.toggleRadio($target);
		},

		'handleFocusRadio': function (e) {
			$(e.currentTarget).addClass('focus');

			this.$el.on('keyup.focus', this.handleKeyPress);
		},

		'handleBlurRadio': function (e) {
			$(e.currentTarget).removeClass('focus');

			this.$el.off('keyup.focus');
		},

		'handleKeyPress': function (e) {
			var $target = $(e.currentTarget);
			switch (e.keyCode) {
				case 37:
					// Left Arrow
				case 38:
					// Up Arrow
					this.togglePrev();
					return false;
					break;
				case 39:
					// Right Arrow
				case 40:
					// Down Arrow
					this.toggleNext();
					return false;
					break;
			}
		},

		'toggleRadio': function ($target) {

			var $source = this.$radios.eq(this.$prettyRadios.index($target));

			if (!$source.is(':checked')) {
				this.$prettyRadios.removeClass('checked');
				$source.attr('checked', true).change();
				$target.addClass('checked');
			}
		},

		'togglePrev': function () {
			var currentRadio = this.$('.checked'),
				index = this.$prettyRadios.index(currentRadio);

			if (index > 0) {
				this.toggleRadio(this.$prettyRadios.eq(index - 1));
			} else {
				this.toggleRadio(this.$prettyRadios.last());
			}
		},

		'toggleNext': function () {
			var currentRadio = this.$('.checked'),
				index = this.$prettyRadios.index(currentRadio);

			if (index < this.$prettyRadios.length - 1) {
				this.toggleRadio(this.$prettyRadios.eq(index + 1));
			} else {
				this.toggleRadio(this.$prettyRadios.first());
			}
		},

		'saveRadioDefaults': function () {
			this.$radios.filter(':checked').data('defaultState', 'checked');
		},

		'resetRadios': function () {
			this.$radios.each(function () {
				if ($(this).data('defaultState') === 'checked') {
					$(this).attr('checked', true).change();
				} else {
					$(this).attr('checked', false).change();
				}
			});
			this.updateRadios();
		},

		'updateRadios': function () {
			var view = this;

			this.$prettyRadios.removeClass('checked');

			this.$radios.each(function () {
				if ($(this).is(':checked')) {
					view.$prettyRadios.eq(view.$radios.index($(this))).addClass('checked');
				}
			});
		}

	});

});
