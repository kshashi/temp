/**
 * @module view/AddClientView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .form-select': 'handleFormSelect',
			'click .play-button': 'showVideo',
			'click .carousel-item .play-button': 'setSelectedVideo',
			'click .form-cancel': 'cancelForm'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.render();

			log('Backbone : Persona : Initialized');
		},

		'render': function () {

		},

		'handleFormSelect': function (e) {
			e.preventDefault();

			var view = this,
				$this = $(e.currentTarget);

			$('#section-addclient-persona').find('.selected').removeClass('selected');
			$this.addClass('selected');
			view.handleButtonText();
			$this.closest('.persona').addClass('selected');

			view.setVariableTestimonial($this);
		},
		'handleButtonText': function (e) {

			var view = this;

			view.$el.find('.form-select').text('select');
			view.$el.find('.form-select.selected').text('Selected');
		},
		'showVideo': function (e) {

			e.preventDefault();

			var view = this,
				modalView;

			modalView = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'VideoModalTemplate'
			});
		},
		'setVariableTestimonial': function ($this) {

			var view = this,
				selectedTestimonial = $this.parent().find('.thumb-wrap').html(),
				$variableTestimonial = $('.variable-testimonial');

			$variableTestimonial.find('.thumb-wrap').html(selectedTestimonial).addClass('active');
			$variableTestimonial.find('.play-button').addClass('selected');

			$variableTestimonial.find('.play-button').on('click', function (e) {
				view.showVideo(e);
			});

			view.enableInput($this);


		},
		'setSelectedVideo': function (e) {

			$('.carousel-list').find('.selected').removeClass('selected');
			$(e.currentTarget).addClass('selected');
		},
		'enableInput': function ($this) {
			var view = this;

			view.$el.find('#available-personas').find('input').attr('disabled', 'disabled');
			$this.closest('.persona').find('input').attr('disabled', false)
		},
		'cancelForm': function () {
			window.location.href = $('#back-button').attr('href');
		}
	});

});
