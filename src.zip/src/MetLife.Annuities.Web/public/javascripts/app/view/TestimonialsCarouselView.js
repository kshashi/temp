/**
 * @module view/CarouselView
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global'),
		jcarousel = require('jcarousel');

	return Backbone.View.extend({

		'events': {},

		'initialize': function (options) {

			_.bindAll(this);
			this.options = options;
			log('Backbone : View : TestimonialsCarouselView : Initialized');
		},

		'render': function () {

			var view = this;

			function mycarousel_initCallback(carousel) {
				$('.jcarousel-control li a').bind('click', function () {
					$(this).addClass('selected').parent().siblings().find('a').removeClass('selected');
					carousel.scroll($.jcarousel.intval($(this).text()));
					return false;
				});
				$('.next').bind('click', function () {
					carousel.next();
					return false;
				});
				$('.prev').bind('click', function () {
					carousel.prev();
					return false;
				});
			};


			$('#mycarousel').jcarousel({
				scroll: view.options.start,
				initCallback: mycarousel_initCallback,
				// This tells jCarousel NOT to autobuild prev/next buttons
				buttonNextHTML: null,
				buttonPrevHTML: null
			});
		}

	});

});
