/**
 * @module view/FilterView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'submit': 'handleFormSubmit',
			'blur .filter-search': 'handleFormSubmit'
		},

		'initialize': function (options) {

			_.bindAll(this);
			this.options = options;
			this.$filterCategories = this.$el.find('.filter-category');
			this.$filterItems = this.$el.find('.filter-item');
			this.$filterSearchInput = this.$('.filter-search');
			this.currentCategory = 'All';
			this.currentSearch = '';

			App.on(this.options.name + ':customSelect:change', this.filterCategory);

			this.render();
			log('Backbone : View : Shared : FilterView : Initialized');
		},

		'render': function () {
			this.$el.find('.custom-select').val(this.currentCategory);
			this.$el.find('.dk_label').text(this.currentCategory);
			this.$el.find('.dk_options_inner li').attr('class', '');
			this.$el.find('.dk_options_inner li').first().attr('class', 'dk_option_current');
			this.$el.find('.filter-search').val(this.currentSearch);
			this.filterCategory(this.currentCategory);
			this.filterSearch(this.currentSearch);
		},

		'handleFormSubmit': function (e) {
			e.preventDefault();

			var searchVal = this.$filterSearchInput.val();

			this.filterSearch(searchVal);

		},

		'filterCategory': function (label) {
			this.currentCategory = label;
			if (this.options.customFilter === true) {
				App.trigger('resources:videos:filter', this.currentCategory, this.currentSearch);
			} else {
				if (label !== 'All') {
					this.$filterCategories.removeClass('active');
					this.$filterCategories.each(function () {
						if ($(this).data('filter-category') === label) {
							$(this).addClass('active');
						}
					});
				} else {
					this.$filterCategories.addClass('active');
				}
			}
		},

		'filterSearch': function (value) {
			value = value.toLowerCase();
			this.currentSearch = value;
			if (this.options.customFilter === true) {
				App.trigger('resources:videos:filter', this.currentCategory, this.currentSearch);
			} else {
				if (value !== '') {
					this.$filterItems.removeClass('active');
					this.$filterItems.each(function () {
						var item = $(this).data('filter-item').toLowerCase();
	
						if (item.indexOf(value) >= 0) {
							$(this).addClass('active');
						} else {
							$(this).removeClass('active');
						}
					});
				} else {
					this.$filterItems.addClass('active');
				}
			}
		}

	});

});
