/**
 * @module view/ApplicationView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .form-do-not-agree': 'handleDoNotAgree',
			/*'click .download-all': 'handleDownloadAll',*/
			'click .download a': 'handleDownload',
			'click .module-sub-nav .not_visited': 'handleSubNav'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.render();

			log('Backbone : Clients : ApplicationView : Initialized');
		},

		'render': function () {

		},
		'handleDoNotAgree': function () {
			var view = this,
				modalView;

			modalView = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'DeclineModalTemplate'
			});
		},
		'handleDownloadAll': function (e) {
			e.preventDefault();

			var view = this;

			view.$el.find('.download').find('a').each(function(){
				$(this).addClass('selected');
				window.open($(this).attr('href'));
			});

		},
		'handleDownload': function (e) {

			var view = this,
				$this = $(e.currentTarget);
			$this.addClass('selected');

		},
		'handleSubNav': function (e) {

			e.preventDefault();

		}

	});

});
