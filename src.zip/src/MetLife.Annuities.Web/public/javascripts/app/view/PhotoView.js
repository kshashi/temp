/**
 * @module view/PhotoView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .image-option': 'handleImageSelection',
			'change #file-upload': 'handleUploadSubmit'
		},

		'initialize': function (options) {

			_.bindAll(this);

			App.on('upload:file', this.handleUploadSubmit)

			log('Backbone : PhotoView : Initialized');
		},

		'render': function () {

		},
		'handleImageSelection': function (e) {
			var view = this,
				$this = $(e.currentTarget),
				$parent = $this.parent();

			view.$el.find('.selected').removeClass('selected');
			$this.addClass('selected');
			view.$el.find('.image-choice').attr('disabled', true);
			$parent.find('.image-choice').attr('disabled', false);
		},
		'handleUploadSubmit': function () {

			var view = this,
				ext = view.$el.find('#file-upload').val().split('.').pop().toLowerCase();
			if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) === -1) {
				var modalPopUpView = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'InvalidFileTypeTemplate'
				});
				App.trigger('open:uploadError');
				$('#file-upload').val('');
				App.off('upload:file');
			} else {
				$('#image-upload').submit();
				view.$el.find('.selected').removeClass('selected');
				view.$el.find('#uploaded-image').addClass('selected');
			}
		}
	});

});
