/**
 * @module view/AddClientProductView
 */

define(function (require) {

    'use strict';

    var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

    return Backbone.View.extend({

        'events': {
            'click .select-product': 'handleFormSubmit',
            'hover .more': 'handleShowMoreInfo'
        },

        'initialize': function (options) {

            _.bindAll(this);

            log('Backbone : View : AddClientProductView : Initialized');
        },

        'render': function () { },

        'handleFormSubmit': function (e) {
            console.log();
            e.preventDefault();

            var view = this,
				$target = $(e.currentTarget);

            if ($('.product.shield.disabled').length > 0 && e.currentTarget.text == 'SELECT SHIELD LEVEL SELECTOR') {
                var modalView = new App.views.ModalPopUpView({
                    'el': 'body',
                    'template': 'SlsUnavailableTemplate'
                });
                modalView.handleModalSelection();
            } else {
                $target.parent().find('input').attr('disabled', false);
                view.$el.find('form').submit();
            }

        },
        'handleShowMoreInfo': function (e) {

            e.preventDefault();

            var view = this,
				$target = $(e.currentTarget);

            ///view.$el.find('.active').removeClass('active');
            $target.parent().find('.pointer').toggleClass('active');
            $target.parent().find('.more-info').toggleClass('active');

        }

    });

});
