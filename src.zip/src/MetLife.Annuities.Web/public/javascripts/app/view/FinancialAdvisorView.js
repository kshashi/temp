/**
 * @module view/FinancialAdvisorView
 */

define(function (require) {

    'use strict';

    var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

    return Backbone.View.extend({

        'events': {
            'click .page-nav': 'handlePaginationClick',
            'click #find-fa-submit': 'handleFilterSearch',
            'click .supported-firms': 'showFirmsList'
        },

        'initialize': function (options) {

            _.bindAll(this);

            this.$faContainer = $('#section-fas');
            this.faFeedTemplate = App.templates.FinancialAdvisorTemplate;
            this.$faTemplate;
            this.currentPage = 1;
            this.filterFirstName = '';
            this.filterLastName = '';
            this.filterFirmName = '';
            this.filterAdvisorId = '';
            this.filterState = '';
            this.filterMyTerritory = '';
            this.filter = 'all';
            this.sort = 'last_name';
            this.$noData = $('.no-data');
            this.$loading = $('.spinner');
            this.$paginator = $('.controls-wrapper');
            this.$filterSearchFirstName = $('#fa-first-name');
            this.$filterSearchLastName = $('#fa-last-name');
            this.$filterSearchFirmName = $('#fa-firm-name');
            this.$filterSearchAdvisorId = $('#fa-id');
            this.$filterSearchState = $('#fa-state');
            this.$filterSearchMyTerritory = $('#my-territory');
            App.on('filter-fas:customSelect:change', this.handleFilterChange);
            App.on('sort-fas:customSelect:change', this.handleSortChange);
            this.render();

            log('Backbone : View : FinancialAdvisorView : Initialized');
        },

        'render': function () {
            //this.getFeed();
            var tooltipView = new App.views.TooltipView({
                'el': '#section-content'
            });
        },

        'showFirmsList': function (e) {
            e.preventDefault();
            var firmsModal;
            $.ajax({
                type: "GET",
                url: '/rvps/advisors/firms',
                success: function (data) {

                    firmsModal = new App.views.ModalPopUpView({
                        'el': 'body',
                        'template': 'FirmsModalTemplate',
                        'attributes': {
                            'firms': data
                        }
                    });
                    firmsModal.handleModalSelection();
                },
                error: function (data) { }
            });


        },

        'handleFilterSearch': function (e) {
            e.preventDefault();
            var firstNameVal = this.$filterSearchFirstName.val(),
				lastNameVal = this.$filterSearchLastName.val(),
				firmNameVal = this.$filterSearchFirmName.val(),
				advisorIdVal = this.$filterSearchAdvisorId.val(),
				stateVal = this.$filterSearchState.val(),
				myTerritoryVal = this.$filterSearchMyTerritory.prop('checked');


            if (firstNameVal === '' && lastNameVal === '' && firmNameVal === '' && advisorIdVal === '' && stateVal === '' && !myTerritoryVal) {
                $('.search-error').remove();
                $('#form-search-fa').before('<p class="search-error">Please fill in at least one field</p>');
            } else {
                if ($('.search-error').length) {
                    $('.search-error').remove();
                }
                this.getFeed({
                    'page': 1,
                    'filter': 'all',
                    'sort': 'last_name',
                    'filterFirstName': firstNameVal,
                    'filterLastName': lastNameVal,
                    'filterFirmName': firmNameVal,
                    'filterAdvisorId': advisorIdVal,
                    'filterState': stateVal,
                    'filterMyTerritory': myTerritoryVal
                });

            }

        },

        'handleFilterChange': function (value) {
            var filter = value;
            this.getFeed({
                'page': 1,
                'filter': filter
            });
        },

        'handleSortChange': function (value) {
            var sort = value;
            this.getFeed({
                'page': 1,
                'sort': sort
            });
        },

        'handlePaginationClick': function (e) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: 0
            }, 0);
            var $target = $(e.currentTarget),
				page = $target.data('position');
            this.getFeed({
                'page': page
            });
        },

        'getFeed': function (args) {
            var view = this;

            args = args || {};

            args.filter = args.filter || view.filter;
            view.filter = args.filter;

            args.sort = args.sort || view.sort;
            view.sort = args.sort;

            args.filterFirstName = args.filterFirstName || view.filterFirstName;
            view.filterFirstName = args.filterFirstName;
            args.filterLastName = args.filterLastName || view.filterLastName;
            view.filterLastName = args.filterLastName;
            args.filterFirmName = args.filterFirmName || view.filterFirmName;
            view.filterFirmName = args.filterFirmName;
            args.filterAdvisorId = args.filterAdvisorId || view.filterAdvisorId;
            view.filterAdvisorId = args.filterAdvisorId;
            args.filterState = (args.filterState === null || args.filterState === undefined) ? view.filterState : args.filterState;
            view.filterState = args.filterState;
            args.filterMyTerritory = (args.filterMyTerritory === null || args.filterMyTerritory === undefined) ? view.filterMyTerritory : args.filterMyTerritory;
            view.filterMyTerritory = args.filterMyTerritory;

            args.page = args.page || view.currentPage;
            view.currentPage = args.page;

            view.$faContainer.empty();
            view.$noData.hide();
            view.$loading.show();

            $.ajax({
                type: "POST",
                url: '/rvps/advisors/find',
                data: args,
                success: function (data) {
                    log(data)
                    view.$loading.hide();
                    if (data.items.length == 0) {
                        view.$paginator.hide();
                        $('#section-filter').hide();
                        view.$noData.html("There were no financial advisors found.").show();
                    } else {
                        view.$faTemplate = $(_.template(view.faFeedTemplate, data));
                        view.$faContainer.html(view.$faTemplate);
                        $('.send-email-link').on('click', function (e) {
                            e.preventDefault();
                            var statusId = parseInt($(this).data('statusId'), 10);
                            var ctaLink = $(this).data('emailUrl');
                            if (statusId == 1 || statusId == 2) view.sendEmail(ctaLink);
                            else if (ctaLink.indexOf('impersonate') >= 0) window.open(ctaLink);
                            else window.location.href = ctaLink;
                        });
                        $('#section-filter').show();
                    }
                },
                error: function (data) {
                    view.$loading.hide();
                    view.$paginator.hide();
                    $('#section-filter').hide();
                    view.$noData.html("An error has occurred. Please try again.").show();
                }
            });
        },

        'sendEmail': function (url) {
            $.ajax({
                type: "POST",
                url: url,
                data: {},
                complete: function (data) {
                    $('#find-fa-submit').trigger('click');
                }
            });
        }

    });

});
