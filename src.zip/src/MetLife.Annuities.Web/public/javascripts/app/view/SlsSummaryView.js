/**
 * @module view/SlsSummaryView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .button-cta.start': 'handleSubmitApplication'
		},

		'initialize': function (options) {
			var view = this;
			_.bindAll(this);
			// Set SLS Model
			this.slsData = new App.models.SlsModel();
			this.slsAnnuity = new App.models.SlsAnnuityModel(slsAnnuity);
			this.slsOptions = this.slsAnnuity.getOptionsCollection();			
			this.render();
			self.setTimeout(function () { try { wnvPdfConverter.startConversion(); } catch (e) { } }, 1);		    
			log('Backbone : View : SlsSummaryView : Initialized');
		},

		'render': function () {
			var enableHypoView = new App.views.EnableHypoView({
				'el': '#sls-charts'
			});
			$('#shield-table').html(_.template(App.templates.SlsSummaryTableTemplate, {
				'products': this.slsData.get('products'),
				'indexes': this.slsData.get('indexes'),
				'annuity': this.slsAnnuity,
				'options': this.slsOptions
			}));			
			this.tooltipView = new App.views.TooltipView({
				'el': '#section-content',
				'attributes': {
					'bindEvents': this.bindTooltipEvents
				}
			});
		},

		'bindTooltipEvents': function () {
			var view = this;
			$('#tooltip-content a').on('click', function () {
				view.openDisclosures($(this).html());
				return false;
			});
		},

		'openDisclosures': function (letter) {
			var modalView = new App.views.ModalPopUpView({
				'el': 'body',
				'template': 'SlsSetupDisclosuresTemplate',
				'attributes': {
					'disclosures': this.slsData.get('disclosures'),
					'indexes': this.slsData.get('indexes'),
					'letter': letter || 'A'
				}
			});
			modalView.handleModalSelection();
			var el = $('#disclosure-' + letter);
			var elA = $('#disclosure-A');
			$('#sls-disclosures ul').scrollTop(el.offset().top - elA.offset().top);
		},

		'handleSubmitApplication': function (e) {

			e.preventDefault();

			var view = this;
			
			view.$el.find('#form-application-start').submit();
		}

	});

});
