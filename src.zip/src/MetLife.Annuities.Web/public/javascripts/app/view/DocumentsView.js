/**
 * @module view/DocumentsView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.View.extend({

		'events': {
			'click .print a': 'handlePrintClick'
		},

		'initialize': function (options) {

			_.bindAll(this);

			this.render();

			log('Backbone : DocumentsView : Initialized');
		},

		'render': function () {
			this.$documentsPrintContainer = $('<div/>', {
				'id': 'documents-print-container'
			}).appendTo(document.body);
		},

		'handlePrintClick': function (e) {

			// TODO: This functionality is not cross-browser compatible.
			e.preventDefault();

			var $target = $(e.currentTarget),
				href = $target.attr('href'),
				$documentsPrintTemplate = $(_.template(App.templates.DocumentsPrintTemplate, {
					'source': href
				}));

			this.$documentsPrintContainer.html($documentsPrintTemplate);

			_.delay(function () {
				$documentsPrintTemplate[0].contentWindow.print();
			}, 300);
		}
	});

});
