/**
 * @module view/SlsOptionsPartialView
 */

define(function (require) {

	'use strict';

	var $ = require('jquery'),
		_ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global')

		return Backbone.View.extend({

			'events': {
				'click #shield-in-action': 'handleChartsPopUp'
			},

			'initialize': function (options) {
				var view = this;
				_.bindAll(this);
				// Set SLS Model
				this.slsData = new App.models.SlsModel();
				this.slsAnnuity = new App.models.SlsAnnuityModel(slsAnnuity);
				this.slsOptions = this.slsAnnuity.getOptionsCollection();
				this.render();
				log('Backbone : View : SlsOptionsPartialView : Initialized');
			},

			'render': function () {
				var view = this;
				// Return of Death Benefit Applies to all options, so just render once
				var pdb = (this.slsAnnuity.get('slsRodb') === true) ? 'Yes' : 'No';
				$('#sls-pdb').html(pdb);
				// Render page title by concatenating unique product names
				$('#sls-title .product-name').html('"' + this.slsAnnuity.get('slsName') + '"');
				var productIds = this.slsOptions.getUniqueProductIds();
				for (var p = 0; p < productIds.length; p++) {
					var prefix = (p === 0) ? ' ' : (p == productIds.length - 1) ? ' &amp; ' : ', ';
					$('#sls-title .product-name').append(prefix + this.slsData.get('products').get(productIds[p]).get('name'));
				}
				// Load product drop down. If product appears more than once, use (1)....(n) for product name.
				var $prodSelect = $('#sls-product');
				$prodSelect.html(_.template(App.templates.SlsOptionsPartialProductTemplate, {
					'products': this.slsData.get('products'),
					'options': this.slsOptions,
					'prodCounts': this.slsOptions.getProductCounts()
				}));
				$prodSelect.removeData("dropkick");
				$('#dk_container_sls-product').remove();
				$prodSelect.dropkick({
					'startSpeed': 0,
					'change': function (value, label) {
						view.changeOption(value);
					}
				});
				this.tooltipView = new App.views.TooltipView({
					'el': '#section-content',
					'attributes': {
						'bindEvents': this.bindTooltipEvents
					}
				});
				view.changeOption(0);
			},

			'changeOption': function (index) {
				var view = this;
				var products = this.slsData.get('products');
				var indexes = this.slsData.get('indexes');
				var option = this.slsOptions.at(index);
				var index = indexes.get(option.get('index'));
				var product = products.get(option.get('product'));
				var isFixed = product.isFixed();
				var term = option.get('term');
				var termDisplay = (term > 1) ? term + ' Years' : term + ' Year';
				var protectionDisplay = (isFixed) ? 'N/A' : product.get('protection') + '%';
				var shieldInActionClass = (isFixed || term != 1) ? 'shield-in-action-disabled tooltip' : 'shield-in-action tooltip';
				$('#shield-in-action').attr('class', shieldInActionClass);
				$('#sls-term').html(termDisplay).attr('data-years', term);
				$('#sls-allocation').html(Math.round(option.get('allocation')) + '%');
				$('#sls-index').html(index.get('name')).attr('data-index', index.id).data('tooltip', _.template(App.templates.SlsIndexTooltipTemplate, {
					'index': index
				}));
				$('#sls-protection').html(protectionDisplay);
				if (isFixed) $('#sls-mgo-label').html('Fixed Rate');
				else if (product.get('isStepRate') === true) $('#sls-mgo-label').html('Step Rate');
				else $('#sls-mgo-label').html('Max Growth Opportunity');
				$('#sls-mgo').html(option.get('rate') + '%');
				App.trigger('change:sls-option');
			},

			'handleChartsPopUp': function (e) {
				e.preventDefault();
				if ($('#shield-in-action').hasClass('shield-in-action')) {
					var modalPopUpView;
					modalPopUpView = new App.views.ModalPopUpView({
						'el': 'body',
						'template': 'ChartsAndTablesModalTemplate'
					});
				}
			},

			'bindTooltipEvents': function () {
				var view = this;
				$('#tooltip-content a').on('click', function () {
					view.openDisclosures($(this).html());
					return false;
				});
			},

			'openDisclosures': function (letter) {
				var modalView = new App.views.ModalPopUpView({
					'el': 'body',
					'template': 'SlsSetupDisclosuresTemplate',
					'attributes': {
						'disclosures': this.slsData.get('disclosures'),
						'indexes': this.slsData.get('indexes'),
						'letter': letter || 'A'
					}
				});
				modalView.handleModalSelection();
				var el = $('#disclosure-' + letter);
				var elA = $('#disclosure-A');
				$('#sls-disclosures ul').scrollTop(el.offset().top - elA.offset().top);
			}

		});

});
