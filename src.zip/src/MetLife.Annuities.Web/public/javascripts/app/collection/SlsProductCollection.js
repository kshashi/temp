/**
 * @module collection/SlsProductCollection
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.Collection.extend({

		'initialize': function () {
			this.model = App.models.SlsProductModel;
		},
		
		'comparator': function(product) {
			var name = product.get('name').toLowerCase();
			var numeric = parseInt(name.replace(/[^0-9\.]+/g, ''));
			if(numeric !== NaN && name.indexOf('step') >= 0) numeric = numeric + 1;
			return numeric;
		}

	});

});
