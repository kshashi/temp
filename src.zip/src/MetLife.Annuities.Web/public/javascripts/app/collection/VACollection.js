/**
 * @module collection/VACollection
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.Collection.extend({

		'initialize': function () {

			this.model = App.models.VAModel;

			log('Backbone : VACollection : Initialized');

		}

	});

});
