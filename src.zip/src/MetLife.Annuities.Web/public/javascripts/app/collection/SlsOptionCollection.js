/**
 * @module collection/SlsOptionCollection
 */

define(function (require) {

	'use strict';

	var _ = require('underscore'),
		Backbone = require('backbone'),
		App = require('global');

	return Backbone.Collection.extend({

		'initialize': function () {
			this.model = App.models.SlsOptionModel;
		},

		'getUniqueProductIds': function () {
			return _.uniq(this.pluck('product'));
		},

		'getProductCounts': function () {
			var prodCount = {};
			for (var x = 0; x < this.length; x++) {
				var prodId = this.at(x).get('product');
				if (prodId in prodCount) prodCount[prodId] = prodCount[prodId] + 1;
				else prodCount[prodId] = 1;
			}
			return prodCount;
		}

	});

});
