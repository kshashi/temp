/**
 * @module index
 */

define(function (require) {

	'use strict';

	return {

		'routers': {
			'AppRouter': require('router/AppRouter'),
			'ResourcesRouter': require('router/ResourcesRouter'),
			'HelpRouter': require('router/HelpRouter')
		},

		'models': {
			'AppConfig': require('model/AppConfig'),
			'BrightcovePlaylistModel': require('model/BrightcovePlaylistModel'),
			'VAModel': require('model/VAModel'),
			'AllocationsModel': require('model/AllocationsModel'),
			'SlsModel': require('model/SlsModel'),
			'SlsIndexModel': require('model/SlsIndexModel'),
			'SlsProductModel': require('model/SlsProductModel'),
			'SlsOptionModel': require('model/SlsOptionModel'),
			'SlsAnnuityModel': require('model/SlsAnnuityModel')
		},

		'collections': {
			'VACollection': require('collection/VACollection'),
			'AllocationsCollection': require('collection/AllocationsCollection'),
			'SlsIndexCollection': require('collection/SlsIndexCollection'),
			'SlsProductCollection': require('collection/SlsProductCollection'),
			'SlsOptionCollection': require('collection/SlsOptionCollection')
		},

		'views': {
			'TestimonialsView': require('view/TestimonialsView'),
			'ResourcesView': require('view/ResourcesView'),
			'ResourcesVideoView': require('view/ResourcesVideoView'),
			'ResourcesNavView': require('view/ResourcesNavView'),
			'GlossaryView': require('view/GlossaryView'),
			'DocumentsView': require('view/DocumentsView'),
			'AccordionView': require('view/AccordionView'),
			'AppView': require('view/AppView'),
			'BrightcovePlayerView': require('view/BrightcovePlayerView'),
			'BrightcovePlaylistPlayerView': require('view/BrightcovePlaylistPlayerView'),
			'FilterView': require('view/FilterView'),
			'ResourcesVideosView': require('view/ResourcesVideosView'),
			'CarouselView': require('view/CarouselView'),
			'FormView': require('view/FormView'),
			'LoginFormView': require('view/LoginFormView'),
			'IncrementalInputView': require('view/IncrementalInputView'),
			'PrettyCheckboxesView': require('view/PrettyCheckboxesView'),
			'PrettyRadiosView': require('view/PrettyRadiosView'),
			'RadioSliderView': require('view/RadioSliderView'),
			'TooltipView': require('view/TooltipView'),
			'HiddenFormView': require('view/HiddenFormView'),
			'FeedbackTabView': require('view/FeedbackTabView'),
			'FeedbackFormView': require('view/FeedbackFormView'),
			'ActivityView': require('view/ActivityView'),
			'ClientFullView': require('view/ClientFullView'),
			'SavedAnnuityView': require('view/SavedAnnuityView'),
			'FinishHypotheticalView': require('view/FinishHypotheticalView'),
			'ApplicationView': require('view/ApplicationView'),
			'ModalPopUpView': require('view/ModalPopUpView'),
			'EnableHypoView': require('view/EnableHypoView'),
			'ChartDetailView': require('view/ChartDetailView'),
			'ProductView': require('view/ProductView'),
			'GMIBView': require('view/GMIBView'),
			'PersonaView': require('view/PersonaView'),
			'HelpNavView': require('view/HelpNavView'),
			'PhotoView': require('view/PhotoView'),
			'ClientView': require('view/ClientView'),
			'FinancialAdvisorView': require('view/FinancialAdvisorView'),
			'SlsSetupView': require('view/SlsSetupView'),
			'SlsRecommendedView': require('view/SlsRecommendedView'),
			'SlsProtectionView': require('view/SlsProtectionView'),
			'SlsParticipationView': require('view/SlsParticipationView'),
			'SlsSummaryView': require('view/SlsSummaryView'),
			'SlsOptionsPartialView': require('view/SlsOptionsPartialView'),
			'FollowUpFlagView': require('view/FollowUpFlagView'),
			'AddClientCommonView': require('view/AddClientCommonView'),
			'AddClientBasicView': require('view/AddClientBasicView'),
			'AddClientProductView': require('view/AddClientProductView'),
			'IntroView': require('view/IntroView'),
			'AdvisorEmailView': require('view/AdvisorEmailView')

		},

		'templates': {
			'BrightcovePlayerTemplate': require('plugins/text!template/BrightcovePlayerTemplate.html'),
			'BrightcovePlaylistPlayerTemplate': require('plugins/text!template/BrightcovePlaylistPlayerTemplate.html'),
			'BrightcovePlaylistVideoTemplate': require('plugins/text!template/BrightcovePlaylistVideoTemplate.html'),
			'ChapterTooltipTemplate': require('plugins/text!template/ChapterTooltipTemplate.html'),
			'FormCloneTemplate': require('plugins/text!template/FormCloneTemplate.html'),
			'TooltipTemplate': require('plugins/text!template/TooltipTemplate.html'),
			'RadioSliderTemplate': require('plugins/text!template/RadioSliderTemplate.html'),
			'PrettyRadioTemplate': require('plugins/text!template/PrettyRadioTemplate.html'),
			'PrettyCheckboxTemplate': require('plugins/text!template/PrettyCheckboxTemplate.html'),
			'CarouselThumbNavTemplate': require('plugins/text!template/CarouselThumbNavTemplate.html'),
			'CarouselNavItemTemplate': require('plugins/text!template/CarouselNavItemTemplate.html'),
			'IncrementalInputTemplate': require('plugins/text!template/IncrementalInputTemplate.html'),
			'EnableHypotheticalTemplate': require('plugins/text!template/EnableHypotheticalTemplate.html'),
			'DeclineModalTemplate': require('plugins/text!template/DeclineModalTemplate.html'),
			'AccountAccessUserTemplate': require('plugins/text!template/AccountAccessUserTemplate.html'),
			'FeedbackTabTemplate': require('plugins/text!template/FeedbackTabTemplate.html'),
			'FeedbackModalTemplate': require('plugins/text!template/FeedbackModalTemplate.html'),
			'ActivityTemplate': require('plugins/text!template/ActivityTemplate.html'),
			'MessageTemplate': require('plugins/text!template/MessageTemplate.html'),
			'ChangedAnnuityAdvisorTemplate': require('plugins/text!template/ChangedAnnuityAdvisorTemplate.html'),
			'ChangedAnnuityTemplate': require('plugins/text!template/ChangedAnnuityTemplate.html'),
			'AllocationsModalTemplate': require('plugins/text!template/AllocationsModalTemplate.html'),
			'VideoModalTemplate': require('plugins/text!template/VideoModalTemplate.html'),
			'DeleteAnnuityModalTemplate': require('plugins/text!template/DeleteAnnuityModalTemplate.html'),
			'BrightcoveSegmentTooltipTemplate': require('plugins/text!template/BrightcoveSegmentTooltipTemplate.html'),
			'InvalidFileTypeTemplate': require('plugins/text!template/InvalidFileTypeTemplate.html'),
			'DocumentsPrintTemplate': require('plugins/text!template/DocumentsPrintTemplate.html'),
			'ClientTemplate': require('plugins/text!template/ClientTemplate.html'),
			'FinancialAdvisorTemplate': require('plugins/text!template/FinancialAdvisorTemplate.html'),
			'SlsSetupOptionTemplate': require('plugins/text!template/SlsSetupOptionTemplate.html'),
			'SlsSetupDeleteOptionTemplate': require('plugins/text!template/SlsSetupDeleteOptionTemplate.html'),
			'SlsSetupDisclosuresTemplate': require('plugins/text!template/SlsSetupDisclosuresTemplate.html'),
			'SlsSetupProductSelectTemplate': require('plugins/text!template/SlsSetupProductSelectTemplate.html'),
			'SlsSetupTermSelectTemplate': require('plugins/text!template/SlsSetupTermSelectTemplate.html'),
			'SlsSetupIndexSelectTemplate': require('plugins/text!template/SlsSetupIndexSelectTemplate.html'),
			'SlsSetupIndexTableTemplate': require('plugins/text!template/SlsSetupIndexTableTemplate.html'),
			'SlsOptionsPartialProductTemplate': require('plugins/text!template/SlsOptionsPartialProductTemplate.html'),
			'SlsProtectionChartEmptyTemplate': require('plugins/text!template/SlsProtectionChartEmptyTemplate.html'),
			'SlsProtectionXAxisTemplate': require('plugins/text!template/SlsProtectionXAxisTemplate.html'),
			'SlsProtectionYAxisTemplate': require('plugins/text!template/SlsProtectionYAxisTemplate.html'),
			'SlsProtectionDataLabelTemplate': require('plugins/text!template/SlsProtectionDataLabelTemplate.html'),
			'SlsProtectionTooltipTemplate': require('plugins/text!template/SlsProtectionTooltipTemplate.html'),
			'SlsHistoricIndexTableTemplate': require('plugins/text!template/SlsHistoricIndexTableTemplate.html'),
			'SlsHistoricIndexEmptyTemplate': require('plugins/text!template/SlsHistoricIndexEmptyTemplate.html'),
			'SlsSummaryTableTemplate': require('plugins/text!template/SlsSummaryTableTemplate.html'),
			'SlsRecommendedTemplate': require('plugins/text!template/SlsRecommendedTemplate.html'),
			'SlsIndexTooltipTemplate': require('plugins/text!template/SlsIndexTooltipTemplate.html'),
			'ChartsAndTablesModalTemplate': require('plugins/text!template/ChartsAndTablesModalTemplate.html'),
			'VaDataTableTemplate': require('plugins/text!template/VaDataTableTemplate.html'),
			'FollowUpFlagTemplate': require('plugins/text!template/FollowUpFlagTemplate.html'),
			'FollowUpFlagFormTemplate': require('plugins/text!template/FollowUpFlagFormTemplate.html'),
			'FirmsModalTemplate': require('plugins/text!template/FirmsModalTemplate.html'),
			'PvaSelectTemplate': require('plugins/text!template/PvaSelectTemplate.html'),
			'VideoCarouselItemTemplate': require('plugins/text!template/VideoCarouselItemTemplate.html'),
			'SlsUnavailableTemplate': require('plugins/text!template/SlsUnavailableTemplate.html')
		}

	};

});
