using Mvc.Mailer;

namespace MetLife.Annuities.Web.Mailers
{ 
    public class UserMailer : MailerBase, IUserMailer 	
	{
		public UserMailer()
		{
			MasterName="_Layout";
		}
		
		public virtual MvcMailMessage ClientWelcome()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "ClientWelcome";
				x.ViewName = "ClientWelcome";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage HypotheticalFollowUp()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "HypotheticalFollowUp";
				x.ViewName = "HypotheticalFollowUp";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage SystemNotification()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "SystemNotification";
				x.ViewName = "SystemNotification";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage FollowUpFlagsAdded()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "FollowUpFlagsAdded";
				x.ViewName = "FollowUpFlagsAdded";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage ProductAlerts()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "ProductAlerts";
				x.ViewName = "ProductAlerts";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage ProspectusDelivery()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "ProspectusDelivery";
				x.ViewName = "ProspectusDelivery";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage ProductPromotions()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "ProductPromotions";
				x.ViewName = "ProductPromotions";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage AdvisorWelcome()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "AdvisorWelcome";
				x.ViewName = "AdvisorWelcome";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage ReEngagement()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "ReEngagement";
				x.ViewName = "ReEngagement";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage InformationRequest()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "InformationRequest";
				x.ViewName = "InformationRequest";
				x.To.Add("some-email@example.com");
			});
		}
 
		public virtual MvcMailMessage HypotheticalEnabled()
		{
			//ViewBag.Data = someObject;
			return Populate(x =>
			{
				x.Subject = "HypotheticalEnabled";
				x.ViewName = "HypotheticalEnabled";
				x.To.Add("some-email@example.com");
			});
		}
 	}
}