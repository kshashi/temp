using Mvc.Mailer;

namespace MetLife.Annuities.Web.Mailers
{ 
    public interface IUserMailer
    {
			MvcMailMessage ClientWelcome();
			MvcMailMessage HypotheticalFollowUp();
			MvcMailMessage SystemNotification();
			MvcMailMessage FollowUpFlagsAdded();
			MvcMailMessage ProductAlerts();
			MvcMailMessage ProspectusDelivery();
			MvcMailMessage ProductPromotions();
			MvcMailMessage AdvisorWelcome();
			MvcMailMessage ReEngagement();
			MvcMailMessage InformationRequest();
			MvcMailMessage HypotheticalEnabled();
	}
}