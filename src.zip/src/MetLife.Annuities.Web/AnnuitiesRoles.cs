﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetLife.Annuities.Web
{
    public class AnnuitiesRoles
    {
        public const string Client = "Client";
        public const string RVP = "RVP";
        public const string Advisor = "Advisor";
        public const string Admin = "Admin";
    }
}