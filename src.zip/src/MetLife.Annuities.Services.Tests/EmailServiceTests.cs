﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Email;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class EmailServiceTests
    {
        [TestMethod]
        public void CanSendEmailToNetworkFolder()
        {
            EmailSender sender = new EmailSender(new Models.email_template(), "to@test.com");
            sender.SendEmail(new Dictionary<string, string>(), "");

        }

        [TestMethod]
        public void CanSendInviteEmail()
        {
            EmailService service = new EmailService();
            service.SendAdvisorInvite(new Models.advisor { email = "alicialatta@gmail.com", first_name = "alicia" }, "","");

        }

    }
}
