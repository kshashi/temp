﻿using MetLife.Annuities.Services.Security;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace MetLife.Annuities.Services.Tests
{
    
    
    /// <summary>
    ///This is a test class for IBSERolesServiceTest and is intended
    ///to contain all IBSERolesServiceTest Unit Tests
    ///</summary>
	[TestClass()]
	public class IBSERolesServiceTest
	{


		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for GetRolesForUser
		///</summary>
		[TestMethod()]
		public void GetRolesForUserTest()
		{
			IBSERolesService target = new IBSERolesService(); // TODO: Initialize to an appropriate value
			string universalId = "1023107"; 
			string[] expected = new[] { "RVP" };
			string[] actual;
			actual = target.GetRolesForUser(universalId);
			Assert.AreEqual(expected[0], actual[0]);

			universalId = "mdudenhoeffer";
			expected = new[] { "Advisor" };			
			actual = target.GetRolesForUser(universalId);
			Assert.AreEqual(expected[0], actual[0]);

			//universalId = "1023107";
			//expected = new[] { "RVP" };
			//actual = target.GetRolesForUser(universalId);
			//Assert.AreEqual(expected[0], actual[0]);
		}
	}
}
