﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class TridionUXTests
    {
        string url;
        int pubId;

        [TestInitialize]
        public void Setup()
        {
            url = TridionConfiguration.TridionWebServiceUrl;
            pubId = TridionConfiguration.TridionPublicationId;
        }

        [TestMethod]
        public void UX19_20_21_22()
        {
            TridionContainer container = new TridionContainer(url, pubId);

            //var videos = container.GetComponent<advisor_tutorials>();

            //Assert.IsNotNull(videos);
            // TODO:
            /*
            var footer = container.GetComponent<advisor_footer>();
            
            Assert.IsNotNull(footer);

            var disclaimer = container.GetComponent<disclaimers>();

            Assert.IsNotNull(disclaimer);
             */
        }

        [TestMethod]
        public void UX25()
        {
            TridionContainer container = new TridionContainer(url, pubId);
            //TODO 
            /*
            var templates = container.GetComponent<email_templates>();
            
            Assert.IsNotNull(templates);
             */
        }

        [TestMethod]
        public void UX32()
        {
            TridionContainer container = new TridionContainer(url, pubId);
            // TODO:
            /*
            var intro = container.GetComponent<advisor_welcome>();

            Assert.IsNotNull(intro);
            
             * var footer = container.GetComponent<advisor_footer>();
            
            Assert.IsNotNull(footer);

            var disclaimer = container.GetComponent<disclaimers>();


             */

        }

        //[TestMethod]
        //public void UX46()
        //{
        //    TridionContainer container = new TridionContainer(url, pubId);
        //    var help = container.GetComponent<advisor_help>();

        //    Assert.IsNotNull(help);
        //}

        [TestMethod]
        public void UX52()
        {
            TridionContainer container = new TridionContainer(url, pubId);
            var types = container.GetComponent<product_types>();

            Assert.IsNotNull(types);
 
        }

        [TestMethod]
        public void UX71()
        {
            TridionContainer container = new TridionContainer(url, pubId);
            var types = container.GetComponent<product_types>();

            Assert.IsNotNull(types);             
        }

        [TestMethod]
        public void UX74()
        {
            TridionContainer container = new TridionContainer(url, pubId);
            var types = container.GetComponent<shield_configuration_data>();

            Assert.IsNotNull(types);
        }
    }
}
