﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Annuities;
using MetLife.Annuities.Services.Data;
using MetLife.Annuities.Data;
using System.IO;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class AnnuitiesTest
    {
        [TestMethod]
        public void CanParseXMLHypotheticalFromDB()
        {
            var sql = new SqlAnnuityService();
            var hyp = sql.GetHypothetical(10);
        }

        [TestMethod]
        public void CanParseXMLIllustrationFromDB()
        {
            var sql = new SqlAnnuityService();
            Illustration illustration = sql.GetHypotheticalIllustration(5);
        }


        //[TestMethod]
        //public void TranslateXml()
        //{
        //    HypotheticalTranslator translater = new HypotheticalTranslator();
        //    string xml = File.ReadAllText(@"C:\Users\mikebh\Downloads\error_illus_data.xml");
        //    translater.TranslateXml(xml);
        //}
 
    }
}
