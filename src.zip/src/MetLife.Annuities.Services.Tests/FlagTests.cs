﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Data;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class FlagTests
    {
        [TestMethod]
        public void TestMethod1()
        {
            var service = new SqlDataService();
            service.SaveFlag(1, 1,
                new Dictionary<string, string> { { "meta1", "value" },
                { "meta2", "meta" } },
                new Flag
                {
                    selected_option = "test",
                    position = new ChartPosition { x = 1, y = 1 }
                }, "delete");
        }
    }
}
