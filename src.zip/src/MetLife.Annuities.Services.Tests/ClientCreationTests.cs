﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class ClientCreationTests
    {
        IBSEUserService service = new IBSEUserService();

        [TestMethod]
        public void CanCreateClient()
        {
            CreateUserStatusDetails statusDetails;
            string username = "client2test2"; 
            string password = "metlife1";
            string firstname = "Samantha"; 
            string lastname = "Smith";
            var user = service.CreateUser(username,password,firstname,lastname, out statusDetails);
            Assert.IsTrue(statusDetails.Status == CreateUserStatus.Success);
        }
    }
}
