﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services;
using MetLife.Annuities.Services.Fulfillment;
using MetLife.Annuities.Services.Models;
using System.IO;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class SharepointTest
    {
        [TestMethod]
        public void TestGetDocument()
        {
            Fulfillment.SharePoint test = new Fulfillment.SharePoint();
            Stream item1 = test.GetDocument("appusavaak-az.pdf");
            Stream item2 = test.GetDocument("https://eforms.metlife.com/wcm8/PDFFiles/42.pdf");
            Assert.IsNotNull(item1);
        }

        [TestMethod]
        public void GetFormList()
        {
            Fulfillment.SharePoint test = new Fulfillment.SharePoint();
            form[] formList = test.GetFormList("SA6YR1", "AR", "TPD");
            string formName1 = formList.GetValue(0).ToString();
            Assert.IsTrue(formList.Length > 0);
        }

       
        /// <summary>
        ///A test for GetFile
        ///</summary>
        [TestMethod()]
        public void GetFileTest()
        {
            SharePoint target = new SharePoint(); 
            string doc_path_val = "https://int.annuities.metlife.com/public/sharepoint/assets/documents/PROKIT-NYVA.pdf";             
            Stream actual;
            actual = target.GetFile(doc_path_val);
            Assert.IsNotNull(actual);            
        }

        /// <summary>
        ///A test for GetFile
        ///</summary>
        [TestMethod()]
        public void GetFileTest1()
        {
            SharePoint target = new SharePoint(); // TODO: Initialize to an appropriate value
            string doc_path_val = string.Empty; // TODO: Initialize to an appropriate value
            Stream expected = null; // TODO: Initialize to an appropriate value
            Stream actual;
            actual = target.GetFile(doc_path_val);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
