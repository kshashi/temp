﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class ForesightSchemaTests
    {
        [TestMethod]
        public void CanDeserializeXMLSamples()
        {
            MetLife.Annuities.Services.Foresight.TXLife_Type data;
             
            string path = @"C:\Projects\US-MetLife-Annuities\src\MetLife.Annuities.Web\public\samples\Class VA 04222013.xml";

            XmlSerializer serializer = new XmlSerializer(typeof(MetLife.Annuities.Services.Foresight.TXLife_Type));

            StreamReader reader = new StreamReader(path);
            data = (MetLife.Annuities.Services.Foresight.TXLife_Type)serializer.Deserialize(reader);
            var response = data.Items[1] as MetLife.Annuities.Services.Foresight.TXLifeResponse_Type;
            if (response != null)
            {
                foreach (var item in response.IllustrationResult.ResultBasis)
                {
                    foreach (var vector in item.Vector)
                    {

                    }
                }
            }
            reader.Close();
        }


        //[TestMethod]
        //public void HypotheticalTranslatorTests()
        //{
        //    HypotheticalTranslator translator = new HypotheticalTranslator();
        //    string path = @"C:\Projects\US-MetLife-Annuities\src\MetLife.Annuities.Web\public\samples\Class VA 04222013.xml";
        //    var xml = File.ReadAllText(path);
        //    var model = translator.TranslateXml(xml);
        //}
    }
}
