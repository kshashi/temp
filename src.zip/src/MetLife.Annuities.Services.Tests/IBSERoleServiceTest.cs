﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Services.Tests
{
    /// <summary>
    /// Summary description for IBSERoleServiceTest
    /// </summary>
    [TestClass]
    public class IBSERoleServiceTest
    {
        public IBSERoleServiceTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void RemoveRolesForRVPUser()
        {
            Security.IBSERolesService test = new Security.IBSERolesService();
            test.IBSERemoveUsersToRoles(new string[] { "1023107" }, new string[] { "Advisor", "Client" });
        }

        [TestMethod]
        public void IBSERoleServiceTestMethod()
        {
            //User Registration
            //Security.IBSEUserService ser = new IBSEUserService();
            //CreateUserStatus status = new CreateUserStatus();
            //AnnuitiesUser val = ser.CreateUser("George", "xyzgeorge1", "George", "Smith", out status);
            //String[] roles;

            //Security Question
            Security.IBSERolesService test = new Security.IBSERolesService();

            //UserSecurityQuestions data1 = new UserSecurityQuestions();
            //roles = test.GetRolesForUser(val.UserID); 

            //Get Roles for a User
						string userId = "mdudenhoeffer";
            string[] roles = test.GetRolesForUser(userId);

            userId = "client1email1@gmail.com";
            roles = test.GetRolesForUser(userId);

            // Add/Remove Roles
			string[] userids = new string[] { "mdudenhoeffer" };
            string[] rolenames = new string[] { "18901" };

            test.IBSERemoveUsersToRoles(userids, rolenames);
            test.IBSEAddUsersToRoles(userids, rolenames);

            userids = new string[] {"client1email1@gmail.com" };
            rolenames = new string[] {"18902" };

            test.IBSERemoveUsersToRoles(userids, rolenames);
            test.IBSEAddUsersToRoles(userids, rolenames);
        }
    }
}
