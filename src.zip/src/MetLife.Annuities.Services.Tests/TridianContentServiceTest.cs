﻿using MetLife.Annuities.Services.Content;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Tests
{
    /// <summary>
    ///This is a test class for TridianContentServiceTest and is intended
    ///to contain all TridianContentServiceTest Unit Tests
    ///</summary>
    [TestClass()]
    public class TridianContentServiceTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion



        /// <summary>
        ///A test for GetRelatedDocuments
        ///</summary>
        [TestMethod()]
        public void GetRelatedDocumentsTest()
        {
            // TODO: Test this once Tridion is available
            TridianContentService target = new TridianContentService(); // TODO: Initialize to an appropriate value
            bool EDBMax = false; // TODO: Initialize to an appropriate value
            string planCode = "SA6YR1";
            document_item[] actual;
            actual = target.GetRelatedDocuments(EDBMax, planCode, "WA", "ID");
            Assert.IsNotNull(actual);
           
        }

        /// <summary>
        ///A test for GetProductDisclaimer
        ///</summary>
        [TestMethod()]
        public void GetProductDisclaimerTest()
        {
            TridianContentService target = new TridianContentService(); // TODO: Initialize to an appropriate value
            bool EDBMax = false; // TODO: Initialize to an appropriate value
            string planCode = string.Empty; // TODO: Initialize to an appropriate value
            disclaimer[] expected = null; // TODO: Initialize to an appropriate value
            disclaimer[] actual;
            actual = target.GetProductDisclaimer(EDBMax, planCode);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetProductDisclaimer
        ///</summary>
        [TestMethod()]
        public void GetProductDisclaimerTest1()
        {
            TridianContentService target = new TridianContentService(); // TODO: Initialize to an appropriate value
            bool EDBMax = false; // TODO: Initialize to an appropriate value
            string planCode = "ST1101";
            disclaimer[] expected = null; // TODO: Initialize to an appropriate value
            disclaimer[] actual;
            actual = target.GetProductDisclaimer(EDBMax, planCode);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        [TestMethod()]
        public void VAVideoQueueOrder()
        {
            var queue = new TridianContentService().GetVideosByCategory("_SeriesVA");
            Assert.AreEqual("Intro", queue[0].title);
            Assert.AreEqual("Annuity Basics", queue[1].title);
            Assert.AreEqual("Variable Annuities", queue[2].title);
            Assert.AreEqual("Riders", queue[3].title);
        }

        [TestMethod()]
        public void SLSVideoQueueOrder()
        {
            var queue = new TridianContentService().GetVideosByCategory("_Shield");
            Assert.AreEqual("Intro", queue[0].title);
            Assert.AreEqual("Annuity Basics", queue[1].title);
            Assert.AreEqual("Shield", queue[2].title);
            Assert.AreEqual("Outro", queue[3].title);
        }
    }
}
