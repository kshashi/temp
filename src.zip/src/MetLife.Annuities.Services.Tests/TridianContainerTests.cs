﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Models;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class TridianContainerTests
    {
        string url;
        int pubId;

        [TestInitialize]
        public void Setup()
        {
            url = TridionConfiguration.TridionWebServiceUrl;
            pubId = TridionConfiguration.TridionPublicationId;
        }
        
        //[TestMethod]
        //public void CanDeserialize_advisor_tutorials()
        //{
        //    var container = new TridionContainer(url, pubId);
        //    var item = container.GetComponent<advisor_tutorials>();
        //    Assert.IsNotNull(item);
        //}
        [TestMethod]
        public void CanDeserialize_advisor_tutorials()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<advisor_tutorials>();
            Assert.IsNotNull(item);
        }
        [TestMethod]
        public void CanDeserialize_disclaimers()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<disclaimers>();
            Assert.IsNotNull(item);
        }
        
        [TestMethod]
        public void CanDeserialize_disclosures()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<disclosures>();
            Assert.IsNotNull(item);
        }
        //[TestMethod]
        //public void CanDeserialize_featured_tutorial()
        //{
        //    var container = new TridionContainer(url, pubId);
        //    var item = container.GetComponent<featured_tutorial>();
        //    Assert.IsNotNull(item);
        //}
        [TestMethod]
        public void CanDeserialize_market_indexes()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<market_indexes>();
            Assert.IsNotNull(item);
        }

         
        //[TestMethod]
        //public void CanDeserialize_points_of_interest()
        //{
        //    var container = new TridionContainer(url, pubId);
        //    var item = container.GetComponent<points_of_interest>();
        //    Assert.IsNotNull(item);
        //}
        [TestMethod]
        public void CanDeserialize_shield_configuration_data()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<shield_configuration_data>();
            Assert.IsNotNull(item);
        }
        [TestMethod]
        public void CanDeserialize_personas()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<personas>();
            Assert.IsNotNull(item);
        }
        [TestMethod]
        public void CanDeserialize_advisor_footer()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<advisor_footer>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanDeserialize_client_footer()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<client_footer>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanDeserialize_global_config()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<global_config>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanDeserialize_email_template()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<email_templates>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanDeserialize_email_templates()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<email_templates>();
            Assert.IsNotNull(item);
        }

        //[TestMethod]
        //public void CanDeserialize_advisor_help()
        //{
        //    var container = new TridionContainer(url, pubId);
        //    var item = container.GetComponent<advisor_help>();
        //    Assert.IsNotNull(item);
        //}

        [TestMethod]
        public void CanDeserialize_products()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<products>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanDeserialize_product_types()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<product_types>();
            Assert.IsNotNull(item);
        }

        //[TestMethod]
        //public void CanDeserialize_benefit_riders()
        //{
        //    var container = new TridionContainer(url, pubId);
        //    var item = container.GetComponent<benefit_riders>();
        //    Assert.IsNotNull(item);
        //}
        
        //[TestMethod]
        //public void CanDeserialize_advisor_welcome()
        //{
        //    var container = new TridionContainer(url, pubId);
        //    var item = container.GetComponent<advisor_welcome>();
        //    Assert.IsNotNull(item);
        //}

        [TestMethod]
        public void CanDeserialize_allocations()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<allocations>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanDeserialize_resources_collection()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<resources_collection>();
            Assert.IsNotNull(item);
        }

        [TestMethod]
        public void CanReadSLSDataForProducts()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<shield_configuration_data>();
            Assert.IsNotNull(item);
        }


        [TestMethod]
        public void CanEmailTemplateUseId()
        {
            var container = new TridionContainer(url, pubId);
            var item = container.GetComponent<email_templates>()
                .Item.email_template
                .Single(g => g.id == "sendadvisorinvite");

            Assert.IsNotNull(item);
        }
    }
}
