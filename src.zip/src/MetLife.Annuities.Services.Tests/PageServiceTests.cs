﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Pages;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class PageServiceTests
    {
        [TestMethod]
        public void CanDeserizlieFooter()
        {
            TridianPageService service = new TridianPageService();
            var result = service.GetClientFooter();
        }
    }
}
