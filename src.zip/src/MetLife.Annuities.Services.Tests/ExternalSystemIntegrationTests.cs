﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetLife.Annuities.Services.Advisors;
using MetLife.Annuities.Services.RVP;
using MetLife.Annuities.Services.Security;

namespace MetLife.Annuities.Services.Tests
{
    [TestClass]
    public class ExternalSystemIntegrationTests
    {
        [TestMethod]
        public void CanConnectToMIGDatabase()
        {
            AdvisorService service = new AdvisorService();
            service.GetAdvisor("mdudenhoeffer");
        }

        [TestMethod]
        public void CanGetPlanCodes()
        {
            AdvisorService service = new AdvisorService();
            var codes = service.GetPlanCodesForAdvisor("mdudenhoeffer","WA");
        }

        [TestMethod]
        public void CanUpdateAdvisorStatus()
        {
            AdvisorService services = new AdvisorService();
            services.UpdateAdvisorStatus("mdudenhoeffer", string.Empty, AdvisorStatus.Invited);
        }

        [TestMethod]
        public void CanConnectToCashForCashDatabase()
        {
            MLIRVPService service = new MLIRVPService();
            var rvp = service.GetRVP("1023107");

        }

        [TestMethod]
        public void CanConnectToProxyServices()
        {
            IBSERolesService service = new IBSERolesService();
            var roles = service.GetRolesForUser("1023107");
        }
    }
}
