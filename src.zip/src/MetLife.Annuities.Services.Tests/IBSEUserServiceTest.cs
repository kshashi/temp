﻿using MetLife.Annuities.Services.Security;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace MetLife.Annuities.Services.Tests
{
    
    
    /// <summary>
    ///This is a test class for IBSEUserServiceTest and is intended
    ///to contain all IBSEUserServiceTest Unit Tests
    ///</summary>
	[TestClass()]
	public class IBSEUserServiceTest
	{


		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion


		/// <summary>
		///A test for GetSecurityQuestions
		///</summary>
		[TestMethod()]
		public void GetSecurityQuestionsTest()
		{
			IBSEUserService target = new IBSEUserService(); 
			List<SecurityQuestion> actual;
			actual = target.GetSecurityQuestions();
			Assert.IsTrue(actual.Count > 0);			
		}

		/// <summary>
		///A test for SetSecurityQuestions
		///</summary>
		[TestMethod()]
		public void SetSecurityQuestionsTest()
		{
			IBSEUserService target = new IBSEUserService();
            string universalId = "skylarwhitebrba@gmail.com"; 
			List<SecurityQuestion> questions = new List<SecurityQuestion>();
            questions.Add(new SecurityQuestion() { QuestionNumber = "21", QuestionAnswer = "TestAnswer1" });
            questions.Add(new SecurityQuestion() { QuestionNumber = "23", QuestionAnswer = "TestAnswer2" });
            questions.Add(new SecurityQuestion() { QuestionNumber = "25", QuestionAnswer = "TestAnswer3" });
			bool isUpdate = false;
			KeyValuePair<string, string> expected = new KeyValuePair<string, string>("0", "OK"); 
			KeyValuePair<string, string> actual;
			actual = target.SetSecurityQuestions(universalId, null, questions, isUpdate);
			Assert.AreEqual(expected, actual);			
		}

		/// <summary>
		///A test for GetUserSecurityQuestions
		///</summary>
		[TestMethod()]
		public void GetUserSecurityQuestionsTest()
		{
			IBSEUserService target = new IBSEUserService();
            string universalId = "skylarwhitebrba@gmail.com";
			string metRefId = string.Empty; 			
			List<SecurityQuestion> actual;            
            actual = target.GetUserSecurityQuestions(universalId, metRefId);
			Assert.IsTrue(actual.Count > 0);			
		}

		/// <summary>
		///A test for GetCustomerSecurityQuestions
		///</summary>
		[TestMethod()]
		public void GetCustomerSecurityQuestionsTest()
		{
			IBSEUserService target = new IBSEUserService();
			string universalId = "W8IDLTSR";
			string metRefId = string.Empty;
			List<SecurityQuestion> actual;            
			actual = target.GetUserSecurityQuestions(universalId, metRefId);
			Assert.IsTrue(actual.Count > 0);
		}

		/// <summary>
		///A test for CheckSecurityQuestionAnswer
		///</summary>
		[TestMethod()]
		public void CheckSecurityQuestionAnswerTest()
		{
			IBSEUserService target = new IBSEUserService(); 
			string universalId = "mdudenhoeffer"; 
			string metRefId = string.Empty; 
			string questionNumber = "1";
			string answer = "TestAnswer1";
			int attempts = 0; 
			int attemptsExpected = 0; 
			bool expected = true; 
			bool actual;
			actual = target.CheckSecurityQuestionAnswer(universalId, metRefId, questionNumber, answer, out attempts);
			Assert.AreEqual(attemptsExpected, attempts);
			Assert.AreEqual(expected, actual);			
		}

		/// <summary>
		///A test for CreateUser
		///</summary>
		[TestMethod()]
		public void CreateUserTest()
		{
			IBSEUserService target = new IBSEUserService();
			var chars = "ABCDEFGHIJKLMNOP545454VWXYZ0123456789";
			var random = new Random();
			var result = new string(
					Enumerable.Repeat(chars, 8)
										.Select(s => s[random.Next(s.Length)])
										.ToArray());
            result = "client1email86754546571@gmail.com";
			string username = result; 
			string password = "metlife1"; 
			string firstname = "Test";
            string lastname = "UserLastName";
			CreateUserStatusDetails statusDetails = new CreateUserStatusDetails(); 
			CreateUserStatus statusExpected = CreateUserStatus.Success; 			
			AnnuitiesUser actual;
			actual = target.CreateUser(username, password, firstname, lastname, out statusDetails);
			Assert.AreEqual(statusExpected, statusDetails.Status);
			Assert.IsTrue(actual != null);
		}

		/// <summary>
		///A test for CheckSecurityQuestionAnswer that should return false
		///</summary>
		[TestMethod()]
		public void CheckSecurityQuestionAnswerTest1()
		{
			IBSEUserService target = new IBSEUserService(); 
			string universalId = "W8IDLTSR";
			string metRefId = string.Empty; 
			string questionNumber = "22";
			string answer = "TestAnswerWrong";
			int attempts = 1; 			
			bool expected = false; 
			bool actual;
			actual = target.CheckSecurityQuestionAnswer(universalId, metRefId, questionNumber, answer, out attempts);
			Assert.IsTrue(attempts > 0);
			Assert.AreEqual(expected, actual);			
		}

		/// <summary>
		///A test for CheckSecurityQuestionAnswer should succeed
		///</summary>
		[TestMethod()]
		public void CheckSecurityQuestionAnswerTest2()
		{
			IBSEUserService target = new IBSEUserService();
			string universalId = "W8IDLTSR";
			string metRefId = string.Empty;
			string questionNumber = "22";
			string answer = "TestAnswer1";
			int attempts = 0;
			int attemptsExpected = 0;
			bool expected = true;
			bool actual;
			actual = target.CheckSecurityQuestionAnswer(universalId, metRefId, questionNumber, answer, out attempts);
			Assert.AreEqual(attemptsExpected, attempts);
			Assert.AreEqual(expected, actual);
		}

		/// <summary>
		///A test for ResetPassword
		///</summary>
		[TestMethod()]
		public void ResetPasswordTest()
		{
			IBSEUserService target = new IBSEUserService();
            string universalId = "1020195"; 
			string currentPassword = "metlife3"; 
            string newPassword = "metlife1"; 
            string statusDesc;
			bool expected = true; 
			bool actual;
			string expectedStatusDesc = string.Empty;
			string actualStatusDesc = string.Empty;
            actual = target.ResetPassword(universalId, currentPassword, newPassword, out statusDesc);
          
			Assert.AreEqual(expected, actual);			
		}

		/// <summary>
		///A test for UploadProfileImage
		///</summary>
		[TestMethod()]
		public void UploadProfileImageTest()
		{
			IBSEUserService target = new IBSEUserService(); 
			byte[] file = System.IO.File.ReadAllBytes(@"..\..\..\MetLife.Annuities.Web\public\profile_images\imagetest.jpg");
			string fileName = Guid.NewGuid().ToString() + ".jpg";
			target.UploadProfileImage(file, fileName);
			//Assert.Inconclusive("A method that does not return a value cannot be verified.");
		}

		/// <summary>
		///A test for GetProfileImage
		///</summary>
		[TestMethod()]
		public void GetProfileImageTest()
		{
			IBSEUserService target = new IBSEUserService();
			string fileName = "481426d0-76e8-405d-aadf-43738f78b38f.jpg";			
			System.Net.HttpWebResponse actual;
			actual = target.GetProfileImage(fileName);
			var s = actual.GetResponseStream();
			FileStream fs = new FileStream(Path.Combine(@"..\..\..\MetLife.Annuities.Web\public\profile_images\", "testing.jpg"), FileMode.Create);

			byte[] read = new byte[256];
			int count = s.Read(read, 0, read.Length);
			while (count > 0)
			{
				fs.Write(read, 0, count);
				count = s.Read(read, 0, read.Length);
			}			
			fs.Close();
			actual.Close();
		}
	}
}
