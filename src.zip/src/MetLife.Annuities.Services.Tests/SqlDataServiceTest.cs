﻿using MetLife.Annuities.Services.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;


namespace MetLife.Annuities.Services.Tests
{
    
    
    /// <summary>
    ///This is a test class for SqlDataServiceTest and is intended
    ///to contain all SqlDataServiceTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SqlDataServiceTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for IsDNSSEmail
        ///</summary>
        [TestMethod()]
        public void IsDNSSEmailTest()
        {
            SqlDataService target = new SqlDataService(); 
            List<string> emails = new List<string>();
            emails.Add("nodnss@email.com");
            emails.Add("000.000@000.com");
            emails.Add("000.000@000.tst");
            emails.Add("anything@metlife.com");
            emails.Add("nonesense@METLIFE.com");
            string[] dnssEmails = null;
            bool expected = true; 
            bool actual;
            actual = target.IsDNSSEmail(emails, ref dnssEmails);
            Assert.AreEqual(expected, actual);
            Assert.IsTrue(dnssEmails.Length == 2);

            emails.Clear();
            emails.Add("nodnss@email.com");
            emails.Add("A@B2.COM");
            expected = false;
            actual = target.IsDNSSEmail(emails, ref dnssEmails);
            Assert.IsTrue(dnssEmails.Length == 0);
            Assert.AreEqual(expected, actual);            
        }

        /// <summary>
        ///A test for IsDNSSEmail
        ///</summary>
        [TestMethod()]
        public void IsDNSSEmailTest1()
        {
            SqlDataService target = new SqlDataService(); 
            string email = "a@b.com";
            bool expected = false; 
            bool actual;
            actual = target.IsDNSSEmail(email);
            Assert.AreEqual(expected, actual);

            email = "a@MetLife.com";
            expected = false;            
            actual = target.IsDNSSEmail(email);
            Assert.AreEqual(expected, actual);            
        }

        /// <summary>
        ///A test for IsDNSSEmail
        ///</summary>
        [TestMethod()]
        public void IsDNSSEmailTest2()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            List<string> emails = null; // TODO: Initialize to an appropriate value
            string[] dnssEmails = null; // TODO: Initialize to an appropriate value
            string[] dnssEmailsExpected = null; // TODO: Initialize to an appropriate value
            bool expected = false; // TODO: Initialize to an appropriate value
            bool actual;
            actual = target.IsDNSSEmail(emails, ref dnssEmails);
            Assert.AreEqual(dnssEmailsExpected, dnssEmails);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetProducts
        ///</summary>
        [TestMethod()]
        public void GetProductsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            Dictionary<string, string> expected = new Dictionary<string, string>() { { "Class VA", "Class VA" }, { "MPP", "MPP" }, { "Series VA", "Series VA" }, { "SLS", "SLS" } };
            Dictionary<string, string> actual;
            actual = target.GetProducts();

            Assert.IsTrue(actual.Keys.Count == expected.Keys.Count);
            CollectionAssert.AreEquivalent(expected, actual, "Mismatch in Actual and Expected data.");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetChannels
        ///</summary>
        [TestMethod()]
        public void GetChannelsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            Dictionary<string, string> expected = new Dictionary<string, string>() { { "ID", "ID" }, { "TPD", "TPD" } };
            Dictionary<string, string> actual;
            actual = target.GetChannels();
            Assert.IsTrue(actual.Keys.Count == expected.Keys.Count);
            CollectionAssert.AreEquivalent(expected, actual, "Mismatch in Actual and Expected data.");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetDocCombined
        ///</summary>
        [TestMethod()]
        public void GetDocCombinedTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            int expectedCount = 236;
            Dictionary<string, string> actual;
            actual = target.GetDocCombined();
            Assert.IsTrue(actual.Keys.Count > 0 , "Empty Result");
            Assert.IsTrue(actual.Keys.Count == expectedCount, "Actual data count is not as expected");
            
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetActiveDocCombined
        ///</summary>
        [TestMethod()]
        public void GetActiveDocCombinedTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            int expectedCount = 220;
            Dictionary<string, string> actual;
            actual = target.GetActiveDocCombined();
            Assert.IsTrue(actual.Keys.Count > 0, "Empty Result");
            Assert.IsTrue(actual.Keys.Count == expectedCount, "Actual data count is not as expected");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetTDocDetails
        ///</summary>
        [TestMethod()]
        public void GetTDocDetailsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            Doc expected = new Doc()
            {
                DOC_CD = "11886-1-GA",
                DOC_NM = "Georgia Replacement Notice",
                DOC_DSCR = "GA disclosure given to applicant when replacement is proposed12",
                DOC_PATH_VAL = "https://eforms.metlife.com/wcm8/OIDAction.do?OID=501",
                DSTR_CD = "ID",
                DOC_RQR_IND = true,
                DOC_TYP_DSCR = "State Replacement Form1",
                DOC_PRD = "MPP",
                Active = false
            };
            Doc actual;
            string doc_cd = "11886-1-GA";
            string doc_prd = "MPP";
            string dstr_cd = "ID";
            actual = target.GetTDocDetails(doc_cd, doc_prd, dstr_cd);

            Assert.AreEqual(expected.DOC_CD, actual.DOC_CD, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_NM, actual.DOC_NM, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_DSCR, actual.DOC_DSCR, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_PATH_VAL, actual.DOC_PATH_VAL, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DSTR_CD, actual.DSTR_CD, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_RQR_IND, actual.DOC_RQR_IND, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_TYP_DSCR, actual.DOC_TYP_DSCR, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_PRD, actual.DOC_PRD, "Actual Data is not as expected.");
            Assert.AreEqual(expected.Active, actual.Active, "Actual Data is not as expected.");
            
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for UpdateDocDetails
        ///</summary>
        [TestMethod()]
        public void UpdateDocDetailsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            bool actual;
            string doc_cd = "11886-1-GA";
            string doc_prd = "MPP";
            string dstr_typ = "ID";
            Doc docs = new Doc()
            {
                DOC_CD = "11886-1-GA",
                DOC_NM = "Georgia Replacement Notice test",
                DOC_DSCR = "GA disclosure given to applicant when replacement is proposed12",
                DOC_PATH_VAL = "https://eforms.metlife.com/wcm8/OIDAction.do?OID=501",
                DSTR_CD = "ID",
                DOC_RQR_IND = true,
                DOC_TYP_DSCR = "State Replacement Form1",
                DOC_PRD = "MPP",
                Active = false,
                LST_UPDT_BY_USR_ID = "Test User",
                LST_UPDT_TS = DateTime.UtcNow
            };
            string errorMessage = "";

            try
            {
                actual = target.UpdateDocDetails(doc_cd, doc_prd, dstr_typ, docs, out errorMessage);
                Assert.IsTrue(actual, "Update Failed:- " + errorMessage);
            }
            finally
            {
                docs.DOC_NM = "Georgia Replacement Notice";
                target.UpdateDocDetails(doc_cd, doc_prd, dstr_typ, docs, out errorMessage);
            }

            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetStateDocDetails
        ///</summary>
        [TestMethod()]
        public void GetStateDocDetailsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            Doc expected = new Doc()
            {
                DOC_CD = "11886-1-IL",
                DSTR_CD = "ID",
                StateID = 2,
                DOC_Combined = "11886-1-IL - State Replacement Form - Notice Regarding Replacement of Life Insurance or Annuity",
                DOC_PRD = "MPP",
                Active = true
            };
            Doc actual;
            string doc_cd = "11886-1-IL";
            string doc_prd = "MPP";
            string dstr_cd = "ID";
            int st = 2;

            actual = target.GetStateDocDetails(doc_cd, doc_prd, dstr_cd, st);
            
            Assert.AreEqual(expected.DOC_CD, actual.DOC_CD, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DSTR_CD, actual.DSTR_CD, "Actual Data is not as expected.");
            Assert.AreEqual(expected.StateID, actual.StateID, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_Combined, actual.DOC_Combined, "Actual Data is not as expected.");
            Assert.AreEqual(expected.DOC_PRD, actual.DOC_PRD, "Actual Data is not as expected.");
            Assert.AreEqual(expected.Active, actual.Active, "Actual Data is not as expected.");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for UpdateStateDocDetails
        ///</summary>
        [TestMethod()]
        public void UpdateStateDocDetailsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            bool actual;
            Doc docs = new Doc()
            {
                DOC_CD = "11886-1-IL",
                DSTR_CD = "ID",
                StateID = 17,
                DOC_Combined = "11886-1-IL - State Replacement Form - Notice Regarding Replacement of Life Insurance or Annuity",
                DOC_PRD = "MPP",
                Active = true,
                LST_UPDT_BY_USR_ID = "Test User",
                LST_UPDT_TS = DateTime.UtcNow
            };
            string doc_cd = "11886-1-IL";
            string doc_prd = "MPP";
            string dstr_typ = "ID";
            int st = 2;
            string errorMessage = "";
            try
            {
                actual = target.UpdateStateDocDetails(doc_cd, doc_prd, dstr_typ, st, docs, out errorMessage);
                Assert.IsTrue(actual, "Update Failed:- " + errorMessage);
            }
            finally
            {
                st = docs.StateID;
                docs.StateID = 2;
                target.UpdateStateDocDetails(doc_cd, doc_prd, dstr_typ, st, docs, out errorMessage);
            }
            //Assert.Equals(actual, true);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for AddDocDetails
        ///</summary>
        [TestMethod()]
        public void AddDocDetailsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            bool actual;
            Doc docs = new Doc()
            {
                DOC_CD = "11886-1-UTC",
                DOC_NM = "Georgia Replacement Notice - added from unit test case",
                DOC_DSCR = "GA disclosure given to applicant when replacement is proposed12",
                DOC_PATH_VAL = "https://eforms.metlife.com/wcm8/OIDAction.do?OID=501",
                DSTR_CD = "ID",
                DOC_RQR_IND = true,
                DOC_TYP_DSCR = "State Replacement Form1",
                DOC_PRD = "MPP",
                Active = false,
                LST_UPDT_BY_USR_ID = "Unit Test Case",
                LST_UPDT_TS = DateTime.UtcNow,
                CRT_USR_ID = "Unit Test Case"
            };
            string errorMessage = "";
            actual = target.AddDocDetails(docs, out errorMessage);
            Assert.IsTrue(actual, "Insert Failed:- "+errorMessage);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for AddStateDocDetails
        ///</summary>
        [TestMethod()]
        public void AddStateDocDetailsTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            bool actual;
            Doc docs = new Doc()
            {
                DOC_CD = "11886-1-IL",
                DSTR_CD = "ID",
                StateID = 4,
                DOC_Combined = "11886-1-IL",
                DOC_PRD = "MPP",
                Active = true,
                CRT_USR_ID = "Unit Test Case",
                CRT_TS = DateTime.UtcNow
            };

            string errorMessage = "";
            actual = target.AddStateDocDetails(docs, out errorMessage);
            Assert.IsTrue(actual, "Insert Failed:- " + errorMessage);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CheckForStateReferenceActiveDocument
        ///</summary>
        [TestMethod()]
        public void CheckForStateReferenceActiveDocumentTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            bool expected = true;
            bool actual;
            string doc_cd = "11886-1-IL";
            string doc_prd = "MPP";
            string dstr_typ = "ID";
            string errorMessage = "";
            actual = target.CheckForStateReferenceActiveDocument(doc_cd, doc_prd, dstr_typ,  out errorMessage);
            Assert.AreEqual(actual, expected, "Actual result is not as expected.");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for CheckForActiveDocument
        ///</summary>
        [TestMethod()]
        public void CheckForActiveDocumentTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            bool expected = false;
            bool actual;
            string doc_cd = "11886-1-IL";
            string doc_prd = "MPP";
            string dstr_typ = "ID";
            string errorMessage = "";
            actual = target.CheckForActiveDocument(doc_cd, doc_prd, dstr_typ, out errorMessage);
            Assert.AreEqual(actual, expected, "Actual result is not as expected.");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for SearchDoc
        ///</summary>
        [TestMethod()]
        public void SearchDocTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            List<Doc> actual;
            string state = "";
            string channel = "";
            string product = "";
            string active = "";
            actual = target.SearchDoc(state, channel, product, active);
            Assert.IsTrue(actual.Count > 0, "Result is empty");
            
            // Searching by State
            int expectedCount = 63;
            state = "4";
            channel = "";
            product = "";
            active = "";
            actual = target.SearchDoc(state, channel, product, active);
            Assert.IsTrue(actual.Count == expectedCount, "No. of Records are not same as Expected");

            // Searching by Document
            expectedCount = 83;
            state = "";
            channel = "ID";
            product = "MPP";
            active = "true";
            actual = target.SearchDoc(state, channel, product, active);
            Assert.IsTrue(actual.Count == expectedCount, "No. of Records are not same as Expected");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for SearchStateDocMapping
        ///</summary>
        [TestMethod()]
        public void SearchStateDocMappingTest()
        {
            SqlDataService target = new SqlDataService(); // TODO: Initialize to an appropriate value
            int expectedCount = 2;
            List<Doc> actual;
            string docCode = "11886-A-KS";
            actual = target.SearchStateDocMapping(docCode);
            Assert.IsTrue(actual.Count == expectedCount, "No. of records are not as expected");
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

    }
}
