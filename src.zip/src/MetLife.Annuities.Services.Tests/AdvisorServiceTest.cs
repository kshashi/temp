﻿using MetLife.Annuities.Services.Advisors;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MetLife.Annuities.Services.Models;
using MetLife.Annuities.Services;
using System.Collections.Generic;
using MetLife.Annuities.Services.Annuities;

namespace MetLife.Annuities.Services.Tests
{


    /// <summary>
    ///This is a test class for AdvisorServiceTest and is intended
    ///to contain all AdvisorServiceTest Unit Tests
    ///</summary>
    [TestClass()]
    public class AdvisorServiceTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for GetEntitledFirms
        ///</summary>
        [TestMethod()]
        public void GetEntitledFirmsTest()
        {
            AdvisorService target = new AdvisorService(); // TODO: Initialize to an appropriate value			
            firm[] actual;
            actual = target.GetEntitledFirms();
            Assert.IsTrue(actual.Length > 0);
        }

        /// <summary>
        ///A test for UpdateAdvisorStatus
        ///</summary>
        [TestMethod()]
        public void UpdateAdvisorStatusTest()
        {
            AdvisorService target = new AdvisorService(); // TODO: Initialize to an appropriate value
            string universalId = "mmordecai"; // TODO: Initialize to an appropriate value
            //int statusId = 1; // TODO: Initialize to an appropriate value
            target.UpdateAdvisorStatus(universalId, string.Empty, AdvisorStatus.Invited);
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for FindAdvisors
        ///</summary>
        [TestMethod()]
        public void FindAdvisorsTest()
        {
            AdvisorService target = new AdvisorService(); // TODO: Initialize to an appropriate value
            string rvpId = string.Empty; // TODO: Initialize to an appropriate value
            string firstName = string.Empty; // TODO: Initialize to an appropriate value
            string lastName = string.Empty; // TODO: Initialize to an appropriate value
            string firmCode = string.Empty; // TODO: Initialize to an appropriate value
            string advisorId = string.Empty; // TODO: Initialize to an appropriate value
            string stateCode = string.Empty; // TODO: Initialize to an appropriate value
            int page = 0; // TODO: Initialize to an appropriate value
            int pageSize = 0; // TODO: Initialize to an appropriate value
            bool rvpRegionOnly = false; // TODO: Initialize to an appropriate value
            PagedList<advisor> expected = null; // TODO: Initialize to an appropriate value
            PagedList<advisor> actual;
            actual = target.FindAdvisors(rvpId, firstName, lastName, firmCode, advisorId, stateCode, page, pageSize, rvpRegionOnly, null, null);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetAdvisor
        ///</summary>
        [TestMethod()]
        public void GetAdvisorTest()
        {
            AdvisorService target = new AdvisorService(); // TODO: Initialize to an appropriate value

            advisor expected = null; // TODO: Initialize to an appropriate value
            advisor actual;

            string universalId = "mdudenhoeffer";
            actual = target.GetAdvisor(universalId);


            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetPlanCodesForAdvisor
        ///</summary>
        [TestMethod()]
        public void GetPlanCodesForAdvisorTest()
        {
            AdvisorService target = new AdvisorService();
            string universalId = "mdudenhoeffer";
                 // L231511 	
                 //L232545	
                 //L238273
               

            //string[] expected = null; 
            string[] actual;
            actual = target.GetPlanCodesForAdvisor(universalId, "WA");
            Assert.IsTrue(actual.Length > 0);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

				/// <summary>
				///A test for GetAdvisorStatusList
				///</summary>
				[TestMethod()]
				public void GetAdvisorStatusListTest()
				{
					AdvisorService target = new AdvisorService(); // TODO: Initialize to an appropriate value
					Dictionary<int, string> expected = null; // TODO: Initialize to an appropriate value
					Dictionary<int, string> actual;
					actual = target.GetAdvisorStatusList();
					Assert.AreEqual(expected, actual);
					Assert.Inconclusive("Verify the correctness of this test method.");
				}
        
                /// <summary>
                ///A test for CanSellProductType
                ///</summary>
                [TestMethod()]
                public void CanSellProductTypeTest()
                {
                    AdvisorService target = new AdvisorService(); // TODO: Initialize to an appropriate value
                    string universalId = "L231511";
                    string state = "WA";
                    AnnuityProductType type = AnnuityProductType.Variable;
                    bool actual;
                    actual = target.CanSellProductType(universalId, state,type);
                    Assert.IsNotNull(actual);
                }
        
        [TestMethod()]
        public void GetVeriableProductsTest()
        {
            AdvisorService target = new AdvisorService();
            string universalId = "mdudenhoeffer";
                 // L231511 	
                 //L232545	
                 //L238273
               

            //string[] expected = null; 
            string[] actual;
            actual = target.GetVeriableProducts(universalId, "WA");
            Assert.IsTrue(actual.Length > 0);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
